/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.sm.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description SM_CODE_CUST_HIST
 */
@XmlType(propOrder={"histDate", "custCode", "approveYn", "useYn", "custDiv", "bankDiv", "custName", "custAbbr", "custEng", "custLegalNo", "representName", "representRrn", "bizStatus", "bizType", "phone", "cellno", "fax", "zipCode", "addr1", "addr2", "compPhone", "infoYn", "sendZipCode", "sendAddr1", "sendAddr2", "sendReceiptname", "sendEmail", "bankCode", "depositNo", "depositOwner", "agentName", "agentRrn", "agentPhone", "agentCellno", "agentFax", "agentZipCode", "agentAddr1", "agentAddr2", "agentEmail", "foreignTag", "foreignNation", "companyCode", "projCode", "incomeDiv", "custGroupCode", "amYn", "tmYn", "hdYn", "mmYn", "hdPassword", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "fileName", "custDiv2", "zipCodeOrg", "addr1Org", "addr2Org", "addrTag", "agentZipCodeOrg", "agentAddr1Org", "agentAddr2Org", "agentAddrTag", "sendZipCodeOrg", "sendAddr1Org", "sendAddr2Org", "sendAddrTag", "custCode2", "triTag"}, name="DSMCodeCustHist01IO")
@XmlRootElement(name="DSMCodeCustHist01IO")
@SuppressWarnings("all")
public class DSMCodeCustHist01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -163749119L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "SM_CODE_CUST_HIST";

	/*******************************************************************************************************************************
	* Property set << histDate >> [[ */
	
	@XmlTransient
	private boolean isSet_histDate = false;
	
	protected boolean isSet_histDate()
	{
		return this.isSet_histDate;
	}
	
	protected void setIsSet_histDate(boolean value)
	{
		this.isSet_histDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0013056(C)]", formatType="", format="", align="left", length=11, decimal=0, arrayReference="", fill="")
	private java.lang.String histDate  = null;
	
	/**
	 * @Description  [SYS_C0013056(C)]
	 */
	public java.lang.String getHistDate(){
		return histDate;
	}
	
	/**
	 * @Description  [SYS_C0013056(C)]
	 */
	@JsonProperty("histDate")
	public void setHistDate( java.lang.String histDate ) {
		isSet_histDate = true;
		this.histDate = histDate;
	}
	
	/** Property set << histDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0013057(C)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description  [SYS_C0013057(C)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description  [SYS_C0013057(C)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << approveYn >> [[ */
	
	@XmlTransient
	private boolean isSet_approveYn = false;
	
	protected boolean isSet_approveYn()
	{
		return this.isSet_approveYn;
	}
	
	protected void setIsSet_approveYn(boolean value)
	{
		this.isSet_approveYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String approveYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getApproveYn(){
		return approveYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("approveYn")
	public void setApproveYn( java.lang.String approveYn ) {
		isSet_approveYn = true;
		this.approveYn = approveYn;
	}
	
	/** Property set << approveYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << useYn >> [[ */
	
	@XmlTransient
	private boolean isSet_useYn = false;
	
	protected boolean isSet_useYn()
	{
		return this.isSet_useYn;
	}
	
	protected void setIsSet_useYn(boolean value)
	{
		this.isSet_useYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String useYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getUseYn(){
		return useYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("useYn")
	public void setUseYn( java.lang.String useYn ) {
		isSet_useYn = true;
		this.useYn = useYn;
	}
	
	/** Property set << useYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custDiv >> [[ */
	
	@XmlTransient
	private boolean isSet_custDiv = false;
	
	protected boolean isSet_custDiv()
	{
		return this.isSet_custDiv;
	}
	
	protected void setIsSet_custDiv(boolean value)
	{
		this.isSet_custDiv = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String custDiv  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustDiv(){
		return custDiv;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custDiv")
	public void setCustDiv( java.lang.String custDiv ) {
		isSet_custDiv = true;
		this.custDiv = custDiv;
	}
	
	/** Property set << custDiv >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankDiv >> [[ */
	
	@XmlTransient
	private boolean isSet_bankDiv = false;
	
	protected boolean isSet_bankDiv()
	{
		return this.isSet_bankDiv;
	}
	
	protected void setIsSet_bankDiv(boolean value)
	{
		this.isSet_bankDiv = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String bankDiv  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getBankDiv(){
		return bankDiv;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("bankDiv")
	public void setBankDiv( java.lang.String bankDiv ) {
		isSet_bankDiv = true;
		this.bankDiv = bankDiv;
	}
	
	/** Property set << bankDiv >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custName >> [[ */
	
	@XmlTransient
	private boolean isSet_custName = false;
	
	protected boolean isSet_custName()
	{
		return this.isSet_custName;
	}
	
	protected void setIsSet_custName(boolean value)
	{
		this.isSet_custName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String custName  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustName(){
		return custName;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custName")
	public void setCustName( java.lang.String custName ) {
		isSet_custName = true;
		this.custName = custName;
	}
	
	/** Property set << custName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custAbbr >> [[ */
	
	@XmlTransient
	private boolean isSet_custAbbr = false;
	
	protected boolean isSet_custAbbr()
	{
		return this.isSet_custAbbr;
	}
	
	protected void setIsSet_custAbbr(boolean value)
	{
		this.isSet_custAbbr = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custAbbr  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustAbbr(){
		return custAbbr;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custAbbr")
	public void setCustAbbr( java.lang.String custAbbr ) {
		isSet_custAbbr = true;
		this.custAbbr = custAbbr;
	}
	
	/** Property set << custAbbr >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custEng >> [[ */
	
	@XmlTransient
	private boolean isSet_custEng = false;
	
	protected boolean isSet_custEng()
	{
		return this.isSet_custEng;
	}
	
	protected void setIsSet_custEng(boolean value)
	{
		this.isSet_custEng = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String custEng  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustEng(){
		return custEng;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custEng")
	public void setCustEng( java.lang.String custEng ) {
		isSet_custEng = true;
		this.custEng = custEng;
	}
	
	/** Property set << custEng >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custLegalNo >> [[ */
	
	@XmlTransient
	private boolean isSet_custLegalNo = false;
	
	protected boolean isSet_custLegalNo()
	{
		return this.isSet_custLegalNo;
	}
	
	protected void setIsSet_custLegalNo(boolean value)
	{
		this.isSet_custLegalNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custLegalNo  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustLegalNo(){
		return custLegalNo;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custLegalNo")
	public void setCustLegalNo( java.lang.String custLegalNo ) {
		isSet_custLegalNo = true;
		this.custLegalNo = custLegalNo;
	}
	
	/** Property set << custLegalNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << representName >> [[ */
	
	@XmlTransient
	private boolean isSet_representName = false;
	
	protected boolean isSet_representName()
	{
		return this.isSet_representName;
	}
	
	protected void setIsSet_representName(boolean value)
	{
		this.isSet_representName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String representName  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRepresentName(){
		return representName;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("representName")
	public void setRepresentName( java.lang.String representName ) {
		isSet_representName = true;
		this.representName = representName;
	}
	
	/** Property set << representName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << representRrn >> [[ */
	
	@XmlTransient
	private boolean isSet_representRrn = false;
	
	protected boolean isSet_representRrn()
	{
		return this.isSet_representRrn;
	}
	
	protected void setIsSet_representRrn(boolean value)
	{
		this.isSet_representRrn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=13, decimal=0, arrayReference="", fill="")
	private java.lang.String representRrn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRepresentRrn(){
		return representRrn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("representRrn")
	public void setRepresentRrn( java.lang.String representRrn ) {
		isSet_representRrn = true;
		this.representRrn = representRrn;
	}
	
	/** Property set << representRrn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bizStatus >> [[ */
	
	@XmlTransient
	private boolean isSet_bizStatus = false;
	
	protected boolean isSet_bizStatus()
	{
		return this.isSet_bizStatus;
	}
	
	protected void setIsSet_bizStatus(boolean value)
	{
		this.isSet_bizStatus = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String bizStatus  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getBizStatus(){
		return bizStatus;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("bizStatus")
	public void setBizStatus( java.lang.String bizStatus ) {
		isSet_bizStatus = true;
		this.bizStatus = bizStatus;
	}
	
	/** Property set << bizStatus >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bizType >> [[ */
	
	@XmlTransient
	private boolean isSet_bizType = false;
	
	protected boolean isSet_bizType()
	{
		return this.isSet_bizType;
	}
	
	protected void setIsSet_bizType(boolean value)
	{
		this.isSet_bizType = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String bizType  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getBizType(){
		return bizType;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("bizType")
	public void setBizType( java.lang.String bizType ) {
		isSet_bizType = true;
		this.bizType = bizType;
	}
	
	/** Property set << bizType >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << phone >> [[ */
	
	@XmlTransient
	private boolean isSet_phone = false;
	
	protected boolean isSet_phone()
	{
		return this.isSet_phone;
	}
	
	protected void setIsSet_phone(boolean value)
	{
		this.isSet_phone = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String phone  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getPhone(){
		return phone;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("phone")
	public void setPhone( java.lang.String phone ) {
		isSet_phone = true;
		this.phone = phone;
	}
	
	/** Property set << phone >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cellno >> [[ */
	
	@XmlTransient
	private boolean isSet_cellno = false;
	
	protected boolean isSet_cellno()
	{
		return this.isSet_cellno;
	}
	
	protected void setIsSet_cellno(boolean value)
	{
		this.isSet_cellno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String cellno  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCellno(){
		return cellno;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("cellno")
	public void setCellno( java.lang.String cellno ) {
		isSet_cellno = true;
		this.cellno = cellno;
	}
	
	/** Property set << cellno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fax >> [[ */
	
	@XmlTransient
	private boolean isSet_fax = false;
	
	protected boolean isSet_fax()
	{
		return this.isSet_fax;
	}
	
	protected void setIsSet_fax(boolean value)
	{
		this.isSet_fax = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String fax  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getFax(){
		return fax;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("fax")
	public void setFax( java.lang.String fax ) {
		isSet_fax = true;
		this.fax = fax;
	}
	
	/** Property set << fax >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << zipCode >> [[ */
	
	@XmlTransient
	private boolean isSet_zipCode = false;
	
	protected boolean isSet_zipCode()
	{
		return this.isSet_zipCode;
	}
	
	protected void setIsSet_zipCode(boolean value)
	{
		this.isSet_zipCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String zipCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getZipCode(){
		return zipCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("zipCode")
	public void setZipCode( java.lang.String zipCode ) {
		isSet_zipCode = true;
		this.zipCode = zipCode;
	}
	
	/** Property set << zipCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr1 = false;
	
	protected boolean isSet_addr1()
	{
		return this.isSet_addr1;
	}
	
	protected void setIsSet_addr1(boolean value)
	{
		this.isSet_addr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr1  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAddr1(){
		return addr1;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("addr1")
	public void setAddr1( java.lang.String addr1 ) {
		isSet_addr1 = true;
		this.addr1 = addr1;
	}
	
	/** Property set << addr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2 = false;
	
	protected boolean isSet_addr2()
	{
		return this.isSet_addr2;
	}
	
	protected void setIsSet_addr2(boolean value)
	{
		this.isSet_addr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAddr2(){
		return addr2;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("addr2")
	public void setAddr2( java.lang.String addr2 ) {
		isSet_addr2 = true;
		this.addr2 = addr2;
	}
	
	/** Property set << addr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << compPhone >> [[ */
	
	@XmlTransient
	private boolean isSet_compPhone = false;
	
	protected boolean isSet_compPhone()
	{
		return this.isSet_compPhone;
	}
	
	protected void setIsSet_compPhone(boolean value)
	{
		this.isSet_compPhone = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String compPhone  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCompPhone(){
		return compPhone;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("compPhone")
	public void setCompPhone( java.lang.String compPhone ) {
		isSet_compPhone = true;
		this.compPhone = compPhone;
	}
	
	/** Property set << compPhone >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << infoYn >> [[ */
	
	@XmlTransient
	private boolean isSet_infoYn = false;
	
	protected boolean isSet_infoYn()
	{
		return this.isSet_infoYn;
	}
	
	protected void setIsSet_infoYn(boolean value)
	{
		this.isSet_infoYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String infoYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInfoYn(){
		return infoYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("infoYn")
	public void setInfoYn( java.lang.String infoYn ) {
		isSet_infoYn = true;
		this.infoYn = infoYn;
	}
	
	/** Property set << infoYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendZipCode >> [[ */
	
	@XmlTransient
	private boolean isSet_sendZipCode = false;
	
	protected boolean isSet_sendZipCode()
	{
		return this.isSet_sendZipCode;
	}
	
	protected void setIsSet_sendZipCode(boolean value)
	{
		this.isSet_sendZipCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String sendZipCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendZipCode(){
		return sendZipCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendZipCode")
	public void setSendZipCode( java.lang.String sendZipCode ) {
		isSet_sendZipCode = true;
		this.sendZipCode = sendZipCode;
	}
	
	/** Property set << sendZipCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendAddr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_sendAddr1 = false;
	
	protected boolean isSet_sendAddr1()
	{
		return this.isSet_sendAddr1;
	}
	
	protected void setIsSet_sendAddr1(boolean value)
	{
		this.isSet_sendAddr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String sendAddr1  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendAddr1(){
		return sendAddr1;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendAddr1")
	public void setSendAddr1( java.lang.String sendAddr1 ) {
		isSet_sendAddr1 = true;
		this.sendAddr1 = sendAddr1;
	}
	
	/** Property set << sendAddr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendAddr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_sendAddr2 = false;
	
	protected boolean isSet_sendAddr2()
	{
		return this.isSet_sendAddr2;
	}
	
	protected void setIsSet_sendAddr2(boolean value)
	{
		this.isSet_sendAddr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String sendAddr2  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendAddr2(){
		return sendAddr2;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendAddr2")
	public void setSendAddr2( java.lang.String sendAddr2 ) {
		isSet_sendAddr2 = true;
		this.sendAddr2 = sendAddr2;
	}
	
	/** Property set << sendAddr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendReceiptname >> [[ */
	
	@XmlTransient
	private boolean isSet_sendReceiptname = false;
	
	protected boolean isSet_sendReceiptname()
	{
		return this.isSet_sendReceiptname;
	}
	
	protected void setIsSet_sendReceiptname(boolean value)
	{
		this.isSet_sendReceiptname = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sendReceiptname  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendReceiptname(){
		return sendReceiptname;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendReceiptname")
	public void setSendReceiptname( java.lang.String sendReceiptname ) {
		isSet_sendReceiptname = true;
		this.sendReceiptname = sendReceiptname;
	}
	
	/** Property set << sendReceiptname >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendEmail >> [[ */
	
	@XmlTransient
	private boolean isSet_sendEmail = false;
	
	protected boolean isSet_sendEmail()
	{
		return this.isSet_sendEmail;
	}
	
	protected void setIsSet_sendEmail(boolean value)
	{
		this.isSet_sendEmail = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String sendEmail  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendEmail(){
		return sendEmail;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendEmail")
	public void setSendEmail( java.lang.String sendEmail ) {
		isSet_sendEmail = true;
		this.sendEmail = sendEmail;
	}
	
	/** Property set << sendEmail >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankCode = false;
	
	protected boolean isSet_bankCode()
	{
		return this.isSet_bankCode;
	}
	
	protected void setIsSet_bankCode(boolean value)
	{
		this.isSet_bankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String bankCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getBankCode(){
		return bankCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("bankCode")
	public void setBankCode( java.lang.String bankCode ) {
		isSet_bankCode = true;
		this.bankCode = bankCode;
	}
	
	/** Property set << bankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositOwner >> [[ */
	
	@XmlTransient
	private boolean isSet_depositOwner = false;
	
	protected boolean isSet_depositOwner()
	{
		return this.isSet_depositOwner;
	}
	
	protected void setIsSet_depositOwner(boolean value)
	{
		this.isSet_depositOwner = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=60, decimal=0, arrayReference="", fill="")
	private java.lang.String depositOwner  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getDepositOwner(){
		return depositOwner;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("depositOwner")
	public void setDepositOwner( java.lang.String depositOwner ) {
		isSet_depositOwner = true;
		this.depositOwner = depositOwner;
	}
	
	/** Property set << depositOwner >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentName >> [[ */
	
	@XmlTransient
	private boolean isSet_agentName = false;
	
	protected boolean isSet_agentName()
	{
		return this.isSet_agentName;
	}
	
	protected void setIsSet_agentName(boolean value)
	{
		this.isSet_agentName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String agentName  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentName(){
		return agentName;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentName")
	public void setAgentName( java.lang.String agentName ) {
		isSet_agentName = true;
		this.agentName = agentName;
	}
	
	/** Property set << agentName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentRrn >> [[ */
	
	@XmlTransient
	private boolean isSet_agentRrn = false;
	
	protected boolean isSet_agentRrn()
	{
		return this.isSet_agentRrn;
	}
	
	protected void setIsSet_agentRrn(boolean value)
	{
		this.isSet_agentRrn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=13, decimal=0, arrayReference="", fill="")
	private java.lang.String agentRrn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentRrn(){
		return agentRrn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentRrn")
	public void setAgentRrn( java.lang.String agentRrn ) {
		isSet_agentRrn = true;
		this.agentRrn = agentRrn;
	}
	
	/** Property set << agentRrn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentPhone >> [[ */
	
	@XmlTransient
	private boolean isSet_agentPhone = false;
	
	protected boolean isSet_agentPhone()
	{
		return this.isSet_agentPhone;
	}
	
	protected void setIsSet_agentPhone(boolean value)
	{
		this.isSet_agentPhone = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String agentPhone  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentPhone(){
		return agentPhone;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentPhone")
	public void setAgentPhone( java.lang.String agentPhone ) {
		isSet_agentPhone = true;
		this.agentPhone = agentPhone;
	}
	
	/** Property set << agentPhone >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentCellno >> [[ */
	
	@XmlTransient
	private boolean isSet_agentCellno = false;
	
	protected boolean isSet_agentCellno()
	{
		return this.isSet_agentCellno;
	}
	
	protected void setIsSet_agentCellno(boolean value)
	{
		this.isSet_agentCellno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String agentCellno  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentCellno(){
		return agentCellno;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentCellno")
	public void setAgentCellno( java.lang.String agentCellno ) {
		isSet_agentCellno = true;
		this.agentCellno = agentCellno;
	}
	
	/** Property set << agentCellno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentFax >> [[ */
	
	@XmlTransient
	private boolean isSet_agentFax = false;
	
	protected boolean isSet_agentFax()
	{
		return this.isSet_agentFax;
	}
	
	protected void setIsSet_agentFax(boolean value)
	{
		this.isSet_agentFax = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String agentFax  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentFax(){
		return agentFax;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentFax")
	public void setAgentFax( java.lang.String agentFax ) {
		isSet_agentFax = true;
		this.agentFax = agentFax;
	}
	
	/** Property set << agentFax >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentZipCode >> [[ */
	
	@XmlTransient
	private boolean isSet_agentZipCode = false;
	
	protected boolean isSet_agentZipCode()
	{
		return this.isSet_agentZipCode;
	}
	
	protected void setIsSet_agentZipCode(boolean value)
	{
		this.isSet_agentZipCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String agentZipCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentZipCode(){
		return agentZipCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentZipCode")
	public void setAgentZipCode( java.lang.String agentZipCode ) {
		isSet_agentZipCode = true;
		this.agentZipCode = agentZipCode;
	}
	
	/** Property set << agentZipCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentAddr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_agentAddr1 = false;
	
	protected boolean isSet_agentAddr1()
	{
		return this.isSet_agentAddr1;
	}
	
	protected void setIsSet_agentAddr1(boolean value)
	{
		this.isSet_agentAddr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String agentAddr1  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentAddr1(){
		return agentAddr1;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentAddr1")
	public void setAgentAddr1( java.lang.String agentAddr1 ) {
		isSet_agentAddr1 = true;
		this.agentAddr1 = agentAddr1;
	}
	
	/** Property set << agentAddr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentAddr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_agentAddr2 = false;
	
	protected boolean isSet_agentAddr2()
	{
		return this.isSet_agentAddr2;
	}
	
	protected void setIsSet_agentAddr2(boolean value)
	{
		this.isSet_agentAddr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String agentAddr2  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentAddr2(){
		return agentAddr2;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentAddr2")
	public void setAgentAddr2( java.lang.String agentAddr2 ) {
		isSet_agentAddr2 = true;
		this.agentAddr2 = agentAddr2;
	}
	
	/** Property set << agentAddr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentEmail >> [[ */
	
	@XmlTransient
	private boolean isSet_agentEmail = false;
	
	protected boolean isSet_agentEmail()
	{
		return this.isSet_agentEmail;
	}
	
	protected void setIsSet_agentEmail(boolean value)
	{
		this.isSet_agentEmail = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String agentEmail  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentEmail(){
		return agentEmail;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentEmail")
	public void setAgentEmail( java.lang.String agentEmail ) {
		isSet_agentEmail = true;
		this.agentEmail = agentEmail;
	}
	
	/** Property set << agentEmail >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << foreignTag >> [[ */
	
	@XmlTransient
	private boolean isSet_foreignTag = false;
	
	protected boolean isSet_foreignTag()
	{
		return this.isSet_foreignTag;
	}
	
	protected void setIsSet_foreignTag(boolean value)
	{
		this.isSet_foreignTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String foreignTag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getForeignTag(){
		return foreignTag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("foreignTag")
	public void setForeignTag( java.lang.String foreignTag ) {
		isSet_foreignTag = true;
		this.foreignTag = foreignTag;
	}
	
	/** Property set << foreignTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << foreignNation >> [[ */
	
	@XmlTransient
	private boolean isSet_foreignNation = false;
	
	protected boolean isSet_foreignNation()
	{
		return this.isSet_foreignNation;
	}
	
	protected void setIsSet_foreignNation(boolean value)
	{
		this.isSet_foreignNation = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String foreignNation  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getForeignNation(){
		return foreignNation;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("foreignNation")
	public void setForeignNation( java.lang.String foreignNation ) {
		isSet_foreignNation = true;
		this.foreignNation = foreignNation;
	}
	
	/** Property set << foreignNation >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << companyCode >> [[ */
	
	@XmlTransient
	private boolean isSet_companyCode = false;
	
	protected boolean isSet_companyCode()
	{
		return this.isSet_companyCode;
	}
	
	protected void setIsSet_companyCode(boolean value)
	{
		this.isSet_companyCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String companyCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCompanyCode(){
		return companyCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("companyCode")
	public void setCompanyCode( java.lang.String companyCode ) {
		isSet_companyCode = true;
		this.companyCode = companyCode;
	}
	
	/** Property set << companyCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << projCode >> [[ */
	
	@XmlTransient
	private boolean isSet_projCode = false;
	
	protected boolean isSet_projCode()
	{
		return this.isSet_projCode;
	}
	
	protected void setIsSet_projCode(boolean value)
	{
		this.isSet_projCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String projCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getProjCode(){
		return projCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("projCode")
	public void setProjCode( java.lang.String projCode ) {
		isSet_projCode = true;
		this.projCode = projCode;
	}
	
	/** Property set << projCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << incomeDiv >> [[ */
	
	@XmlTransient
	private boolean isSet_incomeDiv = false;
	
	protected boolean isSet_incomeDiv()
	{
		return this.isSet_incomeDiv;
	}
	
	protected void setIsSet_incomeDiv(boolean value)
	{
		this.isSet_incomeDiv = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String incomeDiv  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getIncomeDiv(){
		return incomeDiv;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("incomeDiv")
	public void setIncomeDiv( java.lang.String incomeDiv ) {
		isSet_incomeDiv = true;
		this.incomeDiv = incomeDiv;
	}
	
	/** Property set << incomeDiv >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custGroupCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custGroupCode = false;
	
	protected boolean isSet_custGroupCode()
	{
		return this.isSet_custGroupCode;
	}
	
	protected void setIsSet_custGroupCode(boolean value)
	{
		this.isSet_custGroupCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custGroupCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustGroupCode(){
		return custGroupCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custGroupCode")
	public void setCustGroupCode( java.lang.String custGroupCode ) {
		isSet_custGroupCode = true;
		this.custGroupCode = custGroupCode;
	}
	
	/** Property set << custGroupCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amYn >> [[ */
	
	@XmlTransient
	private boolean isSet_amYn = false;
	
	protected boolean isSet_amYn()
	{
		return this.isSet_amYn;
	}
	
	protected void setIsSet_amYn(boolean value)
	{
		this.isSet_amYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String amYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAmYn(){
		return amYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("amYn")
	public void setAmYn( java.lang.String amYn ) {
		isSet_amYn = true;
		this.amYn = amYn;
	}
	
	/** Property set << amYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << tmYn >> [[ */
	
	@XmlTransient
	private boolean isSet_tmYn = false;
	
	protected boolean isSet_tmYn()
	{
		return this.isSet_tmYn;
	}
	
	protected void setIsSet_tmYn(boolean value)
	{
		this.isSet_tmYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String tmYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getTmYn(){
		return tmYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("tmYn")
	public void setTmYn( java.lang.String tmYn ) {
		isSet_tmYn = true;
		this.tmYn = tmYn;
	}
	
	/** Property set << tmYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << hdYn >> [[ */
	
	@XmlTransient
	private boolean isSet_hdYn = false;
	
	protected boolean isSet_hdYn()
	{
		return this.isSet_hdYn;
	}
	
	protected void setIsSet_hdYn(boolean value)
	{
		this.isSet_hdYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String hdYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getHdYn(){
		return hdYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("hdYn")
	public void setHdYn( java.lang.String hdYn ) {
		isSet_hdYn = true;
		this.hdYn = hdYn;
	}
	
	/** Property set << hdYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << mmYn >> [[ */
	
	@XmlTransient
	private boolean isSet_mmYn = false;
	
	protected boolean isSet_mmYn()
	{
		return this.isSet_mmYn;
	}
	
	protected void setIsSet_mmYn(boolean value)
	{
		this.isSet_mmYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String mmYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getMmYn(){
		return mmYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("mmYn")
	public void setMmYn( java.lang.String mmYn ) {
		isSet_mmYn = true;
		this.mmYn = mmYn;
	}
	
	/** Property set << mmYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << hdPassword >> [[ */
	
	@XmlTransient
	private boolean isSet_hdPassword = false;
	
	protected boolean isSet_hdPassword()
	{
		return this.isSet_hdPassword;
	}
	
	protected void setIsSet_hdPassword(boolean value)
	{
		this.isSet_hdPassword = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String hdPassword  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getHdPassword(){
		return hdPassword;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("hdPassword")
	public void setHdPassword( java.lang.String hdPassword ) {
		isSet_hdPassword = true;
		this.hdPassword = hdPassword;
	}
	
	/** Property set << hdPassword >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fileName >> [[ */
	
	@XmlTransient
	private boolean isSet_fileName = false;
	
	protected boolean isSet_fileName()
	{
		return this.isSet_fileName;
	}
	
	protected void setIsSet_fileName(boolean value)
	{
		this.isSet_fileName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String fileName  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getFileName(){
		return fileName;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("fileName")
	public void setFileName( java.lang.String fileName ) {
		isSet_fileName = true;
		this.fileName = fileName;
	}
	
	/** Property set << fileName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custDiv2 >> [[ */
	
	@XmlTransient
	private boolean isSet_custDiv2 = false;
	
	protected boolean isSet_custDiv2()
	{
		return this.isSet_custDiv2;
	}
	
	protected void setIsSet_custDiv2(boolean value)
	{
		this.isSet_custDiv2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String custDiv2  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustDiv2(){
		return custDiv2;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custDiv2")
	public void setCustDiv2( java.lang.String custDiv2 ) {
		isSet_custDiv2 = true;
		this.custDiv2 = custDiv2;
	}
	
	/** Property set << custDiv2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << zipCodeOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_zipCodeOrg = false;
	
	protected boolean isSet_zipCodeOrg()
	{
		return this.isSet_zipCodeOrg;
	}
	
	protected void setIsSet_zipCodeOrg(boolean value)
	{
		this.isSet_zipCodeOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String zipCodeOrg  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getZipCodeOrg(){
		return zipCodeOrg;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("zipCodeOrg")
	public void setZipCodeOrg( java.lang.String zipCodeOrg ) {
		isSet_zipCodeOrg = true;
		this.zipCodeOrg = zipCodeOrg;
	}
	
	/** Property set << zipCodeOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_addr1Org = false;
	
	protected boolean isSet_addr1Org()
	{
		return this.isSet_addr1Org;
	}
	
	protected void setIsSet_addr1Org(boolean value)
	{
		this.isSet_addr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr1Org  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAddr1Org(){
		return addr1Org;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("addr1Org")
	public void setAddr1Org( java.lang.String addr1Org ) {
		isSet_addr1Org = true;
		this.addr1Org = addr1Org;
	}
	
	/** Property set << addr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2Org = false;
	
	protected boolean isSet_addr2Org()
	{
		return this.isSet_addr2Org;
	}
	
	protected void setIsSet_addr2Org(boolean value)
	{
		this.isSet_addr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2Org  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAddr2Org(){
		return addr2Org;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("addr2Org")
	public void setAddr2Org( java.lang.String addr2Org ) {
		isSet_addr2Org = true;
		this.addr2Org = addr2Org;
	}
	
	/** Property set << addr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_addrTag = false;
	
	protected boolean isSet_addrTag()
	{
		return this.isSet_addrTag;
	}
	
	protected void setIsSet_addrTag(boolean value)
	{
		this.isSet_addrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String addrTag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAddrTag(){
		return addrTag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("addrTag")
	public void setAddrTag( java.lang.String addrTag ) {
		isSet_addrTag = true;
		this.addrTag = addrTag;
	}
	
	/** Property set << addrTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentZipCodeOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_agentZipCodeOrg = false;
	
	protected boolean isSet_agentZipCodeOrg()
	{
		return this.isSet_agentZipCodeOrg;
	}
	
	protected void setIsSet_agentZipCodeOrg(boolean value)
	{
		this.isSet_agentZipCodeOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String agentZipCodeOrg  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentZipCodeOrg(){
		return agentZipCodeOrg;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentZipCodeOrg")
	public void setAgentZipCodeOrg( java.lang.String agentZipCodeOrg ) {
		isSet_agentZipCodeOrg = true;
		this.agentZipCodeOrg = agentZipCodeOrg;
	}
	
	/** Property set << agentZipCodeOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentAddr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_agentAddr1Org = false;
	
	protected boolean isSet_agentAddr1Org()
	{
		return this.isSet_agentAddr1Org;
	}
	
	protected void setIsSet_agentAddr1Org(boolean value)
	{
		this.isSet_agentAddr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String agentAddr1Org  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentAddr1Org(){
		return agentAddr1Org;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentAddr1Org")
	public void setAgentAddr1Org( java.lang.String agentAddr1Org ) {
		isSet_agentAddr1Org = true;
		this.agentAddr1Org = agentAddr1Org;
	}
	
	/** Property set << agentAddr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentAddr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_agentAddr2Org = false;
	
	protected boolean isSet_agentAddr2Org()
	{
		return this.isSet_agentAddr2Org;
	}
	
	protected void setIsSet_agentAddr2Org(boolean value)
	{
		this.isSet_agentAddr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String agentAddr2Org  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentAddr2Org(){
		return agentAddr2Org;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentAddr2Org")
	public void setAgentAddr2Org( java.lang.String agentAddr2Org ) {
		isSet_agentAddr2Org = true;
		this.agentAddr2Org = agentAddr2Org;
	}
	
	/** Property set << agentAddr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agentAddrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_agentAddrTag = false;
	
	protected boolean isSet_agentAddrTag()
	{
		return this.isSet_agentAddrTag;
	}
	
	protected void setIsSet_agentAddrTag(boolean value)
	{
		this.isSet_agentAddrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String agentAddrTag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getAgentAddrTag(){
		return agentAddrTag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("agentAddrTag")
	public void setAgentAddrTag( java.lang.String agentAddrTag ) {
		isSet_agentAddrTag = true;
		this.agentAddrTag = agentAddrTag;
	}
	
	/** Property set << agentAddrTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendZipCodeOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_sendZipCodeOrg = false;
	
	protected boolean isSet_sendZipCodeOrg()
	{
		return this.isSet_sendZipCodeOrg;
	}
	
	protected void setIsSet_sendZipCodeOrg(boolean value)
	{
		this.isSet_sendZipCodeOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String sendZipCodeOrg  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendZipCodeOrg(){
		return sendZipCodeOrg;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendZipCodeOrg")
	public void setSendZipCodeOrg( java.lang.String sendZipCodeOrg ) {
		isSet_sendZipCodeOrg = true;
		this.sendZipCodeOrg = sendZipCodeOrg;
	}
	
	/** Property set << sendZipCodeOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendAddr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_sendAddr1Org = false;
	
	protected boolean isSet_sendAddr1Org()
	{
		return this.isSet_sendAddr1Org;
	}
	
	protected void setIsSet_sendAddr1Org(boolean value)
	{
		this.isSet_sendAddr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String sendAddr1Org  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendAddr1Org(){
		return sendAddr1Org;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendAddr1Org")
	public void setSendAddr1Org( java.lang.String sendAddr1Org ) {
		isSet_sendAddr1Org = true;
		this.sendAddr1Org = sendAddr1Org;
	}
	
	/** Property set << sendAddr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendAddr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_sendAddr2Org = false;
	
	protected boolean isSet_sendAddr2Org()
	{
		return this.isSet_sendAddr2Org;
	}
	
	protected void setIsSet_sendAddr2Org(boolean value)
	{
		this.isSet_sendAddr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String sendAddr2Org  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendAddr2Org(){
		return sendAddr2Org;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendAddr2Org")
	public void setSendAddr2Org( java.lang.String sendAddr2Org ) {
		isSet_sendAddr2Org = true;
		this.sendAddr2Org = sendAddr2Org;
	}
	
	/** Property set << sendAddr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sendAddrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_sendAddrTag = false;
	
	protected boolean isSet_sendAddrTag()
	{
		return this.isSet_sendAddrTag;
	}
	
	protected void setIsSet_sendAddrTag(boolean value)
	{
		this.isSet_sendAddrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String sendAddrTag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getSendAddrTag(){
		return sendAddrTag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("sendAddrTag")
	public void setSendAddrTag( java.lang.String sendAddrTag ) {
		isSet_sendAddrTag = true;
		this.sendAddrTag = sendAddrTag;
	}
	
	/** Property set << sendAddrTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode2 >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode2 = false;
	
	protected boolean isSet_custCode2()
	{
		return this.isSet_custCode2;
	}
	
	protected void setIsSet_custCode2(boolean value)
	{
		this.isSet_custCode2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode2  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getCustCode2(){
		return custCode2;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("custCode2")
	public void setCustCode2( java.lang.String custCode2 ) {
		isSet_custCode2 = true;
		this.custCode2 = custCode2;
	}
	
	/** Property set << custCode2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << triTag >> [[ */
	
	@XmlTransient
	private boolean isSet_triTag = false;
	
	protected boolean isSet_triTag()
	{
		return this.isSet_triTag;
	}
	
	protected void setIsSet_triTag(boolean value)
	{
		this.isSet_triTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String triTag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getTriTag(){
		return triTag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("triTag")
	public void setTriTag( java.lang.String triTag ) {
		isSet_triTag = true;
		this.triTag = triTag;
	}
	
	/** Property set << triTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DSMCodeCustHist01IO clone(){
		try{
			DSMCodeCustHist01IO object= (DSMCodeCustHist01IO)super.clone();
			if ( this.histDate== null ) object.histDate = null;
			else{
				object.histDate = this.histDate;
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.approveYn== null ) object.approveYn = null;
			else{
				object.approveYn = this.approveYn;
			}
			if ( this.useYn== null ) object.useYn = null;
			else{
				object.useYn = this.useYn;
			}
			if ( this.custDiv== null ) object.custDiv = null;
			else{
				object.custDiv = this.custDiv;
			}
			if ( this.bankDiv== null ) object.bankDiv = null;
			else{
				object.bankDiv = this.bankDiv;
			}
			if ( this.custName== null ) object.custName = null;
			else{
				object.custName = this.custName;
			}
			if ( this.custAbbr== null ) object.custAbbr = null;
			else{
				object.custAbbr = this.custAbbr;
			}
			if ( this.custEng== null ) object.custEng = null;
			else{
				object.custEng = this.custEng;
			}
			if ( this.custLegalNo== null ) object.custLegalNo = null;
			else{
				object.custLegalNo = this.custLegalNo;
			}
			if ( this.representName== null ) object.representName = null;
			else{
				object.representName = this.representName;
			}
			if ( this.representRrn== null ) object.representRrn = null;
			else{
				object.representRrn = this.representRrn;
			}
			if ( this.bizStatus== null ) object.bizStatus = null;
			else{
				object.bizStatus = this.bizStatus;
			}
			if ( this.bizType== null ) object.bizType = null;
			else{
				object.bizType = this.bizType;
			}
			if ( this.phone== null ) object.phone = null;
			else{
				object.phone = this.phone;
			}
			if ( this.cellno== null ) object.cellno = null;
			else{
				object.cellno = this.cellno;
			}
			if ( this.fax== null ) object.fax = null;
			else{
				object.fax = this.fax;
			}
			if ( this.zipCode== null ) object.zipCode = null;
			else{
				object.zipCode = this.zipCode;
			}
			if ( this.addr1== null ) object.addr1 = null;
			else{
				object.addr1 = this.addr1;
			}
			if ( this.addr2== null ) object.addr2 = null;
			else{
				object.addr2 = this.addr2;
			}
			if ( this.compPhone== null ) object.compPhone = null;
			else{
				object.compPhone = this.compPhone;
			}
			if ( this.infoYn== null ) object.infoYn = null;
			else{
				object.infoYn = this.infoYn;
			}
			if ( this.sendZipCode== null ) object.sendZipCode = null;
			else{
				object.sendZipCode = this.sendZipCode;
			}
			if ( this.sendAddr1== null ) object.sendAddr1 = null;
			else{
				object.sendAddr1 = this.sendAddr1;
			}
			if ( this.sendAddr2== null ) object.sendAddr2 = null;
			else{
				object.sendAddr2 = this.sendAddr2;
			}
			if ( this.sendReceiptname== null ) object.sendReceiptname = null;
			else{
				object.sendReceiptname = this.sendReceiptname;
			}
			if ( this.sendEmail== null ) object.sendEmail = null;
			else{
				object.sendEmail = this.sendEmail;
			}
			if ( this.bankCode== null ) object.bankCode = null;
			else{
				object.bankCode = this.bankCode;
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.depositOwner== null ) object.depositOwner = null;
			else{
				object.depositOwner = this.depositOwner;
			}
			if ( this.agentName== null ) object.agentName = null;
			else{
				object.agentName = this.agentName;
			}
			if ( this.agentRrn== null ) object.agentRrn = null;
			else{
				object.agentRrn = this.agentRrn;
			}
			if ( this.agentPhone== null ) object.agentPhone = null;
			else{
				object.agentPhone = this.agentPhone;
			}
			if ( this.agentCellno== null ) object.agentCellno = null;
			else{
				object.agentCellno = this.agentCellno;
			}
			if ( this.agentFax== null ) object.agentFax = null;
			else{
				object.agentFax = this.agentFax;
			}
			if ( this.agentZipCode== null ) object.agentZipCode = null;
			else{
				object.agentZipCode = this.agentZipCode;
			}
			if ( this.agentAddr1== null ) object.agentAddr1 = null;
			else{
				object.agentAddr1 = this.agentAddr1;
			}
			if ( this.agentAddr2== null ) object.agentAddr2 = null;
			else{
				object.agentAddr2 = this.agentAddr2;
			}
			if ( this.agentEmail== null ) object.agentEmail = null;
			else{
				object.agentEmail = this.agentEmail;
			}
			if ( this.foreignTag== null ) object.foreignTag = null;
			else{
				object.foreignTag = this.foreignTag;
			}
			if ( this.foreignNation== null ) object.foreignNation = null;
			else{
				object.foreignNation = this.foreignNation;
			}
			if ( this.companyCode== null ) object.companyCode = null;
			else{
				object.companyCode = this.companyCode;
			}
			if ( this.projCode== null ) object.projCode = null;
			else{
				object.projCode = this.projCode;
			}
			if ( this.incomeDiv== null ) object.incomeDiv = null;
			else{
				object.incomeDiv = this.incomeDiv;
			}
			if ( this.custGroupCode== null ) object.custGroupCode = null;
			else{
				object.custGroupCode = this.custGroupCode;
			}
			if ( this.amYn== null ) object.amYn = null;
			else{
				object.amYn = this.amYn;
			}
			if ( this.tmYn== null ) object.tmYn = null;
			else{
				object.tmYn = this.tmYn;
			}
			if ( this.hdYn== null ) object.hdYn = null;
			else{
				object.hdYn = this.hdYn;
			}
			if ( this.mmYn== null ) object.mmYn = null;
			else{
				object.mmYn = this.mmYn;
			}
			if ( this.hdPassword== null ) object.hdPassword = null;
			else{
				object.hdPassword = this.hdPassword;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.fileName== null ) object.fileName = null;
			else{
				object.fileName = this.fileName;
			}
			if ( this.custDiv2== null ) object.custDiv2 = null;
			else{
				object.custDiv2 = this.custDiv2;
			}
			if ( this.zipCodeOrg== null ) object.zipCodeOrg = null;
			else{
				object.zipCodeOrg = this.zipCodeOrg;
			}
			if ( this.addr1Org== null ) object.addr1Org = null;
			else{
				object.addr1Org = this.addr1Org;
			}
			if ( this.addr2Org== null ) object.addr2Org = null;
			else{
				object.addr2Org = this.addr2Org;
			}
			if ( this.addrTag== null ) object.addrTag = null;
			else{
				object.addrTag = this.addrTag;
			}
			if ( this.agentZipCodeOrg== null ) object.agentZipCodeOrg = null;
			else{
				object.agentZipCodeOrg = this.agentZipCodeOrg;
			}
			if ( this.agentAddr1Org== null ) object.agentAddr1Org = null;
			else{
				object.agentAddr1Org = this.agentAddr1Org;
			}
			if ( this.agentAddr2Org== null ) object.agentAddr2Org = null;
			else{
				object.agentAddr2Org = this.agentAddr2Org;
			}
			if ( this.agentAddrTag== null ) object.agentAddrTag = null;
			else{
				object.agentAddrTag = this.agentAddrTag;
			}
			if ( this.sendZipCodeOrg== null ) object.sendZipCodeOrg = null;
			else{
				object.sendZipCodeOrg = this.sendZipCodeOrg;
			}
			if ( this.sendAddr1Org== null ) object.sendAddr1Org = null;
			else{
				object.sendAddr1Org = this.sendAddr1Org;
			}
			if ( this.sendAddr2Org== null ) object.sendAddr2Org = null;
			else{
				object.sendAddr2Org = this.sendAddr2Org;
			}
			if ( this.sendAddrTag== null ) object.sendAddrTag = null;
			else{
				object.sendAddrTag = this.sendAddrTag;
			}
			if ( this.custCode2== null ) object.custCode2 = null;
			else{
				object.custCode2 = this.custCode2;
			}
			if ( this.triTag== null ) object.triTag = null;
			else{
				object.triTag = this.triTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((histDate==null)?0:histDate.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((approveYn==null)?0:approveYn.hashCode());
		result = prime * result + ((useYn==null)?0:useYn.hashCode());
		result = prime * result + ((custDiv==null)?0:custDiv.hashCode());
		result = prime * result + ((bankDiv==null)?0:bankDiv.hashCode());
		result = prime * result + ((custName==null)?0:custName.hashCode());
		result = prime * result + ((custAbbr==null)?0:custAbbr.hashCode());
		result = prime * result + ((custEng==null)?0:custEng.hashCode());
		result = prime * result + ((custLegalNo==null)?0:custLegalNo.hashCode());
		result = prime * result + ((representName==null)?0:representName.hashCode());
		result = prime * result + ((representRrn==null)?0:representRrn.hashCode());
		result = prime * result + ((bizStatus==null)?0:bizStatus.hashCode());
		result = prime * result + ((bizType==null)?0:bizType.hashCode());
		result = prime * result + ((phone==null)?0:phone.hashCode());
		result = prime * result + ((cellno==null)?0:cellno.hashCode());
		result = prime * result + ((fax==null)?0:fax.hashCode());
		result = prime * result + ((zipCode==null)?0:zipCode.hashCode());
		result = prime * result + ((addr1==null)?0:addr1.hashCode());
		result = prime * result + ((addr2==null)?0:addr2.hashCode());
		result = prime * result + ((compPhone==null)?0:compPhone.hashCode());
		result = prime * result + ((infoYn==null)?0:infoYn.hashCode());
		result = prime * result + ((sendZipCode==null)?0:sendZipCode.hashCode());
		result = prime * result + ((sendAddr1==null)?0:sendAddr1.hashCode());
		result = prime * result + ((sendAddr2==null)?0:sendAddr2.hashCode());
		result = prime * result + ((sendReceiptname==null)?0:sendReceiptname.hashCode());
		result = prime * result + ((sendEmail==null)?0:sendEmail.hashCode());
		result = prime * result + ((bankCode==null)?0:bankCode.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((depositOwner==null)?0:depositOwner.hashCode());
		result = prime * result + ((agentName==null)?0:agentName.hashCode());
		result = prime * result + ((agentRrn==null)?0:agentRrn.hashCode());
		result = prime * result + ((agentPhone==null)?0:agentPhone.hashCode());
		result = prime * result + ((agentCellno==null)?0:agentCellno.hashCode());
		result = prime * result + ((agentFax==null)?0:agentFax.hashCode());
		result = prime * result + ((agentZipCode==null)?0:agentZipCode.hashCode());
		result = prime * result + ((agentAddr1==null)?0:agentAddr1.hashCode());
		result = prime * result + ((agentAddr2==null)?0:agentAddr2.hashCode());
		result = prime * result + ((agentEmail==null)?0:agentEmail.hashCode());
		result = prime * result + ((foreignTag==null)?0:foreignTag.hashCode());
		result = prime * result + ((foreignNation==null)?0:foreignNation.hashCode());
		result = prime * result + ((companyCode==null)?0:companyCode.hashCode());
		result = prime * result + ((projCode==null)?0:projCode.hashCode());
		result = prime * result + ((incomeDiv==null)?0:incomeDiv.hashCode());
		result = prime * result + ((custGroupCode==null)?0:custGroupCode.hashCode());
		result = prime * result + ((amYn==null)?0:amYn.hashCode());
		result = prime * result + ((tmYn==null)?0:tmYn.hashCode());
		result = prime * result + ((hdYn==null)?0:hdYn.hashCode());
		result = prime * result + ((mmYn==null)?0:mmYn.hashCode());
		result = prime * result + ((hdPassword==null)?0:hdPassword.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((fileName==null)?0:fileName.hashCode());
		result = prime * result + ((custDiv2==null)?0:custDiv2.hashCode());
		result = prime * result + ((zipCodeOrg==null)?0:zipCodeOrg.hashCode());
		result = prime * result + ((addr1Org==null)?0:addr1Org.hashCode());
		result = prime * result + ((addr2Org==null)?0:addr2Org.hashCode());
		result = prime * result + ((addrTag==null)?0:addrTag.hashCode());
		result = prime * result + ((agentZipCodeOrg==null)?0:agentZipCodeOrg.hashCode());
		result = prime * result + ((agentAddr1Org==null)?0:agentAddr1Org.hashCode());
		result = prime * result + ((agentAddr2Org==null)?0:agentAddr2Org.hashCode());
		result = prime * result + ((agentAddrTag==null)?0:agentAddrTag.hashCode());
		result = prime * result + ((sendZipCodeOrg==null)?0:sendZipCodeOrg.hashCode());
		result = prime * result + ((sendAddr1Org==null)?0:sendAddr1Org.hashCode());
		result = prime * result + ((sendAddr2Org==null)?0:sendAddr2Org.hashCode());
		result = prime * result + ((sendAddrTag==null)?0:sendAddrTag.hashCode());
		result = prime * result + ((custCode2==null)?0:custCode2.hashCode());
		result = prime * result + ((triTag==null)?0:triTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.sm.code.onl.dao.dto.DSMCodeCustHist01IO other = (kait.sm.code.onl.dao.dto.DSMCodeCustHist01IO)obj;
		if ( histDate == null ){
			if ( other.histDate != null ) return false;
		}
		else if ( !histDate.equals(other.histDate) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( approveYn == null ){
			if ( other.approveYn != null ) return false;
		}
		else if ( !approveYn.equals(other.approveYn) )
			return false;
		if ( useYn == null ){
			if ( other.useYn != null ) return false;
		}
		else if ( !useYn.equals(other.useYn) )
			return false;
		if ( custDiv == null ){
			if ( other.custDiv != null ) return false;
		}
		else if ( !custDiv.equals(other.custDiv) )
			return false;
		if ( bankDiv == null ){
			if ( other.bankDiv != null ) return false;
		}
		else if ( !bankDiv.equals(other.bankDiv) )
			return false;
		if ( custName == null ){
			if ( other.custName != null ) return false;
		}
		else if ( !custName.equals(other.custName) )
			return false;
		if ( custAbbr == null ){
			if ( other.custAbbr != null ) return false;
		}
		else if ( !custAbbr.equals(other.custAbbr) )
			return false;
		if ( custEng == null ){
			if ( other.custEng != null ) return false;
		}
		else if ( !custEng.equals(other.custEng) )
			return false;
		if ( custLegalNo == null ){
			if ( other.custLegalNo != null ) return false;
		}
		else if ( !custLegalNo.equals(other.custLegalNo) )
			return false;
		if ( representName == null ){
			if ( other.representName != null ) return false;
		}
		else if ( !representName.equals(other.representName) )
			return false;
		if ( representRrn == null ){
			if ( other.representRrn != null ) return false;
		}
		else if ( !representRrn.equals(other.representRrn) )
			return false;
		if ( bizStatus == null ){
			if ( other.bizStatus != null ) return false;
		}
		else if ( !bizStatus.equals(other.bizStatus) )
			return false;
		if ( bizType == null ){
			if ( other.bizType != null ) return false;
		}
		else if ( !bizType.equals(other.bizType) )
			return false;
		if ( phone == null ){
			if ( other.phone != null ) return false;
		}
		else if ( !phone.equals(other.phone) )
			return false;
		if ( cellno == null ){
			if ( other.cellno != null ) return false;
		}
		else if ( !cellno.equals(other.cellno) )
			return false;
		if ( fax == null ){
			if ( other.fax != null ) return false;
		}
		else if ( !fax.equals(other.fax) )
			return false;
		if ( zipCode == null ){
			if ( other.zipCode != null ) return false;
		}
		else if ( !zipCode.equals(other.zipCode) )
			return false;
		if ( addr1 == null ){
			if ( other.addr1 != null ) return false;
		}
		else if ( !addr1.equals(other.addr1) )
			return false;
		if ( addr2 == null ){
			if ( other.addr2 != null ) return false;
		}
		else if ( !addr2.equals(other.addr2) )
			return false;
		if ( compPhone == null ){
			if ( other.compPhone != null ) return false;
		}
		else if ( !compPhone.equals(other.compPhone) )
			return false;
		if ( infoYn == null ){
			if ( other.infoYn != null ) return false;
		}
		else if ( !infoYn.equals(other.infoYn) )
			return false;
		if ( sendZipCode == null ){
			if ( other.sendZipCode != null ) return false;
		}
		else if ( !sendZipCode.equals(other.sendZipCode) )
			return false;
		if ( sendAddr1 == null ){
			if ( other.sendAddr1 != null ) return false;
		}
		else if ( !sendAddr1.equals(other.sendAddr1) )
			return false;
		if ( sendAddr2 == null ){
			if ( other.sendAddr2 != null ) return false;
		}
		else if ( !sendAddr2.equals(other.sendAddr2) )
			return false;
		if ( sendReceiptname == null ){
			if ( other.sendReceiptname != null ) return false;
		}
		else if ( !sendReceiptname.equals(other.sendReceiptname) )
			return false;
		if ( sendEmail == null ){
			if ( other.sendEmail != null ) return false;
		}
		else if ( !sendEmail.equals(other.sendEmail) )
			return false;
		if ( bankCode == null ){
			if ( other.bankCode != null ) return false;
		}
		else if ( !bankCode.equals(other.bankCode) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( depositOwner == null ){
			if ( other.depositOwner != null ) return false;
		}
		else if ( !depositOwner.equals(other.depositOwner) )
			return false;
		if ( agentName == null ){
			if ( other.agentName != null ) return false;
		}
		else if ( !agentName.equals(other.agentName) )
			return false;
		if ( agentRrn == null ){
			if ( other.agentRrn != null ) return false;
		}
		else if ( !agentRrn.equals(other.agentRrn) )
			return false;
		if ( agentPhone == null ){
			if ( other.agentPhone != null ) return false;
		}
		else if ( !agentPhone.equals(other.agentPhone) )
			return false;
		if ( agentCellno == null ){
			if ( other.agentCellno != null ) return false;
		}
		else if ( !agentCellno.equals(other.agentCellno) )
			return false;
		if ( agentFax == null ){
			if ( other.agentFax != null ) return false;
		}
		else if ( !agentFax.equals(other.agentFax) )
			return false;
		if ( agentZipCode == null ){
			if ( other.agentZipCode != null ) return false;
		}
		else if ( !agentZipCode.equals(other.agentZipCode) )
			return false;
		if ( agentAddr1 == null ){
			if ( other.agentAddr1 != null ) return false;
		}
		else if ( !agentAddr1.equals(other.agentAddr1) )
			return false;
		if ( agentAddr2 == null ){
			if ( other.agentAddr2 != null ) return false;
		}
		else if ( !agentAddr2.equals(other.agentAddr2) )
			return false;
		if ( agentEmail == null ){
			if ( other.agentEmail != null ) return false;
		}
		else if ( !agentEmail.equals(other.agentEmail) )
			return false;
		if ( foreignTag == null ){
			if ( other.foreignTag != null ) return false;
		}
		else if ( !foreignTag.equals(other.foreignTag) )
			return false;
		if ( foreignNation == null ){
			if ( other.foreignNation != null ) return false;
		}
		else if ( !foreignNation.equals(other.foreignNation) )
			return false;
		if ( companyCode == null ){
			if ( other.companyCode != null ) return false;
		}
		else if ( !companyCode.equals(other.companyCode) )
			return false;
		if ( projCode == null ){
			if ( other.projCode != null ) return false;
		}
		else if ( !projCode.equals(other.projCode) )
			return false;
		if ( incomeDiv == null ){
			if ( other.incomeDiv != null ) return false;
		}
		else if ( !incomeDiv.equals(other.incomeDiv) )
			return false;
		if ( custGroupCode == null ){
			if ( other.custGroupCode != null ) return false;
		}
		else if ( !custGroupCode.equals(other.custGroupCode) )
			return false;
		if ( amYn == null ){
			if ( other.amYn != null ) return false;
		}
		else if ( !amYn.equals(other.amYn) )
			return false;
		if ( tmYn == null ){
			if ( other.tmYn != null ) return false;
		}
		else if ( !tmYn.equals(other.tmYn) )
			return false;
		if ( hdYn == null ){
			if ( other.hdYn != null ) return false;
		}
		else if ( !hdYn.equals(other.hdYn) )
			return false;
		if ( mmYn == null ){
			if ( other.mmYn != null ) return false;
		}
		else if ( !mmYn.equals(other.mmYn) )
			return false;
		if ( hdPassword == null ){
			if ( other.hdPassword != null ) return false;
		}
		else if ( !hdPassword.equals(other.hdPassword) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( fileName == null ){
			if ( other.fileName != null ) return false;
		}
		else if ( !fileName.equals(other.fileName) )
			return false;
		if ( custDiv2 == null ){
			if ( other.custDiv2 != null ) return false;
		}
		else if ( !custDiv2.equals(other.custDiv2) )
			return false;
		if ( zipCodeOrg == null ){
			if ( other.zipCodeOrg != null ) return false;
		}
		else if ( !zipCodeOrg.equals(other.zipCodeOrg) )
			return false;
		if ( addr1Org == null ){
			if ( other.addr1Org != null ) return false;
		}
		else if ( !addr1Org.equals(other.addr1Org) )
			return false;
		if ( addr2Org == null ){
			if ( other.addr2Org != null ) return false;
		}
		else if ( !addr2Org.equals(other.addr2Org) )
			return false;
		if ( addrTag == null ){
			if ( other.addrTag != null ) return false;
		}
		else if ( !addrTag.equals(other.addrTag) )
			return false;
		if ( agentZipCodeOrg == null ){
			if ( other.agentZipCodeOrg != null ) return false;
		}
		else if ( !agentZipCodeOrg.equals(other.agentZipCodeOrg) )
			return false;
		if ( agentAddr1Org == null ){
			if ( other.agentAddr1Org != null ) return false;
		}
		else if ( !agentAddr1Org.equals(other.agentAddr1Org) )
			return false;
		if ( agentAddr2Org == null ){
			if ( other.agentAddr2Org != null ) return false;
		}
		else if ( !agentAddr2Org.equals(other.agentAddr2Org) )
			return false;
		if ( agentAddrTag == null ){
			if ( other.agentAddrTag != null ) return false;
		}
		else if ( !agentAddrTag.equals(other.agentAddrTag) )
			return false;
		if ( sendZipCodeOrg == null ){
			if ( other.sendZipCodeOrg != null ) return false;
		}
		else if ( !sendZipCodeOrg.equals(other.sendZipCodeOrg) )
			return false;
		if ( sendAddr1Org == null ){
			if ( other.sendAddr1Org != null ) return false;
		}
		else if ( !sendAddr1Org.equals(other.sendAddr1Org) )
			return false;
		if ( sendAddr2Org == null ){
			if ( other.sendAddr2Org != null ) return false;
		}
		else if ( !sendAddr2Org.equals(other.sendAddr2Org) )
			return false;
		if ( sendAddrTag == null ){
			if ( other.sendAddrTag != null ) return false;
		}
		else if ( !sendAddrTag.equals(other.sendAddrTag) )
			return false;
		if ( custCode2 == null ){
			if ( other.custCode2 != null ) return false;
		}
		else if ( !custCode2.equals(other.custCode2) )
			return false;
		if ( triTag == null ){
			if ( other.triTag != null ) return false;
		}
		else if ( !triTag.equals(other.triTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.sm.code.onl.dao.dto.DSMCodeCustHist01IO:\n");
		sb.append("\thistDate: ");
		sb.append(histDate==null?"null":getHistDate());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tapproveYn: ");
		sb.append(approveYn==null?"null":getApproveYn());
		sb.append("\n");
		sb.append("\tuseYn: ");
		sb.append(useYn==null?"null":getUseYn());
		sb.append("\n");
		sb.append("\tcustDiv: ");
		sb.append(custDiv==null?"null":getCustDiv());
		sb.append("\n");
		sb.append("\tbankDiv: ");
		sb.append(bankDiv==null?"null":getBankDiv());
		sb.append("\n");
		sb.append("\tcustName: ");
		sb.append(custName==null?"null":getCustName());
		sb.append("\n");
		sb.append("\tcustAbbr: ");
		sb.append(custAbbr==null?"null":getCustAbbr());
		sb.append("\n");
		sb.append("\tcustEng: ");
		sb.append(custEng==null?"null":getCustEng());
		sb.append("\n");
		sb.append("\tcustLegalNo: ");
		sb.append(custLegalNo==null?"null":getCustLegalNo());
		sb.append("\n");
		sb.append("\trepresentName: ");
		sb.append(representName==null?"null":getRepresentName());
		sb.append("\n");
		sb.append("\trepresentRrn: ");
		sb.append(representRrn==null?"null":getRepresentRrn());
		sb.append("\n");
		sb.append("\tbizStatus: ");
		sb.append(bizStatus==null?"null":getBizStatus());
		sb.append("\n");
		sb.append("\tbizType: ");
		sb.append(bizType==null?"null":getBizType());
		sb.append("\n");
		sb.append("\tphone: ");
		sb.append(phone==null?"null":getPhone());
		sb.append("\n");
		sb.append("\tcellno: ");
		sb.append(cellno==null?"null":getCellno());
		sb.append("\n");
		sb.append("\tfax: ");
		sb.append(fax==null?"null":getFax());
		sb.append("\n");
		sb.append("\tzipCode: ");
		sb.append(zipCode==null?"null":getZipCode());
		sb.append("\n");
		sb.append("\taddr1: ");
		sb.append(addr1==null?"null":getAddr1());
		sb.append("\n");
		sb.append("\taddr2: ");
		sb.append(addr2==null?"null":getAddr2());
		sb.append("\n");
		sb.append("\tcompPhone: ");
		sb.append(compPhone==null?"null":getCompPhone());
		sb.append("\n");
		sb.append("\tinfoYn: ");
		sb.append(infoYn==null?"null":getInfoYn());
		sb.append("\n");
		sb.append("\tsendZipCode: ");
		sb.append(sendZipCode==null?"null":getSendZipCode());
		sb.append("\n");
		sb.append("\tsendAddr1: ");
		sb.append(sendAddr1==null?"null":getSendAddr1());
		sb.append("\n");
		sb.append("\tsendAddr2: ");
		sb.append(sendAddr2==null?"null":getSendAddr2());
		sb.append("\n");
		sb.append("\tsendReceiptname: ");
		sb.append(sendReceiptname==null?"null":getSendReceiptname());
		sb.append("\n");
		sb.append("\tsendEmail: ");
		sb.append(sendEmail==null?"null":getSendEmail());
		sb.append("\n");
		sb.append("\tbankCode: ");
		sb.append(bankCode==null?"null":getBankCode());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\tdepositOwner: ");
		sb.append(depositOwner==null?"null":getDepositOwner());
		sb.append("\n");
		sb.append("\tagentName: ");
		sb.append(agentName==null?"null":getAgentName());
		sb.append("\n");
		sb.append("\tagentRrn: ");
		sb.append(agentRrn==null?"null":getAgentRrn());
		sb.append("\n");
		sb.append("\tagentPhone: ");
		sb.append(agentPhone==null?"null":getAgentPhone());
		sb.append("\n");
		sb.append("\tagentCellno: ");
		sb.append(agentCellno==null?"null":getAgentCellno());
		sb.append("\n");
		sb.append("\tagentFax: ");
		sb.append(agentFax==null?"null":getAgentFax());
		sb.append("\n");
		sb.append("\tagentZipCode: ");
		sb.append(agentZipCode==null?"null":getAgentZipCode());
		sb.append("\n");
		sb.append("\tagentAddr1: ");
		sb.append(agentAddr1==null?"null":getAgentAddr1());
		sb.append("\n");
		sb.append("\tagentAddr2: ");
		sb.append(agentAddr2==null?"null":getAgentAddr2());
		sb.append("\n");
		sb.append("\tagentEmail: ");
		sb.append(agentEmail==null?"null":getAgentEmail());
		sb.append("\n");
		sb.append("\tforeignTag: ");
		sb.append(foreignTag==null?"null":getForeignTag());
		sb.append("\n");
		sb.append("\tforeignNation: ");
		sb.append(foreignNation==null?"null":getForeignNation());
		sb.append("\n");
		sb.append("\tcompanyCode: ");
		sb.append(companyCode==null?"null":getCompanyCode());
		sb.append("\n");
		sb.append("\tprojCode: ");
		sb.append(projCode==null?"null":getProjCode());
		sb.append("\n");
		sb.append("\tincomeDiv: ");
		sb.append(incomeDiv==null?"null":getIncomeDiv());
		sb.append("\n");
		sb.append("\tcustGroupCode: ");
		sb.append(custGroupCode==null?"null":getCustGroupCode());
		sb.append("\n");
		sb.append("\tamYn: ");
		sb.append(amYn==null?"null":getAmYn());
		sb.append("\n");
		sb.append("\ttmYn: ");
		sb.append(tmYn==null?"null":getTmYn());
		sb.append("\n");
		sb.append("\thdYn: ");
		sb.append(hdYn==null?"null":getHdYn());
		sb.append("\n");
		sb.append("\tmmYn: ");
		sb.append(mmYn==null?"null":getMmYn());
		sb.append("\n");
		sb.append("\thdPassword: ");
		sb.append(hdPassword==null?"null":getHdPassword());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tfileName: ");
		sb.append(fileName==null?"null":getFileName());
		sb.append("\n");
		sb.append("\tcustDiv2: ");
		sb.append(custDiv2==null?"null":getCustDiv2());
		sb.append("\n");
		sb.append("\tzipCodeOrg: ");
		sb.append(zipCodeOrg==null?"null":getZipCodeOrg());
		sb.append("\n");
		sb.append("\taddr1Org: ");
		sb.append(addr1Org==null?"null":getAddr1Org());
		sb.append("\n");
		sb.append("\taddr2Org: ");
		sb.append(addr2Org==null?"null":getAddr2Org());
		sb.append("\n");
		sb.append("\taddrTag: ");
		sb.append(addrTag==null?"null":getAddrTag());
		sb.append("\n");
		sb.append("\tagentZipCodeOrg: ");
		sb.append(agentZipCodeOrg==null?"null":getAgentZipCodeOrg());
		sb.append("\n");
		sb.append("\tagentAddr1Org: ");
		sb.append(agentAddr1Org==null?"null":getAgentAddr1Org());
		sb.append("\n");
		sb.append("\tagentAddr2Org: ");
		sb.append(agentAddr2Org==null?"null":getAgentAddr2Org());
		sb.append("\n");
		sb.append("\tagentAddrTag: ");
		sb.append(agentAddrTag==null?"null":getAgentAddrTag());
		sb.append("\n");
		sb.append("\tsendZipCodeOrg: ");
		sb.append(sendZipCodeOrg==null?"null":getSendZipCodeOrg());
		sb.append("\n");
		sb.append("\tsendAddr1Org: ");
		sb.append(sendAddr1Org==null?"null":getSendAddr1Org());
		sb.append("\n");
		sb.append("\tsendAddr2Org: ");
		sb.append(sendAddr2Org==null?"null":getSendAddr2Org());
		sb.append("\n");
		sb.append("\tsendAddrTag: ");
		sb.append(sendAddrTag==null?"null":getSendAddrTag());
		sb.append("\n");
		sb.append("\tcustCode2: ");
		sb.append(custCode2==null?"null":getCustCode2());
		sb.append("\n");
		sb.append("\ttriTag: ");
		sb.append(triTag==null?"null":getTriTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 11; /* histDate */
		messageLen+= 20; /* custCode */
		messageLen+= 1; /* approveYn */
		messageLen+= 1; /* useYn */
		messageLen+= 3; /* custDiv */
		messageLen+= 3; /* bankDiv */
		messageLen+= 50; /* custName */
		messageLen+= 20; /* custAbbr */
		messageLen+= 30; /* custEng */
		messageLen+= 20; /* custLegalNo */
		messageLen+= 30; /* representName */
		messageLen+= 13; /* representRrn */
		messageLen+= 30; /* bizStatus */
		messageLen+= 30; /* bizType */
		messageLen+= 16; /* phone */
		messageLen+= 16; /* cellno */
		messageLen+= 16; /* fax */
		messageLen+= 6; /* zipCode */
		messageLen+= 300; /* addr1 */
		messageLen+= 300; /* addr2 */
		messageLen+= 20; /* compPhone */
		messageLen+= 1; /* infoYn */
		messageLen+= 6; /* sendZipCode */
		messageLen+= 300; /* sendAddr1 */
		messageLen+= 300; /* sendAddr2 */
		messageLen+= 40; /* sendReceiptname */
		messageLen+= 50; /* sendEmail */
		messageLen+= 8; /* bankCode */
		messageLen+= 30; /* depositNo */
		messageLen+= 60; /* depositOwner */
		messageLen+= 20; /* agentName */
		messageLen+= 13; /* agentRrn */
		messageLen+= 16; /* agentPhone */
		messageLen+= 16; /* agentCellno */
		messageLen+= 16; /* agentFax */
		messageLen+= 6; /* agentZipCode */
		messageLen+= 300; /* agentAddr1 */
		messageLen+= 300; /* agentAddr2 */
		messageLen+= 50; /* agentEmail */
		messageLen+= 3; /* foreignTag */
		messageLen+= 3; /* foreignNation */
		messageLen+= 6; /* companyCode */
		messageLen+= 12; /* projCode */
		messageLen+= 3; /* incomeDiv */
		messageLen+= 20; /* custGroupCode */
		messageLen+= 1; /* amYn */
		messageLen+= 1; /* tmYn */
		messageLen+= 1; /* hdYn */
		messageLen+= 1; /* mmYn */
		messageLen+= 40; /* hdPassword */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 100; /* fileName */
		messageLen+= 3; /* custDiv2 */
		messageLen+= 6; /* zipCodeOrg */
		messageLen+= 300; /* addr1Org */
		messageLen+= 300; /* addr2Org */
		messageLen+= 1; /* addrTag */
		messageLen+= 6; /* agentZipCodeOrg */
		messageLen+= 300; /* agentAddr1Org */
		messageLen+= 300; /* agentAddr2Org */
		messageLen+= 1; /* agentAddrTag */
		messageLen+= 6; /* sendZipCodeOrg */
		messageLen+= 300; /* sendAddr1Org */
		messageLen+= 300; /* sendAddr2Org */
		messageLen+= 1; /* sendAddrTag */
		messageLen+= 20; /* custCode2 */
		messageLen+= 1; /* triTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("histDate");
	
		fieldNames.add("custCode");
	
		fieldNames.add("approveYn");
	
		fieldNames.add("useYn");
	
		fieldNames.add("custDiv");
	
		fieldNames.add("bankDiv");
	
		fieldNames.add("custName");
	
		fieldNames.add("custAbbr");
	
		fieldNames.add("custEng");
	
		fieldNames.add("custLegalNo");
	
		fieldNames.add("representName");
	
		fieldNames.add("representRrn");
	
		fieldNames.add("bizStatus");
	
		fieldNames.add("bizType");
	
		fieldNames.add("phone");
	
		fieldNames.add("cellno");
	
		fieldNames.add("fax");
	
		fieldNames.add("zipCode");
	
		fieldNames.add("addr1");
	
		fieldNames.add("addr2");
	
		fieldNames.add("compPhone");
	
		fieldNames.add("infoYn");
	
		fieldNames.add("sendZipCode");
	
		fieldNames.add("sendAddr1");
	
		fieldNames.add("sendAddr2");
	
		fieldNames.add("sendReceiptname");
	
		fieldNames.add("sendEmail");
	
		fieldNames.add("bankCode");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("depositOwner");
	
		fieldNames.add("agentName");
	
		fieldNames.add("agentRrn");
	
		fieldNames.add("agentPhone");
	
		fieldNames.add("agentCellno");
	
		fieldNames.add("agentFax");
	
		fieldNames.add("agentZipCode");
	
		fieldNames.add("agentAddr1");
	
		fieldNames.add("agentAddr2");
	
		fieldNames.add("agentEmail");
	
		fieldNames.add("foreignTag");
	
		fieldNames.add("foreignNation");
	
		fieldNames.add("companyCode");
	
		fieldNames.add("projCode");
	
		fieldNames.add("incomeDiv");
	
		fieldNames.add("custGroupCode");
	
		fieldNames.add("amYn");
	
		fieldNames.add("tmYn");
	
		fieldNames.add("hdYn");
	
		fieldNames.add("mmYn");
	
		fieldNames.add("hdPassword");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("fileName");
	
		fieldNames.add("custDiv2");
	
		fieldNames.add("zipCodeOrg");
	
		fieldNames.add("addr1Org");
	
		fieldNames.add("addr2Org");
	
		fieldNames.add("addrTag");
	
		fieldNames.add("agentZipCodeOrg");
	
		fieldNames.add("agentAddr1Org");
	
		fieldNames.add("agentAddr2Org");
	
		fieldNames.add("agentAddrTag");
	
		fieldNames.add("sendZipCodeOrg");
	
		fieldNames.add("sendAddr1Org");
	
		fieldNames.add("sendAddr2Org");
	
		fieldNames.add("sendAddrTag");
	
		fieldNames.add("custCode2");
	
		fieldNames.add("triTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("histDate", get("histDate"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("approveYn", get("approveYn"));
	
		fieldValueMap.put("useYn", get("useYn"));
	
		fieldValueMap.put("custDiv", get("custDiv"));
	
		fieldValueMap.put("bankDiv", get("bankDiv"));
	
		fieldValueMap.put("custName", get("custName"));
	
		fieldValueMap.put("custAbbr", get("custAbbr"));
	
		fieldValueMap.put("custEng", get("custEng"));
	
		fieldValueMap.put("custLegalNo", get("custLegalNo"));
	
		fieldValueMap.put("representName", get("representName"));
	
		fieldValueMap.put("representRrn", get("representRrn"));
	
		fieldValueMap.put("bizStatus", get("bizStatus"));
	
		fieldValueMap.put("bizType", get("bizType"));
	
		fieldValueMap.put("phone", get("phone"));
	
		fieldValueMap.put("cellno", get("cellno"));
	
		fieldValueMap.put("fax", get("fax"));
	
		fieldValueMap.put("zipCode", get("zipCode"));
	
		fieldValueMap.put("addr1", get("addr1"));
	
		fieldValueMap.put("addr2", get("addr2"));
	
		fieldValueMap.put("compPhone", get("compPhone"));
	
		fieldValueMap.put("infoYn", get("infoYn"));
	
		fieldValueMap.put("sendZipCode", get("sendZipCode"));
	
		fieldValueMap.put("sendAddr1", get("sendAddr1"));
	
		fieldValueMap.put("sendAddr2", get("sendAddr2"));
	
		fieldValueMap.put("sendReceiptname", get("sendReceiptname"));
	
		fieldValueMap.put("sendEmail", get("sendEmail"));
	
		fieldValueMap.put("bankCode", get("bankCode"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("depositOwner", get("depositOwner"));
	
		fieldValueMap.put("agentName", get("agentName"));
	
		fieldValueMap.put("agentRrn", get("agentRrn"));
	
		fieldValueMap.put("agentPhone", get("agentPhone"));
	
		fieldValueMap.put("agentCellno", get("agentCellno"));
	
		fieldValueMap.put("agentFax", get("agentFax"));
	
		fieldValueMap.put("agentZipCode", get("agentZipCode"));
	
		fieldValueMap.put("agentAddr1", get("agentAddr1"));
	
		fieldValueMap.put("agentAddr2", get("agentAddr2"));
	
		fieldValueMap.put("agentEmail", get("agentEmail"));
	
		fieldValueMap.put("foreignTag", get("foreignTag"));
	
		fieldValueMap.put("foreignNation", get("foreignNation"));
	
		fieldValueMap.put("companyCode", get("companyCode"));
	
		fieldValueMap.put("projCode", get("projCode"));
	
		fieldValueMap.put("incomeDiv", get("incomeDiv"));
	
		fieldValueMap.put("custGroupCode", get("custGroupCode"));
	
		fieldValueMap.put("amYn", get("amYn"));
	
		fieldValueMap.put("tmYn", get("tmYn"));
	
		fieldValueMap.put("hdYn", get("hdYn"));
	
		fieldValueMap.put("mmYn", get("mmYn"));
	
		fieldValueMap.put("hdPassword", get("hdPassword"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("fileName", get("fileName"));
	
		fieldValueMap.put("custDiv2", get("custDiv2"));
	
		fieldValueMap.put("zipCodeOrg", get("zipCodeOrg"));
	
		fieldValueMap.put("addr1Org", get("addr1Org"));
	
		fieldValueMap.put("addr2Org", get("addr2Org"));
	
		fieldValueMap.put("addrTag", get("addrTag"));
	
		fieldValueMap.put("agentZipCodeOrg", get("agentZipCodeOrg"));
	
		fieldValueMap.put("agentAddr1Org", get("agentAddr1Org"));
	
		fieldValueMap.put("agentAddr2Org", get("agentAddr2Org"));
	
		fieldValueMap.put("agentAddrTag", get("agentAddrTag"));
	
		fieldValueMap.put("sendZipCodeOrg", get("sendZipCodeOrg"));
	
		fieldValueMap.put("sendAddr1Org", get("sendAddr1Org"));
	
		fieldValueMap.put("sendAddr2Org", get("sendAddr2Org"));
	
		fieldValueMap.put("sendAddrTag", get("sendAddrTag"));
	
		fieldValueMap.put("custCode2", get("custCode2"));
	
		fieldValueMap.put("triTag", get("triTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			return getHistDate();
		case 604866272 : /* custCode */
			return getCustCode();
		case -1912115390 : /* approveYn */
			return getApproveYn();
		case 111577852 : /* useYn */
			return getUseYn();
		case 1127891262 : /* custDiv */
			return getCustDiv();
		case -337081163 : /* bankDiv */
			return getBankDiv();
		case 605180798 : /* custName */
			return getCustName();
		case 604794148 : /* custAbbr */
			return getCustAbbr();
		case 1127892363 : /* custEng */
			return getCustEng();
		case 1297367175 : /* custLegalNo */
			return getCustLegalNo();
		case -160778797 : /* representName */
			return getRepresentName();
		case -2083392026 : /* representRrn */
			return getRepresentRrn();
		case 662232805 : /* bizStatus */
			return getBizStatus();
		case -97599763 : /* bizType */
			return getBizType();
		case 106642798 : /* phone */
			return getPhone();
		case -1364080989 : /* cellno */
			return getCellno();
		case 101149 : /* fax */
			return getFax();
		case -282099538 : /* zipCode */
			return getZipCode();
		case 92660320 : /* addr1 */
			return getAddr1();
		case 92660321 : /* addr2 */
			return getAddr2();
		case -1428705377 : /* compPhone */
			return getCompPhone();
		case -1184170909 : /* infoYn */
			return getInfoYn();
		case -545570810 : /* sendZipCode */
			return getSendZipCode();
		case -1468488 : /* sendAddr1 */
			return getSendAddr1();
		case -1468487 : /* sendAddr2 */
			return getSendAddr2();
		case -730962917 : /* sendReceiptname */
			return getSendReceiptname();
		case 2490612 : /* sendEmail */
			return getSendEmail();
		case -1859605943 : /* bankCode */
			return getBankCode();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 277175989 : /* depositOwner */
			return getDepositOwner();
		case -1701238992 : /* agentName */
			return getAgentName();
		case 1469146345 : /* agentRrn */
			return getAgentRrn();
		case -1196743319 : /* agentPhone */
			return getAgentPhone();
		case 1180622344 : /* agentCellno */
			return getAgentCellno();
		case 1469134296 : /* agentFax */
			return getAgentFax();
		case 1294292457 : /* agentZipCode */
			return getAgentZipCode();
		case -1210725797 : /* agentAddr1 */
			return getAgentAddr1();
		case -1210725796 : /* agentAddr2 */
			return getAgentAddr2();
		case -1206766697 : /* agentEmail */
			return getAgentEmail();
		case 2031494694 : /* foreignTag */
			return getForeignTag();
		case -297022149 : /* foreignNation */
			return getForeignNation();
		case -508897270 : /* companyCode */
			return getCompanyCode();
		case -999698710 : /* projCode */
			return getProjCode();
		case -1418420696 : /* incomeDiv */
			return getIncomeDiv();
		case 1944422393 : /* custGroupCode */
			return getCustGroupCode();
		case 2997345 : /* amYn */
			return getAmYn();
		case 3563374 : /* tmYn */
			return getTmYn();
		case 3197233 : /* hdYn */
			return getHdYn();
		case 3354837 : /* mmYn */
			return getMmYn();
		case 1962241975 : /* hdPassword */
			return getHdPassword();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -735721945 : /* fileName */
			return getFileName();
		case 604890804 : /* custDiv2 */
			return getCustDiv2();
		case 1223741270 : /* zipCodeOrg */
			return getZipCodeOrg();
		case -1220298652 : /* addr1Org */
			return getAddr1Org();
		case -1220268861 : /* addr2Org */
			return getAddr2Org();
		case -1147708951 : /* addrTag */
			return getAddrTag();
		case -1949717445 : /* agentZipCodeOrg */
			return getAgentZipCodeOrg();
		case 403212937 : /* agentAddr1Org */
			return getAgentAddr1Org();
		case 403242728 : /* agentAddr2Org */
			return getAgentAddr2Org();
		case 428683044 : /* agentAddrTag */
			return getAgentAddrTag();
		case -943673090 : /* sendZipCodeOrg */
			return getSendZipCodeOrg();
		case -797973492 : /* sendAddr1Org */
			return getSendAddr1Org();
		case -797943701 : /* sendAddr2Org */
			return getSendAddr2Org();
		case -1411180223 : /* sendAddrTag */
			return getSendAddrTag();
		case 1570985298 : /* custCode2 */
			return getCustCode2();
		case -865492497 : /* triTag */
			return getTriTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			setHistDate((java.lang.String) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case -1912115390 : /* approveYn */
			setApproveYn((java.lang.String) value);
			return;
		case 111577852 : /* useYn */
			setUseYn((java.lang.String) value);
			return;
		case 1127891262 : /* custDiv */
			setCustDiv((java.lang.String) value);
			return;
		case -337081163 : /* bankDiv */
			setBankDiv((java.lang.String) value);
			return;
		case 605180798 : /* custName */
			setCustName((java.lang.String) value);
			return;
		case 604794148 : /* custAbbr */
			setCustAbbr((java.lang.String) value);
			return;
		case 1127892363 : /* custEng */
			setCustEng((java.lang.String) value);
			return;
		case 1297367175 : /* custLegalNo */
			setCustLegalNo((java.lang.String) value);
			return;
		case -160778797 : /* representName */
			setRepresentName((java.lang.String) value);
			return;
		case -2083392026 : /* representRrn */
			setRepresentRrn((java.lang.String) value);
			return;
		case 662232805 : /* bizStatus */
			setBizStatus((java.lang.String) value);
			return;
		case -97599763 : /* bizType */
			setBizType((java.lang.String) value);
			return;
		case 106642798 : /* phone */
			setPhone((java.lang.String) value);
			return;
		case -1364080989 : /* cellno */
			setCellno((java.lang.String) value);
			return;
		case 101149 : /* fax */
			setFax((java.lang.String) value);
			return;
		case -282099538 : /* zipCode */
			setZipCode((java.lang.String) value);
			return;
		case 92660320 : /* addr1 */
			setAddr1((java.lang.String) value);
			return;
		case 92660321 : /* addr2 */
			setAddr2((java.lang.String) value);
			return;
		case -1428705377 : /* compPhone */
			setCompPhone((java.lang.String) value);
			return;
		case -1184170909 : /* infoYn */
			setInfoYn((java.lang.String) value);
			return;
		case -545570810 : /* sendZipCode */
			setSendZipCode((java.lang.String) value);
			return;
		case -1468488 : /* sendAddr1 */
			setSendAddr1((java.lang.String) value);
			return;
		case -1468487 : /* sendAddr2 */
			setSendAddr2((java.lang.String) value);
			return;
		case -730962917 : /* sendReceiptname */
			setSendReceiptname((java.lang.String) value);
			return;
		case 2490612 : /* sendEmail */
			setSendEmail((java.lang.String) value);
			return;
		case -1859605943 : /* bankCode */
			setBankCode((java.lang.String) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 277175989 : /* depositOwner */
			setDepositOwner((java.lang.String) value);
			return;
		case -1701238992 : /* agentName */
			setAgentName((java.lang.String) value);
			return;
		case 1469146345 : /* agentRrn */
			setAgentRrn((java.lang.String) value);
			return;
		case -1196743319 : /* agentPhone */
			setAgentPhone((java.lang.String) value);
			return;
		case 1180622344 : /* agentCellno */
			setAgentCellno((java.lang.String) value);
			return;
		case 1469134296 : /* agentFax */
			setAgentFax((java.lang.String) value);
			return;
		case 1294292457 : /* agentZipCode */
			setAgentZipCode((java.lang.String) value);
			return;
		case -1210725797 : /* agentAddr1 */
			setAgentAddr1((java.lang.String) value);
			return;
		case -1210725796 : /* agentAddr2 */
			setAgentAddr2((java.lang.String) value);
			return;
		case -1206766697 : /* agentEmail */
			setAgentEmail((java.lang.String) value);
			return;
		case 2031494694 : /* foreignTag */
			setForeignTag((java.lang.String) value);
			return;
		case -297022149 : /* foreignNation */
			setForeignNation((java.lang.String) value);
			return;
		case -508897270 : /* companyCode */
			setCompanyCode((java.lang.String) value);
			return;
		case -999698710 : /* projCode */
			setProjCode((java.lang.String) value);
			return;
		case -1418420696 : /* incomeDiv */
			setIncomeDiv((java.lang.String) value);
			return;
		case 1944422393 : /* custGroupCode */
			setCustGroupCode((java.lang.String) value);
			return;
		case 2997345 : /* amYn */
			setAmYn((java.lang.String) value);
			return;
		case 3563374 : /* tmYn */
			setTmYn((java.lang.String) value);
			return;
		case 3197233 : /* hdYn */
			setHdYn((java.lang.String) value);
			return;
		case 3354837 : /* mmYn */
			setMmYn((java.lang.String) value);
			return;
		case 1962241975 : /* hdPassword */
			setHdPassword((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -735721945 : /* fileName */
			setFileName((java.lang.String) value);
			return;
		case 604890804 : /* custDiv2 */
			setCustDiv2((java.lang.String) value);
			return;
		case 1223741270 : /* zipCodeOrg */
			setZipCodeOrg((java.lang.String) value);
			return;
		case -1220298652 : /* addr1Org */
			setAddr1Org((java.lang.String) value);
			return;
		case -1220268861 : /* addr2Org */
			setAddr2Org((java.lang.String) value);
			return;
		case -1147708951 : /* addrTag */
			setAddrTag((java.lang.String) value);
			return;
		case -1949717445 : /* agentZipCodeOrg */
			setAgentZipCodeOrg((java.lang.String) value);
			return;
		case 403212937 : /* agentAddr1Org */
			setAgentAddr1Org((java.lang.String) value);
			return;
		case 403242728 : /* agentAddr2Org */
			setAgentAddr2Org((java.lang.String) value);
			return;
		case 428683044 : /* agentAddrTag */
			setAgentAddrTag((java.lang.String) value);
			return;
		case -943673090 : /* sendZipCodeOrg */
			setSendZipCodeOrg((java.lang.String) value);
			return;
		case -797973492 : /* sendAddr1Org */
			setSendAddr1Org((java.lang.String) value);
			return;
		case -797943701 : /* sendAddr2Org */
			setSendAddr2Org((java.lang.String) value);
			return;
		case -1411180223 : /* sendAddrTag */
			setSendAddrTag((java.lang.String) value);
			return;
		case 1570985298 : /* custCode2 */
			setCustCode2((java.lang.String) value);
			return;
		case -865492497 : /* triTag */
			setTriTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
