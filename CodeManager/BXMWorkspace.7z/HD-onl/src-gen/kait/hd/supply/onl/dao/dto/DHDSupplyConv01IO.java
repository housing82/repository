/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.supply.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_자료변환_세대별공급내역 ( HD_SUPPLY_CONV )
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "square", "type", "classJrw", "options", "exclusivearea", "commonarea", "etccommonarea", "parkingarea", "servicearea", "sitearea", "totSupplyamt", "totLandamt", "totBuildamt", "totVatamt", "totManageamt", "amt00", "amt00L", "amt00B", "amt00V", "amt00M", "amt01", "amt01L", "amt01B", "amt01V", "amt01M", "amt02", "amt02L", "amt02B", "amt02V", "amt02M", "amt11", "amt11L", "amt11B", "amt11V", "amt11M", "amt12", "amt12L", "amt12B", "amt12V", "amt12M", "amt13", "amt13L", "amt13B", "amt13V", "amt13M", "amt14", "amt14L", "amt14B", "amt14V", "amt14M", "amt15", "amt15L", "amt15B", "amt15V", "amt15M", "amt16", "amt16L", "amt16B", "amt16V", "amt16M", "amt17", "amt17L", "amt17B", "amt17V", "amt17M", "amt18", "amt18L", "amt18B", "amt18V", "amt18M", "amt19", "amt19L", "amt19B", "amt19V", "amt19M", "amt20", "amt20L", "amt20B", "amt20V", "amt20M", "amt90", "amt90L", "amt90B", "amt90V", "amt90M"}, name="DHDSupplyConv01IO")
@XmlRootElement(name="DHDSupplyConv01IO")
@SuppressWarnings("all")
public class DHDSupplyConv01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1387675740L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_자료변환_세대별공급내역 ( HD_SUPPLY_CONV )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012833(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012833(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012833(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012834(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012834(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012834(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012835(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012835(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012835(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012836(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012836(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012836(C),SYS_C0013020(P) XPKHD_SUPPLY_CONV(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 평형
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 평형
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 평형
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 평형
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << type >> [[ */
	
	@XmlTransient
	private boolean isSet_type = false;
	
	protected boolean isSet_type()
	{
		return this.isSet_type;
	}
	
	protected void setIsSet_type(boolean value)
	{
		this.isSet_type = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="TYPE", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String type  = null;
	
	/**
	 * @Description TYPE
	 */
	public java.lang.String getType(){
		return type;
	}
	
	/**
	 * @Description TYPE
	 */
	@JsonProperty("type")
	public void setType( java.lang.String type ) {
		isSet_type = true;
		this.type = type;
	}
	
	/** Property set << type >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << classJrw >> [[ */
	
	@XmlTransient
	private boolean isSet_classJrw = false;
	
	protected boolean isSet_classJrw()
	{
		return this.isSet_classJrw;
	}
	
	protected void setIsSet_classJrw(boolean value)
	{
		this.isSet_classJrw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="군", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String classJrw  = null;
	
	/**
	 * @Description 군
	 */
	public java.lang.String getClassJrw(){
		return classJrw;
	}
	
	/**
	 * @Description 군
	 */
	@JsonProperty("classJrw")
	public void setClassJrw( java.lang.String classJrw ) {
		isSet_classJrw = true;
		this.classJrw = classJrw;
	}
	
	/** Property set << classJrw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << options >> [[ */
	
	@XmlTransient
	private boolean isSet_options = false;
	
	protected boolean isSet_options()
	{
		return this.isSet_options;
	}
	
	protected void setIsSet_options(boolean value)
	{
		this.isSet_options = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선택사양코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String options  = null;
	
	/**
	 * @Description 선택사양코드
	 */
	public java.lang.String getOptions(){
		return options;
	}
	
	/**
	 * @Description 선택사양코드
	 */
	@JsonProperty("options")
	public void setOptions( java.lang.String options ) {
		isSet_options = true;
		this.options = options;
	}
	
	/** Property set << options >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exclusivearea >> [[ */
	
	@XmlTransient
	private boolean isSet_exclusivearea = false;
	
	protected boolean isSet_exclusivearea()
	{
		return this.isSet_exclusivearea;
	}
	
	protected void setIsSet_exclusivearea(boolean value)
	{
		this.isSet_exclusivearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전용면적
	 */
	public void setExclusivearea(java.lang.String value) {
		isSet_exclusivearea = true;
		this.exclusivearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전용면적
	 */
	public void setExclusivearea(double value) {
		isSet_exclusivearea = true;
		this.exclusivearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전용면적
	 */
	public void setExclusivearea(long value) {
		isSet_exclusivearea = true;
		this.exclusivearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전용면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal exclusivearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전용면적
	 */
	public java.math.BigDecimal getExclusivearea(){
		return exclusivearea;
	}
	
	/**
	 * @Description 전용면적
	 */
	@JsonProperty("exclusivearea")
	public void setExclusivearea( java.math.BigDecimal exclusivearea ) {
		isSet_exclusivearea = true;
		this.exclusivearea = exclusivearea;
	}
	
	/** Property set << exclusivearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << commonarea >> [[ */
	
	@XmlTransient
	private boolean isSet_commonarea = false;
	
	protected boolean isSet_commonarea()
	{
		return this.isSet_commonarea;
	}
	
	protected void setIsSet_commonarea(boolean value)
	{
		this.isSet_commonarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주거공용면적
	 */
	public void setCommonarea(java.lang.String value) {
		isSet_commonarea = true;
		this.commonarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주거공용면적
	 */
	public void setCommonarea(double value) {
		isSet_commonarea = true;
		this.commonarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주거공용면적
	 */
	public void setCommonarea(long value) {
		isSet_commonarea = true;
		this.commonarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주거공용면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal commonarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주거공용면적
	 */
	public java.math.BigDecimal getCommonarea(){
		return commonarea;
	}
	
	/**
	 * @Description 주거공용면적
	 */
	@JsonProperty("commonarea")
	public void setCommonarea( java.math.BigDecimal commonarea ) {
		isSet_commonarea = true;
		this.commonarea = commonarea;
	}
	
	/** Property set << commonarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etccommonarea >> [[ */
	
	@XmlTransient
	private boolean isSet_etccommonarea = false;
	
	protected boolean isSet_etccommonarea()
	{
		return this.isSet_etccommonarea;
	}
	
	protected void setIsSet_etccommonarea(boolean value)
	{
		this.isSet_etccommonarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공용면적
	 */
	public void setEtccommonarea(java.lang.String value) {
		isSet_etccommonarea = true;
		this.etccommonarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공용면적
	 */
	public void setEtccommonarea(double value) {
		isSet_etccommonarea = true;
		this.etccommonarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공용면적
	 */
	public void setEtccommonarea(long value) {
		isSet_etccommonarea = true;
		this.etccommonarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공용면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal etccommonarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공용면적
	 */
	public java.math.BigDecimal getEtccommonarea(){
		return etccommonarea;
	}
	
	/**
	 * @Description 기타공용면적
	 */
	@JsonProperty("etccommonarea")
	public void setEtccommonarea( java.math.BigDecimal etccommonarea ) {
		isSet_etccommonarea = true;
		this.etccommonarea = etccommonarea;
	}
	
	/** Property set << etccommonarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << parkingarea >> [[ */
	
	@XmlTransient
	private boolean isSet_parkingarea = false;
	
	protected boolean isSet_parkingarea()
	{
		return this.isSet_parkingarea;
	}
	
	protected void setIsSet_parkingarea(boolean value)
	{
		this.isSet_parkingarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주차장면적
	 */
	public void setParkingarea(java.lang.String value) {
		isSet_parkingarea = true;
		this.parkingarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주차장면적
	 */
	public void setParkingarea(double value) {
		isSet_parkingarea = true;
		this.parkingarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주차장면적
	 */
	public void setParkingarea(long value) {
		isSet_parkingarea = true;
		this.parkingarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주차장면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal parkingarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주차장면적
	 */
	public java.math.BigDecimal getParkingarea(){
		return parkingarea;
	}
	
	/**
	 * @Description 주차장면적
	 */
	@JsonProperty("parkingarea")
	public void setParkingarea( java.math.BigDecimal parkingarea ) {
		isSet_parkingarea = true;
		this.parkingarea = parkingarea;
	}
	
	/** Property set << parkingarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << servicearea >> [[ */
	
	@XmlTransient
	private boolean isSet_servicearea = false;
	
	protected boolean isSet_servicearea()
	{
		return this.isSet_servicearea;
	}
	
	protected void setIsSet_servicearea(boolean value)
	{
		this.isSet_servicearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 서비스면적
	 */
	public void setServicearea(java.lang.String value) {
		isSet_servicearea = true;
		this.servicearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 서비스면적
	 */
	public void setServicearea(double value) {
		isSet_servicearea = true;
		this.servicearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 서비스면적
	 */
	public void setServicearea(long value) {
		isSet_servicearea = true;
		this.servicearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="서비스면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal servicearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 서비스면적
	 */
	public java.math.BigDecimal getServicearea(){
		return servicearea;
	}
	
	/**
	 * @Description 서비스면적
	 */
	@JsonProperty("servicearea")
	public void setServicearea( java.math.BigDecimal servicearea ) {
		isSet_servicearea = true;
		this.servicearea = servicearea;
	}
	
	/** Property set << servicearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sitearea >> [[ */
	
	@XmlTransient
	private boolean isSet_sitearea = false;
	
	protected boolean isSet_sitearea()
	{
		return this.isSet_sitearea;
	}
	
	protected void setIsSet_sitearea(boolean value)
	{
		this.isSet_sitearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 대지면적
	 */
	public void setSitearea(java.lang.String value) {
		isSet_sitearea = true;
		this.sitearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 대지면적
	 */
	public void setSitearea(double value) {
		isSet_sitearea = true;
		this.sitearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 대지면적
	 */
	public void setSitearea(long value) {
		isSet_sitearea = true;
		this.sitearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="대지면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sitearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 대지면적
	 */
	public java.math.BigDecimal getSitearea(){
		return sitearea;
	}
	
	/**
	 * @Description 대지면적
	 */
	@JsonProperty("sitearea")
	public void setSitearea( java.math.BigDecimal sitearea ) {
		isSet_sitearea = true;
		this.sitearea = sitearea;
	}
	
	/** Property set << sitearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << totSupplyamt >> [[ */
	
	@XmlTransient
	private boolean isSet_totSupplyamt = false;
	
	protected boolean isSet_totSupplyamt()
	{
		return this.isSet_totSupplyamt;
	}
	
	protected void setIsSet_totSupplyamt(boolean value)
	{
		this.isSet_totSupplyamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 총분양가
	 */
	public void setTotSupplyamt(java.lang.String value) {
		isSet_totSupplyamt = true;
		this.totSupplyamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 총분양가
	 */
	public void setTotSupplyamt(double value) {
		isSet_totSupplyamt = true;
		this.totSupplyamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 총분양가
	 */
	public void setTotSupplyamt(long value) {
		isSet_totSupplyamt = true;
		this.totSupplyamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="총분양가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal totSupplyamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 총분양가
	 */
	public java.math.BigDecimal getTotSupplyamt(){
		return totSupplyamt;
	}
	
	/**
	 * @Description 총분양가
	 */
	@JsonProperty("totSupplyamt")
	public void setTotSupplyamt( java.math.BigDecimal totSupplyamt ) {
		isSet_totSupplyamt = true;
		this.totSupplyamt = totSupplyamt;
	}
	
	/** Property set << totSupplyamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << totLandamt >> [[ */
	
	@XmlTransient
	private boolean isSet_totLandamt = false;
	
	protected boolean isSet_totLandamt()
	{
		return this.isSet_totLandamt;
	}
	
	protected void setIsSet_totLandamt(boolean value)
	{
		this.isSet_totLandamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 토지가
	 */
	public void setTotLandamt(java.lang.String value) {
		isSet_totLandamt = true;
		this.totLandamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 토지가
	 */
	public void setTotLandamt(double value) {
		isSet_totLandamt = true;
		this.totLandamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 토지가
	 */
	public void setTotLandamt(long value) {
		isSet_totLandamt = true;
		this.totLandamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="토지가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal totLandamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 토지가
	 */
	public java.math.BigDecimal getTotLandamt(){
		return totLandamt;
	}
	
	/**
	 * @Description 토지가
	 */
	@JsonProperty("totLandamt")
	public void setTotLandamt( java.math.BigDecimal totLandamt ) {
		isSet_totLandamt = true;
		this.totLandamt = totLandamt;
	}
	
	/** Property set << totLandamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << totBuildamt >> [[ */
	
	@XmlTransient
	private boolean isSet_totBuildamt = false;
	
	protected boolean isSet_totBuildamt()
	{
		return this.isSet_totBuildamt;
	}
	
	protected void setIsSet_totBuildamt(boolean value)
	{
		this.isSet_totBuildamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 건물가
	 */
	public void setTotBuildamt(java.lang.String value) {
		isSet_totBuildamt = true;
		this.totBuildamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 건물가
	 */
	public void setTotBuildamt(double value) {
		isSet_totBuildamt = true;
		this.totBuildamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 건물가
	 */
	public void setTotBuildamt(long value) {
		isSet_totBuildamt = true;
		this.totBuildamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="건물가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal totBuildamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 건물가
	 */
	public java.math.BigDecimal getTotBuildamt(){
		return totBuildamt;
	}
	
	/**
	 * @Description 건물가
	 */
	@JsonProperty("totBuildamt")
	public void setTotBuildamt( java.math.BigDecimal totBuildamt ) {
		isSet_totBuildamt = true;
		this.totBuildamt = totBuildamt;
	}
	
	/** Property set << totBuildamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << totVatamt >> [[ */
	
	@XmlTransient
	private boolean isSet_totVatamt = false;
	
	protected boolean isSet_totVatamt()
	{
		return this.isSet_totVatamt;
	}
	
	protected void setIsSet_totVatamt(boolean value)
	{
		this.isSet_totVatamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 부가세
	 */
	public void setTotVatamt(java.lang.String value) {
		isSet_totVatamt = true;
		this.totVatamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 부가세
	 */
	public void setTotVatamt(double value) {
		isSet_totVatamt = true;
		this.totVatamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 부가세
	 */
	public void setTotVatamt(long value) {
		isSet_totVatamt = true;
		this.totVatamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="부가세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal totVatamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 부가세
	 */
	public java.math.BigDecimal getTotVatamt(){
		return totVatamt;
	}
	
	/**
	 * @Description 부가세
	 */
	@JsonProperty("totVatamt")
	public void setTotVatamt( java.math.BigDecimal totVatamt ) {
		isSet_totVatamt = true;
		this.totVatamt = totVatamt;
	}
	
	/** Property set << totVatamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << totManageamt >> [[ */
	
	@XmlTransient
	private boolean isSet_totManageamt = false;
	
	protected boolean isSet_totManageamt()
	{
		return this.isSet_totManageamt;
	}
	
	protected void setIsSet_totManageamt(boolean value)
	{
		this.isSet_totManageamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 관리비
	 */
	public void setTotManageamt(java.lang.String value) {
		isSet_totManageamt = true;
		this.totManageamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 관리비
	 */
	public void setTotManageamt(double value) {
		isSet_totManageamt = true;
		this.totManageamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 관리비
	 */
	public void setTotManageamt(long value) {
		isSet_totManageamt = true;
		this.totManageamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="관리비", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal totManageamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 관리비
	 */
	public java.math.BigDecimal getTotManageamt(){
		return totManageamt;
	}
	
	/**
	 * @Description 관리비
	 */
	@JsonProperty("totManageamt")
	public void setTotManageamt( java.math.BigDecimal totManageamt ) {
		isSet_totManageamt = true;
		this.totManageamt = totManageamt;
	}
	
	/** Property set << totManageamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt00 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt00 = false;
	
	protected boolean isSet_amt00()
	{
		return this.isSet_amt00;
	}
	
	protected void setIsSet_amt00(boolean value)
	{
		this.isSet_amt00 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금
	 */
	public void setAmt00(java.lang.String value) {
		isSet_amt00 = true;
		this.amt00 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금
	 */
	public void setAmt00(double value) {
		isSet_amt00 = true;
		this.amt00 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금
	 */
	public void setAmt00(long value) {
		isSet_amt00 = true;
		this.amt00 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt00  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금
	 */
	public java.math.BigDecimal getAmt00(){
		return amt00;
	}
	
	/**
	 * @Description 계약금
	 */
	@JsonProperty("amt00")
	public void setAmt00( java.math.BigDecimal amt00 ) {
		isSet_amt00 = true;
		this.amt00 = amt00;
	}
	
	/** Property set << amt00 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt00L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt00L = false;
	
	protected boolean isSet_amt00L()
	{
		return this.isSet_amt00L;
	}
	
	protected void setIsSet_amt00L(boolean value)
	{
		this.isSet_amt00L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금_토
	 */
	public void setAmt00L(java.lang.String value) {
		isSet_amt00L = true;
		this.amt00L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금_토
	 */
	public void setAmt00L(double value) {
		isSet_amt00L = true;
		this.amt00L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금_토
	 */
	public void setAmt00L(long value) {
		isSet_amt00L = true;
		this.amt00L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt00L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금_토
	 */
	public java.math.BigDecimal getAmt00L(){
		return amt00L;
	}
	
	/**
	 * @Description 계약금_토
	 */
	@JsonProperty("amt00L")
	public void setAmt00L( java.math.BigDecimal amt00L ) {
		isSet_amt00L = true;
		this.amt00L = amt00L;
	}
	
	/** Property set << amt00L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt00B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt00B = false;
	
	protected boolean isSet_amt00B()
	{
		return this.isSet_amt00B;
	}
	
	protected void setIsSet_amt00B(boolean value)
	{
		this.isSet_amt00B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금_건
	 */
	public void setAmt00B(java.lang.String value) {
		isSet_amt00B = true;
		this.amt00B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금_건
	 */
	public void setAmt00B(double value) {
		isSet_amt00B = true;
		this.amt00B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금_건
	 */
	public void setAmt00B(long value) {
		isSet_amt00B = true;
		this.amt00B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt00B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금_건
	 */
	public java.math.BigDecimal getAmt00B(){
		return amt00B;
	}
	
	/**
	 * @Description 계약금_건
	 */
	@JsonProperty("amt00B")
	public void setAmt00B( java.math.BigDecimal amt00B ) {
		isSet_amt00B = true;
		this.amt00B = amt00B;
	}
	
	/** Property set << amt00B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt00V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt00V = false;
	
	protected boolean isSet_amt00V()
	{
		return this.isSet_amt00V;
	}
	
	protected void setIsSet_amt00V(boolean value)
	{
		this.isSet_amt00V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금_부
	 */
	public void setAmt00V(java.lang.String value) {
		isSet_amt00V = true;
		this.amt00V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금_부
	 */
	public void setAmt00V(double value) {
		isSet_amt00V = true;
		this.amt00V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금_부
	 */
	public void setAmt00V(long value) {
		isSet_amt00V = true;
		this.amt00V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt00V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금_부
	 */
	public java.math.BigDecimal getAmt00V(){
		return amt00V;
	}
	
	/**
	 * @Description 계약금_부
	 */
	@JsonProperty("amt00V")
	public void setAmt00V( java.math.BigDecimal amt00V ) {
		isSet_amt00V = true;
		this.amt00V = amt00V;
	}
	
	/** Property set << amt00V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt00M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt00M = false;
	
	protected boolean isSet_amt00M()
	{
		return this.isSet_amt00M;
	}
	
	protected void setIsSet_amt00M(boolean value)
	{
		this.isSet_amt00M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금_관
	 */
	public void setAmt00M(java.lang.String value) {
		isSet_amt00M = true;
		this.amt00M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금_관
	 */
	public void setAmt00M(double value) {
		isSet_amt00M = true;
		this.amt00M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금_관
	 */
	public void setAmt00M(long value) {
		isSet_amt00M = true;
		this.amt00M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt00M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금_관
	 */
	public java.math.BigDecimal getAmt00M(){
		return amt00M;
	}
	
	/**
	 * @Description 계약금_관
	 */
	@JsonProperty("amt00M")
	public void setAmt00M( java.math.BigDecimal amt00M ) {
		isSet_amt00M = true;
		this.amt00M = amt00M;
	}
	
	/** Property set << amt00M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt01 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt01 = false;
	
	protected boolean isSet_amt01()
	{
		return this.isSet_amt01;
	}
	
	protected void setIsSet_amt01(boolean value)
	{
		this.isSet_amt01 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금1차
	 */
	public void setAmt01(java.lang.String value) {
		isSet_amt01 = true;
		this.amt01 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금1차
	 */
	public void setAmt01(double value) {
		isSet_amt01 = true;
		this.amt01 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금1차
	 */
	public void setAmt01(long value) {
		isSet_amt01 = true;
		this.amt01 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금1차", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt01  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금1차
	 */
	public java.math.BigDecimal getAmt01(){
		return amt01;
	}
	
	/**
	 * @Description 계약금1차
	 */
	@JsonProperty("amt01")
	public void setAmt01( java.math.BigDecimal amt01 ) {
		isSet_amt01 = true;
		this.amt01 = amt01;
	}
	
	/** Property set << amt01 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt01L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt01L = false;
	
	protected boolean isSet_amt01L()
	{
		return this.isSet_amt01L;
	}
	
	protected void setIsSet_amt01L(boolean value)
	{
		this.isSet_amt01L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금1차_토
	 */
	public void setAmt01L(java.lang.String value) {
		isSet_amt01L = true;
		this.amt01L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금1차_토
	 */
	public void setAmt01L(double value) {
		isSet_amt01L = true;
		this.amt01L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금1차_토
	 */
	public void setAmt01L(long value) {
		isSet_amt01L = true;
		this.amt01L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금1차_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt01L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금1차_토
	 */
	public java.math.BigDecimal getAmt01L(){
		return amt01L;
	}
	
	/**
	 * @Description 계약금1차_토
	 */
	@JsonProperty("amt01L")
	public void setAmt01L( java.math.BigDecimal amt01L ) {
		isSet_amt01L = true;
		this.amt01L = amt01L;
	}
	
	/** Property set << amt01L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt01B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt01B = false;
	
	protected boolean isSet_amt01B()
	{
		return this.isSet_amt01B;
	}
	
	protected void setIsSet_amt01B(boolean value)
	{
		this.isSet_amt01B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금1차_건
	 */
	public void setAmt01B(java.lang.String value) {
		isSet_amt01B = true;
		this.amt01B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금1차_건
	 */
	public void setAmt01B(double value) {
		isSet_amt01B = true;
		this.amt01B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금1차_건
	 */
	public void setAmt01B(long value) {
		isSet_amt01B = true;
		this.amt01B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금1차_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt01B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금1차_건
	 */
	public java.math.BigDecimal getAmt01B(){
		return amt01B;
	}
	
	/**
	 * @Description 계약금1차_건
	 */
	@JsonProperty("amt01B")
	public void setAmt01B( java.math.BigDecimal amt01B ) {
		isSet_amt01B = true;
		this.amt01B = amt01B;
	}
	
	/** Property set << amt01B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt01V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt01V = false;
	
	protected boolean isSet_amt01V()
	{
		return this.isSet_amt01V;
	}
	
	protected void setIsSet_amt01V(boolean value)
	{
		this.isSet_amt01V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금1차_부
	 */
	public void setAmt01V(java.lang.String value) {
		isSet_amt01V = true;
		this.amt01V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금1차_부
	 */
	public void setAmt01V(double value) {
		isSet_amt01V = true;
		this.amt01V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금1차_부
	 */
	public void setAmt01V(long value) {
		isSet_amt01V = true;
		this.amt01V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금1차_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt01V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금1차_부
	 */
	public java.math.BigDecimal getAmt01V(){
		return amt01V;
	}
	
	/**
	 * @Description 계약금1차_부
	 */
	@JsonProperty("amt01V")
	public void setAmt01V( java.math.BigDecimal amt01V ) {
		isSet_amt01V = true;
		this.amt01V = amt01V;
	}
	
	/** Property set << amt01V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt01M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt01M = false;
	
	protected boolean isSet_amt01M()
	{
		return this.isSet_amt01M;
	}
	
	protected void setIsSet_amt01M(boolean value)
	{
		this.isSet_amt01M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금1차_관
	 */
	public void setAmt01M(java.lang.String value) {
		isSet_amt01M = true;
		this.amt01M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금1차_관
	 */
	public void setAmt01M(double value) {
		isSet_amt01M = true;
		this.amt01M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금1차_관
	 */
	public void setAmt01M(long value) {
		isSet_amt01M = true;
		this.amt01M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금1차_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt01M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금1차_관
	 */
	public java.math.BigDecimal getAmt01M(){
		return amt01M;
	}
	
	/**
	 * @Description 계약금1차_관
	 */
	@JsonProperty("amt01M")
	public void setAmt01M( java.math.BigDecimal amt01M ) {
		isSet_amt01M = true;
		this.amt01M = amt01M;
	}
	
	/** Property set << amt01M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt02 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt02 = false;
	
	protected boolean isSet_amt02()
	{
		return this.isSet_amt02;
	}
	
	protected void setIsSet_amt02(boolean value)
	{
		this.isSet_amt02 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금2차
	 */
	public void setAmt02(java.lang.String value) {
		isSet_amt02 = true;
		this.amt02 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금2차
	 */
	public void setAmt02(double value) {
		isSet_amt02 = true;
		this.amt02 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금2차
	 */
	public void setAmt02(long value) {
		isSet_amt02 = true;
		this.amt02 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금2차", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt02  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금2차
	 */
	public java.math.BigDecimal getAmt02(){
		return amt02;
	}
	
	/**
	 * @Description 계약금2차
	 */
	@JsonProperty("amt02")
	public void setAmt02( java.math.BigDecimal amt02 ) {
		isSet_amt02 = true;
		this.amt02 = amt02;
	}
	
	/** Property set << amt02 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt02L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt02L = false;
	
	protected boolean isSet_amt02L()
	{
		return this.isSet_amt02L;
	}
	
	protected void setIsSet_amt02L(boolean value)
	{
		this.isSet_amt02L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금2차_토
	 */
	public void setAmt02L(java.lang.String value) {
		isSet_amt02L = true;
		this.amt02L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금2차_토
	 */
	public void setAmt02L(double value) {
		isSet_amt02L = true;
		this.amt02L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금2차_토
	 */
	public void setAmt02L(long value) {
		isSet_amt02L = true;
		this.amt02L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금2차_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt02L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금2차_토
	 */
	public java.math.BigDecimal getAmt02L(){
		return amt02L;
	}
	
	/**
	 * @Description 계약금2차_토
	 */
	@JsonProperty("amt02L")
	public void setAmt02L( java.math.BigDecimal amt02L ) {
		isSet_amt02L = true;
		this.amt02L = amt02L;
	}
	
	/** Property set << amt02L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt02B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt02B = false;
	
	protected boolean isSet_amt02B()
	{
		return this.isSet_amt02B;
	}
	
	protected void setIsSet_amt02B(boolean value)
	{
		this.isSet_amt02B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금2차_건
	 */
	public void setAmt02B(java.lang.String value) {
		isSet_amt02B = true;
		this.amt02B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금2차_건
	 */
	public void setAmt02B(double value) {
		isSet_amt02B = true;
		this.amt02B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금2차_건
	 */
	public void setAmt02B(long value) {
		isSet_amt02B = true;
		this.amt02B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금2차_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt02B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금2차_건
	 */
	public java.math.BigDecimal getAmt02B(){
		return amt02B;
	}
	
	/**
	 * @Description 계약금2차_건
	 */
	@JsonProperty("amt02B")
	public void setAmt02B( java.math.BigDecimal amt02B ) {
		isSet_amt02B = true;
		this.amt02B = amt02B;
	}
	
	/** Property set << amt02B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt02V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt02V = false;
	
	protected boolean isSet_amt02V()
	{
		return this.isSet_amt02V;
	}
	
	protected void setIsSet_amt02V(boolean value)
	{
		this.isSet_amt02V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금2차_부
	 */
	public void setAmt02V(java.lang.String value) {
		isSet_amt02V = true;
		this.amt02V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금2차_부
	 */
	public void setAmt02V(double value) {
		isSet_amt02V = true;
		this.amt02V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금2차_부
	 */
	public void setAmt02V(long value) {
		isSet_amt02V = true;
		this.amt02V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금2차_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt02V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금2차_부
	 */
	public java.math.BigDecimal getAmt02V(){
		return amt02V;
	}
	
	/**
	 * @Description 계약금2차_부
	 */
	@JsonProperty("amt02V")
	public void setAmt02V( java.math.BigDecimal amt02V ) {
		isSet_amt02V = true;
		this.amt02V = amt02V;
	}
	
	/** Property set << amt02V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt02M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt02M = false;
	
	protected boolean isSet_amt02M()
	{
		return this.isSet_amt02M;
	}
	
	protected void setIsSet_amt02M(boolean value)
	{
		this.isSet_amt02M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금2차_관
	 */
	public void setAmt02M(java.lang.String value) {
		isSet_amt02M = true;
		this.amt02M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금2차_관
	 */
	public void setAmt02M(double value) {
		isSet_amt02M = true;
		this.amt02M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금2차_관
	 */
	public void setAmt02M(long value) {
		isSet_amt02M = true;
		this.amt02M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금2차_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt02M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금2차_관
	 */
	public java.math.BigDecimal getAmt02M(){
		return amt02M;
	}
	
	/**
	 * @Description 계약금2차_관
	 */
	@JsonProperty("amt02M")
	public void setAmt02M( java.math.BigDecimal amt02M ) {
		isSet_amt02M = true;
		this.amt02M = amt02M;
	}
	
	/** Property set << amt02M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt11 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt11 = false;
	
	protected boolean isSet_amt11()
	{
		return this.isSet_amt11;
	}
	
	protected void setIsSet_amt11(boolean value)
	{
		this.isSet_amt11 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 1차중도금
	 */
	public void setAmt11(java.lang.String value) {
		isSet_amt11 = true;
		this.amt11 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 1차중도금
	 */
	public void setAmt11(double value) {
		isSet_amt11 = true;
		this.amt11 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 1차중도금
	 */
	public void setAmt11(long value) {
		isSet_amt11 = true;
		this.amt11 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="1차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt11  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 1차중도금
	 */
	public java.math.BigDecimal getAmt11(){
		return amt11;
	}
	
	/**
	 * @Description 1차중도금
	 */
	@JsonProperty("amt11")
	public void setAmt11( java.math.BigDecimal amt11 ) {
		isSet_amt11 = true;
		this.amt11 = amt11;
	}
	
	/** Property set << amt11 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt11L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt11L = false;
	
	protected boolean isSet_amt11L()
	{
		return this.isSet_amt11L;
	}
	
	protected void setIsSet_amt11L(boolean value)
	{
		this.isSet_amt11L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 1차중도금_토
	 */
	public void setAmt11L(java.lang.String value) {
		isSet_amt11L = true;
		this.amt11L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 1차중도금_토
	 */
	public void setAmt11L(double value) {
		isSet_amt11L = true;
		this.amt11L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 1차중도금_토
	 */
	public void setAmt11L(long value) {
		isSet_amt11L = true;
		this.amt11L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="1차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt11L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 1차중도금_토
	 */
	public java.math.BigDecimal getAmt11L(){
		return amt11L;
	}
	
	/**
	 * @Description 1차중도금_토
	 */
	@JsonProperty("amt11L")
	public void setAmt11L( java.math.BigDecimal amt11L ) {
		isSet_amt11L = true;
		this.amt11L = amt11L;
	}
	
	/** Property set << amt11L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt11B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt11B = false;
	
	protected boolean isSet_amt11B()
	{
		return this.isSet_amt11B;
	}
	
	protected void setIsSet_amt11B(boolean value)
	{
		this.isSet_amt11B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 1차중도금_건
	 */
	public void setAmt11B(java.lang.String value) {
		isSet_amt11B = true;
		this.amt11B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 1차중도금_건
	 */
	public void setAmt11B(double value) {
		isSet_amt11B = true;
		this.amt11B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 1차중도금_건
	 */
	public void setAmt11B(long value) {
		isSet_amt11B = true;
		this.amt11B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="1차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt11B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 1차중도금_건
	 */
	public java.math.BigDecimal getAmt11B(){
		return amt11B;
	}
	
	/**
	 * @Description 1차중도금_건
	 */
	@JsonProperty("amt11B")
	public void setAmt11B( java.math.BigDecimal amt11B ) {
		isSet_amt11B = true;
		this.amt11B = amt11B;
	}
	
	/** Property set << amt11B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt11V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt11V = false;
	
	protected boolean isSet_amt11V()
	{
		return this.isSet_amt11V;
	}
	
	protected void setIsSet_amt11V(boolean value)
	{
		this.isSet_amt11V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 1차중도금_부
	 */
	public void setAmt11V(java.lang.String value) {
		isSet_amt11V = true;
		this.amt11V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 1차중도금_부
	 */
	public void setAmt11V(double value) {
		isSet_amt11V = true;
		this.amt11V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 1차중도금_부
	 */
	public void setAmt11V(long value) {
		isSet_amt11V = true;
		this.amt11V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="1차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt11V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 1차중도금_부
	 */
	public java.math.BigDecimal getAmt11V(){
		return amt11V;
	}
	
	/**
	 * @Description 1차중도금_부
	 */
	@JsonProperty("amt11V")
	public void setAmt11V( java.math.BigDecimal amt11V ) {
		isSet_amt11V = true;
		this.amt11V = amt11V;
	}
	
	/** Property set << amt11V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt11M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt11M = false;
	
	protected boolean isSet_amt11M()
	{
		return this.isSet_amt11M;
	}
	
	protected void setIsSet_amt11M(boolean value)
	{
		this.isSet_amt11M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 1차중도금_관
	 */
	public void setAmt11M(java.lang.String value) {
		isSet_amt11M = true;
		this.amt11M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 1차중도금_관
	 */
	public void setAmt11M(double value) {
		isSet_amt11M = true;
		this.amt11M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 1차중도금_관
	 */
	public void setAmt11M(long value) {
		isSet_amt11M = true;
		this.amt11M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="1차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt11M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 1차중도금_관
	 */
	public java.math.BigDecimal getAmt11M(){
		return amt11M;
	}
	
	/**
	 * @Description 1차중도금_관
	 */
	@JsonProperty("amt11M")
	public void setAmt11M( java.math.BigDecimal amt11M ) {
		isSet_amt11M = true;
		this.amt11M = amt11M;
	}
	
	/** Property set << amt11M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt12 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt12 = false;
	
	protected boolean isSet_amt12()
	{
		return this.isSet_amt12;
	}
	
	protected void setIsSet_amt12(boolean value)
	{
		this.isSet_amt12 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 2차중도금
	 */
	public void setAmt12(java.lang.String value) {
		isSet_amt12 = true;
		this.amt12 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 2차중도금
	 */
	public void setAmt12(double value) {
		isSet_amt12 = true;
		this.amt12 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 2차중도금
	 */
	public void setAmt12(long value) {
		isSet_amt12 = true;
		this.amt12 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="2차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt12  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 2차중도금
	 */
	public java.math.BigDecimal getAmt12(){
		return amt12;
	}
	
	/**
	 * @Description 2차중도금
	 */
	@JsonProperty("amt12")
	public void setAmt12( java.math.BigDecimal amt12 ) {
		isSet_amt12 = true;
		this.amt12 = amt12;
	}
	
	/** Property set << amt12 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt12L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt12L = false;
	
	protected boolean isSet_amt12L()
	{
		return this.isSet_amt12L;
	}
	
	protected void setIsSet_amt12L(boolean value)
	{
		this.isSet_amt12L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 2차중도금_토
	 */
	public void setAmt12L(java.lang.String value) {
		isSet_amt12L = true;
		this.amt12L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 2차중도금_토
	 */
	public void setAmt12L(double value) {
		isSet_amt12L = true;
		this.amt12L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 2차중도금_토
	 */
	public void setAmt12L(long value) {
		isSet_amt12L = true;
		this.amt12L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="2차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt12L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 2차중도금_토
	 */
	public java.math.BigDecimal getAmt12L(){
		return amt12L;
	}
	
	/**
	 * @Description 2차중도금_토
	 */
	@JsonProperty("amt12L")
	public void setAmt12L( java.math.BigDecimal amt12L ) {
		isSet_amt12L = true;
		this.amt12L = amt12L;
	}
	
	/** Property set << amt12L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt12B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt12B = false;
	
	protected boolean isSet_amt12B()
	{
		return this.isSet_amt12B;
	}
	
	protected void setIsSet_amt12B(boolean value)
	{
		this.isSet_amt12B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 2차중도금_건
	 */
	public void setAmt12B(java.lang.String value) {
		isSet_amt12B = true;
		this.amt12B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 2차중도금_건
	 */
	public void setAmt12B(double value) {
		isSet_amt12B = true;
		this.amt12B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 2차중도금_건
	 */
	public void setAmt12B(long value) {
		isSet_amt12B = true;
		this.amt12B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="2차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt12B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 2차중도금_건
	 */
	public java.math.BigDecimal getAmt12B(){
		return amt12B;
	}
	
	/**
	 * @Description 2차중도금_건
	 */
	@JsonProperty("amt12B")
	public void setAmt12B( java.math.BigDecimal amt12B ) {
		isSet_amt12B = true;
		this.amt12B = amt12B;
	}
	
	/** Property set << amt12B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt12V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt12V = false;
	
	protected boolean isSet_amt12V()
	{
		return this.isSet_amt12V;
	}
	
	protected void setIsSet_amt12V(boolean value)
	{
		this.isSet_amt12V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 2차중도금_부
	 */
	public void setAmt12V(java.lang.String value) {
		isSet_amt12V = true;
		this.amt12V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 2차중도금_부
	 */
	public void setAmt12V(double value) {
		isSet_amt12V = true;
		this.amt12V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 2차중도금_부
	 */
	public void setAmt12V(long value) {
		isSet_amt12V = true;
		this.amt12V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="2차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt12V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 2차중도금_부
	 */
	public java.math.BigDecimal getAmt12V(){
		return amt12V;
	}
	
	/**
	 * @Description 2차중도금_부
	 */
	@JsonProperty("amt12V")
	public void setAmt12V( java.math.BigDecimal amt12V ) {
		isSet_amt12V = true;
		this.amt12V = amt12V;
	}
	
	/** Property set << amt12V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt12M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt12M = false;
	
	protected boolean isSet_amt12M()
	{
		return this.isSet_amt12M;
	}
	
	protected void setIsSet_amt12M(boolean value)
	{
		this.isSet_amt12M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 2차중도금_관
	 */
	public void setAmt12M(java.lang.String value) {
		isSet_amt12M = true;
		this.amt12M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 2차중도금_관
	 */
	public void setAmt12M(double value) {
		isSet_amt12M = true;
		this.amt12M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 2차중도금_관
	 */
	public void setAmt12M(long value) {
		isSet_amt12M = true;
		this.amt12M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="2차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt12M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 2차중도금_관
	 */
	public java.math.BigDecimal getAmt12M(){
		return amt12M;
	}
	
	/**
	 * @Description 2차중도금_관
	 */
	@JsonProperty("amt12M")
	public void setAmt12M( java.math.BigDecimal amt12M ) {
		isSet_amt12M = true;
		this.amt12M = amt12M;
	}
	
	/** Property set << amt12M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt13 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt13 = false;
	
	protected boolean isSet_amt13()
	{
		return this.isSet_amt13;
	}
	
	protected void setIsSet_amt13(boolean value)
	{
		this.isSet_amt13 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 3차중도금
	 */
	public void setAmt13(java.lang.String value) {
		isSet_amt13 = true;
		this.amt13 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 3차중도금
	 */
	public void setAmt13(double value) {
		isSet_amt13 = true;
		this.amt13 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 3차중도금
	 */
	public void setAmt13(long value) {
		isSet_amt13 = true;
		this.amt13 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="3차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt13  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 3차중도금
	 */
	public java.math.BigDecimal getAmt13(){
		return amt13;
	}
	
	/**
	 * @Description 3차중도금
	 */
	@JsonProperty("amt13")
	public void setAmt13( java.math.BigDecimal amt13 ) {
		isSet_amt13 = true;
		this.amt13 = amt13;
	}
	
	/** Property set << amt13 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt13L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt13L = false;
	
	protected boolean isSet_amt13L()
	{
		return this.isSet_amt13L;
	}
	
	protected void setIsSet_amt13L(boolean value)
	{
		this.isSet_amt13L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 3차중도금_토
	 */
	public void setAmt13L(java.lang.String value) {
		isSet_amt13L = true;
		this.amt13L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 3차중도금_토
	 */
	public void setAmt13L(double value) {
		isSet_amt13L = true;
		this.amt13L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 3차중도금_토
	 */
	public void setAmt13L(long value) {
		isSet_amt13L = true;
		this.amt13L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="3차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt13L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 3차중도금_토
	 */
	public java.math.BigDecimal getAmt13L(){
		return amt13L;
	}
	
	/**
	 * @Description 3차중도금_토
	 */
	@JsonProperty("amt13L")
	public void setAmt13L( java.math.BigDecimal amt13L ) {
		isSet_amt13L = true;
		this.amt13L = amt13L;
	}
	
	/** Property set << amt13L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt13B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt13B = false;
	
	protected boolean isSet_amt13B()
	{
		return this.isSet_amt13B;
	}
	
	protected void setIsSet_amt13B(boolean value)
	{
		this.isSet_amt13B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 3차중도금_건
	 */
	public void setAmt13B(java.lang.String value) {
		isSet_amt13B = true;
		this.amt13B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 3차중도금_건
	 */
	public void setAmt13B(double value) {
		isSet_amt13B = true;
		this.amt13B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 3차중도금_건
	 */
	public void setAmt13B(long value) {
		isSet_amt13B = true;
		this.amt13B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="3차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt13B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 3차중도금_건
	 */
	public java.math.BigDecimal getAmt13B(){
		return amt13B;
	}
	
	/**
	 * @Description 3차중도금_건
	 */
	@JsonProperty("amt13B")
	public void setAmt13B( java.math.BigDecimal amt13B ) {
		isSet_amt13B = true;
		this.amt13B = amt13B;
	}
	
	/** Property set << amt13B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt13V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt13V = false;
	
	protected boolean isSet_amt13V()
	{
		return this.isSet_amt13V;
	}
	
	protected void setIsSet_amt13V(boolean value)
	{
		this.isSet_amt13V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 3차중도금_부
	 */
	public void setAmt13V(java.lang.String value) {
		isSet_amt13V = true;
		this.amt13V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 3차중도금_부
	 */
	public void setAmt13V(double value) {
		isSet_amt13V = true;
		this.amt13V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 3차중도금_부
	 */
	public void setAmt13V(long value) {
		isSet_amt13V = true;
		this.amt13V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="3차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt13V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 3차중도금_부
	 */
	public java.math.BigDecimal getAmt13V(){
		return amt13V;
	}
	
	/**
	 * @Description 3차중도금_부
	 */
	@JsonProperty("amt13V")
	public void setAmt13V( java.math.BigDecimal amt13V ) {
		isSet_amt13V = true;
		this.amt13V = amt13V;
	}
	
	/** Property set << amt13V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt13M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt13M = false;
	
	protected boolean isSet_amt13M()
	{
		return this.isSet_amt13M;
	}
	
	protected void setIsSet_amt13M(boolean value)
	{
		this.isSet_amt13M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 3차중도금_관
	 */
	public void setAmt13M(java.lang.String value) {
		isSet_amt13M = true;
		this.amt13M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 3차중도금_관
	 */
	public void setAmt13M(double value) {
		isSet_amt13M = true;
		this.amt13M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 3차중도금_관
	 */
	public void setAmt13M(long value) {
		isSet_amt13M = true;
		this.amt13M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="3차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt13M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 3차중도금_관
	 */
	public java.math.BigDecimal getAmt13M(){
		return amt13M;
	}
	
	/**
	 * @Description 3차중도금_관
	 */
	@JsonProperty("amt13M")
	public void setAmt13M( java.math.BigDecimal amt13M ) {
		isSet_amt13M = true;
		this.amt13M = amt13M;
	}
	
	/** Property set << amt13M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt14 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt14 = false;
	
	protected boolean isSet_amt14()
	{
		return this.isSet_amt14;
	}
	
	protected void setIsSet_amt14(boolean value)
	{
		this.isSet_amt14 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 4차중도금
	 */
	public void setAmt14(java.lang.String value) {
		isSet_amt14 = true;
		this.amt14 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 4차중도금
	 */
	public void setAmt14(double value) {
		isSet_amt14 = true;
		this.amt14 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 4차중도금
	 */
	public void setAmt14(long value) {
		isSet_amt14 = true;
		this.amt14 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="4차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt14  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 4차중도금
	 */
	public java.math.BigDecimal getAmt14(){
		return amt14;
	}
	
	/**
	 * @Description 4차중도금
	 */
	@JsonProperty("amt14")
	public void setAmt14( java.math.BigDecimal amt14 ) {
		isSet_amt14 = true;
		this.amt14 = amt14;
	}
	
	/** Property set << amt14 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt14L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt14L = false;
	
	protected boolean isSet_amt14L()
	{
		return this.isSet_amt14L;
	}
	
	protected void setIsSet_amt14L(boolean value)
	{
		this.isSet_amt14L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 4차중도금_토
	 */
	public void setAmt14L(java.lang.String value) {
		isSet_amt14L = true;
		this.amt14L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 4차중도금_토
	 */
	public void setAmt14L(double value) {
		isSet_amt14L = true;
		this.amt14L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 4차중도금_토
	 */
	public void setAmt14L(long value) {
		isSet_amt14L = true;
		this.amt14L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="4차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt14L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 4차중도금_토
	 */
	public java.math.BigDecimal getAmt14L(){
		return amt14L;
	}
	
	/**
	 * @Description 4차중도금_토
	 */
	@JsonProperty("amt14L")
	public void setAmt14L( java.math.BigDecimal amt14L ) {
		isSet_amt14L = true;
		this.amt14L = amt14L;
	}
	
	/** Property set << amt14L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt14B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt14B = false;
	
	protected boolean isSet_amt14B()
	{
		return this.isSet_amt14B;
	}
	
	protected void setIsSet_amt14B(boolean value)
	{
		this.isSet_amt14B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 4차중도금_건
	 */
	public void setAmt14B(java.lang.String value) {
		isSet_amt14B = true;
		this.amt14B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 4차중도금_건
	 */
	public void setAmt14B(double value) {
		isSet_amt14B = true;
		this.amt14B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 4차중도금_건
	 */
	public void setAmt14B(long value) {
		isSet_amt14B = true;
		this.amt14B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="4차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt14B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 4차중도금_건
	 */
	public java.math.BigDecimal getAmt14B(){
		return amt14B;
	}
	
	/**
	 * @Description 4차중도금_건
	 */
	@JsonProperty("amt14B")
	public void setAmt14B( java.math.BigDecimal amt14B ) {
		isSet_amt14B = true;
		this.amt14B = amt14B;
	}
	
	/** Property set << amt14B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt14V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt14V = false;
	
	protected boolean isSet_amt14V()
	{
		return this.isSet_amt14V;
	}
	
	protected void setIsSet_amt14V(boolean value)
	{
		this.isSet_amt14V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 4차중도금_부
	 */
	public void setAmt14V(java.lang.String value) {
		isSet_amt14V = true;
		this.amt14V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 4차중도금_부
	 */
	public void setAmt14V(double value) {
		isSet_amt14V = true;
		this.amt14V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 4차중도금_부
	 */
	public void setAmt14V(long value) {
		isSet_amt14V = true;
		this.amt14V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="4차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt14V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 4차중도금_부
	 */
	public java.math.BigDecimal getAmt14V(){
		return amt14V;
	}
	
	/**
	 * @Description 4차중도금_부
	 */
	@JsonProperty("amt14V")
	public void setAmt14V( java.math.BigDecimal amt14V ) {
		isSet_amt14V = true;
		this.amt14V = amt14V;
	}
	
	/** Property set << amt14V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt14M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt14M = false;
	
	protected boolean isSet_amt14M()
	{
		return this.isSet_amt14M;
	}
	
	protected void setIsSet_amt14M(boolean value)
	{
		this.isSet_amt14M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 4차중도금_관
	 */
	public void setAmt14M(java.lang.String value) {
		isSet_amt14M = true;
		this.amt14M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 4차중도금_관
	 */
	public void setAmt14M(double value) {
		isSet_amt14M = true;
		this.amt14M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 4차중도금_관
	 */
	public void setAmt14M(long value) {
		isSet_amt14M = true;
		this.amt14M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="4차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt14M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 4차중도금_관
	 */
	public java.math.BigDecimal getAmt14M(){
		return amt14M;
	}
	
	/**
	 * @Description 4차중도금_관
	 */
	@JsonProperty("amt14M")
	public void setAmt14M( java.math.BigDecimal amt14M ) {
		isSet_amt14M = true;
		this.amt14M = amt14M;
	}
	
	/** Property set << amt14M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt15 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt15 = false;
	
	protected boolean isSet_amt15()
	{
		return this.isSet_amt15;
	}
	
	protected void setIsSet_amt15(boolean value)
	{
		this.isSet_amt15 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 5차중도금
	 */
	public void setAmt15(java.lang.String value) {
		isSet_amt15 = true;
		this.amt15 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 5차중도금
	 */
	public void setAmt15(double value) {
		isSet_amt15 = true;
		this.amt15 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 5차중도금
	 */
	public void setAmt15(long value) {
		isSet_amt15 = true;
		this.amt15 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="5차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt15  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 5차중도금
	 */
	public java.math.BigDecimal getAmt15(){
		return amt15;
	}
	
	/**
	 * @Description 5차중도금
	 */
	@JsonProperty("amt15")
	public void setAmt15( java.math.BigDecimal amt15 ) {
		isSet_amt15 = true;
		this.amt15 = amt15;
	}
	
	/** Property set << amt15 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt15L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt15L = false;
	
	protected boolean isSet_amt15L()
	{
		return this.isSet_amt15L;
	}
	
	protected void setIsSet_amt15L(boolean value)
	{
		this.isSet_amt15L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 5차중도금_토
	 */
	public void setAmt15L(java.lang.String value) {
		isSet_amt15L = true;
		this.amt15L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 5차중도금_토
	 */
	public void setAmt15L(double value) {
		isSet_amt15L = true;
		this.amt15L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 5차중도금_토
	 */
	public void setAmt15L(long value) {
		isSet_amt15L = true;
		this.amt15L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="5차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt15L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 5차중도금_토
	 */
	public java.math.BigDecimal getAmt15L(){
		return amt15L;
	}
	
	/**
	 * @Description 5차중도금_토
	 */
	@JsonProperty("amt15L")
	public void setAmt15L( java.math.BigDecimal amt15L ) {
		isSet_amt15L = true;
		this.amt15L = amt15L;
	}
	
	/** Property set << amt15L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt15B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt15B = false;
	
	protected boolean isSet_amt15B()
	{
		return this.isSet_amt15B;
	}
	
	protected void setIsSet_amt15B(boolean value)
	{
		this.isSet_amt15B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 5차중도금_건
	 */
	public void setAmt15B(java.lang.String value) {
		isSet_amt15B = true;
		this.amt15B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 5차중도금_건
	 */
	public void setAmt15B(double value) {
		isSet_amt15B = true;
		this.amt15B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 5차중도금_건
	 */
	public void setAmt15B(long value) {
		isSet_amt15B = true;
		this.amt15B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="5차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt15B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 5차중도금_건
	 */
	public java.math.BigDecimal getAmt15B(){
		return amt15B;
	}
	
	/**
	 * @Description 5차중도금_건
	 */
	@JsonProperty("amt15B")
	public void setAmt15B( java.math.BigDecimal amt15B ) {
		isSet_amt15B = true;
		this.amt15B = amt15B;
	}
	
	/** Property set << amt15B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt15V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt15V = false;
	
	protected boolean isSet_amt15V()
	{
		return this.isSet_amt15V;
	}
	
	protected void setIsSet_amt15V(boolean value)
	{
		this.isSet_amt15V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 5차중도금_부
	 */
	public void setAmt15V(java.lang.String value) {
		isSet_amt15V = true;
		this.amt15V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 5차중도금_부
	 */
	public void setAmt15V(double value) {
		isSet_amt15V = true;
		this.amt15V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 5차중도금_부
	 */
	public void setAmt15V(long value) {
		isSet_amt15V = true;
		this.amt15V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="5차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt15V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 5차중도금_부
	 */
	public java.math.BigDecimal getAmt15V(){
		return amt15V;
	}
	
	/**
	 * @Description 5차중도금_부
	 */
	@JsonProperty("amt15V")
	public void setAmt15V( java.math.BigDecimal amt15V ) {
		isSet_amt15V = true;
		this.amt15V = amt15V;
	}
	
	/** Property set << amt15V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt15M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt15M = false;
	
	protected boolean isSet_amt15M()
	{
		return this.isSet_amt15M;
	}
	
	protected void setIsSet_amt15M(boolean value)
	{
		this.isSet_amt15M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 5차중도금_관
	 */
	public void setAmt15M(java.lang.String value) {
		isSet_amt15M = true;
		this.amt15M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 5차중도금_관
	 */
	public void setAmt15M(double value) {
		isSet_amt15M = true;
		this.amt15M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 5차중도금_관
	 */
	public void setAmt15M(long value) {
		isSet_amt15M = true;
		this.amt15M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="5차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt15M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 5차중도금_관
	 */
	public java.math.BigDecimal getAmt15M(){
		return amt15M;
	}
	
	/**
	 * @Description 5차중도금_관
	 */
	@JsonProperty("amt15M")
	public void setAmt15M( java.math.BigDecimal amt15M ) {
		isSet_amt15M = true;
		this.amt15M = amt15M;
	}
	
	/** Property set << amt15M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt16 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt16 = false;
	
	protected boolean isSet_amt16()
	{
		return this.isSet_amt16;
	}
	
	protected void setIsSet_amt16(boolean value)
	{
		this.isSet_amt16 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 6차중도금
	 */
	public void setAmt16(java.lang.String value) {
		isSet_amt16 = true;
		this.amt16 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 6차중도금
	 */
	public void setAmt16(double value) {
		isSet_amt16 = true;
		this.amt16 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 6차중도금
	 */
	public void setAmt16(long value) {
		isSet_amt16 = true;
		this.amt16 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="6차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt16  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 6차중도금
	 */
	public java.math.BigDecimal getAmt16(){
		return amt16;
	}
	
	/**
	 * @Description 6차중도금
	 */
	@JsonProperty("amt16")
	public void setAmt16( java.math.BigDecimal amt16 ) {
		isSet_amt16 = true;
		this.amt16 = amt16;
	}
	
	/** Property set << amt16 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt16L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt16L = false;
	
	protected boolean isSet_amt16L()
	{
		return this.isSet_amt16L;
	}
	
	protected void setIsSet_amt16L(boolean value)
	{
		this.isSet_amt16L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 6차중도금_토
	 */
	public void setAmt16L(java.lang.String value) {
		isSet_amt16L = true;
		this.amt16L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 6차중도금_토
	 */
	public void setAmt16L(double value) {
		isSet_amt16L = true;
		this.amt16L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 6차중도금_토
	 */
	public void setAmt16L(long value) {
		isSet_amt16L = true;
		this.amt16L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="6차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt16L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 6차중도금_토
	 */
	public java.math.BigDecimal getAmt16L(){
		return amt16L;
	}
	
	/**
	 * @Description 6차중도금_토
	 */
	@JsonProperty("amt16L")
	public void setAmt16L( java.math.BigDecimal amt16L ) {
		isSet_amt16L = true;
		this.amt16L = amt16L;
	}
	
	/** Property set << amt16L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt16B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt16B = false;
	
	protected boolean isSet_amt16B()
	{
		return this.isSet_amt16B;
	}
	
	protected void setIsSet_amt16B(boolean value)
	{
		this.isSet_amt16B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 6차중도금_건
	 */
	public void setAmt16B(java.lang.String value) {
		isSet_amt16B = true;
		this.amt16B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 6차중도금_건
	 */
	public void setAmt16B(double value) {
		isSet_amt16B = true;
		this.amt16B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 6차중도금_건
	 */
	public void setAmt16B(long value) {
		isSet_amt16B = true;
		this.amt16B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="6차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt16B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 6차중도금_건
	 */
	public java.math.BigDecimal getAmt16B(){
		return amt16B;
	}
	
	/**
	 * @Description 6차중도금_건
	 */
	@JsonProperty("amt16B")
	public void setAmt16B( java.math.BigDecimal amt16B ) {
		isSet_amt16B = true;
		this.amt16B = amt16B;
	}
	
	/** Property set << amt16B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt16V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt16V = false;
	
	protected boolean isSet_amt16V()
	{
		return this.isSet_amt16V;
	}
	
	protected void setIsSet_amt16V(boolean value)
	{
		this.isSet_amt16V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 6차중도금_부
	 */
	public void setAmt16V(java.lang.String value) {
		isSet_amt16V = true;
		this.amt16V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 6차중도금_부
	 */
	public void setAmt16V(double value) {
		isSet_amt16V = true;
		this.amt16V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 6차중도금_부
	 */
	public void setAmt16V(long value) {
		isSet_amt16V = true;
		this.amt16V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="6차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt16V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 6차중도금_부
	 */
	public java.math.BigDecimal getAmt16V(){
		return amt16V;
	}
	
	/**
	 * @Description 6차중도금_부
	 */
	@JsonProperty("amt16V")
	public void setAmt16V( java.math.BigDecimal amt16V ) {
		isSet_amt16V = true;
		this.amt16V = amt16V;
	}
	
	/** Property set << amt16V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt16M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt16M = false;
	
	protected boolean isSet_amt16M()
	{
		return this.isSet_amt16M;
	}
	
	protected void setIsSet_amt16M(boolean value)
	{
		this.isSet_amt16M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 6차중도금_관
	 */
	public void setAmt16M(java.lang.String value) {
		isSet_amt16M = true;
		this.amt16M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 6차중도금_관
	 */
	public void setAmt16M(double value) {
		isSet_amt16M = true;
		this.amt16M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 6차중도금_관
	 */
	public void setAmt16M(long value) {
		isSet_amt16M = true;
		this.amt16M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="6차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt16M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 6차중도금_관
	 */
	public java.math.BigDecimal getAmt16M(){
		return amt16M;
	}
	
	/**
	 * @Description 6차중도금_관
	 */
	@JsonProperty("amt16M")
	public void setAmt16M( java.math.BigDecimal amt16M ) {
		isSet_amt16M = true;
		this.amt16M = amt16M;
	}
	
	/** Property set << amt16M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt17 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt17 = false;
	
	protected boolean isSet_amt17()
	{
		return this.isSet_amt17;
	}
	
	protected void setIsSet_amt17(boolean value)
	{
		this.isSet_amt17 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 7차중도금
	 */
	public void setAmt17(java.lang.String value) {
		isSet_amt17 = true;
		this.amt17 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 7차중도금
	 */
	public void setAmt17(double value) {
		isSet_amt17 = true;
		this.amt17 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 7차중도금
	 */
	public void setAmt17(long value) {
		isSet_amt17 = true;
		this.amt17 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="7차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt17  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 7차중도금
	 */
	public java.math.BigDecimal getAmt17(){
		return amt17;
	}
	
	/**
	 * @Description 7차중도금
	 */
	@JsonProperty("amt17")
	public void setAmt17( java.math.BigDecimal amt17 ) {
		isSet_amt17 = true;
		this.amt17 = amt17;
	}
	
	/** Property set << amt17 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt17L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt17L = false;
	
	protected boolean isSet_amt17L()
	{
		return this.isSet_amt17L;
	}
	
	protected void setIsSet_amt17L(boolean value)
	{
		this.isSet_amt17L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 7차중도금_토
	 */
	public void setAmt17L(java.lang.String value) {
		isSet_amt17L = true;
		this.amt17L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 7차중도금_토
	 */
	public void setAmt17L(double value) {
		isSet_amt17L = true;
		this.amt17L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 7차중도금_토
	 */
	public void setAmt17L(long value) {
		isSet_amt17L = true;
		this.amt17L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="7차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt17L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 7차중도금_토
	 */
	public java.math.BigDecimal getAmt17L(){
		return amt17L;
	}
	
	/**
	 * @Description 7차중도금_토
	 */
	@JsonProperty("amt17L")
	public void setAmt17L( java.math.BigDecimal amt17L ) {
		isSet_amt17L = true;
		this.amt17L = amt17L;
	}
	
	/** Property set << amt17L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt17B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt17B = false;
	
	protected boolean isSet_amt17B()
	{
		return this.isSet_amt17B;
	}
	
	protected void setIsSet_amt17B(boolean value)
	{
		this.isSet_amt17B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 7차중도금_건
	 */
	public void setAmt17B(java.lang.String value) {
		isSet_amt17B = true;
		this.amt17B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 7차중도금_건
	 */
	public void setAmt17B(double value) {
		isSet_amt17B = true;
		this.amt17B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 7차중도금_건
	 */
	public void setAmt17B(long value) {
		isSet_amt17B = true;
		this.amt17B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="7차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt17B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 7차중도금_건
	 */
	public java.math.BigDecimal getAmt17B(){
		return amt17B;
	}
	
	/**
	 * @Description 7차중도금_건
	 */
	@JsonProperty("amt17B")
	public void setAmt17B( java.math.BigDecimal amt17B ) {
		isSet_amt17B = true;
		this.amt17B = amt17B;
	}
	
	/** Property set << amt17B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt17V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt17V = false;
	
	protected boolean isSet_amt17V()
	{
		return this.isSet_amt17V;
	}
	
	protected void setIsSet_amt17V(boolean value)
	{
		this.isSet_amt17V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 7차중도금_부
	 */
	public void setAmt17V(java.lang.String value) {
		isSet_amt17V = true;
		this.amt17V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 7차중도금_부
	 */
	public void setAmt17V(double value) {
		isSet_amt17V = true;
		this.amt17V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 7차중도금_부
	 */
	public void setAmt17V(long value) {
		isSet_amt17V = true;
		this.amt17V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="7차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt17V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 7차중도금_부
	 */
	public java.math.BigDecimal getAmt17V(){
		return amt17V;
	}
	
	/**
	 * @Description 7차중도금_부
	 */
	@JsonProperty("amt17V")
	public void setAmt17V( java.math.BigDecimal amt17V ) {
		isSet_amt17V = true;
		this.amt17V = amt17V;
	}
	
	/** Property set << amt17V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt17M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt17M = false;
	
	protected boolean isSet_amt17M()
	{
		return this.isSet_amt17M;
	}
	
	protected void setIsSet_amt17M(boolean value)
	{
		this.isSet_amt17M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 7차중도금_관
	 */
	public void setAmt17M(java.lang.String value) {
		isSet_amt17M = true;
		this.amt17M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 7차중도금_관
	 */
	public void setAmt17M(double value) {
		isSet_amt17M = true;
		this.amt17M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 7차중도금_관
	 */
	public void setAmt17M(long value) {
		isSet_amt17M = true;
		this.amt17M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="7차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt17M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 7차중도금_관
	 */
	public java.math.BigDecimal getAmt17M(){
		return amt17M;
	}
	
	/**
	 * @Description 7차중도금_관
	 */
	@JsonProperty("amt17M")
	public void setAmt17M( java.math.BigDecimal amt17M ) {
		isSet_amt17M = true;
		this.amt17M = amt17M;
	}
	
	/** Property set << amt17M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt18 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt18 = false;
	
	protected boolean isSet_amt18()
	{
		return this.isSet_amt18;
	}
	
	protected void setIsSet_amt18(boolean value)
	{
		this.isSet_amt18 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 8차중도금
	 */
	public void setAmt18(java.lang.String value) {
		isSet_amt18 = true;
		this.amt18 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 8차중도금
	 */
	public void setAmt18(double value) {
		isSet_amt18 = true;
		this.amt18 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 8차중도금
	 */
	public void setAmt18(long value) {
		isSet_amt18 = true;
		this.amt18 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="8차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt18  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 8차중도금
	 */
	public java.math.BigDecimal getAmt18(){
		return amt18;
	}
	
	/**
	 * @Description 8차중도금
	 */
	@JsonProperty("amt18")
	public void setAmt18( java.math.BigDecimal amt18 ) {
		isSet_amt18 = true;
		this.amt18 = amt18;
	}
	
	/** Property set << amt18 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt18L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt18L = false;
	
	protected boolean isSet_amt18L()
	{
		return this.isSet_amt18L;
	}
	
	protected void setIsSet_amt18L(boolean value)
	{
		this.isSet_amt18L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 8차중도금_토
	 */
	public void setAmt18L(java.lang.String value) {
		isSet_amt18L = true;
		this.amt18L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 8차중도금_토
	 */
	public void setAmt18L(double value) {
		isSet_amt18L = true;
		this.amt18L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 8차중도금_토
	 */
	public void setAmt18L(long value) {
		isSet_amt18L = true;
		this.amt18L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="8차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt18L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 8차중도금_토
	 */
	public java.math.BigDecimal getAmt18L(){
		return amt18L;
	}
	
	/**
	 * @Description 8차중도금_토
	 */
	@JsonProperty("amt18L")
	public void setAmt18L( java.math.BigDecimal amt18L ) {
		isSet_amt18L = true;
		this.amt18L = amt18L;
	}
	
	/** Property set << amt18L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt18B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt18B = false;
	
	protected boolean isSet_amt18B()
	{
		return this.isSet_amt18B;
	}
	
	protected void setIsSet_amt18B(boolean value)
	{
		this.isSet_amt18B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 8차중도금_건
	 */
	public void setAmt18B(java.lang.String value) {
		isSet_amt18B = true;
		this.amt18B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 8차중도금_건
	 */
	public void setAmt18B(double value) {
		isSet_amt18B = true;
		this.amt18B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 8차중도금_건
	 */
	public void setAmt18B(long value) {
		isSet_amt18B = true;
		this.amt18B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="8차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt18B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 8차중도금_건
	 */
	public java.math.BigDecimal getAmt18B(){
		return amt18B;
	}
	
	/**
	 * @Description 8차중도금_건
	 */
	@JsonProperty("amt18B")
	public void setAmt18B( java.math.BigDecimal amt18B ) {
		isSet_amt18B = true;
		this.amt18B = amt18B;
	}
	
	/** Property set << amt18B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt18V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt18V = false;
	
	protected boolean isSet_amt18V()
	{
		return this.isSet_amt18V;
	}
	
	protected void setIsSet_amt18V(boolean value)
	{
		this.isSet_amt18V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 8차중도금_부
	 */
	public void setAmt18V(java.lang.String value) {
		isSet_amt18V = true;
		this.amt18V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 8차중도금_부
	 */
	public void setAmt18V(double value) {
		isSet_amt18V = true;
		this.amt18V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 8차중도금_부
	 */
	public void setAmt18V(long value) {
		isSet_amt18V = true;
		this.amt18V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="8차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt18V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 8차중도금_부
	 */
	public java.math.BigDecimal getAmt18V(){
		return amt18V;
	}
	
	/**
	 * @Description 8차중도금_부
	 */
	@JsonProperty("amt18V")
	public void setAmt18V( java.math.BigDecimal amt18V ) {
		isSet_amt18V = true;
		this.amt18V = amt18V;
	}
	
	/** Property set << amt18V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt18M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt18M = false;
	
	protected boolean isSet_amt18M()
	{
		return this.isSet_amt18M;
	}
	
	protected void setIsSet_amt18M(boolean value)
	{
		this.isSet_amt18M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 8차중도금_관
	 */
	public void setAmt18M(java.lang.String value) {
		isSet_amt18M = true;
		this.amt18M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 8차중도금_관
	 */
	public void setAmt18M(double value) {
		isSet_amt18M = true;
		this.amt18M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 8차중도금_관
	 */
	public void setAmt18M(long value) {
		isSet_amt18M = true;
		this.amt18M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="8차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt18M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 8차중도금_관
	 */
	public java.math.BigDecimal getAmt18M(){
		return amt18M;
	}
	
	/**
	 * @Description 8차중도금_관
	 */
	@JsonProperty("amt18M")
	public void setAmt18M( java.math.BigDecimal amt18M ) {
		isSet_amt18M = true;
		this.amt18M = amt18M;
	}
	
	/** Property set << amt18M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt19 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt19 = false;
	
	protected boolean isSet_amt19()
	{
		return this.isSet_amt19;
	}
	
	protected void setIsSet_amt19(boolean value)
	{
		this.isSet_amt19 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 9차중도금
	 */
	public void setAmt19(java.lang.String value) {
		isSet_amt19 = true;
		this.amt19 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 9차중도금
	 */
	public void setAmt19(double value) {
		isSet_amt19 = true;
		this.amt19 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 9차중도금
	 */
	public void setAmt19(long value) {
		isSet_amt19 = true;
		this.amt19 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="9차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt19  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 9차중도금
	 */
	public java.math.BigDecimal getAmt19(){
		return amt19;
	}
	
	/**
	 * @Description 9차중도금
	 */
	@JsonProperty("amt19")
	public void setAmt19( java.math.BigDecimal amt19 ) {
		isSet_amt19 = true;
		this.amt19 = amt19;
	}
	
	/** Property set << amt19 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt19L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt19L = false;
	
	protected boolean isSet_amt19L()
	{
		return this.isSet_amt19L;
	}
	
	protected void setIsSet_amt19L(boolean value)
	{
		this.isSet_amt19L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 9차중도금_토
	 */
	public void setAmt19L(java.lang.String value) {
		isSet_amt19L = true;
		this.amt19L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 9차중도금_토
	 */
	public void setAmt19L(double value) {
		isSet_amt19L = true;
		this.amt19L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 9차중도금_토
	 */
	public void setAmt19L(long value) {
		isSet_amt19L = true;
		this.amt19L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="9차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt19L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 9차중도금_토
	 */
	public java.math.BigDecimal getAmt19L(){
		return amt19L;
	}
	
	/**
	 * @Description 9차중도금_토
	 */
	@JsonProperty("amt19L")
	public void setAmt19L( java.math.BigDecimal amt19L ) {
		isSet_amt19L = true;
		this.amt19L = amt19L;
	}
	
	/** Property set << amt19L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt19B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt19B = false;
	
	protected boolean isSet_amt19B()
	{
		return this.isSet_amt19B;
	}
	
	protected void setIsSet_amt19B(boolean value)
	{
		this.isSet_amt19B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 9차중도금_건
	 */
	public void setAmt19B(java.lang.String value) {
		isSet_amt19B = true;
		this.amt19B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 9차중도금_건
	 */
	public void setAmt19B(double value) {
		isSet_amt19B = true;
		this.amt19B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 9차중도금_건
	 */
	public void setAmt19B(long value) {
		isSet_amt19B = true;
		this.amt19B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="9차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt19B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 9차중도금_건
	 */
	public java.math.BigDecimal getAmt19B(){
		return amt19B;
	}
	
	/**
	 * @Description 9차중도금_건
	 */
	@JsonProperty("amt19B")
	public void setAmt19B( java.math.BigDecimal amt19B ) {
		isSet_amt19B = true;
		this.amt19B = amt19B;
	}
	
	/** Property set << amt19B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt19V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt19V = false;
	
	protected boolean isSet_amt19V()
	{
		return this.isSet_amt19V;
	}
	
	protected void setIsSet_amt19V(boolean value)
	{
		this.isSet_amt19V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 9차중도금_부
	 */
	public void setAmt19V(java.lang.String value) {
		isSet_amt19V = true;
		this.amt19V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 9차중도금_부
	 */
	public void setAmt19V(double value) {
		isSet_amt19V = true;
		this.amt19V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 9차중도금_부
	 */
	public void setAmt19V(long value) {
		isSet_amt19V = true;
		this.amt19V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="9차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt19V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 9차중도금_부
	 */
	public java.math.BigDecimal getAmt19V(){
		return amt19V;
	}
	
	/**
	 * @Description 9차중도금_부
	 */
	@JsonProperty("amt19V")
	public void setAmt19V( java.math.BigDecimal amt19V ) {
		isSet_amt19V = true;
		this.amt19V = amt19V;
	}
	
	/** Property set << amt19V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt19M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt19M = false;
	
	protected boolean isSet_amt19M()
	{
		return this.isSet_amt19M;
	}
	
	protected void setIsSet_amt19M(boolean value)
	{
		this.isSet_amt19M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 9차중도금_관
	 */
	public void setAmt19M(java.lang.String value) {
		isSet_amt19M = true;
		this.amt19M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 9차중도금_관
	 */
	public void setAmt19M(double value) {
		isSet_amt19M = true;
		this.amt19M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 9차중도금_관
	 */
	public void setAmt19M(long value) {
		isSet_amt19M = true;
		this.amt19M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="9차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt19M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 9차중도금_관
	 */
	public java.math.BigDecimal getAmt19M(){
		return amt19M;
	}
	
	/**
	 * @Description 9차중도금_관
	 */
	@JsonProperty("amt19M")
	public void setAmt19M( java.math.BigDecimal amt19M ) {
		isSet_amt19M = true;
		this.amt19M = amt19M;
	}
	
	/** Property set << amt19M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt20 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt20 = false;
	
	protected boolean isSet_amt20()
	{
		return this.isSet_amt20;
	}
	
	protected void setIsSet_amt20(boolean value)
	{
		this.isSet_amt20 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 10차중도금
	 */
	public void setAmt20(java.lang.String value) {
		isSet_amt20 = true;
		this.amt20 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 10차중도금
	 */
	public void setAmt20(double value) {
		isSet_amt20 = true;
		this.amt20 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 10차중도금
	 */
	public void setAmt20(long value) {
		isSet_amt20 = true;
		this.amt20 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="10차중도금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt20  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 10차중도금
	 */
	public java.math.BigDecimal getAmt20(){
		return amt20;
	}
	
	/**
	 * @Description 10차중도금
	 */
	@JsonProperty("amt20")
	public void setAmt20( java.math.BigDecimal amt20 ) {
		isSet_amt20 = true;
		this.amt20 = amt20;
	}
	
	/** Property set << amt20 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt20L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt20L = false;
	
	protected boolean isSet_amt20L()
	{
		return this.isSet_amt20L;
	}
	
	protected void setIsSet_amt20L(boolean value)
	{
		this.isSet_amt20L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 10차중도금_토
	 */
	public void setAmt20L(java.lang.String value) {
		isSet_amt20L = true;
		this.amt20L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 10차중도금_토
	 */
	public void setAmt20L(double value) {
		isSet_amt20L = true;
		this.amt20L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 10차중도금_토
	 */
	public void setAmt20L(long value) {
		isSet_amt20L = true;
		this.amt20L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="10차중도금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt20L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 10차중도금_토
	 */
	public java.math.BigDecimal getAmt20L(){
		return amt20L;
	}
	
	/**
	 * @Description 10차중도금_토
	 */
	@JsonProperty("amt20L")
	public void setAmt20L( java.math.BigDecimal amt20L ) {
		isSet_amt20L = true;
		this.amt20L = amt20L;
	}
	
	/** Property set << amt20L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt20B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt20B = false;
	
	protected boolean isSet_amt20B()
	{
		return this.isSet_amt20B;
	}
	
	protected void setIsSet_amt20B(boolean value)
	{
		this.isSet_amt20B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 10차중도금_건
	 */
	public void setAmt20B(java.lang.String value) {
		isSet_amt20B = true;
		this.amt20B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 10차중도금_건
	 */
	public void setAmt20B(double value) {
		isSet_amt20B = true;
		this.amt20B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 10차중도금_건
	 */
	public void setAmt20B(long value) {
		isSet_amt20B = true;
		this.amt20B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="10차중도금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt20B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 10차중도금_건
	 */
	public java.math.BigDecimal getAmt20B(){
		return amt20B;
	}
	
	/**
	 * @Description 10차중도금_건
	 */
	@JsonProperty("amt20B")
	public void setAmt20B( java.math.BigDecimal amt20B ) {
		isSet_amt20B = true;
		this.amt20B = amt20B;
	}
	
	/** Property set << amt20B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt20V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt20V = false;
	
	protected boolean isSet_amt20V()
	{
		return this.isSet_amt20V;
	}
	
	protected void setIsSet_amt20V(boolean value)
	{
		this.isSet_amt20V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 10차중도금_부
	 */
	public void setAmt20V(java.lang.String value) {
		isSet_amt20V = true;
		this.amt20V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 10차중도금_부
	 */
	public void setAmt20V(double value) {
		isSet_amt20V = true;
		this.amt20V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 10차중도금_부
	 */
	public void setAmt20V(long value) {
		isSet_amt20V = true;
		this.amt20V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="10차중도금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt20V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 10차중도금_부
	 */
	public java.math.BigDecimal getAmt20V(){
		return amt20V;
	}
	
	/**
	 * @Description 10차중도금_부
	 */
	@JsonProperty("amt20V")
	public void setAmt20V( java.math.BigDecimal amt20V ) {
		isSet_amt20V = true;
		this.amt20V = amt20V;
	}
	
	/** Property set << amt20V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt20M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt20M = false;
	
	protected boolean isSet_amt20M()
	{
		return this.isSet_amt20M;
	}
	
	protected void setIsSet_amt20M(boolean value)
	{
		this.isSet_amt20M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 10차중도금_관
	 */
	public void setAmt20M(java.lang.String value) {
		isSet_amt20M = true;
		this.amt20M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 10차중도금_관
	 */
	public void setAmt20M(double value) {
		isSet_amt20M = true;
		this.amt20M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 10차중도금_관
	 */
	public void setAmt20M(long value) {
		isSet_amt20M = true;
		this.amt20M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="10차중도금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt20M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 10차중도금_관
	 */
	public java.math.BigDecimal getAmt20M(){
		return amt20M;
	}
	
	/**
	 * @Description 10차중도금_관
	 */
	@JsonProperty("amt20M")
	public void setAmt20M( java.math.BigDecimal amt20M ) {
		isSet_amt20M = true;
		this.amt20M = amt20M;
	}
	
	/** Property set << amt20M >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt90 >> [[ */
	
	@XmlTransient
	private boolean isSet_amt90 = false;
	
	protected boolean isSet_amt90()
	{
		return this.isSet_amt90;
	}
	
	protected void setIsSet_amt90(boolean value)
	{
		this.isSet_amt90 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 잔금
	 */
	public void setAmt90(java.lang.String value) {
		isSet_amt90 = true;
		this.amt90 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 잔금
	 */
	public void setAmt90(double value) {
		isSet_amt90 = true;
		this.amt90 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 잔금
	 */
	public void setAmt90(long value) {
		isSet_amt90 = true;
		this.amt90 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="잔금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt90  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 잔금
	 */
	public java.math.BigDecimal getAmt90(){
		return amt90;
	}
	
	/**
	 * @Description 잔금
	 */
	@JsonProperty("amt90")
	public void setAmt90( java.math.BigDecimal amt90 ) {
		isSet_amt90 = true;
		this.amt90 = amt90;
	}
	
	/** Property set << amt90 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt90L >> [[ */
	
	@XmlTransient
	private boolean isSet_amt90L = false;
	
	protected boolean isSet_amt90L()
	{
		return this.isSet_amt90L;
	}
	
	protected void setIsSet_amt90L(boolean value)
	{
		this.isSet_amt90L = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 잔금_토
	 */
	public void setAmt90L(java.lang.String value) {
		isSet_amt90L = true;
		this.amt90L = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 잔금_토
	 */
	public void setAmt90L(double value) {
		isSet_amt90L = true;
		this.amt90L = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 잔금_토
	 */
	public void setAmt90L(long value) {
		isSet_amt90L = true;
		this.amt90L = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="잔금_토", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt90L  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 잔금_토
	 */
	public java.math.BigDecimal getAmt90L(){
		return amt90L;
	}
	
	/**
	 * @Description 잔금_토
	 */
	@JsonProperty("amt90L")
	public void setAmt90L( java.math.BigDecimal amt90L ) {
		isSet_amt90L = true;
		this.amt90L = amt90L;
	}
	
	/** Property set << amt90L >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt90B >> [[ */
	
	@XmlTransient
	private boolean isSet_amt90B = false;
	
	protected boolean isSet_amt90B()
	{
		return this.isSet_amt90B;
	}
	
	protected void setIsSet_amt90B(boolean value)
	{
		this.isSet_amt90B = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 잔금_건
	 */
	public void setAmt90B(java.lang.String value) {
		isSet_amt90B = true;
		this.amt90B = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 잔금_건
	 */
	public void setAmt90B(double value) {
		isSet_amt90B = true;
		this.amt90B = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 잔금_건
	 */
	public void setAmt90B(long value) {
		isSet_amt90B = true;
		this.amt90B = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="잔금_건", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt90B  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 잔금_건
	 */
	public java.math.BigDecimal getAmt90B(){
		return amt90B;
	}
	
	/**
	 * @Description 잔금_건
	 */
	@JsonProperty("amt90B")
	public void setAmt90B( java.math.BigDecimal amt90B ) {
		isSet_amt90B = true;
		this.amt90B = amt90B;
	}
	
	/** Property set << amt90B >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt90V >> [[ */
	
	@XmlTransient
	private boolean isSet_amt90V = false;
	
	protected boolean isSet_amt90V()
	{
		return this.isSet_amt90V;
	}
	
	protected void setIsSet_amt90V(boolean value)
	{
		this.isSet_amt90V = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 잔금_부
	 */
	public void setAmt90V(java.lang.String value) {
		isSet_amt90V = true;
		this.amt90V = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 잔금_부
	 */
	public void setAmt90V(double value) {
		isSet_amt90V = true;
		this.amt90V = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 잔금_부
	 */
	public void setAmt90V(long value) {
		isSet_amt90V = true;
		this.amt90V = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="잔금_부", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt90V  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 잔금_부
	 */
	public java.math.BigDecimal getAmt90V(){
		return amt90V;
	}
	
	/**
	 * @Description 잔금_부
	 */
	@JsonProperty("amt90V")
	public void setAmt90V( java.math.BigDecimal amt90V ) {
		isSet_amt90V = true;
		this.amt90V = amt90V;
	}
	
	/** Property set << amt90V >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt90M >> [[ */
	
	@XmlTransient
	private boolean isSet_amt90M = false;
	
	protected boolean isSet_amt90M()
	{
		return this.isSet_amt90M;
	}
	
	protected void setIsSet_amt90M(boolean value)
	{
		this.isSet_amt90M = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 잔금_관
	 */
	public void setAmt90M(java.lang.String value) {
		isSet_amt90M = true;
		this.amt90M = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 잔금_관
	 */
	public void setAmt90M(double value) {
		isSet_amt90M = true;
		this.amt90M = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 잔금_관
	 */
	public void setAmt90M(long value) {
		isSet_amt90M = true;
		this.amt90M = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="잔금_관", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt90M  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 잔금_관
	 */
	public java.math.BigDecimal getAmt90M(){
		return amt90M;
	}
	
	/**
	 * @Description 잔금_관
	 */
	@JsonProperty("amt90M")
	public void setAmt90M( java.math.BigDecimal amt90M ) {
		isSet_amt90M = true;
		this.amt90M = amt90M;
	}
	
	/** Property set << amt90M >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDSupplyConv01IO clone(){
		try{
			DHDSupplyConv01IO object= (DHDSupplyConv01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.type== null ) object.type = null;
			else{
				object.type = this.type;
			}
			if ( this.classJrw== null ) object.classJrw = null;
			else{
				object.classJrw = this.classJrw;
			}
			if ( this.options== null ) object.options = null;
			else{
				object.options = this.options;
			}
			if ( this.exclusivearea== null ) object.exclusivearea = null;
			else{
				object.exclusivearea = new java.math.BigDecimal(exclusivearea.toString());
			}
			if ( this.commonarea== null ) object.commonarea = null;
			else{
				object.commonarea = new java.math.BigDecimal(commonarea.toString());
			}
			if ( this.etccommonarea== null ) object.etccommonarea = null;
			else{
				object.etccommonarea = new java.math.BigDecimal(etccommonarea.toString());
			}
			if ( this.parkingarea== null ) object.parkingarea = null;
			else{
				object.parkingarea = new java.math.BigDecimal(parkingarea.toString());
			}
			if ( this.servicearea== null ) object.servicearea = null;
			else{
				object.servicearea = new java.math.BigDecimal(servicearea.toString());
			}
			if ( this.sitearea== null ) object.sitearea = null;
			else{
				object.sitearea = new java.math.BigDecimal(sitearea.toString());
			}
			if ( this.totSupplyamt== null ) object.totSupplyamt = null;
			else{
				object.totSupplyamt = new java.math.BigDecimal(totSupplyamt.toString());
			}
			if ( this.totLandamt== null ) object.totLandamt = null;
			else{
				object.totLandamt = new java.math.BigDecimal(totLandamt.toString());
			}
			if ( this.totBuildamt== null ) object.totBuildamt = null;
			else{
				object.totBuildamt = new java.math.BigDecimal(totBuildamt.toString());
			}
			if ( this.totVatamt== null ) object.totVatamt = null;
			else{
				object.totVatamt = new java.math.BigDecimal(totVatamt.toString());
			}
			if ( this.totManageamt== null ) object.totManageamt = null;
			else{
				object.totManageamt = new java.math.BigDecimal(totManageamt.toString());
			}
			if ( this.amt00== null ) object.amt00 = null;
			else{
				object.amt00 = new java.math.BigDecimal(amt00.toString());
			}
			if ( this.amt00L== null ) object.amt00L = null;
			else{
				object.amt00L = new java.math.BigDecimal(amt00L.toString());
			}
			if ( this.amt00B== null ) object.amt00B = null;
			else{
				object.amt00B = new java.math.BigDecimal(amt00B.toString());
			}
			if ( this.amt00V== null ) object.amt00V = null;
			else{
				object.amt00V = new java.math.BigDecimal(amt00V.toString());
			}
			if ( this.amt00M== null ) object.amt00M = null;
			else{
				object.amt00M = new java.math.BigDecimal(amt00M.toString());
			}
			if ( this.amt01== null ) object.amt01 = null;
			else{
				object.amt01 = new java.math.BigDecimal(amt01.toString());
			}
			if ( this.amt01L== null ) object.amt01L = null;
			else{
				object.amt01L = new java.math.BigDecimal(amt01L.toString());
			}
			if ( this.amt01B== null ) object.amt01B = null;
			else{
				object.amt01B = new java.math.BigDecimal(amt01B.toString());
			}
			if ( this.amt01V== null ) object.amt01V = null;
			else{
				object.amt01V = new java.math.BigDecimal(amt01V.toString());
			}
			if ( this.amt01M== null ) object.amt01M = null;
			else{
				object.amt01M = new java.math.BigDecimal(amt01M.toString());
			}
			if ( this.amt02== null ) object.amt02 = null;
			else{
				object.amt02 = new java.math.BigDecimal(amt02.toString());
			}
			if ( this.amt02L== null ) object.amt02L = null;
			else{
				object.amt02L = new java.math.BigDecimal(amt02L.toString());
			}
			if ( this.amt02B== null ) object.amt02B = null;
			else{
				object.amt02B = new java.math.BigDecimal(amt02B.toString());
			}
			if ( this.amt02V== null ) object.amt02V = null;
			else{
				object.amt02V = new java.math.BigDecimal(amt02V.toString());
			}
			if ( this.amt02M== null ) object.amt02M = null;
			else{
				object.amt02M = new java.math.BigDecimal(amt02M.toString());
			}
			if ( this.amt11== null ) object.amt11 = null;
			else{
				object.amt11 = new java.math.BigDecimal(amt11.toString());
			}
			if ( this.amt11L== null ) object.amt11L = null;
			else{
				object.amt11L = new java.math.BigDecimal(amt11L.toString());
			}
			if ( this.amt11B== null ) object.amt11B = null;
			else{
				object.amt11B = new java.math.BigDecimal(amt11B.toString());
			}
			if ( this.amt11V== null ) object.amt11V = null;
			else{
				object.amt11V = new java.math.BigDecimal(amt11V.toString());
			}
			if ( this.amt11M== null ) object.amt11M = null;
			else{
				object.amt11M = new java.math.BigDecimal(amt11M.toString());
			}
			if ( this.amt12== null ) object.amt12 = null;
			else{
				object.amt12 = new java.math.BigDecimal(amt12.toString());
			}
			if ( this.amt12L== null ) object.amt12L = null;
			else{
				object.amt12L = new java.math.BigDecimal(amt12L.toString());
			}
			if ( this.amt12B== null ) object.amt12B = null;
			else{
				object.amt12B = new java.math.BigDecimal(amt12B.toString());
			}
			if ( this.amt12V== null ) object.amt12V = null;
			else{
				object.amt12V = new java.math.BigDecimal(amt12V.toString());
			}
			if ( this.amt12M== null ) object.amt12M = null;
			else{
				object.amt12M = new java.math.BigDecimal(amt12M.toString());
			}
			if ( this.amt13== null ) object.amt13 = null;
			else{
				object.amt13 = new java.math.BigDecimal(amt13.toString());
			}
			if ( this.amt13L== null ) object.amt13L = null;
			else{
				object.amt13L = new java.math.BigDecimal(amt13L.toString());
			}
			if ( this.amt13B== null ) object.amt13B = null;
			else{
				object.amt13B = new java.math.BigDecimal(amt13B.toString());
			}
			if ( this.amt13V== null ) object.amt13V = null;
			else{
				object.amt13V = new java.math.BigDecimal(amt13V.toString());
			}
			if ( this.amt13M== null ) object.amt13M = null;
			else{
				object.amt13M = new java.math.BigDecimal(amt13M.toString());
			}
			if ( this.amt14== null ) object.amt14 = null;
			else{
				object.amt14 = new java.math.BigDecimal(amt14.toString());
			}
			if ( this.amt14L== null ) object.amt14L = null;
			else{
				object.amt14L = new java.math.BigDecimal(amt14L.toString());
			}
			if ( this.amt14B== null ) object.amt14B = null;
			else{
				object.amt14B = new java.math.BigDecimal(amt14B.toString());
			}
			if ( this.amt14V== null ) object.amt14V = null;
			else{
				object.amt14V = new java.math.BigDecimal(amt14V.toString());
			}
			if ( this.amt14M== null ) object.amt14M = null;
			else{
				object.amt14M = new java.math.BigDecimal(amt14M.toString());
			}
			if ( this.amt15== null ) object.amt15 = null;
			else{
				object.amt15 = new java.math.BigDecimal(amt15.toString());
			}
			if ( this.amt15L== null ) object.amt15L = null;
			else{
				object.amt15L = new java.math.BigDecimal(amt15L.toString());
			}
			if ( this.amt15B== null ) object.amt15B = null;
			else{
				object.amt15B = new java.math.BigDecimal(amt15B.toString());
			}
			if ( this.amt15V== null ) object.amt15V = null;
			else{
				object.amt15V = new java.math.BigDecimal(amt15V.toString());
			}
			if ( this.amt15M== null ) object.amt15M = null;
			else{
				object.amt15M = new java.math.BigDecimal(amt15M.toString());
			}
			if ( this.amt16== null ) object.amt16 = null;
			else{
				object.amt16 = new java.math.BigDecimal(amt16.toString());
			}
			if ( this.amt16L== null ) object.amt16L = null;
			else{
				object.amt16L = new java.math.BigDecimal(amt16L.toString());
			}
			if ( this.amt16B== null ) object.amt16B = null;
			else{
				object.amt16B = new java.math.BigDecimal(amt16B.toString());
			}
			if ( this.amt16V== null ) object.amt16V = null;
			else{
				object.amt16V = new java.math.BigDecimal(amt16V.toString());
			}
			if ( this.amt16M== null ) object.amt16M = null;
			else{
				object.amt16M = new java.math.BigDecimal(amt16M.toString());
			}
			if ( this.amt17== null ) object.amt17 = null;
			else{
				object.amt17 = new java.math.BigDecimal(amt17.toString());
			}
			if ( this.amt17L== null ) object.amt17L = null;
			else{
				object.amt17L = new java.math.BigDecimal(amt17L.toString());
			}
			if ( this.amt17B== null ) object.amt17B = null;
			else{
				object.amt17B = new java.math.BigDecimal(amt17B.toString());
			}
			if ( this.amt17V== null ) object.amt17V = null;
			else{
				object.amt17V = new java.math.BigDecimal(amt17V.toString());
			}
			if ( this.amt17M== null ) object.amt17M = null;
			else{
				object.amt17M = new java.math.BigDecimal(amt17M.toString());
			}
			if ( this.amt18== null ) object.amt18 = null;
			else{
				object.amt18 = new java.math.BigDecimal(amt18.toString());
			}
			if ( this.amt18L== null ) object.amt18L = null;
			else{
				object.amt18L = new java.math.BigDecimal(amt18L.toString());
			}
			if ( this.amt18B== null ) object.amt18B = null;
			else{
				object.amt18B = new java.math.BigDecimal(amt18B.toString());
			}
			if ( this.amt18V== null ) object.amt18V = null;
			else{
				object.amt18V = new java.math.BigDecimal(amt18V.toString());
			}
			if ( this.amt18M== null ) object.amt18M = null;
			else{
				object.amt18M = new java.math.BigDecimal(amt18M.toString());
			}
			if ( this.amt19== null ) object.amt19 = null;
			else{
				object.amt19 = new java.math.BigDecimal(amt19.toString());
			}
			if ( this.amt19L== null ) object.amt19L = null;
			else{
				object.amt19L = new java.math.BigDecimal(amt19L.toString());
			}
			if ( this.amt19B== null ) object.amt19B = null;
			else{
				object.amt19B = new java.math.BigDecimal(amt19B.toString());
			}
			if ( this.amt19V== null ) object.amt19V = null;
			else{
				object.amt19V = new java.math.BigDecimal(amt19V.toString());
			}
			if ( this.amt19M== null ) object.amt19M = null;
			else{
				object.amt19M = new java.math.BigDecimal(amt19M.toString());
			}
			if ( this.amt20== null ) object.amt20 = null;
			else{
				object.amt20 = new java.math.BigDecimal(amt20.toString());
			}
			if ( this.amt20L== null ) object.amt20L = null;
			else{
				object.amt20L = new java.math.BigDecimal(amt20L.toString());
			}
			if ( this.amt20B== null ) object.amt20B = null;
			else{
				object.amt20B = new java.math.BigDecimal(amt20B.toString());
			}
			if ( this.amt20V== null ) object.amt20V = null;
			else{
				object.amt20V = new java.math.BigDecimal(amt20V.toString());
			}
			if ( this.amt20M== null ) object.amt20M = null;
			else{
				object.amt20M = new java.math.BigDecimal(amt20M.toString());
			}
			if ( this.amt90== null ) object.amt90 = null;
			else{
				object.amt90 = new java.math.BigDecimal(amt90.toString());
			}
			if ( this.amt90L== null ) object.amt90L = null;
			else{
				object.amt90L = new java.math.BigDecimal(amt90L.toString());
			}
			if ( this.amt90B== null ) object.amt90B = null;
			else{
				object.amt90B = new java.math.BigDecimal(amt90B.toString());
			}
			if ( this.amt90V== null ) object.amt90V = null;
			else{
				object.amt90V = new java.math.BigDecimal(amt90V.toString());
			}
			if ( this.amt90M== null ) object.amt90M = null;
			else{
				object.amt90M = new java.math.BigDecimal(amt90M.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((type==null)?0:type.hashCode());
		result = prime * result + ((classJrw==null)?0:classJrw.hashCode());
		result = prime * result + ((options==null)?0:options.hashCode());
		result = prime * result + ((exclusivearea==null)?0:exclusivearea.hashCode());
		result = prime * result + ((commonarea==null)?0:commonarea.hashCode());
		result = prime * result + ((etccommonarea==null)?0:etccommonarea.hashCode());
		result = prime * result + ((parkingarea==null)?0:parkingarea.hashCode());
		result = prime * result + ((servicearea==null)?0:servicearea.hashCode());
		result = prime * result + ((sitearea==null)?0:sitearea.hashCode());
		result = prime * result + ((totSupplyamt==null)?0:totSupplyamt.hashCode());
		result = prime * result + ((totLandamt==null)?0:totLandamt.hashCode());
		result = prime * result + ((totBuildamt==null)?0:totBuildamt.hashCode());
		result = prime * result + ((totVatamt==null)?0:totVatamt.hashCode());
		result = prime * result + ((totManageamt==null)?0:totManageamt.hashCode());
		result = prime * result + ((amt00==null)?0:amt00.hashCode());
		result = prime * result + ((amt00L==null)?0:amt00L.hashCode());
		result = prime * result + ((amt00B==null)?0:amt00B.hashCode());
		result = prime * result + ((amt00V==null)?0:amt00V.hashCode());
		result = prime * result + ((amt00M==null)?0:amt00M.hashCode());
		result = prime * result + ((amt01==null)?0:amt01.hashCode());
		result = prime * result + ((amt01L==null)?0:amt01L.hashCode());
		result = prime * result + ((amt01B==null)?0:amt01B.hashCode());
		result = prime * result + ((amt01V==null)?0:amt01V.hashCode());
		result = prime * result + ((amt01M==null)?0:amt01M.hashCode());
		result = prime * result + ((amt02==null)?0:amt02.hashCode());
		result = prime * result + ((amt02L==null)?0:amt02L.hashCode());
		result = prime * result + ((amt02B==null)?0:amt02B.hashCode());
		result = prime * result + ((amt02V==null)?0:amt02V.hashCode());
		result = prime * result + ((amt02M==null)?0:amt02M.hashCode());
		result = prime * result + ((amt11==null)?0:amt11.hashCode());
		result = prime * result + ((amt11L==null)?0:amt11L.hashCode());
		result = prime * result + ((amt11B==null)?0:amt11B.hashCode());
		result = prime * result + ((amt11V==null)?0:amt11V.hashCode());
		result = prime * result + ((amt11M==null)?0:amt11M.hashCode());
		result = prime * result + ((amt12==null)?0:amt12.hashCode());
		result = prime * result + ((amt12L==null)?0:amt12L.hashCode());
		result = prime * result + ((amt12B==null)?0:amt12B.hashCode());
		result = prime * result + ((amt12V==null)?0:amt12V.hashCode());
		result = prime * result + ((amt12M==null)?0:amt12M.hashCode());
		result = prime * result + ((amt13==null)?0:amt13.hashCode());
		result = prime * result + ((amt13L==null)?0:amt13L.hashCode());
		result = prime * result + ((amt13B==null)?0:amt13B.hashCode());
		result = prime * result + ((amt13V==null)?0:amt13V.hashCode());
		result = prime * result + ((amt13M==null)?0:amt13M.hashCode());
		result = prime * result + ((amt14==null)?0:amt14.hashCode());
		result = prime * result + ((amt14L==null)?0:amt14L.hashCode());
		result = prime * result + ((amt14B==null)?0:amt14B.hashCode());
		result = prime * result + ((amt14V==null)?0:amt14V.hashCode());
		result = prime * result + ((amt14M==null)?0:amt14M.hashCode());
		result = prime * result + ((amt15==null)?0:amt15.hashCode());
		result = prime * result + ((amt15L==null)?0:amt15L.hashCode());
		result = prime * result + ((amt15B==null)?0:amt15B.hashCode());
		result = prime * result + ((amt15V==null)?0:amt15V.hashCode());
		result = prime * result + ((amt15M==null)?0:amt15M.hashCode());
		result = prime * result + ((amt16==null)?0:amt16.hashCode());
		result = prime * result + ((amt16L==null)?0:amt16L.hashCode());
		result = prime * result + ((amt16B==null)?0:amt16B.hashCode());
		result = prime * result + ((amt16V==null)?0:amt16V.hashCode());
		result = prime * result + ((amt16M==null)?0:amt16M.hashCode());
		result = prime * result + ((amt17==null)?0:amt17.hashCode());
		result = prime * result + ((amt17L==null)?0:amt17L.hashCode());
		result = prime * result + ((amt17B==null)?0:amt17B.hashCode());
		result = prime * result + ((amt17V==null)?0:amt17V.hashCode());
		result = prime * result + ((amt17M==null)?0:amt17M.hashCode());
		result = prime * result + ((amt18==null)?0:amt18.hashCode());
		result = prime * result + ((amt18L==null)?0:amt18L.hashCode());
		result = prime * result + ((amt18B==null)?0:amt18B.hashCode());
		result = prime * result + ((amt18V==null)?0:amt18V.hashCode());
		result = prime * result + ((amt18M==null)?0:amt18M.hashCode());
		result = prime * result + ((amt19==null)?0:amt19.hashCode());
		result = prime * result + ((amt19L==null)?0:amt19L.hashCode());
		result = prime * result + ((amt19B==null)?0:amt19B.hashCode());
		result = prime * result + ((amt19V==null)?0:amt19V.hashCode());
		result = prime * result + ((amt19M==null)?0:amt19M.hashCode());
		result = prime * result + ((amt20==null)?0:amt20.hashCode());
		result = prime * result + ((amt20L==null)?0:amt20L.hashCode());
		result = prime * result + ((amt20B==null)?0:amt20B.hashCode());
		result = prime * result + ((amt20V==null)?0:amt20V.hashCode());
		result = prime * result + ((amt20M==null)?0:amt20M.hashCode());
		result = prime * result + ((amt90==null)?0:amt90.hashCode());
		result = prime * result + ((amt90L==null)?0:amt90L.hashCode());
		result = prime * result + ((amt90B==null)?0:amt90B.hashCode());
		result = prime * result + ((amt90V==null)?0:amt90V.hashCode());
		result = prime * result + ((amt90M==null)?0:amt90M.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO other = (kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( type == null ){
			if ( other.type != null ) return false;
		}
		else if ( !type.equals(other.type) )
			return false;
		if ( classJrw == null ){
			if ( other.classJrw != null ) return false;
		}
		else if ( !classJrw.equals(other.classJrw) )
			return false;
		if ( options == null ){
			if ( other.options != null ) return false;
		}
		else if ( !options.equals(other.options) )
			return false;
		if ( exclusivearea == null ){
			if ( other.exclusivearea != null ) return false;
		}
		else if ( !exclusivearea.equals(other.exclusivearea) )
			return false;
		if ( commonarea == null ){
			if ( other.commonarea != null ) return false;
		}
		else if ( !commonarea.equals(other.commonarea) )
			return false;
		if ( etccommonarea == null ){
			if ( other.etccommonarea != null ) return false;
		}
		else if ( !etccommonarea.equals(other.etccommonarea) )
			return false;
		if ( parkingarea == null ){
			if ( other.parkingarea != null ) return false;
		}
		else if ( !parkingarea.equals(other.parkingarea) )
			return false;
		if ( servicearea == null ){
			if ( other.servicearea != null ) return false;
		}
		else if ( !servicearea.equals(other.servicearea) )
			return false;
		if ( sitearea == null ){
			if ( other.sitearea != null ) return false;
		}
		else if ( !sitearea.equals(other.sitearea) )
			return false;
		if ( totSupplyamt == null ){
			if ( other.totSupplyamt != null ) return false;
		}
		else if ( !totSupplyamt.equals(other.totSupplyamt) )
			return false;
		if ( totLandamt == null ){
			if ( other.totLandamt != null ) return false;
		}
		else if ( !totLandamt.equals(other.totLandamt) )
			return false;
		if ( totBuildamt == null ){
			if ( other.totBuildamt != null ) return false;
		}
		else if ( !totBuildamt.equals(other.totBuildamt) )
			return false;
		if ( totVatamt == null ){
			if ( other.totVatamt != null ) return false;
		}
		else if ( !totVatamt.equals(other.totVatamt) )
			return false;
		if ( totManageamt == null ){
			if ( other.totManageamt != null ) return false;
		}
		else if ( !totManageamt.equals(other.totManageamt) )
			return false;
		if ( amt00 == null ){
			if ( other.amt00 != null ) return false;
		}
		else if ( !amt00.equals(other.amt00) )
			return false;
		if ( amt00L == null ){
			if ( other.amt00L != null ) return false;
		}
		else if ( !amt00L.equals(other.amt00L) )
			return false;
		if ( amt00B == null ){
			if ( other.amt00B != null ) return false;
		}
		else if ( !amt00B.equals(other.amt00B) )
			return false;
		if ( amt00V == null ){
			if ( other.amt00V != null ) return false;
		}
		else if ( !amt00V.equals(other.amt00V) )
			return false;
		if ( amt00M == null ){
			if ( other.amt00M != null ) return false;
		}
		else if ( !amt00M.equals(other.amt00M) )
			return false;
		if ( amt01 == null ){
			if ( other.amt01 != null ) return false;
		}
		else if ( !amt01.equals(other.amt01) )
			return false;
		if ( amt01L == null ){
			if ( other.amt01L != null ) return false;
		}
		else if ( !amt01L.equals(other.amt01L) )
			return false;
		if ( amt01B == null ){
			if ( other.amt01B != null ) return false;
		}
		else if ( !amt01B.equals(other.amt01B) )
			return false;
		if ( amt01V == null ){
			if ( other.amt01V != null ) return false;
		}
		else if ( !amt01V.equals(other.amt01V) )
			return false;
		if ( amt01M == null ){
			if ( other.amt01M != null ) return false;
		}
		else if ( !amt01M.equals(other.amt01M) )
			return false;
		if ( amt02 == null ){
			if ( other.amt02 != null ) return false;
		}
		else if ( !amt02.equals(other.amt02) )
			return false;
		if ( amt02L == null ){
			if ( other.amt02L != null ) return false;
		}
		else if ( !amt02L.equals(other.amt02L) )
			return false;
		if ( amt02B == null ){
			if ( other.amt02B != null ) return false;
		}
		else if ( !amt02B.equals(other.amt02B) )
			return false;
		if ( amt02V == null ){
			if ( other.amt02V != null ) return false;
		}
		else if ( !amt02V.equals(other.amt02V) )
			return false;
		if ( amt02M == null ){
			if ( other.amt02M != null ) return false;
		}
		else if ( !amt02M.equals(other.amt02M) )
			return false;
		if ( amt11 == null ){
			if ( other.amt11 != null ) return false;
		}
		else if ( !amt11.equals(other.amt11) )
			return false;
		if ( amt11L == null ){
			if ( other.amt11L != null ) return false;
		}
		else if ( !amt11L.equals(other.amt11L) )
			return false;
		if ( amt11B == null ){
			if ( other.amt11B != null ) return false;
		}
		else if ( !amt11B.equals(other.amt11B) )
			return false;
		if ( amt11V == null ){
			if ( other.amt11V != null ) return false;
		}
		else if ( !amt11V.equals(other.amt11V) )
			return false;
		if ( amt11M == null ){
			if ( other.amt11M != null ) return false;
		}
		else if ( !amt11M.equals(other.amt11M) )
			return false;
		if ( amt12 == null ){
			if ( other.amt12 != null ) return false;
		}
		else if ( !amt12.equals(other.amt12) )
			return false;
		if ( amt12L == null ){
			if ( other.amt12L != null ) return false;
		}
		else if ( !amt12L.equals(other.amt12L) )
			return false;
		if ( amt12B == null ){
			if ( other.amt12B != null ) return false;
		}
		else if ( !amt12B.equals(other.amt12B) )
			return false;
		if ( amt12V == null ){
			if ( other.amt12V != null ) return false;
		}
		else if ( !amt12V.equals(other.amt12V) )
			return false;
		if ( amt12M == null ){
			if ( other.amt12M != null ) return false;
		}
		else if ( !amt12M.equals(other.amt12M) )
			return false;
		if ( amt13 == null ){
			if ( other.amt13 != null ) return false;
		}
		else if ( !amt13.equals(other.amt13) )
			return false;
		if ( amt13L == null ){
			if ( other.amt13L != null ) return false;
		}
		else if ( !amt13L.equals(other.amt13L) )
			return false;
		if ( amt13B == null ){
			if ( other.amt13B != null ) return false;
		}
		else if ( !amt13B.equals(other.amt13B) )
			return false;
		if ( amt13V == null ){
			if ( other.amt13V != null ) return false;
		}
		else if ( !amt13V.equals(other.amt13V) )
			return false;
		if ( amt13M == null ){
			if ( other.amt13M != null ) return false;
		}
		else if ( !amt13M.equals(other.amt13M) )
			return false;
		if ( amt14 == null ){
			if ( other.amt14 != null ) return false;
		}
		else if ( !amt14.equals(other.amt14) )
			return false;
		if ( amt14L == null ){
			if ( other.amt14L != null ) return false;
		}
		else if ( !amt14L.equals(other.amt14L) )
			return false;
		if ( amt14B == null ){
			if ( other.amt14B != null ) return false;
		}
		else if ( !amt14B.equals(other.amt14B) )
			return false;
		if ( amt14V == null ){
			if ( other.amt14V != null ) return false;
		}
		else if ( !amt14V.equals(other.amt14V) )
			return false;
		if ( amt14M == null ){
			if ( other.amt14M != null ) return false;
		}
		else if ( !amt14M.equals(other.amt14M) )
			return false;
		if ( amt15 == null ){
			if ( other.amt15 != null ) return false;
		}
		else if ( !amt15.equals(other.amt15) )
			return false;
		if ( amt15L == null ){
			if ( other.amt15L != null ) return false;
		}
		else if ( !amt15L.equals(other.amt15L) )
			return false;
		if ( amt15B == null ){
			if ( other.amt15B != null ) return false;
		}
		else if ( !amt15B.equals(other.amt15B) )
			return false;
		if ( amt15V == null ){
			if ( other.amt15V != null ) return false;
		}
		else if ( !amt15V.equals(other.amt15V) )
			return false;
		if ( amt15M == null ){
			if ( other.amt15M != null ) return false;
		}
		else if ( !amt15M.equals(other.amt15M) )
			return false;
		if ( amt16 == null ){
			if ( other.amt16 != null ) return false;
		}
		else if ( !amt16.equals(other.amt16) )
			return false;
		if ( amt16L == null ){
			if ( other.amt16L != null ) return false;
		}
		else if ( !amt16L.equals(other.amt16L) )
			return false;
		if ( amt16B == null ){
			if ( other.amt16B != null ) return false;
		}
		else if ( !amt16B.equals(other.amt16B) )
			return false;
		if ( amt16V == null ){
			if ( other.amt16V != null ) return false;
		}
		else if ( !amt16V.equals(other.amt16V) )
			return false;
		if ( amt16M == null ){
			if ( other.amt16M != null ) return false;
		}
		else if ( !amt16M.equals(other.amt16M) )
			return false;
		if ( amt17 == null ){
			if ( other.amt17 != null ) return false;
		}
		else if ( !amt17.equals(other.amt17) )
			return false;
		if ( amt17L == null ){
			if ( other.amt17L != null ) return false;
		}
		else if ( !amt17L.equals(other.amt17L) )
			return false;
		if ( amt17B == null ){
			if ( other.amt17B != null ) return false;
		}
		else if ( !amt17B.equals(other.amt17B) )
			return false;
		if ( amt17V == null ){
			if ( other.amt17V != null ) return false;
		}
		else if ( !amt17V.equals(other.amt17V) )
			return false;
		if ( amt17M == null ){
			if ( other.amt17M != null ) return false;
		}
		else if ( !amt17M.equals(other.amt17M) )
			return false;
		if ( amt18 == null ){
			if ( other.amt18 != null ) return false;
		}
		else if ( !amt18.equals(other.amt18) )
			return false;
		if ( amt18L == null ){
			if ( other.amt18L != null ) return false;
		}
		else if ( !amt18L.equals(other.amt18L) )
			return false;
		if ( amt18B == null ){
			if ( other.amt18B != null ) return false;
		}
		else if ( !amt18B.equals(other.amt18B) )
			return false;
		if ( amt18V == null ){
			if ( other.amt18V != null ) return false;
		}
		else if ( !amt18V.equals(other.amt18V) )
			return false;
		if ( amt18M == null ){
			if ( other.amt18M != null ) return false;
		}
		else if ( !amt18M.equals(other.amt18M) )
			return false;
		if ( amt19 == null ){
			if ( other.amt19 != null ) return false;
		}
		else if ( !amt19.equals(other.amt19) )
			return false;
		if ( amt19L == null ){
			if ( other.amt19L != null ) return false;
		}
		else if ( !amt19L.equals(other.amt19L) )
			return false;
		if ( amt19B == null ){
			if ( other.amt19B != null ) return false;
		}
		else if ( !amt19B.equals(other.amt19B) )
			return false;
		if ( amt19V == null ){
			if ( other.amt19V != null ) return false;
		}
		else if ( !amt19V.equals(other.amt19V) )
			return false;
		if ( amt19M == null ){
			if ( other.amt19M != null ) return false;
		}
		else if ( !amt19M.equals(other.amt19M) )
			return false;
		if ( amt20 == null ){
			if ( other.amt20 != null ) return false;
		}
		else if ( !amt20.equals(other.amt20) )
			return false;
		if ( amt20L == null ){
			if ( other.amt20L != null ) return false;
		}
		else if ( !amt20L.equals(other.amt20L) )
			return false;
		if ( amt20B == null ){
			if ( other.amt20B != null ) return false;
		}
		else if ( !amt20B.equals(other.amt20B) )
			return false;
		if ( amt20V == null ){
			if ( other.amt20V != null ) return false;
		}
		else if ( !amt20V.equals(other.amt20V) )
			return false;
		if ( amt20M == null ){
			if ( other.amt20M != null ) return false;
		}
		else if ( !amt20M.equals(other.amt20M) )
			return false;
		if ( amt90 == null ){
			if ( other.amt90 != null ) return false;
		}
		else if ( !amt90.equals(other.amt90) )
			return false;
		if ( amt90L == null ){
			if ( other.amt90L != null ) return false;
		}
		else if ( !amt90L.equals(other.amt90L) )
			return false;
		if ( amt90B == null ){
			if ( other.amt90B != null ) return false;
		}
		else if ( !amt90B.equals(other.amt90B) )
			return false;
		if ( amt90V == null ){
			if ( other.amt90V != null ) return false;
		}
		else if ( !amt90V.equals(other.amt90V) )
			return false;
		if ( amt90M == null ){
			if ( other.amt90M != null ) return false;
		}
		else if ( !amt90M.equals(other.amt90M) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttype: ");
		sb.append(type==null?"null":getType());
		sb.append("\n");
		sb.append("\tclassJrw: ");
		sb.append(classJrw==null?"null":getClassJrw());
		sb.append("\n");
		sb.append("\toptions: ");
		sb.append(options==null?"null":getOptions());
		sb.append("\n");
		sb.append("\texclusivearea: ");
		sb.append(exclusivearea==null?"null":getExclusivearea());
		sb.append("\n");
		sb.append("\tcommonarea: ");
		sb.append(commonarea==null?"null":getCommonarea());
		sb.append("\n");
		sb.append("\tetccommonarea: ");
		sb.append(etccommonarea==null?"null":getEtccommonarea());
		sb.append("\n");
		sb.append("\tparkingarea: ");
		sb.append(parkingarea==null?"null":getParkingarea());
		sb.append("\n");
		sb.append("\tservicearea: ");
		sb.append(servicearea==null?"null":getServicearea());
		sb.append("\n");
		sb.append("\tsitearea: ");
		sb.append(sitearea==null?"null":getSitearea());
		sb.append("\n");
		sb.append("\ttotSupplyamt: ");
		sb.append(totSupplyamt==null?"null":getTotSupplyamt());
		sb.append("\n");
		sb.append("\ttotLandamt: ");
		sb.append(totLandamt==null?"null":getTotLandamt());
		sb.append("\n");
		sb.append("\ttotBuildamt: ");
		sb.append(totBuildamt==null?"null":getTotBuildamt());
		sb.append("\n");
		sb.append("\ttotVatamt: ");
		sb.append(totVatamt==null?"null":getTotVatamt());
		sb.append("\n");
		sb.append("\ttotManageamt: ");
		sb.append(totManageamt==null?"null":getTotManageamt());
		sb.append("\n");
		sb.append("\tamt00: ");
		sb.append(amt00==null?"null":getAmt00());
		sb.append("\n");
		sb.append("\tamt00L: ");
		sb.append(amt00L==null?"null":getAmt00L());
		sb.append("\n");
		sb.append("\tamt00B: ");
		sb.append(amt00B==null?"null":getAmt00B());
		sb.append("\n");
		sb.append("\tamt00V: ");
		sb.append(amt00V==null?"null":getAmt00V());
		sb.append("\n");
		sb.append("\tamt00M: ");
		sb.append(amt00M==null?"null":getAmt00M());
		sb.append("\n");
		sb.append("\tamt01: ");
		sb.append(amt01==null?"null":getAmt01());
		sb.append("\n");
		sb.append("\tamt01L: ");
		sb.append(amt01L==null?"null":getAmt01L());
		sb.append("\n");
		sb.append("\tamt01B: ");
		sb.append(amt01B==null?"null":getAmt01B());
		sb.append("\n");
		sb.append("\tamt01V: ");
		sb.append(amt01V==null?"null":getAmt01V());
		sb.append("\n");
		sb.append("\tamt01M: ");
		sb.append(amt01M==null?"null":getAmt01M());
		sb.append("\n");
		sb.append("\tamt02: ");
		sb.append(amt02==null?"null":getAmt02());
		sb.append("\n");
		sb.append("\tamt02L: ");
		sb.append(amt02L==null?"null":getAmt02L());
		sb.append("\n");
		sb.append("\tamt02B: ");
		sb.append(amt02B==null?"null":getAmt02B());
		sb.append("\n");
		sb.append("\tamt02V: ");
		sb.append(amt02V==null?"null":getAmt02V());
		sb.append("\n");
		sb.append("\tamt02M: ");
		sb.append(amt02M==null?"null":getAmt02M());
		sb.append("\n");
		sb.append("\tamt11: ");
		sb.append(amt11==null?"null":getAmt11());
		sb.append("\n");
		sb.append("\tamt11L: ");
		sb.append(amt11L==null?"null":getAmt11L());
		sb.append("\n");
		sb.append("\tamt11B: ");
		sb.append(amt11B==null?"null":getAmt11B());
		sb.append("\n");
		sb.append("\tamt11V: ");
		sb.append(amt11V==null?"null":getAmt11V());
		sb.append("\n");
		sb.append("\tamt11M: ");
		sb.append(amt11M==null?"null":getAmt11M());
		sb.append("\n");
		sb.append("\tamt12: ");
		sb.append(amt12==null?"null":getAmt12());
		sb.append("\n");
		sb.append("\tamt12L: ");
		sb.append(amt12L==null?"null":getAmt12L());
		sb.append("\n");
		sb.append("\tamt12B: ");
		sb.append(amt12B==null?"null":getAmt12B());
		sb.append("\n");
		sb.append("\tamt12V: ");
		sb.append(amt12V==null?"null":getAmt12V());
		sb.append("\n");
		sb.append("\tamt12M: ");
		sb.append(amt12M==null?"null":getAmt12M());
		sb.append("\n");
		sb.append("\tamt13: ");
		sb.append(amt13==null?"null":getAmt13());
		sb.append("\n");
		sb.append("\tamt13L: ");
		sb.append(amt13L==null?"null":getAmt13L());
		sb.append("\n");
		sb.append("\tamt13B: ");
		sb.append(amt13B==null?"null":getAmt13B());
		sb.append("\n");
		sb.append("\tamt13V: ");
		sb.append(amt13V==null?"null":getAmt13V());
		sb.append("\n");
		sb.append("\tamt13M: ");
		sb.append(amt13M==null?"null":getAmt13M());
		sb.append("\n");
		sb.append("\tamt14: ");
		sb.append(amt14==null?"null":getAmt14());
		sb.append("\n");
		sb.append("\tamt14L: ");
		sb.append(amt14L==null?"null":getAmt14L());
		sb.append("\n");
		sb.append("\tamt14B: ");
		sb.append(amt14B==null?"null":getAmt14B());
		sb.append("\n");
		sb.append("\tamt14V: ");
		sb.append(amt14V==null?"null":getAmt14V());
		sb.append("\n");
		sb.append("\tamt14M: ");
		sb.append(amt14M==null?"null":getAmt14M());
		sb.append("\n");
		sb.append("\tamt15: ");
		sb.append(amt15==null?"null":getAmt15());
		sb.append("\n");
		sb.append("\tamt15L: ");
		sb.append(amt15L==null?"null":getAmt15L());
		sb.append("\n");
		sb.append("\tamt15B: ");
		sb.append(amt15B==null?"null":getAmt15B());
		sb.append("\n");
		sb.append("\tamt15V: ");
		sb.append(amt15V==null?"null":getAmt15V());
		sb.append("\n");
		sb.append("\tamt15M: ");
		sb.append(amt15M==null?"null":getAmt15M());
		sb.append("\n");
		sb.append("\tamt16: ");
		sb.append(amt16==null?"null":getAmt16());
		sb.append("\n");
		sb.append("\tamt16L: ");
		sb.append(amt16L==null?"null":getAmt16L());
		sb.append("\n");
		sb.append("\tamt16B: ");
		sb.append(amt16B==null?"null":getAmt16B());
		sb.append("\n");
		sb.append("\tamt16V: ");
		sb.append(amt16V==null?"null":getAmt16V());
		sb.append("\n");
		sb.append("\tamt16M: ");
		sb.append(amt16M==null?"null":getAmt16M());
		sb.append("\n");
		sb.append("\tamt17: ");
		sb.append(amt17==null?"null":getAmt17());
		sb.append("\n");
		sb.append("\tamt17L: ");
		sb.append(amt17L==null?"null":getAmt17L());
		sb.append("\n");
		sb.append("\tamt17B: ");
		sb.append(amt17B==null?"null":getAmt17B());
		sb.append("\n");
		sb.append("\tamt17V: ");
		sb.append(amt17V==null?"null":getAmt17V());
		sb.append("\n");
		sb.append("\tamt17M: ");
		sb.append(amt17M==null?"null":getAmt17M());
		sb.append("\n");
		sb.append("\tamt18: ");
		sb.append(amt18==null?"null":getAmt18());
		sb.append("\n");
		sb.append("\tamt18L: ");
		sb.append(amt18L==null?"null":getAmt18L());
		sb.append("\n");
		sb.append("\tamt18B: ");
		sb.append(amt18B==null?"null":getAmt18B());
		sb.append("\n");
		sb.append("\tamt18V: ");
		sb.append(amt18V==null?"null":getAmt18V());
		sb.append("\n");
		sb.append("\tamt18M: ");
		sb.append(amt18M==null?"null":getAmt18M());
		sb.append("\n");
		sb.append("\tamt19: ");
		sb.append(amt19==null?"null":getAmt19());
		sb.append("\n");
		sb.append("\tamt19L: ");
		sb.append(amt19L==null?"null":getAmt19L());
		sb.append("\n");
		sb.append("\tamt19B: ");
		sb.append(amt19B==null?"null":getAmt19B());
		sb.append("\n");
		sb.append("\tamt19V: ");
		sb.append(amt19V==null?"null":getAmt19V());
		sb.append("\n");
		sb.append("\tamt19M: ");
		sb.append(amt19M==null?"null":getAmt19M());
		sb.append("\n");
		sb.append("\tamt20: ");
		sb.append(amt20==null?"null":getAmt20());
		sb.append("\n");
		sb.append("\tamt20L: ");
		sb.append(amt20L==null?"null":getAmt20L());
		sb.append("\n");
		sb.append("\tamt20B: ");
		sb.append(amt20B==null?"null":getAmt20B());
		sb.append("\n");
		sb.append("\tamt20V: ");
		sb.append(amt20V==null?"null":getAmt20V());
		sb.append("\n");
		sb.append("\tamt20M: ");
		sb.append(amt20M==null?"null":getAmt20M());
		sb.append("\n");
		sb.append("\tamt90: ");
		sb.append(amt90==null?"null":getAmt90());
		sb.append("\n");
		sb.append("\tamt90L: ");
		sb.append(amt90L==null?"null":getAmt90L());
		sb.append("\n");
		sb.append("\tamt90B: ");
		sb.append(amt90B==null?"null":getAmt90B());
		sb.append("\n");
		sb.append("\tamt90V: ");
		sb.append(amt90V==null?"null":getAmt90V());
		sb.append("\n");
		sb.append("\tamt90M: ");
		sb.append(amt90M==null?"null":getAmt90M());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 22; /* square */
		messageLen+= 4; /* type */
		messageLen+= 1; /* classJrw */
		messageLen+= 2; /* options */
		messageLen+= 22; /* exclusivearea */
		messageLen+= 22; /* commonarea */
		messageLen+= 22; /* etccommonarea */
		messageLen+= 22; /* parkingarea */
		messageLen+= 22; /* servicearea */
		messageLen+= 22; /* sitearea */
		messageLen+= 22; /* totSupplyamt */
		messageLen+= 22; /* totLandamt */
		messageLen+= 22; /* totBuildamt */
		messageLen+= 22; /* totVatamt */
		messageLen+= 22; /* totManageamt */
		messageLen+= 22; /* amt00 */
		messageLen+= 22; /* amt00L */
		messageLen+= 22; /* amt00B */
		messageLen+= 22; /* amt00V */
		messageLen+= 22; /* amt00M */
		messageLen+= 22; /* amt01 */
		messageLen+= 22; /* amt01L */
		messageLen+= 22; /* amt01B */
		messageLen+= 22; /* amt01V */
		messageLen+= 22; /* amt01M */
		messageLen+= 22; /* amt02 */
		messageLen+= 22; /* amt02L */
		messageLen+= 22; /* amt02B */
		messageLen+= 22; /* amt02V */
		messageLen+= 22; /* amt02M */
		messageLen+= 22; /* amt11 */
		messageLen+= 22; /* amt11L */
		messageLen+= 22; /* amt11B */
		messageLen+= 22; /* amt11V */
		messageLen+= 22; /* amt11M */
		messageLen+= 22; /* amt12 */
		messageLen+= 22; /* amt12L */
		messageLen+= 22; /* amt12B */
		messageLen+= 22; /* amt12V */
		messageLen+= 22; /* amt12M */
		messageLen+= 22; /* amt13 */
		messageLen+= 22; /* amt13L */
		messageLen+= 22; /* amt13B */
		messageLen+= 22; /* amt13V */
		messageLen+= 22; /* amt13M */
		messageLen+= 22; /* amt14 */
		messageLen+= 22; /* amt14L */
		messageLen+= 22; /* amt14B */
		messageLen+= 22; /* amt14V */
		messageLen+= 22; /* amt14M */
		messageLen+= 22; /* amt15 */
		messageLen+= 22; /* amt15L */
		messageLen+= 22; /* amt15B */
		messageLen+= 22; /* amt15V */
		messageLen+= 22; /* amt15M */
		messageLen+= 22; /* amt16 */
		messageLen+= 22; /* amt16L */
		messageLen+= 22; /* amt16B */
		messageLen+= 22; /* amt16V */
		messageLen+= 22; /* amt16M */
		messageLen+= 22; /* amt17 */
		messageLen+= 22; /* amt17L */
		messageLen+= 22; /* amt17B */
		messageLen+= 22; /* amt17V */
		messageLen+= 22; /* amt17M */
		messageLen+= 22; /* amt18 */
		messageLen+= 22; /* amt18L */
		messageLen+= 22; /* amt18B */
		messageLen+= 22; /* amt18V */
		messageLen+= 22; /* amt18M */
		messageLen+= 22; /* amt19 */
		messageLen+= 22; /* amt19L */
		messageLen+= 22; /* amt19B */
		messageLen+= 22; /* amt19V */
		messageLen+= 22; /* amt19M */
		messageLen+= 22; /* amt20 */
		messageLen+= 22; /* amt20L */
		messageLen+= 22; /* amt20B */
		messageLen+= 22; /* amt20V */
		messageLen+= 22; /* amt20M */
		messageLen+= 22; /* amt90 */
		messageLen+= 22; /* amt90L */
		messageLen+= 22; /* amt90B */
		messageLen+= 22; /* amt90V */
		messageLen+= 22; /* amt90M */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("square");
	
		fieldNames.add("type");
	
		fieldNames.add("classJrw");
	
		fieldNames.add("options");
	
		fieldNames.add("exclusivearea");
	
		fieldNames.add("commonarea");
	
		fieldNames.add("etccommonarea");
	
		fieldNames.add("parkingarea");
	
		fieldNames.add("servicearea");
	
		fieldNames.add("sitearea");
	
		fieldNames.add("totSupplyamt");
	
		fieldNames.add("totLandamt");
	
		fieldNames.add("totBuildamt");
	
		fieldNames.add("totVatamt");
	
		fieldNames.add("totManageamt");
	
		fieldNames.add("amt00");
	
		fieldNames.add("amt00L");
	
		fieldNames.add("amt00B");
	
		fieldNames.add("amt00V");
	
		fieldNames.add("amt00M");
	
		fieldNames.add("amt01");
	
		fieldNames.add("amt01L");
	
		fieldNames.add("amt01B");
	
		fieldNames.add("amt01V");
	
		fieldNames.add("amt01M");
	
		fieldNames.add("amt02");
	
		fieldNames.add("amt02L");
	
		fieldNames.add("amt02B");
	
		fieldNames.add("amt02V");
	
		fieldNames.add("amt02M");
	
		fieldNames.add("amt11");
	
		fieldNames.add("amt11L");
	
		fieldNames.add("amt11B");
	
		fieldNames.add("amt11V");
	
		fieldNames.add("amt11M");
	
		fieldNames.add("amt12");
	
		fieldNames.add("amt12L");
	
		fieldNames.add("amt12B");
	
		fieldNames.add("amt12V");
	
		fieldNames.add("amt12M");
	
		fieldNames.add("amt13");
	
		fieldNames.add("amt13L");
	
		fieldNames.add("amt13B");
	
		fieldNames.add("amt13V");
	
		fieldNames.add("amt13M");
	
		fieldNames.add("amt14");
	
		fieldNames.add("amt14L");
	
		fieldNames.add("amt14B");
	
		fieldNames.add("amt14V");
	
		fieldNames.add("amt14M");
	
		fieldNames.add("amt15");
	
		fieldNames.add("amt15L");
	
		fieldNames.add("amt15B");
	
		fieldNames.add("amt15V");
	
		fieldNames.add("amt15M");
	
		fieldNames.add("amt16");
	
		fieldNames.add("amt16L");
	
		fieldNames.add("amt16B");
	
		fieldNames.add("amt16V");
	
		fieldNames.add("amt16M");
	
		fieldNames.add("amt17");
	
		fieldNames.add("amt17L");
	
		fieldNames.add("amt17B");
	
		fieldNames.add("amt17V");
	
		fieldNames.add("amt17M");
	
		fieldNames.add("amt18");
	
		fieldNames.add("amt18L");
	
		fieldNames.add("amt18B");
	
		fieldNames.add("amt18V");
	
		fieldNames.add("amt18M");
	
		fieldNames.add("amt19");
	
		fieldNames.add("amt19L");
	
		fieldNames.add("amt19B");
	
		fieldNames.add("amt19V");
	
		fieldNames.add("amt19M");
	
		fieldNames.add("amt20");
	
		fieldNames.add("amt20L");
	
		fieldNames.add("amt20B");
	
		fieldNames.add("amt20V");
	
		fieldNames.add("amt20M");
	
		fieldNames.add("amt90");
	
		fieldNames.add("amt90L");
	
		fieldNames.add("amt90B");
	
		fieldNames.add("amt90V");
	
		fieldNames.add("amt90M");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("type", get("type"));
	
		fieldValueMap.put("classJrw", get("classJrw"));
	
		fieldValueMap.put("options", get("options"));
	
		fieldValueMap.put("exclusivearea", get("exclusivearea"));
	
		fieldValueMap.put("commonarea", get("commonarea"));
	
		fieldValueMap.put("etccommonarea", get("etccommonarea"));
	
		fieldValueMap.put("parkingarea", get("parkingarea"));
	
		fieldValueMap.put("servicearea", get("servicearea"));
	
		fieldValueMap.put("sitearea", get("sitearea"));
	
		fieldValueMap.put("totSupplyamt", get("totSupplyamt"));
	
		fieldValueMap.put("totLandamt", get("totLandamt"));
	
		fieldValueMap.put("totBuildamt", get("totBuildamt"));
	
		fieldValueMap.put("totVatamt", get("totVatamt"));
	
		fieldValueMap.put("totManageamt", get("totManageamt"));
	
		fieldValueMap.put("amt00", get("amt00"));
	
		fieldValueMap.put("amt00L", get("amt00L"));
	
		fieldValueMap.put("amt00B", get("amt00B"));
	
		fieldValueMap.put("amt00V", get("amt00V"));
	
		fieldValueMap.put("amt00M", get("amt00M"));
	
		fieldValueMap.put("amt01", get("amt01"));
	
		fieldValueMap.put("amt01L", get("amt01L"));
	
		fieldValueMap.put("amt01B", get("amt01B"));
	
		fieldValueMap.put("amt01V", get("amt01V"));
	
		fieldValueMap.put("amt01M", get("amt01M"));
	
		fieldValueMap.put("amt02", get("amt02"));
	
		fieldValueMap.put("amt02L", get("amt02L"));
	
		fieldValueMap.put("amt02B", get("amt02B"));
	
		fieldValueMap.put("amt02V", get("amt02V"));
	
		fieldValueMap.put("amt02M", get("amt02M"));
	
		fieldValueMap.put("amt11", get("amt11"));
	
		fieldValueMap.put("amt11L", get("amt11L"));
	
		fieldValueMap.put("amt11B", get("amt11B"));
	
		fieldValueMap.put("amt11V", get("amt11V"));
	
		fieldValueMap.put("amt11M", get("amt11M"));
	
		fieldValueMap.put("amt12", get("amt12"));
	
		fieldValueMap.put("amt12L", get("amt12L"));
	
		fieldValueMap.put("amt12B", get("amt12B"));
	
		fieldValueMap.put("amt12V", get("amt12V"));
	
		fieldValueMap.put("amt12M", get("amt12M"));
	
		fieldValueMap.put("amt13", get("amt13"));
	
		fieldValueMap.put("amt13L", get("amt13L"));
	
		fieldValueMap.put("amt13B", get("amt13B"));
	
		fieldValueMap.put("amt13V", get("amt13V"));
	
		fieldValueMap.put("amt13M", get("amt13M"));
	
		fieldValueMap.put("amt14", get("amt14"));
	
		fieldValueMap.put("amt14L", get("amt14L"));
	
		fieldValueMap.put("amt14B", get("amt14B"));
	
		fieldValueMap.put("amt14V", get("amt14V"));
	
		fieldValueMap.put("amt14M", get("amt14M"));
	
		fieldValueMap.put("amt15", get("amt15"));
	
		fieldValueMap.put("amt15L", get("amt15L"));
	
		fieldValueMap.put("amt15B", get("amt15B"));
	
		fieldValueMap.put("amt15V", get("amt15V"));
	
		fieldValueMap.put("amt15M", get("amt15M"));
	
		fieldValueMap.put("amt16", get("amt16"));
	
		fieldValueMap.put("amt16L", get("amt16L"));
	
		fieldValueMap.put("amt16B", get("amt16B"));
	
		fieldValueMap.put("amt16V", get("amt16V"));
	
		fieldValueMap.put("amt16M", get("amt16M"));
	
		fieldValueMap.put("amt17", get("amt17"));
	
		fieldValueMap.put("amt17L", get("amt17L"));
	
		fieldValueMap.put("amt17B", get("amt17B"));
	
		fieldValueMap.put("amt17V", get("amt17V"));
	
		fieldValueMap.put("amt17M", get("amt17M"));
	
		fieldValueMap.put("amt18", get("amt18"));
	
		fieldValueMap.put("amt18L", get("amt18L"));
	
		fieldValueMap.put("amt18B", get("amt18B"));
	
		fieldValueMap.put("amt18V", get("amt18V"));
	
		fieldValueMap.put("amt18M", get("amt18M"));
	
		fieldValueMap.put("amt19", get("amt19"));
	
		fieldValueMap.put("amt19L", get("amt19L"));
	
		fieldValueMap.put("amt19B", get("amt19B"));
	
		fieldValueMap.put("amt19V", get("amt19V"));
	
		fieldValueMap.put("amt19M", get("amt19M"));
	
		fieldValueMap.put("amt20", get("amt20"));
	
		fieldValueMap.put("amt20L", get("amt20L"));
	
		fieldValueMap.put("amt20B", get("amt20B"));
	
		fieldValueMap.put("amt20V", get("amt20V"));
	
		fieldValueMap.put("amt20M", get("amt20M"));
	
		fieldValueMap.put("amt90", get("amt90"));
	
		fieldValueMap.put("amt90L", get("amt90L"));
	
		fieldValueMap.put("amt90B", get("amt90B"));
	
		fieldValueMap.put("amt90V", get("amt90V"));
	
		fieldValueMap.put("amt90M", get("amt90M"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -894674659 : /* square */
			return getSquare();
		case 3575610 : /* type */
			return getType();
		case 692414359 : /* classJrw */
			return getClassJrw();
		case -1249474914 : /* options */
			return getOptions();
		case 1197019179 : /* exclusivearea */
			return getExclusivearea();
		case 1184894200 : /* commonarea */
			return getCommonarea();
		case 1900129676 : /* etccommonarea */
			return getEtccommonarea();
		case -1720326075 : /* parkingarea */
			return getParkingarea();
		case -1927990078 : /* servicearea */
			return getServicearea();
		case 675591252 : /* sitearea */
			return getSitearea();
		case 856443168 : /* totSupplyamt */
			return getTotSupplyamt();
		case 1830317156 : /* totLandamt */
			return getTotLandamt();
		case 1091547411 : /* totBuildamt */
			return getTotBuildamt();
		case -901415752 : /* totVatamt */
			return getTotVatamt();
		case 405108970 : /* totManageamt */
			return getTotManageamt();
		case 92941768 : /* amt00 */
			return getAmt00();
		case -1413772412 : /* amt00L */
			return getAmt00L();
		case -1413772422 : /* amt00B */
			return getAmt00B();
		case -1413772402 : /* amt00V */
			return getAmt00V();
		case -1413772411 : /* amt00M */
			return getAmt00M();
		case 92941769 : /* amt01 */
			return getAmt01();
		case -1413772381 : /* amt01L */
			return getAmt01L();
		case -1413772391 : /* amt01B */
			return getAmt01B();
		case -1413772371 : /* amt01V */
			return getAmt01V();
		case -1413772380 : /* amt01M */
			return getAmt01M();
		case 92941770 : /* amt02 */
			return getAmt02();
		case -1413772350 : /* amt02L */
			return getAmt02L();
		case -1413772360 : /* amt02B */
			return getAmt02B();
		case -1413772340 : /* amt02V */
			return getAmt02V();
		case -1413772349 : /* amt02M */
			return getAmt02M();
		case 92941800 : /* amt11 */
			return getAmt11();
		case -1413771420 : /* amt11L */
			return getAmt11L();
		case -1413771430 : /* amt11B */
			return getAmt11B();
		case -1413771410 : /* amt11V */
			return getAmt11V();
		case -1413771419 : /* amt11M */
			return getAmt11M();
		case 92941801 : /* amt12 */
			return getAmt12();
		case -1413771389 : /* amt12L */
			return getAmt12L();
		case -1413771399 : /* amt12B */
			return getAmt12B();
		case -1413771379 : /* amt12V */
			return getAmt12V();
		case -1413771388 : /* amt12M */
			return getAmt12M();
		case 92941802 : /* amt13 */
			return getAmt13();
		case -1413771358 : /* amt13L */
			return getAmt13L();
		case -1413771368 : /* amt13B */
			return getAmt13B();
		case -1413771348 : /* amt13V */
			return getAmt13V();
		case -1413771357 : /* amt13M */
			return getAmt13M();
		case 92941803 : /* amt14 */
			return getAmt14();
		case -1413771327 : /* amt14L */
			return getAmt14L();
		case -1413771337 : /* amt14B */
			return getAmt14B();
		case -1413771317 : /* amt14V */
			return getAmt14V();
		case -1413771326 : /* amt14M */
			return getAmt14M();
		case 92941804 : /* amt15 */
			return getAmt15();
		case -1413771296 : /* amt15L */
			return getAmt15L();
		case -1413771306 : /* amt15B */
			return getAmt15B();
		case -1413771286 : /* amt15V */
			return getAmt15V();
		case -1413771295 : /* amt15M */
			return getAmt15M();
		case 92941805 : /* amt16 */
			return getAmt16();
		case -1413771265 : /* amt16L */
			return getAmt16L();
		case -1413771275 : /* amt16B */
			return getAmt16B();
		case -1413771255 : /* amt16V */
			return getAmt16V();
		case -1413771264 : /* amt16M */
			return getAmt16M();
		case 92941806 : /* amt17 */
			return getAmt17();
		case -1413771234 : /* amt17L */
			return getAmt17L();
		case -1413771244 : /* amt17B */
			return getAmt17B();
		case -1413771224 : /* amt17V */
			return getAmt17V();
		case -1413771233 : /* amt17M */
			return getAmt17M();
		case 92941807 : /* amt18 */
			return getAmt18();
		case -1413771203 : /* amt18L */
			return getAmt18L();
		case -1413771213 : /* amt18B */
			return getAmt18B();
		case -1413771193 : /* amt18V */
			return getAmt18V();
		case -1413771202 : /* amt18M */
			return getAmt18M();
		case 92941808 : /* amt19 */
			return getAmt19();
		case -1413771172 : /* amt19L */
			return getAmt19L();
		case -1413771182 : /* amt19B */
			return getAmt19B();
		case -1413771162 : /* amt19V */
			return getAmt19V();
		case -1413771171 : /* amt19M */
			return getAmt19M();
		case 92941830 : /* amt20 */
			return getAmt20();
		case -1413770490 : /* amt20L */
			return getAmt20L();
		case -1413770500 : /* amt20B */
			return getAmt20B();
		case -1413770480 : /* amt20V */
			return getAmt20V();
		case -1413770489 : /* amt20M */
			return getAmt20M();
		case 92942047 : /* amt90 */
			return getAmt90();
		case -1413763763 : /* amt90L */
			return getAmt90L();
		case -1413763773 : /* amt90B */
			return getAmt90B();
		case -1413763753 : /* amt90V */
			return getAmt90V();
		case -1413763762 : /* amt90M */
			return getAmt90M();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case 3575610 : /* type */
			setType((java.lang.String) value);
			return;
		case 692414359 : /* classJrw */
			setClassJrw((java.lang.String) value);
			return;
		case -1249474914 : /* options */
			setOptions((java.lang.String) value);
			return;
		case 1197019179 : /* exclusivearea */
			setExclusivearea((java.math.BigDecimal) value);
			return;
		case 1184894200 : /* commonarea */
			setCommonarea((java.math.BigDecimal) value);
			return;
		case 1900129676 : /* etccommonarea */
			setEtccommonarea((java.math.BigDecimal) value);
			return;
		case -1720326075 : /* parkingarea */
			setParkingarea((java.math.BigDecimal) value);
			return;
		case -1927990078 : /* servicearea */
			setServicearea((java.math.BigDecimal) value);
			return;
		case 675591252 : /* sitearea */
			setSitearea((java.math.BigDecimal) value);
			return;
		case 856443168 : /* totSupplyamt */
			setTotSupplyamt((java.math.BigDecimal) value);
			return;
		case 1830317156 : /* totLandamt */
			setTotLandamt((java.math.BigDecimal) value);
			return;
		case 1091547411 : /* totBuildamt */
			setTotBuildamt((java.math.BigDecimal) value);
			return;
		case -901415752 : /* totVatamt */
			setTotVatamt((java.math.BigDecimal) value);
			return;
		case 405108970 : /* totManageamt */
			setTotManageamt((java.math.BigDecimal) value);
			return;
		case 92941768 : /* amt00 */
			setAmt00((java.math.BigDecimal) value);
			return;
		case -1413772412 : /* amt00L */
			setAmt00L((java.math.BigDecimal) value);
			return;
		case -1413772422 : /* amt00B */
			setAmt00B((java.math.BigDecimal) value);
			return;
		case -1413772402 : /* amt00V */
			setAmt00V((java.math.BigDecimal) value);
			return;
		case -1413772411 : /* amt00M */
			setAmt00M((java.math.BigDecimal) value);
			return;
		case 92941769 : /* amt01 */
			setAmt01((java.math.BigDecimal) value);
			return;
		case -1413772381 : /* amt01L */
			setAmt01L((java.math.BigDecimal) value);
			return;
		case -1413772391 : /* amt01B */
			setAmt01B((java.math.BigDecimal) value);
			return;
		case -1413772371 : /* amt01V */
			setAmt01V((java.math.BigDecimal) value);
			return;
		case -1413772380 : /* amt01M */
			setAmt01M((java.math.BigDecimal) value);
			return;
		case 92941770 : /* amt02 */
			setAmt02((java.math.BigDecimal) value);
			return;
		case -1413772350 : /* amt02L */
			setAmt02L((java.math.BigDecimal) value);
			return;
		case -1413772360 : /* amt02B */
			setAmt02B((java.math.BigDecimal) value);
			return;
		case -1413772340 : /* amt02V */
			setAmt02V((java.math.BigDecimal) value);
			return;
		case -1413772349 : /* amt02M */
			setAmt02M((java.math.BigDecimal) value);
			return;
		case 92941800 : /* amt11 */
			setAmt11((java.math.BigDecimal) value);
			return;
		case -1413771420 : /* amt11L */
			setAmt11L((java.math.BigDecimal) value);
			return;
		case -1413771430 : /* amt11B */
			setAmt11B((java.math.BigDecimal) value);
			return;
		case -1413771410 : /* amt11V */
			setAmt11V((java.math.BigDecimal) value);
			return;
		case -1413771419 : /* amt11M */
			setAmt11M((java.math.BigDecimal) value);
			return;
		case 92941801 : /* amt12 */
			setAmt12((java.math.BigDecimal) value);
			return;
		case -1413771389 : /* amt12L */
			setAmt12L((java.math.BigDecimal) value);
			return;
		case -1413771399 : /* amt12B */
			setAmt12B((java.math.BigDecimal) value);
			return;
		case -1413771379 : /* amt12V */
			setAmt12V((java.math.BigDecimal) value);
			return;
		case -1413771388 : /* amt12M */
			setAmt12M((java.math.BigDecimal) value);
			return;
		case 92941802 : /* amt13 */
			setAmt13((java.math.BigDecimal) value);
			return;
		case -1413771358 : /* amt13L */
			setAmt13L((java.math.BigDecimal) value);
			return;
		case -1413771368 : /* amt13B */
			setAmt13B((java.math.BigDecimal) value);
			return;
		case -1413771348 : /* amt13V */
			setAmt13V((java.math.BigDecimal) value);
			return;
		case -1413771357 : /* amt13M */
			setAmt13M((java.math.BigDecimal) value);
			return;
		case 92941803 : /* amt14 */
			setAmt14((java.math.BigDecimal) value);
			return;
		case -1413771327 : /* amt14L */
			setAmt14L((java.math.BigDecimal) value);
			return;
		case -1413771337 : /* amt14B */
			setAmt14B((java.math.BigDecimal) value);
			return;
		case -1413771317 : /* amt14V */
			setAmt14V((java.math.BigDecimal) value);
			return;
		case -1413771326 : /* amt14M */
			setAmt14M((java.math.BigDecimal) value);
			return;
		case 92941804 : /* amt15 */
			setAmt15((java.math.BigDecimal) value);
			return;
		case -1413771296 : /* amt15L */
			setAmt15L((java.math.BigDecimal) value);
			return;
		case -1413771306 : /* amt15B */
			setAmt15B((java.math.BigDecimal) value);
			return;
		case -1413771286 : /* amt15V */
			setAmt15V((java.math.BigDecimal) value);
			return;
		case -1413771295 : /* amt15M */
			setAmt15M((java.math.BigDecimal) value);
			return;
		case 92941805 : /* amt16 */
			setAmt16((java.math.BigDecimal) value);
			return;
		case -1413771265 : /* amt16L */
			setAmt16L((java.math.BigDecimal) value);
			return;
		case -1413771275 : /* amt16B */
			setAmt16B((java.math.BigDecimal) value);
			return;
		case -1413771255 : /* amt16V */
			setAmt16V((java.math.BigDecimal) value);
			return;
		case -1413771264 : /* amt16M */
			setAmt16M((java.math.BigDecimal) value);
			return;
		case 92941806 : /* amt17 */
			setAmt17((java.math.BigDecimal) value);
			return;
		case -1413771234 : /* amt17L */
			setAmt17L((java.math.BigDecimal) value);
			return;
		case -1413771244 : /* amt17B */
			setAmt17B((java.math.BigDecimal) value);
			return;
		case -1413771224 : /* amt17V */
			setAmt17V((java.math.BigDecimal) value);
			return;
		case -1413771233 : /* amt17M */
			setAmt17M((java.math.BigDecimal) value);
			return;
		case 92941807 : /* amt18 */
			setAmt18((java.math.BigDecimal) value);
			return;
		case -1413771203 : /* amt18L */
			setAmt18L((java.math.BigDecimal) value);
			return;
		case -1413771213 : /* amt18B */
			setAmt18B((java.math.BigDecimal) value);
			return;
		case -1413771193 : /* amt18V */
			setAmt18V((java.math.BigDecimal) value);
			return;
		case -1413771202 : /* amt18M */
			setAmt18M((java.math.BigDecimal) value);
			return;
		case 92941808 : /* amt19 */
			setAmt19((java.math.BigDecimal) value);
			return;
		case -1413771172 : /* amt19L */
			setAmt19L((java.math.BigDecimal) value);
			return;
		case -1413771182 : /* amt19B */
			setAmt19B((java.math.BigDecimal) value);
			return;
		case -1413771162 : /* amt19V */
			setAmt19V((java.math.BigDecimal) value);
			return;
		case -1413771171 : /* amt19M */
			setAmt19M((java.math.BigDecimal) value);
			return;
		case 92941830 : /* amt20 */
			setAmt20((java.math.BigDecimal) value);
			return;
		case -1413770490 : /* amt20L */
			setAmt20L((java.math.BigDecimal) value);
			return;
		case -1413770500 : /* amt20B */
			setAmt20B((java.math.BigDecimal) value);
			return;
		case -1413770480 : /* amt20V */
			setAmt20V((java.math.BigDecimal) value);
			return;
		case -1413770489 : /* amt20M */
			setAmt20M((java.math.BigDecimal) value);
			return;
		case 92942047 : /* amt90 */
			setAmt90((java.math.BigDecimal) value);
			return;
		case -1413763763 : /* amt90L */
			setAmt90L((java.math.BigDecimal) value);
			return;
		case -1413763773 : /* amt90B */
			setAmt90B((java.math.BigDecimal) value);
			return;
		case -1413763753 : /* amt90V */
			setAmt90V((java.math.BigDecimal) value);
			return;
		case -1413763762 : /* amt90M */
			setAmt90M((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
