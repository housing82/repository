/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.slip.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_회계전표_내역 ( HD_SLIP_MAIN )
 */
@XmlType(propOrder={"slipdate", "slipseq", "slipitem", "acntcode", "dbamt", "dbcash", "cramt", "crcash", "remark1", "remark2", "statedate", "stateno", "vatcode", "vatamt", "vatitem", "custgroup", "custcode", "custname", "compcode", "deptcode", "bankcode", "depositno", "no1", "no2", "autotag", "detailtag", "detailok", "itemseq", "insertno", "insertdate", "editemp", "remarkcode", "seq1", "seq2", "fundcode", "cashamt", "pftAcntcode", "cancelTag"}, name="DHDSlipMain01IO")
@XmlRootElement(name="DHDSlipMain01IO")
@SuppressWarnings("all")
public class DHDSlipMain01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -173519989L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_회계전표_내역 ( HD_SLIP_MAIN )";

	/*******************************************************************************************************************************
	* Property set << slipdate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipdate = false;
	
	protected boolean isSet_slipdate()
	{
		return this.isSet_slipdate;
	}
	
	protected void setIsSet_slipdate(boolean value)
	{
		this.isSet_slipdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자 [SYS_C0012811(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipdate  = null;
	
	/**
	 * @Description 전표일자 [SYS_C0012811(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public java.lang.String getSlipdate(){
		return slipdate;
	}
	
	/**
	 * @Description 전표일자 [SYS_C0012811(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	@JsonProperty("slipdate")
	public void setSlipdate( java.lang.String slipdate ) {
		isSet_slipdate = true;
		this.slipdate = slipdate;
	}
	
	/** Property set << slipdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipseq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipseq = false;
	
	protected boolean isSet_slipseq()
	{
		return this.isSet_slipseq;
	}
	
	protected void setIsSet_slipseq(boolean value)
	{
		this.isSet_slipseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번 [SYS_C0012812(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public void setSlipseq(java.lang.String value) {
		isSet_slipseq = true;
		this.slipseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번 [SYS_C0012812(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public void setSlipseq(double value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번 [SYS_C0012812(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public void setSlipseq(long value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번 [SYS_C0012812(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번 [SYS_C0012812(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public java.math.BigDecimal getSlipseq(){
		return slipseq;
	}
	
	/**
	 * @Description 전표순번 [SYS_C0012812(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	@JsonProperty("slipseq")
	public void setSlipseq( java.math.BigDecimal slipseq ) {
		isSet_slipseq = true;
		this.slipseq = slipseq;
	}
	
	/** Property set << slipseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipitem >> [[ */
	
	@XmlTransient
	private boolean isSet_slipitem = false;
	
	protected boolean isSet_slipitem()
	{
		return this.isSet_slipitem;
	}
	
	protected void setIsSet_slipitem(boolean value)
	{
		this.isSet_slipitem = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표항번 [SYS_C0012813(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public void setSlipitem(java.lang.String value) {
		isSet_slipitem = true;
		this.slipitem = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표항번 [SYS_C0012813(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public void setSlipitem(double value) {
		isSet_slipitem = true;
		this.slipitem = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표항번 [SYS_C0012813(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public void setSlipitem(long value) {
		isSet_slipitem = true;
		this.slipitem = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표항번 [SYS_C0012813(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipitem  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표항번 [SYS_C0012813(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	public java.math.BigDecimal getSlipitem(){
		return slipitem;
	}
	
	/**
	 * @Description 전표항번 [SYS_C0012813(C),SYS_C0013018(P) SYS_C0013018(UNIQUE)]
	 */
	@JsonProperty("slipitem")
	public void setSlipitem( java.math.BigDecimal slipitem ) {
		isSet_slipitem = true;
		this.slipitem = slipitem;
	}
	
	/** Property set << slipitem >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << acntcode >> [[ */
	
	@XmlTransient
	private boolean isSet_acntcode = false;
	
	protected boolean isSet_acntcode()
	{
		return this.isSet_acntcode;
	}
	
	protected void setIsSet_acntcode(boolean value)
	{
		this.isSet_acntcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계정코드 [SYS_C0012814(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String acntcode  = null;
	
	/**
	 * @Description 계정코드 [SYS_C0012814(C)]
	 */
	public java.lang.String getAcntcode(){
		return acntcode;
	}
	
	/**
	 * @Description 계정코드 [SYS_C0012814(C)]
	 */
	@JsonProperty("acntcode")
	public void setAcntcode( java.lang.String acntcode ) {
		isSet_acntcode = true;
		this.acntcode = acntcode;
	}
	
	/** Property set << acntcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dbamt >> [[ */
	
	@XmlTransient
	private boolean isSet_dbamt = false;
	
	protected boolean isSet_dbamt()
	{
		return this.isSet_dbamt;
	}
	
	protected void setIsSet_dbamt(boolean value)
	{
		this.isSet_dbamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 차변금액 [SYS_C0012815(C)]
	 */
	public void setDbamt(java.lang.String value) {
		isSet_dbamt = true;
		this.dbamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 차변금액 [SYS_C0012815(C)]
	 */
	public void setDbamt(double value) {
		isSet_dbamt = true;
		this.dbamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 차변금액 [SYS_C0012815(C)]
	 */
	public void setDbamt(long value) {
		isSet_dbamt = true;
		this.dbamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="차변금액 [SYS_C0012815(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal dbamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 차변금액 [SYS_C0012815(C)]
	 */
	public java.math.BigDecimal getDbamt(){
		return dbamt;
	}
	
	/**
	 * @Description 차변금액 [SYS_C0012815(C)]
	 */
	@JsonProperty("dbamt")
	public void setDbamt( java.math.BigDecimal dbamt ) {
		isSet_dbamt = true;
		this.dbamt = dbamt;
	}
	
	/** Property set << dbamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dbcash >> [[ */
	
	@XmlTransient
	private boolean isSet_dbcash = false;
	
	protected boolean isSet_dbcash()
	{
		return this.isSet_dbcash;
	}
	
	protected void setIsSet_dbcash(boolean value)
	{
		this.isSet_dbcash = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 차변현금 [SYS_C0012816(C)]
	 */
	public void setDbcash(java.lang.String value) {
		isSet_dbcash = true;
		this.dbcash = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 차변현금 [SYS_C0012816(C)]
	 */
	public void setDbcash(double value) {
		isSet_dbcash = true;
		this.dbcash = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 차변현금 [SYS_C0012816(C)]
	 */
	public void setDbcash(long value) {
		isSet_dbcash = true;
		this.dbcash = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="차변현금 [SYS_C0012816(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal dbcash  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 차변현금 [SYS_C0012816(C)]
	 */
	public java.math.BigDecimal getDbcash(){
		return dbcash;
	}
	
	/**
	 * @Description 차변현금 [SYS_C0012816(C)]
	 */
	@JsonProperty("dbcash")
	public void setDbcash( java.math.BigDecimal dbcash ) {
		isSet_dbcash = true;
		this.dbcash = dbcash;
	}
	
	/** Property set << dbcash >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cramt >> [[ */
	
	@XmlTransient
	private boolean isSet_cramt = false;
	
	protected boolean isSet_cramt()
	{
		return this.isSet_cramt;
	}
	
	protected void setIsSet_cramt(boolean value)
	{
		this.isSet_cramt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 대변금액 [SYS_C0012817(C)]
	 */
	public void setCramt(java.lang.String value) {
		isSet_cramt = true;
		this.cramt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 대변금액 [SYS_C0012817(C)]
	 */
	public void setCramt(double value) {
		isSet_cramt = true;
		this.cramt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 대변금액 [SYS_C0012817(C)]
	 */
	public void setCramt(long value) {
		isSet_cramt = true;
		this.cramt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="대변금액 [SYS_C0012817(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal cramt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 대변금액 [SYS_C0012817(C)]
	 */
	public java.math.BigDecimal getCramt(){
		return cramt;
	}
	
	/**
	 * @Description 대변금액 [SYS_C0012817(C)]
	 */
	@JsonProperty("cramt")
	public void setCramt( java.math.BigDecimal cramt ) {
		isSet_cramt = true;
		this.cramt = cramt;
	}
	
	/** Property set << cramt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << crcash >> [[ */
	
	@XmlTransient
	private boolean isSet_crcash = false;
	
	protected boolean isSet_crcash()
	{
		return this.isSet_crcash;
	}
	
	protected void setIsSet_crcash(boolean value)
	{
		this.isSet_crcash = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 대변현금 [SYS_C0012818(C)]
	 */
	public void setCrcash(java.lang.String value) {
		isSet_crcash = true;
		this.crcash = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 대변현금 [SYS_C0012818(C)]
	 */
	public void setCrcash(double value) {
		isSet_crcash = true;
		this.crcash = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 대변현금 [SYS_C0012818(C)]
	 */
	public void setCrcash(long value) {
		isSet_crcash = true;
		this.crcash = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="대변현금 [SYS_C0012818(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal crcash  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 대변현금 [SYS_C0012818(C)]
	 */
	public java.math.BigDecimal getCrcash(){
		return crcash;
	}
	
	/**
	 * @Description 대변현금 [SYS_C0012818(C)]
	 */
	@JsonProperty("crcash")
	public void setCrcash( java.math.BigDecimal crcash ) {
		isSet_crcash = true;
		this.crcash = crcash;
	}
	
	/** Property set << crcash >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark1 >> [[ */
	
	@XmlTransient
	private boolean isSet_remark1 = false;
	
	protected boolean isSet_remark1()
	{
		return this.isSet_remark1;
	}
	
	protected void setIsSet_remark1(boolean value)
	{
		this.isSet_remark1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고1 [SYS_C0012819(C)]", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String remark1  = null;
	
	/**
	 * @Description 비고1 [SYS_C0012819(C)]
	 */
	public java.lang.String getRemark1(){
		return remark1;
	}
	
	/**
	 * @Description 비고1 [SYS_C0012819(C)]
	 */
	@JsonProperty("remark1")
	public void setRemark1( java.lang.String remark1 ) {
		isSet_remark1 = true;
		this.remark1 = remark1;
	}
	
	/** Property set << remark1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark2 >> [[ */
	
	@XmlTransient
	private boolean isSet_remark2 = false;
	
	protected boolean isSet_remark2()
	{
		return this.isSet_remark2;
	}
	
	protected void setIsSet_remark2(boolean value)
	{
		this.isSet_remark2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고2", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String remark2  = null;
	
	/**
	 * @Description 비고2
	 */
	public java.lang.String getRemark2(){
		return remark2;
	}
	
	/**
	 * @Description 비고2
	 */
	@JsonProperty("remark2")
	public void setRemark2( java.lang.String remark2 ) {
		isSet_remark2 = true;
		this.remark2 = remark2;
	}
	
	/** Property set << remark2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << statedate >> [[ */
	
	@XmlTransient
	private boolean isSet_statedate = false;
	
	protected boolean isSet_statedate()
	{
		return this.isSet_statedate;
	}
	
	protected void setIsSet_statedate(boolean value)
	{
		this.isSet_statedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="증빙발행일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String statedate  = null;
	
	/**
	 * @Description 증빙발행일자
	 */
	public java.lang.String getStatedate(){
		return statedate;
	}
	
	/**
	 * @Description 증빙발행일자
	 */
	@JsonProperty("statedate")
	public void setStatedate( java.lang.String statedate ) {
		isSet_statedate = true;
		this.statedate = statedate;
	}
	
	/** Property set << statedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << stateno >> [[ */
	
	@XmlTransient
	private boolean isSet_stateno = false;
	
	protected boolean isSet_stateno()
	{
		return this.isSet_stateno;
	}
	
	protected void setIsSet_stateno(boolean value)
	{
		this.isSet_stateno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="증빙번호 [SYS_C0012820(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float stateno  = .0F;
	
	/**
	 * @Description 증빙번호 [SYS_C0012820(C)]
	 */
	public java.lang.Float getStateno(){
		return stateno;
	}
	
	/**
	 * @Description 증빙번호 [SYS_C0012820(C)]
	 */
	@JsonProperty("stateno")
	public void setStateno( java.lang.Float stateno ) {
		isSet_stateno = true;
		this.stateno = stateno;
	}
	
	/** Property set << stateno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatcode >> [[ */
	
	@XmlTransient
	private boolean isSet_vatcode = false;
	
	protected boolean isSet_vatcode()
	{
		return this.isSet_vatcode;
	}
	
	protected void setIsSet_vatcode(boolean value)
	{
		this.isSet_vatcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String vatcode  = null;
	
	/**
	 * @Description 부가세코드
	 */
	public java.lang.String getVatcode(){
		return vatcode;
	}
	
	/**
	 * @Description 부가세코드
	 */
	@JsonProperty("vatcode")
	public void setVatcode( java.lang.String vatcode ) {
		isSet_vatcode = true;
		this.vatcode = vatcode;
	}
	
	/** Property set << vatcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatamt >> [[ */
	
	@XmlTransient
	private boolean isSet_vatamt = false;
	
	protected boolean isSet_vatamt()
	{
		return this.isSet_vatamt;
	}
	
	protected void setIsSet_vatamt(boolean value)
	{
		this.isSet_vatamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 부가세액 [SYS_C0012821(C)]
	 */
	public void setVatamt(java.lang.String value) {
		isSet_vatamt = true;
		this.vatamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 부가세액 [SYS_C0012821(C)]
	 */
	public void setVatamt(double value) {
		isSet_vatamt = true;
		this.vatamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 부가세액 [SYS_C0012821(C)]
	 */
	public void setVatamt(long value) {
		isSet_vatamt = true;
		this.vatamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="부가세액 [SYS_C0012821(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal vatamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 부가세액 [SYS_C0012821(C)]
	 */
	public java.math.BigDecimal getVatamt(){
		return vatamt;
	}
	
	/**
	 * @Description 부가세액 [SYS_C0012821(C)]
	 */
	@JsonProperty("vatamt")
	public void setVatamt( java.math.BigDecimal vatamt ) {
		isSet_vatamt = true;
		this.vatamt = vatamt;
	}
	
	/** Property set << vatamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatitem >> [[ */
	
	@XmlTransient
	private boolean isSet_vatitem = false;
	
	protected boolean isSet_vatitem()
	{
		return this.isSet_vatitem;
	}
	
	protected void setIsSet_vatitem(boolean value)
	{
		this.isSet_vatitem = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세연결항번 [SYS_C0012822(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float vatitem  = .0F;
	
	/**
	 * @Description 부가세연결항번 [SYS_C0012822(C)]
	 */
	public java.lang.Float getVatitem(){
		return vatitem;
	}
	
	/**
	 * @Description 부가세연결항번 [SYS_C0012822(C)]
	 */
	@JsonProperty("vatitem")
	public void setVatitem( java.lang.Float vatitem ) {
		isSet_vatitem = true;
		this.vatitem = vatitem;
	}
	
	/** Property set << vatitem >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custgroup >> [[ */
	
	@XmlTransient
	private boolean isSet_custgroup = false;
	
	protected boolean isSet_custgroup()
	{
		return this.isSet_custgroup;
	}
	
	protected void setIsSet_custgroup(boolean value)
	{
		this.isSet_custgroup = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처그룹", formatType="", format="", align="left", length=13, decimal=0, arrayReference="", fill="")
	private java.lang.String custgroup  = null;
	
	/**
	 * @Description 거래처그룹
	 */
	public java.lang.String getCustgroup(){
		return custgroup;
	}
	
	/**
	 * @Description 거래처그룹
	 */
	@JsonProperty("custgroup")
	public void setCustgroup( java.lang.String custgroup ) {
		isSet_custgroup = true;
		this.custgroup = custgroup;
	}
	
	/** Property set << custgroup >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custcode >> [[ */
	
	@XmlTransient
	private boolean isSet_custcode = false;
	
	protected boolean isSet_custcode()
	{
		return this.isSet_custcode;
	}
	
	protected void setIsSet_custcode(boolean value)
	{
		this.isSet_custcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드", formatType="", format="", align="left", length=13, decimal=0, arrayReference="", fill="")
	private java.lang.String custcode  = null;
	
	/**
	 * @Description 거래처코드
	 */
	public java.lang.String getCustcode(){
		return custcode;
	}
	
	/**
	 * @Description 거래처코드
	 */
	@JsonProperty("custcode")
	public void setCustcode( java.lang.String custcode ) {
		isSet_custcode = true;
		this.custcode = custcode;
	}
	
	/** Property set << custcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custname >> [[ */
	
	@XmlTransient
	private boolean isSet_custname = false;
	
	protected boolean isSet_custname()
	{
		return this.isSet_custname;
	}
	
	protected void setIsSet_custname(boolean value)
	{
		this.isSet_custname = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String custname  = null;
	
	/**
	 * @Description 거래처명칭
	 */
	public java.lang.String getCustname(){
		return custname;
	}
	
	/**
	 * @Description 거래처명칭
	 */
	@JsonProperty("custname")
	public void setCustname( java.lang.String custname ) {
		isSet_custname = true;
		this.custname = custname;
	}
	
	/** Property set << custname >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << compcode >> [[ */
	
	@XmlTransient
	private boolean isSet_compcode = false;
	
	protected boolean isSet_compcode()
	{
		return this.isSet_compcode;
	}
	
	protected void setIsSet_compcode(boolean value)
	{
		this.isSet_compcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="귀속사업장코드", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String compcode  = null;
	
	/**
	 * @Description 귀속사업장코드
	 */
	public java.lang.String getCompcode(){
		return compcode;
	}
	
	/**
	 * @Description 귀속사업장코드
	 */
	@JsonProperty("compcode")
	public void setCompcode( java.lang.String compcode ) {
		isSet_compcode = true;
		this.compcode = compcode;
	}
	
	/** Property set << compcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptcode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptcode = false;
	
	protected boolean isSet_deptcode()
	{
		return this.isSet_deptcode;
	}
	
	protected void setIsSet_deptcode(boolean value)
	{
		this.isSet_deptcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="귀속부서코드 [SYS_C0012823(C)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptcode  = null;
	
	/**
	 * @Description 귀속부서코드 [SYS_C0012823(C)]
	 */
	public java.lang.String getDeptcode(){
		return deptcode;
	}
	
	/**
	 * @Description 귀속부서코드 [SYS_C0012823(C)]
	 */
	@JsonProperty("deptcode")
	public void setDeptcode( java.lang.String deptcode ) {
		isSet_deptcode = true;
		this.deptcode = deptcode;
	}
	
	/** Property set << deptcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankcode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankcode = false;
	
	protected boolean isSet_bankcode()
	{
		return this.isSet_bankcode;
	}
	
	protected void setIsSet_bankcode(boolean value)
	{
		this.isSet_bankcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="금융기관코드", formatType="", format="", align="left", length=7, decimal=0, arrayReference="", fill="")
	private java.lang.String bankcode  = null;
	
	/**
	 * @Description 금융기관코드
	 */
	public java.lang.String getBankcode(){
		return bankcode;
	}
	
	/**
	 * @Description 금융기관코드
	 */
	@JsonProperty("bankcode")
	public void setBankcode( java.lang.String bankcode ) {
		isSet_bankcode = true;
		this.bankcode = bankcode;
	}
	
	/** Property set << bankcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositno >> [[ */
	
	@XmlTransient
	private boolean isSet_depositno = false;
	
	protected boolean isSet_depositno()
	{
		return this.isSet_depositno;
	}
	
	protected void setIsSet_depositno(boolean value)
	{
		this.isSet_depositno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="구좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositno  = null;
	
	/**
	 * @Description 구좌번호
	 */
	public java.lang.String getDepositno(){
		return depositno;
	}
	
	/**
	 * @Description 구좌번호
	 */
	@JsonProperty("depositno")
	public void setDepositno( java.lang.String depositno ) {
		isSet_depositno = true;
		this.depositno = depositno;
	}
	
	/** Property set << depositno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << no1 >> [[ */
	
	@XmlTransient
	private boolean isSet_no1 = false;
	
	protected boolean isSet_no1()
	{
		return this.isSet_no1;
	}
	
	protected void setIsSet_no1(boolean value)
	{
		this.isSet_no1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수표/어음번호1", formatType="", format="", align="left", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.String no1  = null;
	
	/**
	 * @Description 수표/어음번호1
	 */
	public java.lang.String getNo1(){
		return no1;
	}
	
	/**
	 * @Description 수표/어음번호1
	 */
	@JsonProperty("no1")
	public void setNo1( java.lang.String no1 ) {
		isSet_no1 = true;
		this.no1 = no1;
	}
	
	/** Property set << no1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << no2 >> [[ */
	
	@XmlTransient
	private boolean isSet_no2 = false;
	
	protected boolean isSet_no2()
	{
		return this.isSet_no2;
	}
	
	protected void setIsSet_no2(boolean value)
	{
		this.isSet_no2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수표/어음번호2", formatType="", format="", align="left", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.String no2  = null;
	
	/**
	 * @Description 수표/어음번호2
	 */
	public java.lang.String getNo2(){
		return no2;
	}
	
	/**
	 * @Description 수표/어음번호2
	 */
	@JsonProperty("no2")
	public void setNo2( java.lang.String no2 ) {
		isSet_no2 = true;
		this.no2 = no2;
	}
	
	/** Property set << no2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << autotag >> [[ */
	
	@XmlTransient
	private boolean isSet_autotag = false;
	
	protected boolean isSet_autotag()
	{
		return this.isSet_autotag;
	}
	
	protected void setIsSet_autotag(boolean value)
	{
		this.isSet_autotag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="자동발생구분 [SYS_C0012824(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String autotag  = null;
	
	/**
	 * @Description 자동발생구분 [SYS_C0012824(C)]
	 */
	public java.lang.String getAutotag(){
		return autotag;
	}
	
	/**
	 * @Description 자동발생구분 [SYS_C0012824(C)]
	 */
	@JsonProperty("autotag")
	public void setAutotag( java.lang.String autotag ) {
		isSet_autotag = true;
		this.autotag = autotag;
	}
	
	/** Property set << autotag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << detailtag >> [[ */
	
	@XmlTransient
	private boolean isSet_detailtag = false;
	
	protected boolean isSet_detailtag()
	{
		return this.isSet_detailtag;
	}
	
	protected void setIsSet_detailtag(boolean value)
	{
		this.isSet_detailtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="세부사항구분 [SYS_C0012825(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String detailtag  = null;
	
	/**
	 * @Description 세부사항구분 [SYS_C0012825(C)]
	 */
	public java.lang.String getDetailtag(){
		return detailtag;
	}
	
	/**
	 * @Description 세부사항구분 [SYS_C0012825(C)]
	 */
	@JsonProperty("detailtag")
	public void setDetailtag( java.lang.String detailtag ) {
		isSet_detailtag = true;
		this.detailtag = detailtag;
	}
	
	/** Property set << detailtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << detailok >> [[ */
	
	@XmlTransient
	private boolean isSet_detailok = false;
	
	protected boolean isSet_detailok()
	{
		return this.isSet_detailok;
	}
	
	protected void setIsSet_detailok(boolean value)
	{
		this.isSet_detailok = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="세부입력여부 [SYS_C0012826(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String detailok  = null;
	
	/**
	 * @Description 세부입력여부 [SYS_C0012826(C)]
	 */
	public java.lang.String getDetailok(){
		return detailok;
	}
	
	/**
	 * @Description 세부입력여부 [SYS_C0012826(C)]
	 */
	@JsonProperty("detailok")
	public void setDetailok( java.lang.String detailok ) {
		isSet_detailok = true;
		this.detailok = detailok;
	}
	
	/** Property set << detailok >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << itemseq >> [[ */
	
	@XmlTransient
	private boolean isSet_itemseq = false;
	
	protected boolean isSet_itemseq()
	{
		return this.isSet_itemseq;
	}
	
	protected void setIsSet_itemseq(boolean value)
	{
		this.isSet_itemseq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="화면항번 [SYS_C0012827(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float itemseq  = .0F;
	
	/**
	 * @Description 화면항번 [SYS_C0012827(C)]
	 */
	public java.lang.Float getItemseq(){
		return itemseq;
	}
	
	/**
	 * @Description 화면항번 [SYS_C0012827(C)]
	 */
	@JsonProperty("itemseq")
	public void setItemseq( java.lang.Float itemseq ) {
		isSet_itemseq = true;
		this.itemseq = itemseq;
	}
	
	/** Property set << itemseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << insertno >> [[ */
	
	@XmlTransient
	private boolean isSet_insertno = false;
	
	protected boolean isSet_insertno()
	{
		return this.isSet_insertno;
	}
	
	protected void setIsSet_insertno(boolean value)
	{
		this.isSet_insertno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="불입예정회차", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float insertno  = .0F;
	
	/**
	 * @Description 불입예정회차
	 */
	public java.lang.Float getInsertno(){
		return insertno;
	}
	
	/**
	 * @Description 불입예정회차
	 */
	@JsonProperty("insertno")
	public void setInsertno( java.lang.Float insertno ) {
		isSet_insertno = true;
		this.insertno = insertno;
	}
	
	/** Property set << insertno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << insertdate >> [[ */
	
	@XmlTransient
	private boolean isSet_insertdate = false;
	
	protected boolean isSet_insertdate()
	{
		return this.isSet_insertdate;
	}
	
	protected void setIsSet_insertdate(boolean value)
	{
		this.isSet_insertdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="불입일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String insertdate  = null;
	
	/**
	 * @Description 불입일자
	 */
	public java.lang.String getInsertdate(){
		return insertdate;
	}
	
	/**
	 * @Description 불입일자
	 */
	@JsonProperty("insertdate")
	public void setInsertdate( java.lang.String insertdate ) {
		isSet_insertdate = true;
		this.insertdate = insertdate;
	}
	
	/** Property set << insertdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << editemp >> [[ */
	
	@XmlTransient
	private boolean isSet_editemp = false;
	
	protected boolean isSet_editemp()
	{
		return this.isSet_editemp;
	}
	
	protected void setIsSet_editemp(boolean value)
	{
		this.isSet_editemp = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정사원번호", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String editemp  = null;
	
	/**
	 * @Description 수정사원번호
	 */
	public java.lang.String getEditemp(){
		return editemp;
	}
	
	/**
	 * @Description 수정사원번호
	 */
	@JsonProperty("editemp")
	public void setEditemp( java.lang.String editemp ) {
		isSet_editemp = true;
		this.editemp = editemp;
	}
	
	/** Property set << editemp >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remarkcode >> [[ */
	
	@XmlTransient
	private boolean isSet_remarkcode = false;
	
	protected boolean isSet_remarkcode()
	{
		return this.isSet_remarkcode;
	}
	
	protected void setIsSet_remarkcode(boolean value)
	{
		this.isSet_remarkcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="적요코드", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float remarkcode  = .0F;
	
	/**
	 * @Description 적요코드
	 */
	public java.lang.Float getRemarkcode(){
		return remarkcode;
	}
	
	/**
	 * @Description 적요코드
	 */
	@JsonProperty("remarkcode")
	public void setRemarkcode( java.lang.Float remarkcode ) {
		isSet_remarkcode = true;
		this.remarkcode = remarkcode;
	}
	
	/** Property set << remarkcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq1 >> [[ */
	
	@XmlTransient
	private boolean isSet_seq1 = false;
	
	protected boolean isSet_seq1()
	{
		return this.isSet_seq1;
	}
	
	protected void setIsSet_seq1(boolean value)
	{
		this.isSet_seq1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="순번1", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float seq1  = .0F;
	
	/**
	 * @Description 순번1
	 */
	public java.lang.Float getSeq1(){
		return seq1;
	}
	
	/**
	 * @Description 순번1
	 */
	@JsonProperty("seq1")
	public void setSeq1( java.lang.Float seq1 ) {
		isSet_seq1 = true;
		this.seq1 = seq1;
	}
	
	/** Property set << seq1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq2 >> [[ */
	
	@XmlTransient
	private boolean isSet_seq2 = false;
	
	protected boolean isSet_seq2()
	{
		return this.isSet_seq2;
	}
	
	protected void setIsSet_seq2(boolean value)
	{
		this.isSet_seq2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="순번2", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float seq2  = .0F;
	
	/**
	 * @Description 순번2
	 */
	public java.lang.Float getSeq2(){
		return seq2;
	}
	
	/**
	 * @Description 순번2
	 */
	@JsonProperty("seq2")
	public void setSeq2( java.lang.Float seq2 ) {
		isSet_seq2 = true;
		this.seq2 = seq2;
	}
	
	/** Property set << seq2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fundcode >> [[ */
	
	@XmlTransient
	private boolean isSet_fundcode = false;
	
	protected boolean isSet_fundcode()
	{
		return this.isSet_fundcode;
	}
	
	protected void setIsSet_fundcode(boolean value)
	{
		this.isSet_fundcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="자금코드", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String fundcode  = null;
	
	/**
	 * @Description 자금코드
	 */
	public java.lang.String getFundcode(){
		return fundcode;
	}
	
	/**
	 * @Description 자금코드
	 */
	@JsonProperty("fundcode")
	public void setFundcode( java.lang.String fundcode ) {
		isSet_fundcode = true;
		this.fundcode = fundcode;
	}
	
	/** Property set << fundcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cashamt >> [[ */
	
	@XmlTransient
	private boolean isSet_cashamt = false;
	
	protected boolean isSet_cashamt()
	{
		return this.isSet_cashamt;
	}
	
	protected void setIsSet_cashamt(boolean value)
	{
		this.isSet_cashamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현금금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float cashamt  = .0F;
	
	/**
	 * @Description 현금금액
	 */
	public java.lang.Float getCashamt(){
		return cashamt;
	}
	
	/**
	 * @Description 현금금액
	 */
	@JsonProperty("cashamt")
	public void setCashamt( java.lang.Float cashamt ) {
		isSet_cashamt = true;
		this.cashamt = cashamt;
	}
	
	/** Property set << cashamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << pftAcntcode >> [[ */
	
	@XmlTransient
	private boolean isSet_pftAcntcode = false;
	
	protected boolean isSet_pftAcntcode()
	{
		return this.isSet_pftAcntcode;
	}
	
	protected void setIsSet_pftAcntcode(boolean value)
	{
		this.isSet_pftAcntcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="자금수지계정", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String pftAcntcode  = null;
	
	/**
	 * @Description 자금수지계정
	 */
	public java.lang.String getPftAcntcode(){
		return pftAcntcode;
	}
	
	/**
	 * @Description 자금수지계정
	 */
	@JsonProperty("pftAcntcode")
	public void setPftAcntcode( java.lang.String pftAcntcode ) {
		isSet_pftAcntcode = true;
		this.pftAcntcode = pftAcntcode;
	}
	
	/** Property set << pftAcntcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelTag >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelTag = false;
	
	protected boolean isSet_cancelTag()
	{
		return this.isSet_cancelTag;
	}
	
	protected void setIsSet_cancelTag(boolean value)
	{
		this.isSet_cancelTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="취소여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelTag  = null;
	
	/**
	 * @Description 취소여부
	 */
	public java.lang.String getCancelTag(){
		return cancelTag;
	}
	
	/**
	 * @Description 취소여부
	 */
	@JsonProperty("cancelTag")
	public void setCancelTag( java.lang.String cancelTag ) {
		isSet_cancelTag = true;
		this.cancelTag = cancelTag;
	}
	
	/** Property set << cancelTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDSlipMain01IO clone(){
		try{
			DHDSlipMain01IO object= (DHDSlipMain01IO)super.clone();
			if ( this.slipdate== null ) object.slipdate = null;
			else{
				object.slipdate = this.slipdate;
			}
			if ( this.slipseq== null ) object.slipseq = null;
			else{
				object.slipseq = new java.math.BigDecimal(slipseq.toString());
			}
			if ( this.slipitem== null ) object.slipitem = null;
			else{
				object.slipitem = new java.math.BigDecimal(slipitem.toString());
			}
			if ( this.acntcode== null ) object.acntcode = null;
			else{
				object.acntcode = this.acntcode;
			}
			if ( this.dbamt== null ) object.dbamt = null;
			else{
				object.dbamt = new java.math.BigDecimal(dbamt.toString());
			}
			if ( this.dbcash== null ) object.dbcash = null;
			else{
				object.dbcash = new java.math.BigDecimal(dbcash.toString());
			}
			if ( this.cramt== null ) object.cramt = null;
			else{
				object.cramt = new java.math.BigDecimal(cramt.toString());
			}
			if ( this.crcash== null ) object.crcash = null;
			else{
				object.crcash = new java.math.BigDecimal(crcash.toString());
			}
			if ( this.remark1== null ) object.remark1 = null;
			else{
				object.remark1 = this.remark1;
			}
			if ( this.remark2== null ) object.remark2 = null;
			else{
				object.remark2 = this.remark2;
			}
			if ( this.statedate== null ) object.statedate = null;
			else{
				object.statedate = this.statedate;
			}
			if ( this.stateno== null ) object.stateno = null;
			else{
				object.stateno = this.stateno;
			}
			if ( this.vatcode== null ) object.vatcode = null;
			else{
				object.vatcode = this.vatcode;
			}
			if ( this.vatamt== null ) object.vatamt = null;
			else{
				object.vatamt = new java.math.BigDecimal(vatamt.toString());
			}
			if ( this.vatitem== null ) object.vatitem = null;
			else{
				object.vatitem = this.vatitem;
			}
			if ( this.custgroup== null ) object.custgroup = null;
			else{
				object.custgroup = this.custgroup;
			}
			if ( this.custcode== null ) object.custcode = null;
			else{
				object.custcode = this.custcode;
			}
			if ( this.custname== null ) object.custname = null;
			else{
				object.custname = this.custname;
			}
			if ( this.compcode== null ) object.compcode = null;
			else{
				object.compcode = this.compcode;
			}
			if ( this.deptcode== null ) object.deptcode = null;
			else{
				object.deptcode = this.deptcode;
			}
			if ( this.bankcode== null ) object.bankcode = null;
			else{
				object.bankcode = this.bankcode;
			}
			if ( this.depositno== null ) object.depositno = null;
			else{
				object.depositno = this.depositno;
			}
			if ( this.no1== null ) object.no1 = null;
			else{
				object.no1 = this.no1;
			}
			if ( this.no2== null ) object.no2 = null;
			else{
				object.no2 = this.no2;
			}
			if ( this.autotag== null ) object.autotag = null;
			else{
				object.autotag = this.autotag;
			}
			if ( this.detailtag== null ) object.detailtag = null;
			else{
				object.detailtag = this.detailtag;
			}
			if ( this.detailok== null ) object.detailok = null;
			else{
				object.detailok = this.detailok;
			}
			if ( this.itemseq== null ) object.itemseq = null;
			else{
				object.itemseq = this.itemseq;
			}
			if ( this.insertno== null ) object.insertno = null;
			else{
				object.insertno = this.insertno;
			}
			if ( this.insertdate== null ) object.insertdate = null;
			else{
				object.insertdate = this.insertdate;
			}
			if ( this.editemp== null ) object.editemp = null;
			else{
				object.editemp = this.editemp;
			}
			if ( this.remarkcode== null ) object.remarkcode = null;
			else{
				object.remarkcode = this.remarkcode;
			}
			if ( this.seq1== null ) object.seq1 = null;
			else{
				object.seq1 = this.seq1;
			}
			if ( this.seq2== null ) object.seq2 = null;
			else{
				object.seq2 = this.seq2;
			}
			if ( this.fundcode== null ) object.fundcode = null;
			else{
				object.fundcode = this.fundcode;
			}
			if ( this.cashamt== null ) object.cashamt = null;
			else{
				object.cashamt = this.cashamt;
			}
			if ( this.pftAcntcode== null ) object.pftAcntcode = null;
			else{
				object.pftAcntcode = this.pftAcntcode;
			}
			if ( this.cancelTag== null ) object.cancelTag = null;
			else{
				object.cancelTag = this.cancelTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((slipdate==null)?0:slipdate.hashCode());
		result = prime * result + ((slipseq==null)?0:slipseq.hashCode());
		result = prime * result + ((slipitem==null)?0:slipitem.hashCode());
		result = prime * result + ((acntcode==null)?0:acntcode.hashCode());
		result = prime * result + ((dbamt==null)?0:dbamt.hashCode());
		result = prime * result + ((dbcash==null)?0:dbcash.hashCode());
		result = prime * result + ((cramt==null)?0:cramt.hashCode());
		result = prime * result + ((crcash==null)?0:crcash.hashCode());
		result = prime * result + ((remark1==null)?0:remark1.hashCode());
		result = prime * result + ((remark2==null)?0:remark2.hashCode());
		result = prime * result + ((statedate==null)?0:statedate.hashCode());
		result = prime * result + ((stateno==null)?0:stateno.hashCode());
		result = prime * result + ((vatcode==null)?0:vatcode.hashCode());
		result = prime * result + ((vatamt==null)?0:vatamt.hashCode());
		result = prime * result + ((vatitem==null)?0:vatitem.hashCode());
		result = prime * result + ((custgroup==null)?0:custgroup.hashCode());
		result = prime * result + ((custcode==null)?0:custcode.hashCode());
		result = prime * result + ((custname==null)?0:custname.hashCode());
		result = prime * result + ((compcode==null)?0:compcode.hashCode());
		result = prime * result + ((deptcode==null)?0:deptcode.hashCode());
		result = prime * result + ((bankcode==null)?0:bankcode.hashCode());
		result = prime * result + ((depositno==null)?0:depositno.hashCode());
		result = prime * result + ((no1==null)?0:no1.hashCode());
		result = prime * result + ((no2==null)?0:no2.hashCode());
		result = prime * result + ((autotag==null)?0:autotag.hashCode());
		result = prime * result + ((detailtag==null)?0:detailtag.hashCode());
		result = prime * result + ((detailok==null)?0:detailok.hashCode());
		result = prime * result + ((itemseq==null)?0:itemseq.hashCode());
		result = prime * result + ((insertno==null)?0:insertno.hashCode());
		result = prime * result + ((insertdate==null)?0:insertdate.hashCode());
		result = prime * result + ((editemp==null)?0:editemp.hashCode());
		result = prime * result + ((remarkcode==null)?0:remarkcode.hashCode());
		result = prime * result + ((seq1==null)?0:seq1.hashCode());
		result = prime * result + ((seq2==null)?0:seq2.hashCode());
		result = prime * result + ((fundcode==null)?0:fundcode.hashCode());
		result = prime * result + ((cashamt==null)?0:cashamt.hashCode());
		result = prime * result + ((pftAcntcode==null)?0:pftAcntcode.hashCode());
		result = prime * result + ((cancelTag==null)?0:cancelTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.slip.onl.dao.dto.DHDSlipMain01IO other = (kait.hd.slip.onl.dao.dto.DHDSlipMain01IO)obj;
		if ( slipdate == null ){
			if ( other.slipdate != null ) return false;
		}
		else if ( !slipdate.equals(other.slipdate) )
			return false;
		if ( slipseq == null ){
			if ( other.slipseq != null ) return false;
		}
		else if ( !slipseq.equals(other.slipseq) )
			return false;
		if ( slipitem == null ){
			if ( other.slipitem != null ) return false;
		}
		else if ( !slipitem.equals(other.slipitem) )
			return false;
		if ( acntcode == null ){
			if ( other.acntcode != null ) return false;
		}
		else if ( !acntcode.equals(other.acntcode) )
			return false;
		if ( dbamt == null ){
			if ( other.dbamt != null ) return false;
		}
		else if ( !dbamt.equals(other.dbamt) )
			return false;
		if ( dbcash == null ){
			if ( other.dbcash != null ) return false;
		}
		else if ( !dbcash.equals(other.dbcash) )
			return false;
		if ( cramt == null ){
			if ( other.cramt != null ) return false;
		}
		else if ( !cramt.equals(other.cramt) )
			return false;
		if ( crcash == null ){
			if ( other.crcash != null ) return false;
		}
		else if ( !crcash.equals(other.crcash) )
			return false;
		if ( remark1 == null ){
			if ( other.remark1 != null ) return false;
		}
		else if ( !remark1.equals(other.remark1) )
			return false;
		if ( remark2 == null ){
			if ( other.remark2 != null ) return false;
		}
		else if ( !remark2.equals(other.remark2) )
			return false;
		if ( statedate == null ){
			if ( other.statedate != null ) return false;
		}
		else if ( !statedate.equals(other.statedate) )
			return false;
		if ( stateno == null ){
			if ( other.stateno != null ) return false;
		}
		else if ( !stateno.equals(other.stateno) )
			return false;
		if ( vatcode == null ){
			if ( other.vatcode != null ) return false;
		}
		else if ( !vatcode.equals(other.vatcode) )
			return false;
		if ( vatamt == null ){
			if ( other.vatamt != null ) return false;
		}
		else if ( !vatamt.equals(other.vatamt) )
			return false;
		if ( vatitem == null ){
			if ( other.vatitem != null ) return false;
		}
		else if ( !vatitem.equals(other.vatitem) )
			return false;
		if ( custgroup == null ){
			if ( other.custgroup != null ) return false;
		}
		else if ( !custgroup.equals(other.custgroup) )
			return false;
		if ( custcode == null ){
			if ( other.custcode != null ) return false;
		}
		else if ( !custcode.equals(other.custcode) )
			return false;
		if ( custname == null ){
			if ( other.custname != null ) return false;
		}
		else if ( !custname.equals(other.custname) )
			return false;
		if ( compcode == null ){
			if ( other.compcode != null ) return false;
		}
		else if ( !compcode.equals(other.compcode) )
			return false;
		if ( deptcode == null ){
			if ( other.deptcode != null ) return false;
		}
		else if ( !deptcode.equals(other.deptcode) )
			return false;
		if ( bankcode == null ){
			if ( other.bankcode != null ) return false;
		}
		else if ( !bankcode.equals(other.bankcode) )
			return false;
		if ( depositno == null ){
			if ( other.depositno != null ) return false;
		}
		else if ( !depositno.equals(other.depositno) )
			return false;
		if ( no1 == null ){
			if ( other.no1 != null ) return false;
		}
		else if ( !no1.equals(other.no1) )
			return false;
		if ( no2 == null ){
			if ( other.no2 != null ) return false;
		}
		else if ( !no2.equals(other.no2) )
			return false;
		if ( autotag == null ){
			if ( other.autotag != null ) return false;
		}
		else if ( !autotag.equals(other.autotag) )
			return false;
		if ( detailtag == null ){
			if ( other.detailtag != null ) return false;
		}
		else if ( !detailtag.equals(other.detailtag) )
			return false;
		if ( detailok == null ){
			if ( other.detailok != null ) return false;
		}
		else if ( !detailok.equals(other.detailok) )
			return false;
		if ( itemseq == null ){
			if ( other.itemseq != null ) return false;
		}
		else if ( !itemseq.equals(other.itemseq) )
			return false;
		if ( insertno == null ){
			if ( other.insertno != null ) return false;
		}
		else if ( !insertno.equals(other.insertno) )
			return false;
		if ( insertdate == null ){
			if ( other.insertdate != null ) return false;
		}
		else if ( !insertdate.equals(other.insertdate) )
			return false;
		if ( editemp == null ){
			if ( other.editemp != null ) return false;
		}
		else if ( !editemp.equals(other.editemp) )
			return false;
		if ( remarkcode == null ){
			if ( other.remarkcode != null ) return false;
		}
		else if ( !remarkcode.equals(other.remarkcode) )
			return false;
		if ( seq1 == null ){
			if ( other.seq1 != null ) return false;
		}
		else if ( !seq1.equals(other.seq1) )
			return false;
		if ( seq2 == null ){
			if ( other.seq2 != null ) return false;
		}
		else if ( !seq2.equals(other.seq2) )
			return false;
		if ( fundcode == null ){
			if ( other.fundcode != null ) return false;
		}
		else if ( !fundcode.equals(other.fundcode) )
			return false;
		if ( cashamt == null ){
			if ( other.cashamt != null ) return false;
		}
		else if ( !cashamt.equals(other.cashamt) )
			return false;
		if ( pftAcntcode == null ){
			if ( other.pftAcntcode != null ) return false;
		}
		else if ( !pftAcntcode.equals(other.pftAcntcode) )
			return false;
		if ( cancelTag == null ){
			if ( other.cancelTag != null ) return false;
		}
		else if ( !cancelTag.equals(other.cancelTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.slip.onl.dao.dto.DHDSlipMain01IO:\n");
		sb.append("\tslipdate: ");
		sb.append(slipdate==null?"null":getSlipdate());
		sb.append("\n");
		sb.append("\tslipseq: ");
		sb.append(slipseq==null?"null":getSlipseq());
		sb.append("\n");
		sb.append("\tslipitem: ");
		sb.append(slipitem==null?"null":getSlipitem());
		sb.append("\n");
		sb.append("\tacntcode: ");
		sb.append(acntcode==null?"null":getAcntcode());
		sb.append("\n");
		sb.append("\tdbamt: ");
		sb.append(dbamt==null?"null":getDbamt());
		sb.append("\n");
		sb.append("\tdbcash: ");
		sb.append(dbcash==null?"null":getDbcash());
		sb.append("\n");
		sb.append("\tcramt: ");
		sb.append(cramt==null?"null":getCramt());
		sb.append("\n");
		sb.append("\tcrcash: ");
		sb.append(crcash==null?"null":getCrcash());
		sb.append("\n");
		sb.append("\tremark1: ");
		sb.append(remark1==null?"null":getRemark1());
		sb.append("\n");
		sb.append("\tremark2: ");
		sb.append(remark2==null?"null":getRemark2());
		sb.append("\n");
		sb.append("\tstatedate: ");
		sb.append(statedate==null?"null":getStatedate());
		sb.append("\n");
		sb.append("\tstateno: ");
		sb.append(stateno==null?"null":getStateno());
		sb.append("\n");
		sb.append("\tvatcode: ");
		sb.append(vatcode==null?"null":getVatcode());
		sb.append("\n");
		sb.append("\tvatamt: ");
		sb.append(vatamt==null?"null":getVatamt());
		sb.append("\n");
		sb.append("\tvatitem: ");
		sb.append(vatitem==null?"null":getVatitem());
		sb.append("\n");
		sb.append("\tcustgroup: ");
		sb.append(custgroup==null?"null":getCustgroup());
		sb.append("\n");
		sb.append("\tcustcode: ");
		sb.append(custcode==null?"null":getCustcode());
		sb.append("\n");
		sb.append("\tcustname: ");
		sb.append(custname==null?"null":getCustname());
		sb.append("\n");
		sb.append("\tcompcode: ");
		sb.append(compcode==null?"null":getCompcode());
		sb.append("\n");
		sb.append("\tdeptcode: ");
		sb.append(deptcode==null?"null":getDeptcode());
		sb.append("\n");
		sb.append("\tbankcode: ");
		sb.append(bankcode==null?"null":getBankcode());
		sb.append("\n");
		sb.append("\tdepositno: ");
		sb.append(depositno==null?"null":getDepositno());
		sb.append("\n");
		sb.append("\tno1: ");
		sb.append(no1==null?"null":getNo1());
		sb.append("\n");
		sb.append("\tno2: ");
		sb.append(no2==null?"null":getNo2());
		sb.append("\n");
		sb.append("\tautotag: ");
		sb.append(autotag==null?"null":getAutotag());
		sb.append("\n");
		sb.append("\tdetailtag: ");
		sb.append(detailtag==null?"null":getDetailtag());
		sb.append("\n");
		sb.append("\tdetailok: ");
		sb.append(detailok==null?"null":getDetailok());
		sb.append("\n");
		sb.append("\titemseq: ");
		sb.append(itemseq==null?"null":getItemseq());
		sb.append("\n");
		sb.append("\tinsertno: ");
		sb.append(insertno==null?"null":getInsertno());
		sb.append("\n");
		sb.append("\tinsertdate: ");
		sb.append(insertdate==null?"null":getInsertdate());
		sb.append("\n");
		sb.append("\teditemp: ");
		sb.append(editemp==null?"null":getEditemp());
		sb.append("\n");
		sb.append("\tremarkcode: ");
		sb.append(remarkcode==null?"null":getRemarkcode());
		sb.append("\n");
		sb.append("\tseq1: ");
		sb.append(seq1==null?"null":getSeq1());
		sb.append("\n");
		sb.append("\tseq2: ");
		sb.append(seq2==null?"null":getSeq2());
		sb.append("\n");
		sb.append("\tfundcode: ");
		sb.append(fundcode==null?"null":getFundcode());
		sb.append("\n");
		sb.append("\tcashamt: ");
		sb.append(cashamt==null?"null":getCashamt());
		sb.append("\n");
		sb.append("\tpftAcntcode: ");
		sb.append(pftAcntcode==null?"null":getPftAcntcode());
		sb.append("\n");
		sb.append("\tcancelTag: ");
		sb.append(cancelTag==null?"null":getCancelTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 8; /* slipdate */
		messageLen+= 22; /* slipseq */
		messageLen+= 22; /* slipitem */
		messageLen+= 8; /* acntcode */
		messageLen+= 22; /* dbamt */
		messageLen+= 22; /* dbcash */
		messageLen+= 22; /* cramt */
		messageLen+= 22; /* crcash */
		messageLen+= 40; /* remark1 */
		messageLen+= 40; /* remark2 */
		messageLen+= 8; /* statedate */
		messageLen+= 22; /* stateno */
		messageLen+= 2; /* vatcode */
		messageLen+= 22; /* vatamt */
		messageLen+= 22; /* vatitem */
		messageLen+= 13; /* custgroup */
		messageLen+= 13; /* custcode */
		messageLen+= 30; /* custname */
		messageLen+= 6; /* compcode */
		messageLen+= 12; /* deptcode */
		messageLen+= 7; /* bankcode */
		messageLen+= 30; /* depositno */
		messageLen+= 9; /* no1 */
		messageLen+= 9; /* no2 */
		messageLen+= 1; /* autotag */
		messageLen+= 1; /* detailtag */
		messageLen+= 1; /* detailok */
		messageLen+= 22; /* itemseq */
		messageLen+= 22; /* insertno */
		messageLen+= 8; /* insertdate */
		messageLen+= 8; /* editemp */
		messageLen+= 22; /* remarkcode */
		messageLen+= 22; /* seq1 */
		messageLen+= 22; /* seq2 */
		messageLen+= 3; /* fundcode */
		messageLen+= 22; /* cashamt */
		messageLen+= 8; /* pftAcntcode */
		messageLen+= 1; /* cancelTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("slipdate");
	
		fieldNames.add("slipseq");
	
		fieldNames.add("slipitem");
	
		fieldNames.add("acntcode");
	
		fieldNames.add("dbamt");
	
		fieldNames.add("dbcash");
	
		fieldNames.add("cramt");
	
		fieldNames.add("crcash");
	
		fieldNames.add("remark1");
	
		fieldNames.add("remark2");
	
		fieldNames.add("statedate");
	
		fieldNames.add("stateno");
	
		fieldNames.add("vatcode");
	
		fieldNames.add("vatamt");
	
		fieldNames.add("vatitem");
	
		fieldNames.add("custgroup");
	
		fieldNames.add("custcode");
	
		fieldNames.add("custname");
	
		fieldNames.add("compcode");
	
		fieldNames.add("deptcode");
	
		fieldNames.add("bankcode");
	
		fieldNames.add("depositno");
	
		fieldNames.add("no1");
	
		fieldNames.add("no2");
	
		fieldNames.add("autotag");
	
		fieldNames.add("detailtag");
	
		fieldNames.add("detailok");
	
		fieldNames.add("itemseq");
	
		fieldNames.add("insertno");
	
		fieldNames.add("insertdate");
	
		fieldNames.add("editemp");
	
		fieldNames.add("remarkcode");
	
		fieldNames.add("seq1");
	
		fieldNames.add("seq2");
	
		fieldNames.add("fundcode");
	
		fieldNames.add("cashamt");
	
		fieldNames.add("pftAcntcode");
	
		fieldNames.add("cancelTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("slipdate", get("slipdate"));
	
		fieldValueMap.put("slipseq", get("slipseq"));
	
		fieldValueMap.put("slipitem", get("slipitem"));
	
		fieldValueMap.put("acntcode", get("acntcode"));
	
		fieldValueMap.put("dbamt", get("dbamt"));
	
		fieldValueMap.put("dbcash", get("dbcash"));
	
		fieldValueMap.put("cramt", get("cramt"));
	
		fieldValueMap.put("crcash", get("crcash"));
	
		fieldValueMap.put("remark1", get("remark1"));
	
		fieldValueMap.put("remark2", get("remark2"));
	
		fieldValueMap.put("statedate", get("statedate"));
	
		fieldValueMap.put("stateno", get("stateno"));
	
		fieldValueMap.put("vatcode", get("vatcode"));
	
		fieldValueMap.put("vatamt", get("vatamt"));
	
		fieldValueMap.put("vatitem", get("vatitem"));
	
		fieldValueMap.put("custgroup", get("custgroup"));
	
		fieldValueMap.put("custcode", get("custcode"));
	
		fieldValueMap.put("custname", get("custname"));
	
		fieldValueMap.put("compcode", get("compcode"));
	
		fieldValueMap.put("deptcode", get("deptcode"));
	
		fieldValueMap.put("bankcode", get("bankcode"));
	
		fieldValueMap.put("depositno", get("depositno"));
	
		fieldValueMap.put("no1", get("no1"));
	
		fieldValueMap.put("no2", get("no2"));
	
		fieldValueMap.put("autotag", get("autotag"));
	
		fieldValueMap.put("detailtag", get("detailtag"));
	
		fieldValueMap.put("detailok", get("detailok"));
	
		fieldValueMap.put("itemseq", get("itemseq"));
	
		fieldValueMap.put("insertno", get("insertno"));
	
		fieldValueMap.put("insertdate", get("insertdate"));
	
		fieldValueMap.put("editemp", get("editemp"));
	
		fieldValueMap.put("remarkcode", get("remarkcode"));
	
		fieldValueMap.put("seq1", get("seq1"));
	
		fieldValueMap.put("seq2", get("seq2"));
	
		fieldValueMap.put("fundcode", get("fundcode"));
	
		fieldValueMap.put("cashamt", get("cashamt"));
	
		fieldValueMap.put("pftAcntcode", get("pftAcntcode"));
	
		fieldValueMap.put("cancelTag", get("cancelTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1261553426 : /* slipdate */
			return getSlipdate();
		case -2118890721 : /* slipseq */
			return getSlipseq();
		case -1261386669 : /* slipitem */
			return getSlipitem();
		case -1818143915 : /* acntcode */
			return getAcntcode();
		case 95368330 : /* dbamt */
			return getDbamt();
		case -1338500943 : /* dbcash */
			return getDbcash();
		case 94921465 : /* cramt */
			return getCramt();
		case -1352353758 : /* crcash */
			return getCrcash();
		case 1091415217 : /* remark1 */
			return getRemark1();
		case 1091415218 : /* remark2 */
			return getRemark2();
		case -2085420097 : /* statedate */
			return getStatedate();
		case -1897139694 : /* stateno */
			return getStateno();
		case 238467222 : /* vatcode */
			return getVatcode();
		case -823593473 : /* vatamt */
			return getVatamt();
		case 238650812 : /* vatitem */
			return getVatitem();
		case 1604332556 : /* custgroup */
			return getCustgroup();
		case 605819584 : /* custcode */
			return getCustcode();
		case 606134110 : /* custname */
			return getCustname();
		case -599704196 : /* compcode */
			return getCompcode();
		case 947585458 : /* deptcode */
			return getDeptcode();
		case -1858652631 : /* bankcode */
			return getBankcode();
		case -818154273 : /* depositno */
			return getDepositno();
		case 109200 : /* no1 */
			return getNo1();
		case 109201 : /* no2 */
			return getNo2();
		case -646295669 : /* autotag */
			return getAutotag();
		case -1973061207 : /* detailtag */
			return getDetailtag();
		case 1044731373 : /* detailok */
			return getDetailok();
		case 2116224108 : /* itemseq */
			return getItemseq();
		case 541787706 : /* insertno */
			return getInsertno();
		case 966634983 : /* insertdate */
			return getInsertdate();
		case -1887967618 : /* editemp */
			return getEditemp();
		case 1449898349 : /* remarkcode */
			return getRemarkcode();
		case 3526578 : /* seq1 */
			return getSeq1();
		case 3526579 : /* seq2 */
			return getSeq2();
		case 1381361202 : /* fundcode */
			return getFundcode();
		case 554978741 : /* cashamt */
			return getCashamt();
		case 1070549683 : /* pftAcntcode */
			return getPftAcntcode();
		case 476565184 : /* cancelTag */
			return getCancelTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1261553426 : /* slipdate */
			setSlipdate((java.lang.String) value);
			return;
		case -2118890721 : /* slipseq */
			setSlipseq((java.math.BigDecimal) value);
			return;
		case -1261386669 : /* slipitem */
			setSlipitem((java.math.BigDecimal) value);
			return;
		case -1818143915 : /* acntcode */
			setAcntcode((java.lang.String) value);
			return;
		case 95368330 : /* dbamt */
			setDbamt((java.math.BigDecimal) value);
			return;
		case -1338500943 : /* dbcash */
			setDbcash((java.math.BigDecimal) value);
			return;
		case 94921465 : /* cramt */
			setCramt((java.math.BigDecimal) value);
			return;
		case -1352353758 : /* crcash */
			setCrcash((java.math.BigDecimal) value);
			return;
		case 1091415217 : /* remark1 */
			setRemark1((java.lang.String) value);
			return;
		case 1091415218 : /* remark2 */
			setRemark2((java.lang.String) value);
			return;
		case -2085420097 : /* statedate */
			setStatedate((java.lang.String) value);
			return;
		case -1897139694 : /* stateno */
			setStateno((java.lang.Float) value);
			return;
		case 238467222 : /* vatcode */
			setVatcode((java.lang.String) value);
			return;
		case -823593473 : /* vatamt */
			setVatamt((java.math.BigDecimal) value);
			return;
		case 238650812 : /* vatitem */
			setVatitem((java.lang.Float) value);
			return;
		case 1604332556 : /* custgroup */
			setCustgroup((java.lang.String) value);
			return;
		case 605819584 : /* custcode */
			setCustcode((java.lang.String) value);
			return;
		case 606134110 : /* custname */
			setCustname((java.lang.String) value);
			return;
		case -599704196 : /* compcode */
			setCompcode((java.lang.String) value);
			return;
		case 947585458 : /* deptcode */
			setDeptcode((java.lang.String) value);
			return;
		case -1858652631 : /* bankcode */
			setBankcode((java.lang.String) value);
			return;
		case -818154273 : /* depositno */
			setDepositno((java.lang.String) value);
			return;
		case 109200 : /* no1 */
			setNo1((java.lang.String) value);
			return;
		case 109201 : /* no2 */
			setNo2((java.lang.String) value);
			return;
		case -646295669 : /* autotag */
			setAutotag((java.lang.String) value);
			return;
		case -1973061207 : /* detailtag */
			setDetailtag((java.lang.String) value);
			return;
		case 1044731373 : /* detailok */
			setDetailok((java.lang.String) value);
			return;
		case 2116224108 : /* itemseq */
			setItemseq((java.lang.Float) value);
			return;
		case 541787706 : /* insertno */
			setInsertno((java.lang.Float) value);
			return;
		case 966634983 : /* insertdate */
			setInsertdate((java.lang.String) value);
			return;
		case -1887967618 : /* editemp */
			setEditemp((java.lang.String) value);
			return;
		case 1449898349 : /* remarkcode */
			setRemarkcode((java.lang.Float) value);
			return;
		case 3526578 : /* seq1 */
			setSeq1((java.lang.Float) value);
			return;
		case 3526579 : /* seq2 */
			setSeq2((java.lang.Float) value);
			return;
		case 1381361202 : /* fundcode */
			setFundcode((java.lang.String) value);
			return;
		case 554978741 : /* cashamt */
			setCashamt((java.lang.Float) value);
			return;
		case 1070549683 : /* pftAcntcode */
			setPftAcntcode((java.lang.String) value);
			return;
		case 476565184 : /* cancelTag */
			setCancelTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
