/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.slip.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_회계전표_목차 ( HD_SLIP_PARENT )
 */
@XmlType(propOrder={"slipdate", "slipseq", "cashtag", "makedate", "makecomp", "makedept", "makeseq", "empno", "editemp", "editdate", "company", "edtcompany", "cashsumtag", "printSeq", "cancelTag"}, name="DHDSlipParent01IO")
@XmlRootElement(name="DHDSlipParent01IO")
@SuppressWarnings("all")
public class DHDSlipParent01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1105411900L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_회계전표_목차 ( HD_SLIP_PARENT )";

	/*******************************************************************************************************************************
	* Property set << slipdate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipdate = false;
	
	protected boolean isSet_slipdate()
	{
		return this.isSet_slipdate;
	}
	
	protected void setIsSet_slipdate(boolean value)
	{
		this.isSet_slipdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자 [SYS_C0012828(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipdate  = null;
	
	/**
	 * @Description 전표일자 [SYS_C0012828(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	public java.lang.String getSlipdate(){
		return slipdate;
	}
	
	/**
	 * @Description 전표일자 [SYS_C0012828(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	@JsonProperty("slipdate")
	public void setSlipdate( java.lang.String slipdate ) {
		isSet_slipdate = true;
		this.slipdate = slipdate;
	}
	
	/** Property set << slipdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipseq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipseq = false;
	
	protected boolean isSet_slipseq()
	{
		return this.isSet_slipseq;
	}
	
	protected void setIsSet_slipseq(boolean value)
	{
		this.isSet_slipseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번 [SYS_C0012829(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	public void setSlipseq(java.lang.String value) {
		isSet_slipseq = true;
		this.slipseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번 [SYS_C0012829(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	public void setSlipseq(double value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번 [SYS_C0012829(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	public void setSlipseq(long value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번 [SYS_C0012829(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번 [SYS_C0012829(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	public java.math.BigDecimal getSlipseq(){
		return slipseq;
	}
	
	/**
	 * @Description 전표순번 [SYS_C0012829(C),SYS_C0013019(P) SYS_C0013019(UNIQUE)]
	 */
	@JsonProperty("slipseq")
	public void setSlipseq( java.math.BigDecimal slipseq ) {
		isSet_slipseq = true;
		this.slipseq = slipseq;
	}
	
	/** Property set << slipseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cashtag >> [[ */
	
	@XmlTransient
	private boolean isSet_cashtag = false;
	
	protected boolean isSet_cashtag()
	{
		return this.isSet_cashtag;
	}
	
	protected void setIsSet_cashtag(boolean value)
	{
		this.isSet_cashtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대체/입금/출금구분 [SYS_C0012830(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String cashtag  = null;
	
	/**
	 * @Description 대체/입금/출금구분 [SYS_C0012830(C)]
	 */
	public java.lang.String getCashtag(){
		return cashtag;
	}
	
	/**
	 * @Description 대체/입금/출금구분 [SYS_C0012830(C)]
	 */
	@JsonProperty("cashtag")
	public void setCashtag( java.lang.String cashtag ) {
		isSet_cashtag = true;
		this.cashtag = cashtag;
	}
	
	/** Property set << cashtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << makedate >> [[ */
	
	@XmlTransient
	private boolean isSet_makedate = false;
	
	protected boolean isSet_makedate()
	{
		return this.isSet_makedate;
	}
	
	protected void setIsSet_makedate(boolean value)
	{
		this.isSet_makedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="발의일자 [SYS_C0012831(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String makedate  = null;
	
	/**
	 * @Description 발의일자 [SYS_C0012831(C)]
	 */
	public java.lang.String getMakedate(){
		return makedate;
	}
	
	/**
	 * @Description 발의일자 [SYS_C0012831(C)]
	 */
	@JsonProperty("makedate")
	public void setMakedate( java.lang.String makedate ) {
		isSet_makedate = true;
		this.makedate = makedate;
	}
	
	/** Property set << makedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << makecomp >> [[ */
	
	@XmlTransient
	private boolean isSet_makecomp = false;
	
	protected boolean isSet_makecomp()
	{
		return this.isSet_makecomp;
	}
	
	protected void setIsSet_makecomp(boolean value)
	{
		this.isSet_makecomp = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="발의사업장 [XIF27A_SLIP_PARENT(NONUNIQUE)]", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String makecomp  = null;
	
	/**
	 * @Description 발의사업장 [XIF27A_SLIP_PARENT(NONUNIQUE)]
	 */
	public java.lang.String getMakecomp(){
		return makecomp;
	}
	
	/**
	 * @Description 발의사업장 [XIF27A_SLIP_PARENT(NONUNIQUE)]
	 */
	@JsonProperty("makecomp")
	public void setMakecomp( java.lang.String makecomp ) {
		isSet_makecomp = true;
		this.makecomp = makecomp;
	}
	
	/** Property set << makecomp >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << makedept >> [[ */
	
	@XmlTransient
	private boolean isSet_makedept = false;
	
	protected boolean isSet_makedept()
	{
		return this.isSet_makedept;
	}
	
	protected void setIsSet_makedept(boolean value)
	{
		this.isSet_makedept = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="발의부서 [XIF27A_SLIP_PARENT(NONUNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String makedept  = null;
	
	/**
	 * @Description 발의부서 [XIF27A_SLIP_PARENT(NONUNIQUE)]
	 */
	public java.lang.String getMakedept(){
		return makedept;
	}
	
	/**
	 * @Description 발의부서 [XIF27A_SLIP_PARENT(NONUNIQUE)]
	 */
	@JsonProperty("makedept")
	public void setMakedept( java.lang.String makedept ) {
		isSet_makedept = true;
		this.makedept = makedept;
	}
	
	/** Property set << makedept >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << makeseq >> [[ */
	
	@XmlTransient
	private boolean isSet_makeseq = false;
	
	protected boolean isSet_makeseq()
	{
		return this.isSet_makeseq;
	}
	
	protected void setIsSet_makeseq(boolean value)
	{
		this.isSet_makeseq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="발의순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float makeseq  = .0F;
	
	/**
	 * @Description 발의순번
	 */
	public java.lang.Float getMakeseq(){
		return makeseq;
	}
	
	/**
	 * @Description 발의순번
	 */
	@JsonProperty("makeseq")
	public void setMakeseq( java.lang.Float makeseq ) {
		isSet_makeseq = true;
		this.makeseq = makeseq;
	}
	
	/** Property set << makeseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << empno >> [[ */
	
	@XmlTransient
	private boolean isSet_empno = false;
	
	protected boolean isSet_empno()
	{
		return this.isSet_empno;
	}
	
	protected void setIsSet_empno(boolean value)
	{
		this.isSet_empno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력자사원번호 [SYS_C0012832(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String empno  = null;
	
	/**
	 * @Description 입력자사원번호 [SYS_C0012832(C)]
	 */
	public java.lang.String getEmpno(){
		return empno;
	}
	
	/**
	 * @Description 입력자사원번호 [SYS_C0012832(C)]
	 */
	@JsonProperty("empno")
	public void setEmpno( java.lang.String empno ) {
		isSet_empno = true;
		this.empno = empno;
	}
	
	/** Property set << empno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << editemp >> [[ */
	
	@XmlTransient
	private boolean isSet_editemp = false;
	
	protected boolean isSet_editemp()
	{
		return this.isSet_editemp;
	}
	
	protected void setIsSet_editemp(boolean value)
	{
		this.isSet_editemp = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정자사원번호", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String editemp  = null;
	
	/**
	 * @Description 수정자사원번호
	 */
	public java.lang.String getEditemp(){
		return editemp;
	}
	
	/**
	 * @Description 수정자사원번호
	 */
	@JsonProperty("editemp")
	public void setEditemp( java.lang.String editemp ) {
		isSet_editemp = true;
		this.editemp = editemp;
	}
	
	/** Property set << editemp >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << editdate >> [[ */
	
	@XmlTransient
	private boolean isSet_editdate = false;
	
	protected boolean isSet_editdate()
	{
		return this.isSet_editdate;
	}
	
	protected void setIsSet_editdate(boolean value)
	{
		this.isSet_editdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String editdate  = null;
	
	/**
	 * @Description 수정일자
	 */
	public java.lang.String getEditdate(){
		return editdate;
	}
	
	/**
	 * @Description 수정일자
	 */
	@JsonProperty("editdate")
	public void setEditdate( java.lang.String editdate ) {
		isSet_editdate = true;
		this.editdate = editdate;
	}
	
	/** Property set << editdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << company >> [[ */
	
	@XmlTransient
	private boolean isSet_company = false;
	
	protected boolean isSet_company()
	{
		return this.isSet_company;
	}
	
	protected void setIsSet_company(boolean value)
	{
		this.isSet_company = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="COMPANY", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String company  = null;
	
	/**
	 * @Description COMPANY
	 */
	public java.lang.String getCompany(){
		return company;
	}
	
	/**
	 * @Description COMPANY
	 */
	@JsonProperty("company")
	public void setCompany( java.lang.String company ) {
		isSet_company = true;
		this.company = company;
	}
	
	/** Property set << company >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << edtcompany >> [[ */
	
	@XmlTransient
	private boolean isSet_edtcompany = false;
	
	protected boolean isSet_edtcompany()
	{
		return this.isSet_edtcompany;
	}
	
	protected void setIsSet_edtcompany(boolean value)
	{
		this.isSet_edtcompany = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="EDTCOMPANY", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String edtcompany  = null;
	
	/**
	 * @Description EDTCOMPANY
	 */
	public java.lang.String getEdtcompany(){
		return edtcompany;
	}
	
	/**
	 * @Description EDTCOMPANY
	 */
	@JsonProperty("edtcompany")
	public void setEdtcompany( java.lang.String edtcompany ) {
		isSet_edtcompany = true;
		this.edtcompany = edtcompany;
	}
	
	/** Property set << edtcompany >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cashsumtag >> [[ */
	
	@XmlTransient
	private boolean isSet_cashsumtag = false;
	
	protected boolean isSet_cashsumtag()
	{
		return this.isSet_cashsumtag;
	}
	
	protected void setIsSet_cashsumtag(boolean value)
	{
		this.isSet_cashsumtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="CASHSUMTAG", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String cashsumtag  = null;
	
	/**
	 * @Description CASHSUMTAG
	 */
	public java.lang.String getCashsumtag(){
		return cashsumtag;
	}
	
	/**
	 * @Description CASHSUMTAG
	 */
	@JsonProperty("cashsumtag")
	public void setCashsumtag( java.lang.String cashsumtag ) {
		isSet_cashsumtag = true;
		this.cashsumtag = cashsumtag;
	}
	
	/** Property set << cashsumtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_printSeq = false;
	
	protected boolean isSet_printSeq()
	{
		return this.isSet_printSeq;
	}
	
	protected void setIsSet_printSeq(boolean value)
	{
		this.isSet_printSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력번호", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String printSeq  = null;
	
	/**
	 * @Description 출력번호
	 */
	public java.lang.String getPrintSeq(){
		return printSeq;
	}
	
	/**
	 * @Description 출력번호
	 */
	@JsonProperty("printSeq")
	public void setPrintSeq( java.lang.String printSeq ) {
		isSet_printSeq = true;
		this.printSeq = printSeq;
	}
	
	/** Property set << printSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelTag >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelTag = false;
	
	protected boolean isSet_cancelTag()
	{
		return this.isSet_cancelTag;
	}
	
	protected void setIsSet_cancelTag(boolean value)
	{
		this.isSet_cancelTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="취소여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelTag  = null;
	
	/**
	 * @Description 취소여부
	 */
	public java.lang.String getCancelTag(){
		return cancelTag;
	}
	
	/**
	 * @Description 취소여부
	 */
	@JsonProperty("cancelTag")
	public void setCancelTag( java.lang.String cancelTag ) {
		isSet_cancelTag = true;
		this.cancelTag = cancelTag;
	}
	
	/** Property set << cancelTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDSlipParent01IO clone(){
		try{
			DHDSlipParent01IO object= (DHDSlipParent01IO)super.clone();
			if ( this.slipdate== null ) object.slipdate = null;
			else{
				object.slipdate = this.slipdate;
			}
			if ( this.slipseq== null ) object.slipseq = null;
			else{
				object.slipseq = new java.math.BigDecimal(slipseq.toString());
			}
			if ( this.cashtag== null ) object.cashtag = null;
			else{
				object.cashtag = this.cashtag;
			}
			if ( this.makedate== null ) object.makedate = null;
			else{
				object.makedate = this.makedate;
			}
			if ( this.makecomp== null ) object.makecomp = null;
			else{
				object.makecomp = this.makecomp;
			}
			if ( this.makedept== null ) object.makedept = null;
			else{
				object.makedept = this.makedept;
			}
			if ( this.makeseq== null ) object.makeseq = null;
			else{
				object.makeseq = this.makeseq;
			}
			if ( this.empno== null ) object.empno = null;
			else{
				object.empno = this.empno;
			}
			if ( this.editemp== null ) object.editemp = null;
			else{
				object.editemp = this.editemp;
			}
			if ( this.editdate== null ) object.editdate = null;
			else{
				object.editdate = this.editdate;
			}
			if ( this.company== null ) object.company = null;
			else{
				object.company = this.company;
			}
			if ( this.edtcompany== null ) object.edtcompany = null;
			else{
				object.edtcompany = this.edtcompany;
			}
			if ( this.cashsumtag== null ) object.cashsumtag = null;
			else{
				object.cashsumtag = this.cashsumtag;
			}
			if ( this.printSeq== null ) object.printSeq = null;
			else{
				object.printSeq = this.printSeq;
			}
			if ( this.cancelTag== null ) object.cancelTag = null;
			else{
				object.cancelTag = this.cancelTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((slipdate==null)?0:slipdate.hashCode());
		result = prime * result + ((slipseq==null)?0:slipseq.hashCode());
		result = prime * result + ((cashtag==null)?0:cashtag.hashCode());
		result = prime * result + ((makedate==null)?0:makedate.hashCode());
		result = prime * result + ((makecomp==null)?0:makecomp.hashCode());
		result = prime * result + ((makedept==null)?0:makedept.hashCode());
		result = prime * result + ((makeseq==null)?0:makeseq.hashCode());
		result = prime * result + ((empno==null)?0:empno.hashCode());
		result = prime * result + ((editemp==null)?0:editemp.hashCode());
		result = prime * result + ((editdate==null)?0:editdate.hashCode());
		result = prime * result + ((company==null)?0:company.hashCode());
		result = prime * result + ((edtcompany==null)?0:edtcompany.hashCode());
		result = prime * result + ((cashsumtag==null)?0:cashsumtag.hashCode());
		result = prime * result + ((printSeq==null)?0:printSeq.hashCode());
		result = prime * result + ((cancelTag==null)?0:cancelTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.slip.onl.dao.dto.DHDSlipParent01IO other = (kait.hd.slip.onl.dao.dto.DHDSlipParent01IO)obj;
		if ( slipdate == null ){
			if ( other.slipdate != null ) return false;
		}
		else if ( !slipdate.equals(other.slipdate) )
			return false;
		if ( slipseq == null ){
			if ( other.slipseq != null ) return false;
		}
		else if ( !slipseq.equals(other.slipseq) )
			return false;
		if ( cashtag == null ){
			if ( other.cashtag != null ) return false;
		}
		else if ( !cashtag.equals(other.cashtag) )
			return false;
		if ( makedate == null ){
			if ( other.makedate != null ) return false;
		}
		else if ( !makedate.equals(other.makedate) )
			return false;
		if ( makecomp == null ){
			if ( other.makecomp != null ) return false;
		}
		else if ( !makecomp.equals(other.makecomp) )
			return false;
		if ( makedept == null ){
			if ( other.makedept != null ) return false;
		}
		else if ( !makedept.equals(other.makedept) )
			return false;
		if ( makeseq == null ){
			if ( other.makeseq != null ) return false;
		}
		else if ( !makeseq.equals(other.makeseq) )
			return false;
		if ( empno == null ){
			if ( other.empno != null ) return false;
		}
		else if ( !empno.equals(other.empno) )
			return false;
		if ( editemp == null ){
			if ( other.editemp != null ) return false;
		}
		else if ( !editemp.equals(other.editemp) )
			return false;
		if ( editdate == null ){
			if ( other.editdate != null ) return false;
		}
		else if ( !editdate.equals(other.editdate) )
			return false;
		if ( company == null ){
			if ( other.company != null ) return false;
		}
		else if ( !company.equals(other.company) )
			return false;
		if ( edtcompany == null ){
			if ( other.edtcompany != null ) return false;
		}
		else if ( !edtcompany.equals(other.edtcompany) )
			return false;
		if ( cashsumtag == null ){
			if ( other.cashsumtag != null ) return false;
		}
		else if ( !cashsumtag.equals(other.cashsumtag) )
			return false;
		if ( printSeq == null ){
			if ( other.printSeq != null ) return false;
		}
		else if ( !printSeq.equals(other.printSeq) )
			return false;
		if ( cancelTag == null ){
			if ( other.cancelTag != null ) return false;
		}
		else if ( !cancelTag.equals(other.cancelTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.slip.onl.dao.dto.DHDSlipParent01IO:\n");
		sb.append("\tslipdate: ");
		sb.append(slipdate==null?"null":getSlipdate());
		sb.append("\n");
		sb.append("\tslipseq: ");
		sb.append(slipseq==null?"null":getSlipseq());
		sb.append("\n");
		sb.append("\tcashtag: ");
		sb.append(cashtag==null?"null":getCashtag());
		sb.append("\n");
		sb.append("\tmakedate: ");
		sb.append(makedate==null?"null":getMakedate());
		sb.append("\n");
		sb.append("\tmakecomp: ");
		sb.append(makecomp==null?"null":getMakecomp());
		sb.append("\n");
		sb.append("\tmakedept: ");
		sb.append(makedept==null?"null":getMakedept());
		sb.append("\n");
		sb.append("\tmakeseq: ");
		sb.append(makeseq==null?"null":getMakeseq());
		sb.append("\n");
		sb.append("\tempno: ");
		sb.append(empno==null?"null":getEmpno());
		sb.append("\n");
		sb.append("\teditemp: ");
		sb.append(editemp==null?"null":getEditemp());
		sb.append("\n");
		sb.append("\teditdate: ");
		sb.append(editdate==null?"null":getEditdate());
		sb.append("\n");
		sb.append("\tcompany: ");
		sb.append(company==null?"null":getCompany());
		sb.append("\n");
		sb.append("\tedtcompany: ");
		sb.append(edtcompany==null?"null":getEdtcompany());
		sb.append("\n");
		sb.append("\tcashsumtag: ");
		sb.append(cashsumtag==null?"null":getCashsumtag());
		sb.append("\n");
		sb.append("\tprintSeq: ");
		sb.append(printSeq==null?"null":getPrintSeq());
		sb.append("\n");
		sb.append("\tcancelTag: ");
		sb.append(cancelTag==null?"null":getCancelTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 8; /* slipdate */
		messageLen+= 22; /* slipseq */
		messageLen+= 1; /* cashtag */
		messageLen+= 8; /* makedate */
		messageLen+= 6; /* makecomp */
		messageLen+= 12; /* makedept */
		messageLen+= 22; /* makeseq */
		messageLen+= 8; /* empno */
		messageLen+= 8; /* editemp */
		messageLen+= 8; /* editdate */
		messageLen+= 6; /* company */
		messageLen+= 6; /* edtcompany */
		messageLen+= 1; /* cashsumtag */
		messageLen+= 1; /* printSeq */
		messageLen+= 1; /* cancelTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("slipdate");
	
		fieldNames.add("slipseq");
	
		fieldNames.add("cashtag");
	
		fieldNames.add("makedate");
	
		fieldNames.add("makecomp");
	
		fieldNames.add("makedept");
	
		fieldNames.add("makeseq");
	
		fieldNames.add("empno");
	
		fieldNames.add("editemp");
	
		fieldNames.add("editdate");
	
		fieldNames.add("company");
	
		fieldNames.add("edtcompany");
	
		fieldNames.add("cashsumtag");
	
		fieldNames.add("printSeq");
	
		fieldNames.add("cancelTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("slipdate", get("slipdate"));
	
		fieldValueMap.put("slipseq", get("slipseq"));
	
		fieldValueMap.put("cashtag", get("cashtag"));
	
		fieldValueMap.put("makedate", get("makedate"));
	
		fieldValueMap.put("makecomp", get("makecomp"));
	
		fieldValueMap.put("makedept", get("makedept"));
	
		fieldValueMap.put("makeseq", get("makeseq"));
	
		fieldValueMap.put("empno", get("empno"));
	
		fieldValueMap.put("editemp", get("editemp"));
	
		fieldValueMap.put("editdate", get("editdate"));
	
		fieldValueMap.put("company", get("company"));
	
		fieldValueMap.put("edtcompany", get("edtcompany"));
	
		fieldValueMap.put("cashsumtag", get("cashsumtag"));
	
		fieldValueMap.put("printSeq", get("printSeq"));
	
		fieldValueMap.put("cancelTag", get("cancelTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1261553426 : /* slipdate */
			return getSlipdate();
		case -2118890721 : /* slipseq */
			return getSlipseq();
		case 554996615 : /* cashtag */
			return getCashtag();
		case 40980124 : /* makedate */
			return getMakedate();
		case 40963581 : /* makecomp */
			return getMakecomp();
		case 40983859 : /* makedept */
			return getMakedept();
		case 832620465 : /* makeseq */
			return getMakeseq();
		case 96633993 : /* empno */
			return getEmpno();
		case -1887967618 : /* editemp */
			return getEditemp();
		case 1602504888 : /* editdate */
			return getEditdate();
		case 950484093 : /* company */
			return getCompany();
		case -1771794648 : /* edtcompany */
			return getEdtcompany();
		case -1729797534 : /* cashsumtag */
			return getCashsumtag();
		case -1166346638 : /* printSeq */
			return getPrintSeq();
		case 476565184 : /* cancelTag */
			return getCancelTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1261553426 : /* slipdate */
			setSlipdate((java.lang.String) value);
			return;
		case -2118890721 : /* slipseq */
			setSlipseq((java.math.BigDecimal) value);
			return;
		case 554996615 : /* cashtag */
			setCashtag((java.lang.String) value);
			return;
		case 40980124 : /* makedate */
			setMakedate((java.lang.String) value);
			return;
		case 40963581 : /* makecomp */
			setMakecomp((java.lang.String) value);
			return;
		case 40983859 : /* makedept */
			setMakedept((java.lang.String) value);
			return;
		case 832620465 : /* makeseq */
			setMakeseq((java.lang.Float) value);
			return;
		case 96633993 : /* empno */
			setEmpno((java.lang.String) value);
			return;
		case -1887967618 : /* editemp */
			setEditemp((java.lang.String) value);
			return;
		case 1602504888 : /* editdate */
			setEditdate((java.lang.String) value);
			return;
		case 950484093 : /* company */
			setCompany((java.lang.String) value);
			return;
		case -1771794648 : /* edtcompany */
			setEdtcompany((java.lang.String) value);
			return;
		case -1729797534 : /* cashsumtag */
			setCashsumtag((java.lang.String) value);
			return;
		case -1166346638 : /* printSeq */
			setPrintSeq((java.lang.String) value);
			return;
		case 476565184 : /* cancelTag */
			setCancelTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
