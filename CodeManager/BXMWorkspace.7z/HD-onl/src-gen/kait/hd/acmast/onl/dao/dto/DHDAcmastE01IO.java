/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.acmast.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_ACMAST_E
 */
@XmlType(propOrder={"jcode", "jacntcode", "jacntname", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDAcmastE01IO")
@XmlRootElement(name="DHDAcmastE01IO")
@SuppressWarnings("all")
public class DHDAcmastE01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1774183315L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_ACMAST_E";

	/*******************************************************************************************************************************
	* Property set << jcode >> [[ */
	
	@XmlTransient
	private boolean isSet_jcode = false;
	
	protected boolean isSet_jcode()
	{
		return this.isSet_jcode;
	}
	
	protected void setIsSet_jcode(boolean value)
	{
		this.isSet_jcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012068(C),SYS_C0012904(P) SYS_C0012904(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String jcode  = null;
	
	/**
	 * @Description  [SYS_C0012068(C),SYS_C0012904(P) SYS_C0012904(UNIQUE)]
	 */
	public java.lang.String getJcode(){
		return jcode;
	}
	
	/**
	 * @Description  [SYS_C0012068(C),SYS_C0012904(P) SYS_C0012904(UNIQUE)]
	 */
	@JsonProperty("jcode")
	public void setJcode( java.lang.String jcode ) {
		isSet_jcode = true;
		this.jcode = jcode;
	}
	
	/** Property set << jcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jacntcode >> [[ */
	
	@XmlTransient
	private boolean isSet_jacntcode = false;
	
	protected boolean isSet_jacntcode()
	{
		return this.isSet_jacntcode;
	}
	
	protected void setIsSet_jacntcode(boolean value)
	{
		this.isSet_jacntcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String jacntcode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getJacntcode(){
		return jacntcode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("jacntcode")
	public void setJacntcode( java.lang.String jacntcode ) {
		isSet_jacntcode = true;
		this.jacntcode = jacntcode;
	}
	
	/** Property set << jacntcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jacntname >> [[ */
	
	@XmlTransient
	private boolean isSet_jacntname = false;
	
	protected boolean isSet_jacntname()
	{
		return this.isSet_jacntname;
	}
	
	protected void setIsSet_jacntname(boolean value)
	{
		this.isSet_jacntname = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String jacntname  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getJacntname(){
		return jacntname;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("jacntname")
	public void setJacntname( java.lang.String jacntname ) {
		isSet_jacntname = true;
		this.jacntname = jacntname;
	}
	
	/** Property set << jacntname >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDAcmastE01IO clone(){
		try{
			DHDAcmastE01IO object= (DHDAcmastE01IO)super.clone();
			if ( this.jcode== null ) object.jcode = null;
			else{
				object.jcode = this.jcode;
			}
			if ( this.jacntcode== null ) object.jacntcode = null;
			else{
				object.jacntcode = this.jacntcode;
			}
			if ( this.jacntname== null ) object.jacntname = null;
			else{
				object.jacntname = this.jacntname;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((jcode==null)?0:jcode.hashCode());
		result = prime * result + ((jacntcode==null)?0:jacntcode.hashCode());
		result = prime * result + ((jacntname==null)?0:jacntname.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO other = (kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO)obj;
		if ( jcode == null ){
			if ( other.jcode != null ) return false;
		}
		else if ( !jcode.equals(other.jcode) )
			return false;
		if ( jacntcode == null ){
			if ( other.jacntcode != null ) return false;
		}
		else if ( !jacntcode.equals(other.jacntcode) )
			return false;
		if ( jacntname == null ){
			if ( other.jacntname != null ) return false;
		}
		else if ( !jacntname.equals(other.jacntname) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO:\n");
		sb.append("\tjcode: ");
		sb.append(jcode==null?"null":getJcode());
		sb.append("\n");
		sb.append("\tjacntcode: ");
		sb.append(jacntcode==null?"null":getJacntcode());
		sb.append("\n");
		sb.append("\tjacntname: ");
		sb.append(jacntname==null?"null":getJacntname());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 2; /* jcode */
		messageLen+= 8; /* jacntcode */
		messageLen+= 40; /* jacntname */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("jcode");
	
		fieldNames.add("jacntcode");
	
		fieldNames.add("jacntname");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("jcode", get("jcode"));
	
		fieldValueMap.put("jacntcode", get("jacntcode"));
	
		fieldValueMap.put("jacntname", get("jacntname"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 100952407 : /* jcode */
			return getJcode();
		case -134788673 : /* jacntcode */
			return getJacntcode();
		case -134474147 : /* jacntname */
			return getJacntname();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 100952407 : /* jcode */
			setJcode((java.lang.String) value);
			return;
		case -134788673 : /* jacntcode */
			setJacntcode((java.lang.String) value);
			return;
		case -134474147 : /* jacntname */
			setJacntname((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
