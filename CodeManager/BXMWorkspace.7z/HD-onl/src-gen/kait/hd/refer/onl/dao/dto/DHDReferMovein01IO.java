/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.refer.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_입주배정 ( HD_REFER_MOVEIN )
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "rentYn", "moveinTag", "moveinDate", "publishDate", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDReferMovein01IO")
@XmlRootElement(name="DHDReferMovein01IO")
@SuppressWarnings("all")
public class DHDReferMovein01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 77227068L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_입주배정 ( HD_REFER_MOVEIN )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012503(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012503(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012503(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012504(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012504(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012504(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012505(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012505(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012505(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012506(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012506(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012506(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentYn >> [[ */
	
	@XmlTransient
	private boolean isSet_rentYn = false;
	
	protected boolean isSet_rentYn()
	{
		return this.isSet_rentYn;
	}
	
	protected void setIsSet_rentYn(boolean value)
	{
		this.isSet_rentYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대구분 [SYS_C0012507(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String rentYn  = null;
	
	/**
	 * @Description 임대구분 [SYS_C0012507(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	public java.lang.String getRentYn(){
		return rentYn;
	}
	
	/**
	 * @Description 임대구분 [SYS_C0012507(C),SYS_C0012973(P) SYS_C0012973(UNIQUE)]
	 */
	@JsonProperty("rentYn")
	public void setRentYn( java.lang.String rentYn ) {
		isSet_rentYn = true;
		this.rentYn = rentYn;
	}
	
	/** Property set << rentYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << moveinTag >> [[ */
	
	@XmlTransient
	private boolean isSet_moveinTag = false;
	
	protected boolean isSet_moveinTag()
	{
		return this.isSet_moveinTag;
	}
	
	protected void setIsSet_moveinTag(boolean value)
	{
		this.isSet_moveinTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주여부 [SYS_C0012508(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String moveinTag  = null;
	
	/**
	 * @Description 입주여부 [SYS_C0012508(C)]
	 */
	public java.lang.String getMoveinTag(){
		return moveinTag;
	}
	
	/**
	 * @Description 입주여부 [SYS_C0012508(C)]
	 */
	@JsonProperty("moveinTag")
	public void setMoveinTag( java.lang.String moveinTag ) {
		isSet_moveinTag = true;
		this.moveinTag = moveinTag;
	}
	
	/** Property set << moveinTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << moveinDate >> [[ */
	
	@XmlTransient
	private boolean isSet_moveinDate = false;
	
	protected boolean isSet_moveinDate()
	{
		return this.isSet_moveinDate;
	}
	
	protected void setIsSet_moveinDate(boolean value)
	{
		this.isSet_moveinDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String moveinDate  = null;
	
	/**
	 * @Description 입주일자
	 */
	public java.lang.String getMoveinDate(){
		return moveinDate;
	}
	
	/**
	 * @Description 입주일자
	 */
	@JsonProperty("moveinDate")
	public void setMoveinDate( java.lang.String moveinDate ) {
		isSet_moveinDate = true;
		this.moveinDate = moveinDate;
	}
	
	/** Property set << moveinDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << publishDate >> [[ */
	
	@XmlTransient
	private boolean isSet_publishDate = false;
	
	protected boolean isSet_publishDate()
	{
		return this.isSet_publishDate;
	}
	
	protected void setIsSet_publishDate(boolean value)
	{
		this.isSet_publishDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주증발급일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String publishDate  = null;
	
	/**
	 * @Description 입주증발급일
	 */
	public java.lang.String getPublishDate(){
		return publishDate;
	}
	
	/**
	 * @Description 입주증발급일
	 */
	@JsonProperty("publishDate")
	public void setPublishDate( java.lang.String publishDate ) {
		isSet_publishDate = true;
		this.publishDate = publishDate;
	}
	
	/** Property set << publishDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDReferMovein01IO clone(){
		try{
			DHDReferMovein01IO object= (DHDReferMovein01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.rentYn== null ) object.rentYn = null;
			else{
				object.rentYn = this.rentYn;
			}
			if ( this.moveinTag== null ) object.moveinTag = null;
			else{
				object.moveinTag = this.moveinTag;
			}
			if ( this.moveinDate== null ) object.moveinDate = null;
			else{
				object.moveinDate = this.moveinDate;
			}
			if ( this.publishDate== null ) object.publishDate = null;
			else{
				object.publishDate = this.publishDate;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((rentYn==null)?0:rentYn.hashCode());
		result = prime * result + ((moveinTag==null)?0:moveinTag.hashCode());
		result = prime * result + ((moveinDate==null)?0:moveinDate.hashCode());
		result = prime * result + ((publishDate==null)?0:publishDate.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.refer.onl.dao.dto.DHDReferMovein01IO other = (kait.hd.refer.onl.dao.dto.DHDReferMovein01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( rentYn == null ){
			if ( other.rentYn != null ) return false;
		}
		else if ( !rentYn.equals(other.rentYn) )
			return false;
		if ( moveinTag == null ){
			if ( other.moveinTag != null ) return false;
		}
		else if ( !moveinTag.equals(other.moveinTag) )
			return false;
		if ( moveinDate == null ){
			if ( other.moveinDate != null ) return false;
		}
		else if ( !moveinDate.equals(other.moveinDate) )
			return false;
		if ( publishDate == null ){
			if ( other.publishDate != null ) return false;
		}
		else if ( !publishDate.equals(other.publishDate) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.refer.onl.dao.dto.DHDReferMovein01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\trentYn: ");
		sb.append(rentYn==null?"null":getRentYn());
		sb.append("\n");
		sb.append("\tmoveinTag: ");
		sb.append(moveinTag==null?"null":getMoveinTag());
		sb.append("\n");
		sb.append("\tmoveinDate: ");
		sb.append(moveinDate==null?"null":getMoveinDate());
		sb.append("\n");
		sb.append("\tpublishDate: ");
		sb.append(publishDate==null?"null":getPublishDate());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 1; /* rentYn */
		messageLen+= 1; /* moveinTag */
		messageLen+= 8; /* moveinDate */
		messageLen+= 8; /* publishDate */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("rentYn");
	
		fieldNames.add("moveinTag");
	
		fieldNames.add("moveinDate");
	
		fieldNames.add("publishDate");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("rentYn", get("rentYn"));
	
		fieldValueMap.put("moveinTag", get("moveinTag"));
	
		fieldValueMap.put("moveinDate", get("moveinDate"));
	
		fieldValueMap.put("publishDate", get("publishDate"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -934577106 : /* rentYn */
			return getRentYn();
		case 1077504772 : /* moveinTag */
			return getMoveinTag();
		case -957566588 : /* moveinDate */
			return getMoveinDate();
		case -615128739 : /* publishDate */
			return getPublishDate();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -934577106 : /* rentYn */
			setRentYn((java.lang.String) value);
			return;
		case 1077504772 : /* moveinTag */
			setMoveinTag((java.lang.String) value);
			return;
		case -957566588 : /* moveinDate */
			setMoveinDate((java.lang.String) value);
			return;
		case -615128739 : /* publishDate */
			setPublishDate((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
