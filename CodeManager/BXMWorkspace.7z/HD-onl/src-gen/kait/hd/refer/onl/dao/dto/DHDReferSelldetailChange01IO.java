/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.refer.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_세대별약정확정 ( HD_REFER_SELLDETAIL_CHANGE )
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "counts", "agreedate", "agreeamt", "landamt", "buildamt", "vatamt", "dcYn", "acYn", "distributeRate", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "manageamt"}, name="DHDReferSelldetailChange01IO")
@XmlRootElement(name="DHDReferSelldetailChange01IO")
@SuppressWarnings("all")
public class DHDReferSelldetailChange01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1504541191L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_세대별약정확정 ( HD_REFER_SELLDETAIL_CHANGE )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012541(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012541(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012541(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012542(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012542(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012542(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012543(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012543(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012543(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012544(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012544(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012544(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << counts >> [[ */
	
	@XmlTransient
	private boolean isSet_counts = false;
	
	protected boolean isSet_counts()
	{
		return this.isSet_counts;
	}
	
	protected void setIsSet_counts(boolean value)
	{
		this.isSet_counts = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="차수 [SYS_C0012545(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String counts  = null;
	
	/**
	 * @Description 차수 [SYS_C0012545(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	public java.lang.String getCounts(){
		return counts;
	}
	
	/**
	 * @Description 차수 [SYS_C0012545(C),SYS_C0012978(P) SYS_C0012978(UNIQUE)]
	 */
	@JsonProperty("counts")
	public void setCounts( java.lang.String counts ) {
		isSet_counts = true;
		this.counts = counts;
	}
	
	/** Property set << counts >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreedate >> [[ */
	
	@XmlTransient
	private boolean isSet_agreedate = false;
	
	protected boolean isSet_agreedate()
	{
		return this.isSet_agreedate;
	}
	
	protected void setIsSet_agreedate(boolean value)
	{
		this.isSet_agreedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정일자 [SYS_C0012546(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String agreedate  = null;
	
	/**
	 * @Description 약정일자 [SYS_C0012546(C)]
	 */
	public java.lang.String getAgreedate(){
		return agreedate;
	}
	
	/**
	 * @Description 약정일자 [SYS_C0012546(C)]
	 */
	@JsonProperty("agreedate")
	public void setAgreedate( java.lang.String agreedate ) {
		isSet_agreedate = true;
		this.agreedate = agreedate;
	}
	
	/** Property set << agreedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeamt >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeamt = false;
	
	protected boolean isSet_agreeamt()
	{
		return this.isSet_agreeamt;
	}
	
	protected void setIsSet_agreeamt(boolean value)
	{
		this.isSet_agreeamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float agreeamt  = .0F;
	
	/**
	 * @Description 약정금액
	 */
	public java.lang.Float getAgreeamt(){
		return agreeamt;
	}
	
	/**
	 * @Description 약정금액
	 */
	@JsonProperty("agreeamt")
	public void setAgreeamt( java.lang.Float agreeamt ) {
		isSet_agreeamt = true;
		this.agreeamt = agreeamt;
	}
	
	/** Property set << agreeamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << landamt >> [[ */
	
	@XmlTransient
	private boolean isSet_landamt = false;
	
	protected boolean isSet_landamt()
	{
		return this.isSet_landamt;
	}
	
	protected void setIsSet_landamt(boolean value)
	{
		this.isSet_landamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="토지가액 [SYS_C0012547(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float landamt  = .0F;
	
	/**
	 * @Description 토지가액 [SYS_C0012547(C)]
	 */
	public java.lang.Float getLandamt(){
		return landamt;
	}
	
	/**
	 * @Description 토지가액 [SYS_C0012547(C)]
	 */
	@JsonProperty("landamt")
	public void setLandamt( java.lang.Float landamt ) {
		isSet_landamt = true;
		this.landamt = landamt;
	}
	
	/** Property set << landamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildamt >> [[ */
	
	@XmlTransient
	private boolean isSet_buildamt = false;
	
	protected boolean isSet_buildamt()
	{
		return this.isSet_buildamt;
	}
	
	protected void setIsSet_buildamt(boolean value)
	{
		this.isSet_buildamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="건물가액 [SYS_C0012548(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float buildamt  = .0F;
	
	/**
	 * @Description 건물가액 [SYS_C0012548(C)]
	 */
	public java.lang.Float getBuildamt(){
		return buildamt;
	}
	
	/**
	 * @Description 건물가액 [SYS_C0012548(C)]
	 */
	@JsonProperty("buildamt")
	public void setBuildamt( java.lang.Float buildamt ) {
		isSet_buildamt = true;
		this.buildamt = buildamt;
	}
	
	/** Property set << buildamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatamt >> [[ */
	
	@XmlTransient
	private boolean isSet_vatamt = false;
	
	protected boolean isSet_vatamt()
	{
		return this.isSet_vatamt;
	}
	
	protected void setIsSet_vatamt(boolean value)
	{
		this.isSet_vatamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세액 [SYS_C0012549(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float vatamt  = .0F;
	
	/**
	 * @Description 부가세액 [SYS_C0012549(C)]
	 */
	public java.lang.Float getVatamt(){
		return vatamt;
	}
	
	/**
	 * @Description 부가세액 [SYS_C0012549(C)]
	 */
	@JsonProperty("vatamt")
	public void setVatamt( java.lang.Float vatamt ) {
		isSet_vatamt = true;
		this.vatamt = vatamt;
	}
	
	/** Property set << vatamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dcYn >> [[ */
	
	@XmlTransient
	private boolean isSet_dcYn = false;
	
	protected boolean isSet_dcYn()
	{
		return this.isSet_dcYn;
	}
	
	protected void setIsSet_dcYn(boolean value)
	{
		this.isSet_dcYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="할인료계산여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String dcYn  = null;
	
	/**
	 * @Description 할인료계산여부
	 */
	public java.lang.String getDcYn(){
		return dcYn;
	}
	
	/**
	 * @Description 할인료계산여부
	 */
	@JsonProperty("dcYn")
	public void setDcYn( java.lang.String dcYn ) {
		isSet_dcYn = true;
		this.dcYn = dcYn;
	}
	
	/** Property set << dcYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << acYn >> [[ */
	
	@XmlTransient
	private boolean isSet_acYn = false;
	
	protected boolean isSet_acYn()
	{
		return this.isSet_acYn;
	}
	
	protected void setIsSet_acYn(boolean value)
	{
		this.isSet_acYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체료계산여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String acYn  = null;
	
	/**
	 * @Description 연체료계산여부
	 */
	public java.lang.String getAcYn(){
		return acYn;
	}
	
	/**
	 * @Description 연체료계산여부
	 */
	@JsonProperty("acYn")
	public void setAcYn( java.lang.String acYn ) {
		isSet_acYn = true;
		this.acYn = acYn;
	}
	
	/** Property set << acYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << distributeRate >> [[ */
	
	@XmlTransient
	private boolean isSet_distributeRate = false;
	
	protected boolean isSet_distributeRate()
	{
		return this.isSet_distributeRate;
	}
	
	protected void setIsSet_distributeRate(boolean value)
	{
		this.isSet_distributeRate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 배분율
	 */
	public void setDistributeRate(java.lang.String value) {
		isSet_distributeRate = true;
		this.distributeRate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 배분율
	 */
	public void setDistributeRate(double value) {
		isSet_distributeRate = true;
		this.distributeRate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 배분율
	 */
	public void setDistributeRate(long value) {
		isSet_distributeRate = true;
		this.distributeRate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="배분율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal distributeRate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 배분율
	 */
	public java.math.BigDecimal getDistributeRate(){
		return distributeRate;
	}
	
	/**
	 * @Description 배분율
	 */
	@JsonProperty("distributeRate")
	public void setDistributeRate( java.math.BigDecimal distributeRate ) {
		isSet_distributeRate = true;
		this.distributeRate = distributeRate;
	}
	
	/** Property set << distributeRate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << manageamt >> [[ */
	
	@XmlTransient
	private boolean isSet_manageamt = false;
	
	protected boolean isSet_manageamt()
	{
		return this.isSet_manageamt;
	}
	
	protected void setIsSet_manageamt(boolean value)
	{
		this.isSet_manageamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="관리비", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float manageamt  = .0F;
	
	/**
	 * @Description 관리비
	 */
	public java.lang.Float getManageamt(){
		return manageamt;
	}
	
	/**
	 * @Description 관리비
	 */
	@JsonProperty("manageamt")
	public void setManageamt( java.lang.Float manageamt ) {
		isSet_manageamt = true;
		this.manageamt = manageamt;
	}
	
	/** Property set << manageamt >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDReferSelldetailChange01IO clone(){
		try{
			DHDReferSelldetailChange01IO object= (DHDReferSelldetailChange01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.counts== null ) object.counts = null;
			else{
				object.counts = this.counts;
			}
			if ( this.agreedate== null ) object.agreedate = null;
			else{
				object.agreedate = this.agreedate;
			}
			if ( this.agreeamt== null ) object.agreeamt = null;
			else{
				object.agreeamt = this.agreeamt;
			}
			if ( this.landamt== null ) object.landamt = null;
			else{
				object.landamt = this.landamt;
			}
			if ( this.buildamt== null ) object.buildamt = null;
			else{
				object.buildamt = this.buildamt;
			}
			if ( this.vatamt== null ) object.vatamt = null;
			else{
				object.vatamt = this.vatamt;
			}
			if ( this.dcYn== null ) object.dcYn = null;
			else{
				object.dcYn = this.dcYn;
			}
			if ( this.acYn== null ) object.acYn = null;
			else{
				object.acYn = this.acYn;
			}
			if ( this.distributeRate== null ) object.distributeRate = null;
			else{
				object.distributeRate = new java.math.BigDecimal(distributeRate.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.manageamt== null ) object.manageamt = null;
			else{
				object.manageamt = this.manageamt;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((counts==null)?0:counts.hashCode());
		result = prime * result + ((agreedate==null)?0:agreedate.hashCode());
		result = prime * result + ((agreeamt==null)?0:agreeamt.hashCode());
		result = prime * result + ((landamt==null)?0:landamt.hashCode());
		result = prime * result + ((buildamt==null)?0:buildamt.hashCode());
		result = prime * result + ((vatamt==null)?0:vatamt.hashCode());
		result = prime * result + ((dcYn==null)?0:dcYn.hashCode());
		result = prime * result + ((acYn==null)?0:acYn.hashCode());
		result = prime * result + ((distributeRate==null)?0:distributeRate.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((manageamt==null)?0:manageamt.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO other = (kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( counts == null ){
			if ( other.counts != null ) return false;
		}
		else if ( !counts.equals(other.counts) )
			return false;
		if ( agreedate == null ){
			if ( other.agreedate != null ) return false;
		}
		else if ( !agreedate.equals(other.agreedate) )
			return false;
		if ( agreeamt == null ){
			if ( other.agreeamt != null ) return false;
		}
		else if ( !agreeamt.equals(other.agreeamt) )
			return false;
		if ( landamt == null ){
			if ( other.landamt != null ) return false;
		}
		else if ( !landamt.equals(other.landamt) )
			return false;
		if ( buildamt == null ){
			if ( other.buildamt != null ) return false;
		}
		else if ( !buildamt.equals(other.buildamt) )
			return false;
		if ( vatamt == null ){
			if ( other.vatamt != null ) return false;
		}
		else if ( !vatamt.equals(other.vatamt) )
			return false;
		if ( dcYn == null ){
			if ( other.dcYn != null ) return false;
		}
		else if ( !dcYn.equals(other.dcYn) )
			return false;
		if ( acYn == null ){
			if ( other.acYn != null ) return false;
		}
		else if ( !acYn.equals(other.acYn) )
			return false;
		if ( distributeRate == null ){
			if ( other.distributeRate != null ) return false;
		}
		else if ( !distributeRate.equals(other.distributeRate) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( manageamt == null ){
			if ( other.manageamt != null ) return false;
		}
		else if ( !manageamt.equals(other.manageamt) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tcounts: ");
		sb.append(counts==null?"null":getCounts());
		sb.append("\n");
		sb.append("\tagreedate: ");
		sb.append(agreedate==null?"null":getAgreedate());
		sb.append("\n");
		sb.append("\tagreeamt: ");
		sb.append(agreeamt==null?"null":getAgreeamt());
		sb.append("\n");
		sb.append("\tlandamt: ");
		sb.append(landamt==null?"null":getLandamt());
		sb.append("\n");
		sb.append("\tbuildamt: ");
		sb.append(buildamt==null?"null":getBuildamt());
		sb.append("\n");
		sb.append("\tvatamt: ");
		sb.append(vatamt==null?"null":getVatamt());
		sb.append("\n");
		sb.append("\tdcYn: ");
		sb.append(dcYn==null?"null":getDcYn());
		sb.append("\n");
		sb.append("\tacYn: ");
		sb.append(acYn==null?"null":getAcYn());
		sb.append("\n");
		sb.append("\tdistributeRate: ");
		sb.append(distributeRate==null?"null":getDistributeRate());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tmanageamt: ");
		sb.append(manageamt==null?"null":getManageamt());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 2; /* counts */
		messageLen+= 8; /* agreedate */
		messageLen+= 22; /* agreeamt */
		messageLen+= 22; /* landamt */
		messageLen+= 22; /* buildamt */
		messageLen+= 22; /* vatamt */
		messageLen+= 1; /* dcYn */
		messageLen+= 1; /* acYn */
		messageLen+= 22; /* distributeRate */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* manageamt */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("counts");
	
		fieldNames.add("agreedate");
	
		fieldNames.add("agreeamt");
	
		fieldNames.add("landamt");
	
		fieldNames.add("buildamt");
	
		fieldNames.add("vatamt");
	
		fieldNames.add("dcYn");
	
		fieldNames.add("acYn");
	
		fieldNames.add("distributeRate");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("manageamt");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("counts", get("counts"));
	
		fieldValueMap.put("agreedate", get("agreedate"));
	
		fieldValueMap.put("agreeamt", get("agreeamt"));
	
		fieldValueMap.put("landamt", get("landamt"));
	
		fieldValueMap.put("buildamt", get("buildamt"));
	
		fieldValueMap.put("vatamt", get("vatamt"));
	
		fieldValueMap.put("dcYn", get("dcYn"));
	
		fieldValueMap.put("acYn", get("acYn"));
	
		fieldValueMap.put("distributeRate", get("distributeRate"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("manageamt", get("manageamt"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -1354575548 : /* counts */
			return getCounts();
		case 975514714 : /* agreedate */
			return getAgreedate();
		case 1832581020 : /* agreeamt */
			return getAgreeamt();
		case -52159491 : /* landamt */
			return getLandamt();
		case -1430653798 : /* buildamt */
			return getBuildamt();
		case -823593473 : /* vatamt */
			return getVatamt();
		case 3077108 : /* dcYn */
			return getDcYn();
		case 2987735 : /* acYn */
			return getAcYn();
		case 1353256545 : /* distributeRate */
			return getDistributeRate();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -473717181 : /* manageamt */
			return getManageamt();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -1354575548 : /* counts */
			setCounts((java.lang.String) value);
			return;
		case 975514714 : /* agreedate */
			setAgreedate((java.lang.String) value);
			return;
		case 1832581020 : /* agreeamt */
			setAgreeamt((java.lang.Float) value);
			return;
		case -52159491 : /* landamt */
			setLandamt((java.lang.Float) value);
			return;
		case -1430653798 : /* buildamt */
			setBuildamt((java.lang.Float) value);
			return;
		case -823593473 : /* vatamt */
			setVatamt((java.lang.Float) value);
			return;
		case 3077108 : /* dcYn */
			setDcYn((java.lang.String) value);
			return;
		case 2987735 : /* acYn */
			setAcYn((java.lang.String) value);
			return;
		case 1353256545 : /* distributeRate */
			setDistributeRate((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -473717181 : /* manageamt */
			setManageamt((java.lang.Float) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
