/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.refer.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_금융수납처리일자 ( HD_REFER_INCOMEDATE )
 */
@XmlType(propOrder={"deptCode", "housetag", "depositNo", "startdate", "q8050tag", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDReferIncomedate01IO")
@XmlRootElement(name="DHDReferIncomedate01IO")
@SuppressWarnings("all")
public class DHDReferIncomedate01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1596883037L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_금융수납처리일자 ( HD_REFER_INCOMEDATE )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012490(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012490(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012490(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012491(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012491(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012491(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호 [SYS_C0012492(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호 [SYS_C0012492(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호 [SYS_C0012492(C),SYS_C0012970(P) SYS_C0012970(UNIQUE)]
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << startdate >> [[ */
	
	@XmlTransient
	private boolean isSet_startdate = false;
	
	protected boolean isSet_startdate()
	{
		return this.isSet_startdate;
	}
	
	protected void setIsSet_startdate(boolean value)
	{
		this.isSet_startdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시작일자 [SYS_C0012493(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String startdate  = null;
	
	/**
	 * @Description 시작일자 [SYS_C0012493(C)]
	 */
	public java.lang.String getStartdate(){
		return startdate;
	}
	
	/**
	 * @Description 시작일자 [SYS_C0012493(C)]
	 */
	@JsonProperty("startdate")
	public void setStartdate( java.lang.String startdate ) {
		isSet_startdate = true;
		this.startdate = startdate;
	}
	
	/** Property set << startdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << q8050tag >> [[ */
	
	@XmlTransient
	private boolean isSet_q8050tag = false;
	
	protected boolean isSet_q8050tag()
	{
		return this.isSet_q8050tag;
	}
	
	protected void setIsSet_q8050tag(boolean value)
	{
		this.isSet_q8050tag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="Q8050TAG", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String q8050tag  = null;
	
	/**
	 * @Description Q8050TAG
	 */
	public java.lang.String getQ8050tag(){
		return q8050tag;
	}
	
	/**
	 * @Description Q8050TAG
	 */
	@JsonProperty("q8050tag")
	public void setQ8050tag( java.lang.String q8050tag ) {
		isSet_q8050tag = true;
		this.q8050tag = q8050tag;
	}
	
	/** Property set << q8050tag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 변경담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 변경담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 변경일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 변경일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDReferIncomedate01IO clone(){
		try{
			DHDReferIncomedate01IO object= (DHDReferIncomedate01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.startdate== null ) object.startdate = null;
			else{
				object.startdate = this.startdate;
			}
			if ( this.q8050tag== null ) object.q8050tag = null;
			else{
				object.q8050tag = this.q8050tag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((startdate==null)?0:startdate.hashCode());
		result = prime * result + ((q8050tag==null)?0:q8050tag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO other = (kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( startdate == null ){
			if ( other.startdate != null ) return false;
		}
		else if ( !startdate.equals(other.startdate) )
			return false;
		if ( q8050tag == null ){
			if ( other.q8050tag != null ) return false;
		}
		else if ( !q8050tag.equals(other.q8050tag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\tstartdate: ");
		sb.append(startdate==null?"null":getStartdate());
		sb.append("\n");
		sb.append("\tq8050tag: ");
		sb.append(q8050tag==null?"null":getQ8050tag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 20; /* depositNo */
		messageLen+= 8; /* startdate */
		messageLen+= 1; /* q8050tag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("startdate");
	
		fieldNames.add("q8050tag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("startdate", get("startdate"));
	
		fieldValueMap.put("q8050tag", get("q8050tag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case -2128825584 : /* startdate */
			return getStartdate();
		case -1045638762 : /* q8050tag */
			return getQ8050tag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case -2128825584 : /* startdate */
			setStartdate((java.lang.String) value);
			return;
		case -1045638762 : /* q8050tag */
			setQ8050tag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
