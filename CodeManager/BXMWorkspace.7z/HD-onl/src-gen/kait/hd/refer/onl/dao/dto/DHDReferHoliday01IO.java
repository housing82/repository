/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.refer.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_현장별휴일적용 ( HD_REFER_HOLIDAY )
 */
@XmlType(propOrder={"deptCode", "housetag", "rateTag", "adTag", "holiday", "gongDays", "ptag", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDReferHoliday01IO")
@XmlRootElement(name="DHDReferHoliday01IO")
@SuppressWarnings("all")
public class DHDReferHoliday01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1617477504L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_현장별휴일적용 ( HD_REFER_HOLIDAY )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012482(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012482(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012482(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012483(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012483(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012483(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rateTag >> [[ */
	
	@XmlTransient
	private boolean isSet_rateTag = false;
	
	protected boolean isSet_rateTag()
	{
		return this.isSet_rateTag;
	}
	
	protected void setIsSet_rateTag(boolean value)
	{
		this.isSet_rateTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이율종류 [SYS_C0012484(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String rateTag  = null;
	
	/**
	 * @Description 이율종류 [SYS_C0012484(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	public java.lang.String getRateTag(){
		return rateTag;
	}
	
	/**
	 * @Description 이율종류 [SYS_C0012484(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	@JsonProperty("rateTag")
	public void setRateTag( java.lang.String rateTag ) {
		isSet_rateTag = true;
		this.rateTag = rateTag;
	}
	
	/** Property set << rateTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << adTag >> [[ */
	
	@XmlTransient
	private boolean isSet_adTag = false;
	
	protected boolean isSet_adTag()
	{
		return this.isSet_adTag;
	}
	
	protected void setIsSet_adTag(boolean value)
	{
		this.isSet_adTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체할인구분 [SYS_C0012485(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String adTag  = null;
	
	/**
	 * @Description 연체할인구분 [SYS_C0012485(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	public java.lang.String getAdTag(){
		return adTag;
	}
	
	/**
	 * @Description 연체할인구분 [SYS_C0012485(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	@JsonProperty("adTag")
	public void setAdTag( java.lang.String adTag ) {
		isSet_adTag = true;
		this.adTag = adTag;
	}
	
	/** Property set << adTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << holiday >> [[ */
	
	@XmlTransient
	private boolean isSet_holiday = false;
	
	protected boolean isSet_holiday()
	{
		return this.isSet_holiday;
	}
	
	protected void setIsSet_holiday(boolean value)
	{
		this.isSet_holiday = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="공휴일 [SYS_C0012486(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String holiday  = null;
	
	/**
	 * @Description 공휴일 [SYS_C0012486(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	public java.lang.String getHoliday(){
		return holiday;
	}
	
	/**
	 * @Description 공휴일 [SYS_C0012486(C),SYS_C0012968(P) SYS_C0012968(UNIQUE)]
	 */
	@JsonProperty("holiday")
	public void setHoliday( java.lang.String holiday ) {
		isSet_holiday = true;
		this.holiday = holiday;
	}
	
	/** Property set << holiday >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << gongDays >> [[ */
	
	@XmlTransient
	private boolean isSet_gongDays = false;
	
	protected boolean isSet_gongDays()
	{
		return this.isSet_gongDays;
	}
	
	protected void setIsSet_gongDays(boolean value)
	{
		this.isSet_gongDays = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 공제일수
	 */
	public void setGongDays(java.lang.String value) {
		isSet_gongDays = true;
		this.gongDays = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 공제일수
	 */
	public void setGongDays(double value) {
		isSet_gongDays = true;
		this.gongDays = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 공제일수
	 */
	public void setGongDays(long value) {
		isSet_gongDays = true;
		this.gongDays = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="공제일수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal gongDays  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 공제일수
	 */
	public java.math.BigDecimal getGongDays(){
		return gongDays;
	}
	
	/**
	 * @Description 공제일수
	 */
	@JsonProperty("gongDays")
	public void setGongDays( java.math.BigDecimal gongDays ) {
		isSet_gongDays = true;
		this.gongDays = gongDays;
	}
	
	/** Property set << gongDays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << ptag >> [[ */
	
	@XmlTransient
	private boolean isSet_ptag = false;
	
	protected boolean isSet_ptag()
	{
		return this.isSet_ptag;
	}
	
	protected void setIsSet_ptag(boolean value)
	{
		this.isSet_ptag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="처리구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String ptag  = null;
	
	/**
	 * @Description 처리구분
	 */
	public java.lang.String getPtag(){
		return ptag;
	}
	
	/**
	 * @Description 처리구분
	 */
	@JsonProperty("ptag")
	public void setPtag( java.lang.String ptag ) {
		isSet_ptag = true;
		this.ptag = ptag;
	}
	
	/** Property set << ptag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="휴일내역", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 휴일내역
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 휴일내역
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDReferHoliday01IO clone(){
		try{
			DHDReferHoliday01IO object= (DHDReferHoliday01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.rateTag== null ) object.rateTag = null;
			else{
				object.rateTag = this.rateTag;
			}
			if ( this.adTag== null ) object.adTag = null;
			else{
				object.adTag = this.adTag;
			}
			if ( this.holiday== null ) object.holiday = null;
			else{
				object.holiday = this.holiday;
			}
			if ( this.gongDays== null ) object.gongDays = null;
			else{
				object.gongDays = new java.math.BigDecimal(gongDays.toString());
			}
			if ( this.ptag== null ) object.ptag = null;
			else{
				object.ptag = this.ptag;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((rateTag==null)?0:rateTag.hashCode());
		result = prime * result + ((adTag==null)?0:adTag.hashCode());
		result = prime * result + ((holiday==null)?0:holiday.hashCode());
		result = prime * result + ((gongDays==null)?0:gongDays.hashCode());
		result = prime * result + ((ptag==null)?0:ptag.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO other = (kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( rateTag == null ){
			if ( other.rateTag != null ) return false;
		}
		else if ( !rateTag.equals(other.rateTag) )
			return false;
		if ( adTag == null ){
			if ( other.adTag != null ) return false;
		}
		else if ( !adTag.equals(other.adTag) )
			return false;
		if ( holiday == null ){
			if ( other.holiday != null ) return false;
		}
		else if ( !holiday.equals(other.holiday) )
			return false;
		if ( gongDays == null ){
			if ( other.gongDays != null ) return false;
		}
		else if ( !gongDays.equals(other.gongDays) )
			return false;
		if ( ptag == null ){
			if ( other.ptag != null ) return false;
		}
		else if ( !ptag.equals(other.ptag) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\trateTag: ");
		sb.append(rateTag==null?"null":getRateTag());
		sb.append("\n");
		sb.append("\tadTag: ");
		sb.append(adTag==null?"null":getAdTag());
		sb.append("\n");
		sb.append("\tholiday: ");
		sb.append(holiday==null?"null":getHoliday());
		sb.append("\n");
		sb.append("\tgongDays: ");
		sb.append(gongDays==null?"null":getGongDays());
		sb.append("\n");
		sb.append("\tptag: ");
		sb.append(ptag==null?"null":getPtag());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 2; /* rateTag */
		messageLen+= 2; /* adTag */
		messageLen+= 8; /* holiday */
		messageLen+= 22; /* gongDays */
		messageLen+= 2; /* ptag */
		messageLen+= 50; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("rateTag");
	
		fieldNames.add("adTag");
	
		fieldNames.add("holiday");
	
		fieldNames.add("gongDays");
	
		fieldNames.add("ptag");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("rateTag", get("rateTag"));
	
		fieldValueMap.put("adTag", get("adTag"));
	
		fieldValueMap.put("holiday", get("holiday"));
	
		fieldValueMap.put("gongDays", get("gongDays"));
	
		fieldValueMap.put("ptag", get("ptag"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 983453338 : /* rateTag */
			return getRateTag();
		case 92644471 : /* adTag */
			return getAdTag();
		case 1091905624 : /* holiday */
			return getHoliday();
		case 2095951000 : /* gongDays */
			return getGongDays();
		case 3451178 : /* ptag */
			return getPtag();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 983453338 : /* rateTag */
			setRateTag((java.lang.String) value);
			return;
		case 92644471 : /* adTag */
			setAdTag((java.lang.String) value);
			return;
		case 1091905624 : /* holiday */
			setHoliday((java.lang.String) value);
			return;
		case 2095951000 : /* gongDays */
			setGongDays((java.math.BigDecimal) value);
			return;
		case 3451178 : /* ptag */
			setPtag((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
