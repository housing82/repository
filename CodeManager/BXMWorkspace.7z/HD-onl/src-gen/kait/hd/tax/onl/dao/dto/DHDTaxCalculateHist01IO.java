/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.tax.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_세금계산서_납입금_이력 ( HD_TAX_CALCULATE_HIST )
 */
@XmlType(propOrder={"histDate", "deptCode", "housetag", "counts", "times", "calculatetag", "transactioncode", "demandtag", "receiptdate", "buildno", "houseno", "changetag", "kun", "ho", "square", "sangho", "represantation", "addr", "addr2", "uptae", "upjong", "blank", "supplyamt", "landamt", "buildamt", "vatamt", "specialname", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "triTag"}, name="DHDTaxCalculateHist01IO")
@XmlRootElement(name="DHDTaxCalculateHist01IO")
@SuppressWarnings("all")
public class DHDTaxCalculateHist01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 771636976L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_세금계산서_납입금_이력 ( HD_TAX_CALCULATE_HIST )";

	/*******************************************************************************************************************************
	* Property set << histDate >> [[ */
	
	@XmlTransient
	private boolean isSet_histDate = false;
	
	protected boolean isSet_histDate()
	{
		return this.isSet_histDate;
	}
	
	protected void setIsSet_histDate(boolean value)
	{
		this.isSet_histDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이력일자 [SYS_C0012859(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=7, decimal=0, arrayReference="", fill="")
	private java.lang.String histDate  = null;
	
	/**
	 * @Description 이력일자 [SYS_C0012859(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getHistDate(){
		return histDate;
	}
	
	/**
	 * @Description 이력일자 [SYS_C0012859(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("histDate")
	public void setHistDate( java.lang.String histDate ) {
		isSet_histDate = true;
		this.histDate = histDate;
	}
	
	/** Property set << histDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012860(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012860(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012860(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012861(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012861(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012861(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << counts >> [[ */
	
	@XmlTransient
	private boolean isSet_counts = false;
	
	protected boolean isSet_counts()
	{
		return this.isSet_counts;
	}
	
	protected void setIsSet_counts(boolean value)
	{
		this.isSet_counts = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="차수 [SYS_C0012862(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String counts  = null;
	
	/**
	 * @Description 차수 [SYS_C0012862(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getCounts(){
		return counts;
	}
	
	/**
	 * @Description 차수 [SYS_C0012862(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("counts")
	public void setCounts( java.lang.String counts ) {
		isSet_counts = true;
		this.counts = counts;
	}
	
	/** Property set << counts >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << times >> [[ */
	
	@XmlTransient
	private boolean isSet_times = false;
	
	protected boolean isSet_times()
	{
		return this.isSet_times;
	}
	
	protected void setIsSet_times(boolean value)
	{
		this.isSet_times = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="회수 [SYS_C0012863(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float times  = .0F;
	
	/**
	 * @Description 회수 [SYS_C0012863(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.Float getTimes(){
		return times;
	}
	
	/**
	 * @Description 회수 [SYS_C0012863(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("times")
	public void setTimes( java.lang.Float times ) {
		isSet_times = true;
		this.times = times;
	}
	
	/** Property set << times >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << calculatetag >> [[ */
	
	@XmlTransient
	private boolean isSet_calculatetag = false;
	
	protected boolean isSet_calculatetag()
	{
		return this.isSet_calculatetag;
	}
	
	protected void setIsSet_calculatetag(boolean value)
	{
		this.isSet_calculatetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계산서구분 [SYS_C0012864(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String calculatetag  = null;
	
	/**
	 * @Description 계산서구분 [SYS_C0012864(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getCalculatetag(){
		return calculatetag;
	}
	
	/**
	 * @Description 계산서구분 [SYS_C0012864(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("calculatetag")
	public void setCalculatetag( java.lang.String calculatetag ) {
		isSet_calculatetag = true;
		this.calculatetag = calculatetag;
	}
	
	/** Property set << calculatetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << transactioncode >> [[ */
	
	@XmlTransient
	private boolean isSet_transactioncode = false;
	
	protected boolean isSet_transactioncode()
	{
		return this.isSet_transactioncode;
	}
	
	protected void setIsSet_transactioncode(boolean value)
	{
		this.isSet_transactioncode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012865(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=13, decimal=0, arrayReference="", fill="")
	private java.lang.String transactioncode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012865(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getTransactioncode(){
		return transactioncode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012865(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("transactioncode")
	public void setTransactioncode( java.lang.String transactioncode ) {
		isSet_transactioncode = true;
		this.transactioncode = transactioncode;
	}
	
	/** Property set << transactioncode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << demandtag >> [[ */
	
	@XmlTransient
	private boolean isSet_demandtag = false;
	
	protected boolean isSet_demandtag()
	{
		return this.isSet_demandtag;
	}
	
	protected void setIsSet_demandtag(boolean value)
	{
		this.isSet_demandtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="영수/청구구분 [SYS_C0012866(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String demandtag  = null;
	
	/**
	 * @Description 영수/청구구분 [SYS_C0012866(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getDemandtag(){
		return demandtag;
	}
	
	/**
	 * @Description 영수/청구구분 [SYS_C0012866(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("demandtag")
	public void setDemandtag( java.lang.String demandtag ) {
		isSet_demandtag = true;
		this.demandtag = demandtag;
	}
	
	/** Property set << demandtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptdate >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptdate = false;
	
	protected boolean isSet_receiptdate()
	{
		return this.isSet_receiptdate;
	}
	
	protected void setIsSet_receiptdate(boolean value)
	{
		this.isSet_receiptdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입일자 [SYS_C0012867(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String receiptdate  = null;
	
	/**
	 * @Description 납입일자 [SYS_C0012867(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getReceiptdate(){
		return receiptdate;
	}
	
	/**
	 * @Description 납입일자 [SYS_C0012867(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("receiptdate")
	public void setReceiptdate( java.lang.String receiptdate ) {
		isSet_receiptdate = true;
		this.receiptdate = receiptdate;
	}
	
	/** Property set << receiptdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012868(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012868(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012868(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012869(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012869(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012869(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changetag >> [[ */
	
	@XmlTransient
	private boolean isSet_changetag = false;
	
	protected boolean isSet_changetag()
	{
		return this.isSet_changetag;
	}
	
	protected void setIsSet_changetag(boolean value)
	{
		this.isSet_changetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경구분 [SYS_C0012870(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String changetag  = null;
	
	/**
	 * @Description 변경구분 [SYS_C0012870(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	public java.lang.String getChangetag(){
		return changetag;
	}
	
	/**
	 * @Description 변경구분 [SYS_C0012870(C),SYS_C0013023(P) SYS_C0013023(UNIQUE)]
	 */
	@JsonProperty("changetag")
	public void setChangetag( java.lang.String changetag ) {
		isSet_changetag = true;
		this.changetag = changetag;
	}
	
	/** Property set << changetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << kun >> [[ */
	
	@XmlTransient
	private boolean isSet_kun = false;
	
	protected boolean isSet_kun()
	{
		return this.isSet_kun;
	}
	
	protected void setIsSet_kun(boolean value)
	{
		this.isSet_kun = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="권", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String kun  = null;
	
	/**
	 * @Description 권
	 */
	public java.lang.String getKun(){
		return kun;
	}
	
	/**
	 * @Description 권
	 */
	@JsonProperty("kun")
	public void setKun( java.lang.String kun ) {
		isSet_kun = true;
		this.kun = kun;
	}
	
	/** Property set << kun >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << ho >> [[ */
	
	@XmlTransient
	private boolean isSet_ho = false;
	
	protected boolean isSet_ho()
	{
		return this.isSet_ho;
	}
	
	protected void setIsSet_ho(boolean value)
	{
		this.isSet_ho = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="번호", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String ho  = null;
	
	/**
	 * @Description 번호
	 */
	public java.lang.String getHo(){
		return ho;
	}
	
	/**
	 * @Description 번호
	 */
	@JsonProperty("ho")
	public void setHo( java.lang.String ho ) {
		isSet_ho = true;
		this.ho = ho;
	}
	
	/** Property set << ho >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 평형
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 평형
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 평형
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 평형
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sangho >> [[ */
	
	@XmlTransient
	private boolean isSet_sangho = false;
	
	protected boolean isSet_sangho()
	{
		return this.isSet_sangho;
	}
	
	protected void setIsSet_sangho(boolean value)
	{
		this.isSet_sangho = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String sangho  = null;
	
	/**
	 * @Description 상호
	 */
	public java.lang.String getSangho(){
		return sangho;
	}
	
	/**
	 * @Description 상호
	 */
	@JsonProperty("sangho")
	public void setSangho( java.lang.String sangho ) {
		isSet_sangho = true;
		this.sangho = sangho;
	}
	
	/** Property set << sangho >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << represantation >> [[ */
	
	@XmlTransient
	private boolean isSet_represantation = false;
	
	protected boolean isSet_represantation()
	{
		return this.isSet_represantation;
	}
	
	protected void setIsSet_represantation(boolean value)
	{
		this.isSet_represantation = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대표자", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String represantation  = null;
	
	/**
	 * @Description 대표자
	 */
	public java.lang.String getRepresantation(){
		return represantation;
	}
	
	/**
	 * @Description 대표자
	 */
	@JsonProperty("represantation")
	public void setRepresantation( java.lang.String represantation ) {
		isSet_represantation = true;
		this.represantation = represantation;
	}
	
	/** Property set << represantation >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr >> [[ */
	
	@XmlTransient
	private boolean isSet_addr = false;
	
	protected boolean isSet_addr()
	{
		return this.isSet_addr;
	}
	
	protected void setIsSet_addr(boolean value)
	{
		this.isSet_addr = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String addr  = null;
	
	/**
	 * @Description 주소
	 */
	public java.lang.String getAddr(){
		return addr;
	}
	
	/**
	 * @Description 주소
	 */
	@JsonProperty("addr")
	public void setAddr( java.lang.String addr ) {
		isSet_addr = true;
		this.addr = addr;
	}
	
	/** Property set << addr >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2 = false;
	
	protected boolean isSet_addr2()
	{
		return this.isSet_addr2;
	}
	
	protected void setIsSet_addr2(boolean value)
	{
		this.isSet_addr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소2", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2  = null;
	
	/**
	 * @Description 주소2
	 */
	public java.lang.String getAddr2(){
		return addr2;
	}
	
	/**
	 * @Description 주소2
	 */
	@JsonProperty("addr2")
	public void setAddr2( java.lang.String addr2 ) {
		isSet_addr2 = true;
		this.addr2 = addr2;
	}
	
	/** Property set << addr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << uptae >> [[ */
	
	@XmlTransient
	private boolean isSet_uptae = false;
	
	protected boolean isSet_uptae()
	{
		return this.isSet_uptae;
	}
	
	protected void setIsSet_uptae(boolean value)
	{
		this.isSet_uptae = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="업태", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String uptae  = null;
	
	/**
	 * @Description 업태
	 */
	public java.lang.String getUptae(){
		return uptae;
	}
	
	/**
	 * @Description 업태
	 */
	@JsonProperty("uptae")
	public void setUptae( java.lang.String uptae ) {
		isSet_uptae = true;
		this.uptae = uptae;
	}
	
	/** Property set << uptae >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << upjong >> [[ */
	
	@XmlTransient
	private boolean isSet_upjong = false;
	
	protected boolean isSet_upjong()
	{
		return this.isSet_upjong;
	}
	
	protected void setIsSet_upjong(boolean value)
	{
		this.isSet_upjong = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="종목", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String upjong  = null;
	
	/**
	 * @Description 종목
	 */
	public java.lang.String getUpjong(){
		return upjong;
	}
	
	/**
	 * @Description 종목
	 */
	@JsonProperty("upjong")
	public void setUpjong( java.lang.String upjong ) {
		isSet_upjong = true;
		this.upjong = upjong;
	}
	
	/** Property set << upjong >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << blank >> [[ */
	
	@XmlTransient
	private boolean isSet_blank = false;
	
	protected boolean isSet_blank()
	{
		return this.isSet_blank;
	}
	
	protected void setIsSet_blank(boolean value)
	{
		this.isSet_blank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="공란", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String blank  = null;
	
	/**
	 * @Description 공란
	 */
	public java.lang.String getBlank(){
		return blank;
	}
	
	/**
	 * @Description 공란
	 */
	@JsonProperty("blank")
	public void setBlank( java.lang.String blank ) {
		isSet_blank = true;
		this.blank = blank;
	}
	
	/** Property set << blank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << supplyamt >> [[ */
	
	@XmlTransient
	private boolean isSet_supplyamt = false;
	
	protected boolean isSet_supplyamt()
	{
		return this.isSet_supplyamt;
	}
	
	protected void setIsSet_supplyamt(boolean value)
	{
		this.isSet_supplyamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="공급가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float supplyamt  = .0F;
	
	/**
	 * @Description 공급가액
	 */
	public java.lang.Float getSupplyamt(){
		return supplyamt;
	}
	
	/**
	 * @Description 공급가액
	 */
	@JsonProperty("supplyamt")
	public void setSupplyamt( java.lang.Float supplyamt ) {
		isSet_supplyamt = true;
		this.supplyamt = supplyamt;
	}
	
	/** Property set << supplyamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << landamt >> [[ */
	
	@XmlTransient
	private boolean isSet_landamt = false;
	
	protected boolean isSet_landamt()
	{
		return this.isSet_landamt;
	}
	
	protected void setIsSet_landamt(boolean value)
	{
		this.isSet_landamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="토지가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float landamt  = .0F;
	
	/**
	 * @Description 토지가액
	 */
	public java.lang.Float getLandamt(){
		return landamt;
	}
	
	/**
	 * @Description 토지가액
	 */
	@JsonProperty("landamt")
	public void setLandamt( java.lang.Float landamt ) {
		isSet_landamt = true;
		this.landamt = landamt;
	}
	
	/** Property set << landamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildamt >> [[ */
	
	@XmlTransient
	private boolean isSet_buildamt = false;
	
	protected boolean isSet_buildamt()
	{
		return this.isSet_buildamt;
	}
	
	protected void setIsSet_buildamt(boolean value)
	{
		this.isSet_buildamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="건물가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float buildamt  = .0F;
	
	/**
	 * @Description 건물가액
	 */
	public java.lang.Float getBuildamt(){
		return buildamt;
	}
	
	/**
	 * @Description 건물가액
	 */
	@JsonProperty("buildamt")
	public void setBuildamt( java.lang.Float buildamt ) {
		isSet_buildamt = true;
		this.buildamt = buildamt;
	}
	
	/** Property set << buildamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatamt >> [[ */
	
	@XmlTransient
	private boolean isSet_vatamt = false;
	
	protected boolean isSet_vatamt()
	{
		return this.isSet_vatamt;
	}
	
	protected void setIsSet_vatamt(boolean value)
	{
		this.isSet_vatamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float vatamt  = .0F;
	
	/**
	 * @Description 부가세액
	 */
	public java.lang.Float getVatamt(){
		return vatamt;
	}
	
	/**
	 * @Description 부가세액
	 */
	@JsonProperty("vatamt")
	public void setVatamt( java.lang.Float vatamt ) {
		isSet_vatamt = true;
		this.vatamt = vatamt;
	}
	
	/** Property set << vatamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << specialname >> [[ */
	
	@XmlTransient
	private boolean isSet_specialname = false;
	
	protected boolean isSet_specialname()
	{
		return this.isSet_specialname;
	}
	
	protected void setIsSet_specialname(boolean value)
	{
		this.isSet_specialname = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="품목", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String specialname  = null;
	
	/**
	 * @Description 품목
	 */
	public java.lang.String getSpecialname(){
		return specialname;
	}
	
	/**
	 * @Description 품목
	 */
	@JsonProperty("specialname")
	public void setSpecialname( java.lang.String specialname ) {
		isSet_specialname = true;
		this.specialname = specialname;
	}
	
	/** Property set << specialname >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="적요", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 적요
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 적요
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 변경담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 변경담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 변경일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 변경일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << triTag >> [[ */
	
	@XmlTransient
	private boolean isSet_triTag = false;
	
	protected boolean isSet_triTag()
	{
		return this.isSet_triTag;
	}
	
	protected void setIsSet_triTag(boolean value)
	{
		this.isSet_triTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="트리거구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String triTag  = null;
	
	/**
	 * @Description 트리거구분
	 */
	public java.lang.String getTriTag(){
		return triTag;
	}
	
	/**
	 * @Description 트리거구분
	 */
	@JsonProperty("triTag")
	public void setTriTag( java.lang.String triTag ) {
		isSet_triTag = true;
		this.triTag = triTag;
	}
	
	/** Property set << triTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDTaxCalculateHist01IO clone(){
		try{
			DHDTaxCalculateHist01IO object= (DHDTaxCalculateHist01IO)super.clone();
			if ( this.histDate== null ) object.histDate = null;
			else{
				object.histDate = this.histDate;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.counts== null ) object.counts = null;
			else{
				object.counts = this.counts;
			}
			if ( this.times== null ) object.times = null;
			else{
				object.times = this.times;
			}
			if ( this.calculatetag== null ) object.calculatetag = null;
			else{
				object.calculatetag = this.calculatetag;
			}
			if ( this.transactioncode== null ) object.transactioncode = null;
			else{
				object.transactioncode = this.transactioncode;
			}
			if ( this.demandtag== null ) object.demandtag = null;
			else{
				object.demandtag = this.demandtag;
			}
			if ( this.receiptdate== null ) object.receiptdate = null;
			else{
				object.receiptdate = this.receiptdate;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.changetag== null ) object.changetag = null;
			else{
				object.changetag = this.changetag;
			}
			if ( this.kun== null ) object.kun = null;
			else{
				object.kun = this.kun;
			}
			if ( this.ho== null ) object.ho = null;
			else{
				object.ho = this.ho;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.sangho== null ) object.sangho = null;
			else{
				object.sangho = this.sangho;
			}
			if ( this.represantation== null ) object.represantation = null;
			else{
				object.represantation = this.represantation;
			}
			if ( this.addr== null ) object.addr = null;
			else{
				object.addr = this.addr;
			}
			if ( this.addr2== null ) object.addr2 = null;
			else{
				object.addr2 = this.addr2;
			}
			if ( this.uptae== null ) object.uptae = null;
			else{
				object.uptae = this.uptae;
			}
			if ( this.upjong== null ) object.upjong = null;
			else{
				object.upjong = this.upjong;
			}
			if ( this.blank== null ) object.blank = null;
			else{
				object.blank = this.blank;
			}
			if ( this.supplyamt== null ) object.supplyamt = null;
			else{
				object.supplyamt = this.supplyamt;
			}
			if ( this.landamt== null ) object.landamt = null;
			else{
				object.landamt = this.landamt;
			}
			if ( this.buildamt== null ) object.buildamt = null;
			else{
				object.buildamt = this.buildamt;
			}
			if ( this.vatamt== null ) object.vatamt = null;
			else{
				object.vatamt = this.vatamt;
			}
			if ( this.specialname== null ) object.specialname = null;
			else{
				object.specialname = this.specialname;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.triTag== null ) object.triTag = null;
			else{
				object.triTag = this.triTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((histDate==null)?0:histDate.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((counts==null)?0:counts.hashCode());
		result = prime * result + ((times==null)?0:times.hashCode());
		result = prime * result + ((calculatetag==null)?0:calculatetag.hashCode());
		result = prime * result + ((transactioncode==null)?0:transactioncode.hashCode());
		result = prime * result + ((demandtag==null)?0:demandtag.hashCode());
		result = prime * result + ((receiptdate==null)?0:receiptdate.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((changetag==null)?0:changetag.hashCode());
		result = prime * result + ((kun==null)?0:kun.hashCode());
		result = prime * result + ((ho==null)?0:ho.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((sangho==null)?0:sangho.hashCode());
		result = prime * result + ((represantation==null)?0:represantation.hashCode());
		result = prime * result + ((addr==null)?0:addr.hashCode());
		result = prime * result + ((addr2==null)?0:addr2.hashCode());
		result = prime * result + ((uptae==null)?0:uptae.hashCode());
		result = prime * result + ((upjong==null)?0:upjong.hashCode());
		result = prime * result + ((blank==null)?0:blank.hashCode());
		result = prime * result + ((supplyamt==null)?0:supplyamt.hashCode());
		result = prime * result + ((landamt==null)?0:landamt.hashCode());
		result = prime * result + ((buildamt==null)?0:buildamt.hashCode());
		result = prime * result + ((vatamt==null)?0:vatamt.hashCode());
		result = prime * result + ((specialname==null)?0:specialname.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((triTag==null)?0:triTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.tax.onl.dao.dto.DHDTaxCalculateHist01IO other = (kait.hd.tax.onl.dao.dto.DHDTaxCalculateHist01IO)obj;
		if ( histDate == null ){
			if ( other.histDate != null ) return false;
		}
		else if ( !histDate.equals(other.histDate) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( counts == null ){
			if ( other.counts != null ) return false;
		}
		else if ( !counts.equals(other.counts) )
			return false;
		if ( times == null ){
			if ( other.times != null ) return false;
		}
		else if ( !times.equals(other.times) )
			return false;
		if ( calculatetag == null ){
			if ( other.calculatetag != null ) return false;
		}
		else if ( !calculatetag.equals(other.calculatetag) )
			return false;
		if ( transactioncode == null ){
			if ( other.transactioncode != null ) return false;
		}
		else if ( !transactioncode.equals(other.transactioncode) )
			return false;
		if ( demandtag == null ){
			if ( other.demandtag != null ) return false;
		}
		else if ( !demandtag.equals(other.demandtag) )
			return false;
		if ( receiptdate == null ){
			if ( other.receiptdate != null ) return false;
		}
		else if ( !receiptdate.equals(other.receiptdate) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( changetag == null ){
			if ( other.changetag != null ) return false;
		}
		else if ( !changetag.equals(other.changetag) )
			return false;
		if ( kun == null ){
			if ( other.kun != null ) return false;
		}
		else if ( !kun.equals(other.kun) )
			return false;
		if ( ho == null ){
			if ( other.ho != null ) return false;
		}
		else if ( !ho.equals(other.ho) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( sangho == null ){
			if ( other.sangho != null ) return false;
		}
		else if ( !sangho.equals(other.sangho) )
			return false;
		if ( represantation == null ){
			if ( other.represantation != null ) return false;
		}
		else if ( !represantation.equals(other.represantation) )
			return false;
		if ( addr == null ){
			if ( other.addr != null ) return false;
		}
		else if ( !addr.equals(other.addr) )
			return false;
		if ( addr2 == null ){
			if ( other.addr2 != null ) return false;
		}
		else if ( !addr2.equals(other.addr2) )
			return false;
		if ( uptae == null ){
			if ( other.uptae != null ) return false;
		}
		else if ( !uptae.equals(other.uptae) )
			return false;
		if ( upjong == null ){
			if ( other.upjong != null ) return false;
		}
		else if ( !upjong.equals(other.upjong) )
			return false;
		if ( blank == null ){
			if ( other.blank != null ) return false;
		}
		else if ( !blank.equals(other.blank) )
			return false;
		if ( supplyamt == null ){
			if ( other.supplyamt != null ) return false;
		}
		else if ( !supplyamt.equals(other.supplyamt) )
			return false;
		if ( landamt == null ){
			if ( other.landamt != null ) return false;
		}
		else if ( !landamt.equals(other.landamt) )
			return false;
		if ( buildamt == null ){
			if ( other.buildamt != null ) return false;
		}
		else if ( !buildamt.equals(other.buildamt) )
			return false;
		if ( vatamt == null ){
			if ( other.vatamt != null ) return false;
		}
		else if ( !vatamt.equals(other.vatamt) )
			return false;
		if ( specialname == null ){
			if ( other.specialname != null ) return false;
		}
		else if ( !specialname.equals(other.specialname) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( triTag == null ){
			if ( other.triTag != null ) return false;
		}
		else if ( !triTag.equals(other.triTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.tax.onl.dao.dto.DHDTaxCalculateHist01IO:\n");
		sb.append("\thistDate: ");
		sb.append(histDate==null?"null":getHistDate());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tcounts: ");
		sb.append(counts==null?"null":getCounts());
		sb.append("\n");
		sb.append("\ttimes: ");
		sb.append(times==null?"null":getTimes());
		sb.append("\n");
		sb.append("\tcalculatetag: ");
		sb.append(calculatetag==null?"null":getCalculatetag());
		sb.append("\n");
		sb.append("\ttransactioncode: ");
		sb.append(transactioncode==null?"null":getTransactioncode());
		sb.append("\n");
		sb.append("\tdemandtag: ");
		sb.append(demandtag==null?"null":getDemandtag());
		sb.append("\n");
		sb.append("\treceiptdate: ");
		sb.append(receiptdate==null?"null":getReceiptdate());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tchangetag: ");
		sb.append(changetag==null?"null":getChangetag());
		sb.append("\n");
		sb.append("\tkun: ");
		sb.append(kun==null?"null":getKun());
		sb.append("\n");
		sb.append("\tho: ");
		sb.append(ho==null?"null":getHo());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\tsangho: ");
		sb.append(sangho==null?"null":getSangho());
		sb.append("\n");
		sb.append("\trepresantation: ");
		sb.append(represantation==null?"null":getRepresantation());
		sb.append("\n");
		sb.append("\taddr: ");
		sb.append(addr==null?"null":getAddr());
		sb.append("\n");
		sb.append("\taddr2: ");
		sb.append(addr2==null?"null":getAddr2());
		sb.append("\n");
		sb.append("\tuptae: ");
		sb.append(uptae==null?"null":getUptae());
		sb.append("\n");
		sb.append("\tupjong: ");
		sb.append(upjong==null?"null":getUpjong());
		sb.append("\n");
		sb.append("\tblank: ");
		sb.append(blank==null?"null":getBlank());
		sb.append("\n");
		sb.append("\tsupplyamt: ");
		sb.append(supplyamt==null?"null":getSupplyamt());
		sb.append("\n");
		sb.append("\tlandamt: ");
		sb.append(landamt==null?"null":getLandamt());
		sb.append("\n");
		sb.append("\tbuildamt: ");
		sb.append(buildamt==null?"null":getBuildamt());
		sb.append("\n");
		sb.append("\tvatamt: ");
		sb.append(vatamt==null?"null":getVatamt());
		sb.append("\n");
		sb.append("\tspecialname: ");
		sb.append(specialname==null?"null":getSpecialname());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\ttriTag: ");
		sb.append(triTag==null?"null":getTriTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 7; /* histDate */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 2; /* counts */
		messageLen+= 22; /* times */
		messageLen+= 1; /* calculatetag */
		messageLen+= 13; /* transactioncode */
		messageLen+= 1; /* demandtag */
		messageLen+= 8; /* receiptdate */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 1; /* changetag */
		messageLen+= 4; /* kun */
		messageLen+= 4; /* ho */
		messageLen+= 22; /* square */
		messageLen+= 30; /* sangho */
		messageLen+= 30; /* represantation */
		messageLen+= 50; /* addr */
		messageLen+= 50; /* addr2 */
		messageLen+= 30; /* uptae */
		messageLen+= 30; /* upjong */
		messageLen+= 1; /* blank */
		messageLen+= 22; /* supplyamt */
		messageLen+= 22; /* landamt */
		messageLen+= 22; /* buildamt */
		messageLen+= 22; /* vatamt */
		messageLen+= 50; /* specialname */
		messageLen+= 50; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 1; /* triTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("histDate");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("counts");
	
		fieldNames.add("times");
	
		fieldNames.add("calculatetag");
	
		fieldNames.add("transactioncode");
	
		fieldNames.add("demandtag");
	
		fieldNames.add("receiptdate");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("changetag");
	
		fieldNames.add("kun");
	
		fieldNames.add("ho");
	
		fieldNames.add("square");
	
		fieldNames.add("sangho");
	
		fieldNames.add("represantation");
	
		fieldNames.add("addr");
	
		fieldNames.add("addr2");
	
		fieldNames.add("uptae");
	
		fieldNames.add("upjong");
	
		fieldNames.add("blank");
	
		fieldNames.add("supplyamt");
	
		fieldNames.add("landamt");
	
		fieldNames.add("buildamt");
	
		fieldNames.add("vatamt");
	
		fieldNames.add("specialname");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("triTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("histDate", get("histDate"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("counts", get("counts"));
	
		fieldValueMap.put("times", get("times"));
	
		fieldValueMap.put("calculatetag", get("calculatetag"));
	
		fieldValueMap.put("transactioncode", get("transactioncode"));
	
		fieldValueMap.put("demandtag", get("demandtag"));
	
		fieldValueMap.put("receiptdate", get("receiptdate"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("changetag", get("changetag"));
	
		fieldValueMap.put("kun", get("kun"));
	
		fieldValueMap.put("ho", get("ho"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("sangho", get("sangho"));
	
		fieldValueMap.put("represantation", get("represantation"));
	
		fieldValueMap.put("addr", get("addr"));
	
		fieldValueMap.put("addr2", get("addr2"));
	
		fieldValueMap.put("uptae", get("uptae"));
	
		fieldValueMap.put("upjong", get("upjong"));
	
		fieldValueMap.put("blank", get("blank"));
	
		fieldValueMap.put("supplyamt", get("supplyamt"));
	
		fieldValueMap.put("landamt", get("landamt"));
	
		fieldValueMap.put("buildamt", get("buildamt"));
	
		fieldValueMap.put("vatamt", get("vatamt"));
	
		fieldValueMap.put("specialname", get("specialname"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("triTag", get("triTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			return getHistDate();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -1354575548 : /* counts */
			return getCounts();
		case 110364486 : /* times */
			return getTimes();
		case 1089485428 : /* calculatetag */
			return getCalculatetag();
		case 1263460811 : /* transactioncode */
			return getTransactioncode();
		case 408726895 : /* demandtag */
			return getDemandtag();
		case 2034075110 : /* receiptdate */
			return getReceiptdate();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 1455279594 : /* changetag */
			return getChangetag();
		case 106564 : /* kun */
			return getKun();
		case 3335 : /* ho */
			return getHo();
		case -894674659 : /* square */
			return getSquare();
		case -909654066 : /* sangho */
			return getSangho();
		case 947627345 : /* represantation */
			return getRepresantation();
		case 2989041 : /* addr */
			return getAddr();
		case 92660321 : /* addr2 */
			return getAddr2();
		case 111503133 : /* uptae */
			return getUptae();
		case -838654247 : /* upjong */
			return getUpjong();
		case 93819220 : /* blank */
			return getBlank();
		case -22382983 : /* supplyamt */
			return getSupplyamt();
		case -52159491 : /* landamt */
			return getLandamt();
		case -1430653798 : /* buildamt */
			return getBuildamt();
		case -823593473 : /* vatamt */
			return getVatamt();
		case -871647548 : /* specialname */
			return getSpecialname();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -865492497 : /* triTag */
			return getTriTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			setHistDate((java.lang.String) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -1354575548 : /* counts */
			setCounts((java.lang.String) value);
			return;
		case 110364486 : /* times */
			setTimes((java.lang.Float) value);
			return;
		case 1089485428 : /* calculatetag */
			setCalculatetag((java.lang.String) value);
			return;
		case 1263460811 : /* transactioncode */
			setTransactioncode((java.lang.String) value);
			return;
		case 408726895 : /* demandtag */
			setDemandtag((java.lang.String) value);
			return;
		case 2034075110 : /* receiptdate */
			setReceiptdate((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 1455279594 : /* changetag */
			setChangetag((java.lang.String) value);
			return;
		case 106564 : /* kun */
			setKun((java.lang.String) value);
			return;
		case 3335 : /* ho */
			setHo((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case -909654066 : /* sangho */
			setSangho((java.lang.String) value);
			return;
		case 947627345 : /* represantation */
			setRepresantation((java.lang.String) value);
			return;
		case 2989041 : /* addr */
			setAddr((java.lang.String) value);
			return;
		case 92660321 : /* addr2 */
			setAddr2((java.lang.String) value);
			return;
		case 111503133 : /* uptae */
			setUptae((java.lang.String) value);
			return;
		case -838654247 : /* upjong */
			setUpjong((java.lang.String) value);
			return;
		case 93819220 : /* blank */
			setBlank((java.lang.String) value);
			return;
		case -22382983 : /* supplyamt */
			setSupplyamt((java.lang.Float) value);
			return;
		case -52159491 : /* landamt */
			setLandamt((java.lang.Float) value);
			return;
		case -1430653798 : /* buildamt */
			setBuildamt((java.lang.Float) value);
			return;
		case -823593473 : /* vatamt */
			setVatamt((java.lang.Float) value);
			return;
		case -871647548 : /* specialname */
			setSpecialname((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -865492497 : /* triTag */
			setTriTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
