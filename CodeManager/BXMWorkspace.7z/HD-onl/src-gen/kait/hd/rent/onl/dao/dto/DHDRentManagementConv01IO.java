/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_관리비검토_자료올리기 ( HD_RENT_MANAGEMENT_CONV )
 */
@XmlType(propOrder={"deptCode", "housetag", "ym", "seq", "buildno", "houseno", "amt", "remark"}, name="DHDRentManagementConv01IO")
@XmlRootElement(name="DHDRentManagementConv01IO")
@SuppressWarnings("all")
public class DHDRentManagementConv01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1818104859L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_관리비검토_자료올리기 ( HD_RENT_MANAGEMENT_CONV )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012701(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012701(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012701(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012702(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012702(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012702(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << ym >> [[ */
	
	@XmlTransient
	private boolean isSet_ym = false;
	
	protected boolean isSet_ym()
	{
		return this.isSet_ym;
	}
	
	protected void setIsSet_ym(boolean value)
	{
		this.isSet_ym = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="관리비년월 [SYS_C0012703(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String ym  = null;
	
	/**
	 * @Description 관리비년월 [SYS_C0012703(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public java.lang.String getYm(){
		return ym;
	}
	
	/**
	 * @Description 관리비년월 [SYS_C0012703(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	@JsonProperty("ym")
	public void setYm( java.lang.String ym ) {
		isSet_ym = true;
		this.ym = ym;
	}
	
	/** Property set << ym >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012704(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012704(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012704(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012704(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012704(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012704(C),SYS_C0013002(P) XPKHD_RENT_MANAGEMENT_CONV(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt >> [[ */
	
	@XmlTransient
	private boolean isSet_amt = false;
	
	protected boolean isSet_amt()
	{
		return this.isSet_amt;
	}
	
	protected void setIsSet_amt(boolean value)
	{
		this.isSet_amt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 관리비
	 */
	public void setAmt(java.lang.String value) {
		isSet_amt = true;
		this.amt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 관리비
	 */
	public void setAmt(double value) {
		isSet_amt = true;
		this.amt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 관리비
	 */
	public void setAmt(long value) {
		isSet_amt = true;
		this.amt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="관리비", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 관리비
	 */
	public java.math.BigDecimal getAmt(){
		return amt;
	}
	
	/**
	 * @Description 관리비
	 */
	@JsonProperty("amt")
	public void setAmt( java.math.BigDecimal amt ) {
		isSet_amt = true;
		this.amt = amt;
	}
	
	/** Property set << amt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentManagementConv01IO clone(){
		try{
			DHDRentManagementConv01IO object= (DHDRentManagementConv01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.ym== null ) object.ym = null;
			else{
				object.ym = this.ym;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.amt== null ) object.amt = null;
			else{
				object.amt = new java.math.BigDecimal(amt.toString());
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((ym==null)?0:ym.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((amt==null)?0:amt.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentManagementConv01IO other = (kait.hd.rent.onl.dao.dto.DHDRentManagementConv01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( ym == null ){
			if ( other.ym != null ) return false;
		}
		else if ( !ym.equals(other.ym) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( amt == null ){
			if ( other.amt != null ) return false;
		}
		else if ( !amt.equals(other.amt) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentManagementConv01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tym: ");
		sb.append(ym==null?"null":getYm());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tamt: ");
		sb.append(amt==null?"null":getAmt());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 6; /* ym */
		messageLen+= 22; /* seq */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 22; /* amt */
		messageLen+= 200; /* remark */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("ym");
	
		fieldNames.add("seq");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("amt");
	
		fieldNames.add("remark");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("ym", get("ym"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("amt", get("amt"));
	
		fieldValueMap.put("remark", get("remark"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 3860 : /* ym */
			return getYm();
		case 113759 : /* seq */
			return getSeq();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 96712 : /* amt */
			return getAmt();
		case -934624384 : /* remark */
			return getRemark();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 3860 : /* ym */
			setYm((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 96712 : /* amt */
			setAmt((java.math.BigDecimal) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
