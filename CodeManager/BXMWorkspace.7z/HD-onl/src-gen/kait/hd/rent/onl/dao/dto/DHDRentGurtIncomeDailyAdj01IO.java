/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_보증금납입사항_일자별_정산 ( HD_RENT_GURT_INCOME_DAILY_ADJ )
 */
@XmlType(propOrder={"deptCode", "housetag", "inDate", "inSeq", "custCode", "seq", "depositNo", "inAmt", "inGubun", "inType", "transYn", "cardNo", "modYn", "modDelayAmt", "modDiscAmt", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "vdepositNo", "outDt", "outTm", "outSeq", "outBank", "remark"}, name="DHDRentGurtIncomeDailyAdj01IO")
@XmlRootElement(name="DHDRentGurtIncomeDailyAdj01IO")
@SuppressWarnings("all")
public class DHDRentGurtIncomeDailyAdj01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -197767189L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_보증금납입사항_일자별_정산 ( HD_RENT_GURT_INCOME_DAILY_ADJ )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012677(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012677(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012677(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012678(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012678(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012678(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inDate = false;
	
	protected boolean isSet_inDate()
	{
		return this.isSet_inDate;
	}
	
	protected void setIsSet_inDate(boolean value)
	{
		this.isSet_inDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금일자 [SYS_C0012679(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String inDate  = null;
	
	/**
	 * @Description 입금일자 [SYS_C0012679(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public java.lang.String getInDate(){
		return inDate;
	}
	
	/**
	 * @Description 입금일자 [SYS_C0012679(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	@JsonProperty("inDate")
	public void setInDate( java.lang.String inDate ) {
		isSet_inDate = true;
		this.inDate = inDate;
	}
	
	/** Property set << inDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_inSeq = false;
	
	protected boolean isSet_inSeq()
	{
		return this.isSet_inSeq;
	}
	
	protected void setIsSet_inSeq(boolean value)
	{
		this.isSet_inSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012680(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public void setInSeq(java.lang.String value) {
		isSet_inSeq = true;
		this.inSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012680(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public void setInSeq(double value) {
		isSet_inSeq = true;
		this.inSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012680(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public void setInSeq(long value) {
		isSet_inSeq = true;
		this.inSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012680(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012680(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	public java.math.BigDecimal getInSeq(){
		return inSeq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012680(C),SYS_C0012999(P) SYS_C0012999(UNIQUE)]
	 */
	@JsonProperty("inSeq")
	public void setInSeq( java.math.BigDecimal inSeq ) {
		isSet_inSeq = true;
		this.inSeq = inSeq;
	}
	
	/** Property set << inSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_inAmt = false;
	
	protected boolean isSet_inAmt()
	{
		return this.isSet_inAmt;
	}
	
	protected void setIsSet_inAmt(boolean value)
	{
		this.isSet_inAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 입금금액
	 */
	public void setInAmt(java.lang.String value) {
		isSet_inAmt = true;
		this.inAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 입금금액
	 */
	public void setInAmt(double value) {
		isSet_inAmt = true;
		this.inAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 입금금액
	 */
	public void setInAmt(long value) {
		isSet_inAmt = true;
		this.inAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="입금금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 입금금액
	 */
	public java.math.BigDecimal getInAmt(){
		return inAmt;
	}
	
	/**
	 * @Description 입금금액
	 */
	@JsonProperty("inAmt")
	public void setInAmt( java.math.BigDecimal inAmt ) {
		isSet_inAmt = true;
		this.inAmt = inAmt;
	}
	
	/** Property set << inAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inGubun >> [[ */
	
	@XmlTransient
	private boolean isSet_inGubun = false;
	
	protected boolean isSet_inGubun()
	{
		return this.isSet_inGubun;
	}
	
	protected void setIsSet_inGubun(boolean value)
	{
		this.isSet_inGubun = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String inGubun  = null;
	
	/**
	 * @Description 입금구분
	 */
	public java.lang.String getInGubun(){
		return inGubun;
	}
	
	/**
	 * @Description 입금구분
	 */
	@JsonProperty("inGubun")
	public void setInGubun( java.lang.String inGubun ) {
		isSet_inGubun = true;
		this.inGubun = inGubun;
	}
	
	/** Property set << inGubun >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inType >> [[ */
	
	@XmlTransient
	private boolean isSet_inType = false;
	
	protected boolean isSet_inType()
	{
		return this.isSet_inType;
	}
	
	protected void setIsSet_inType(boolean value)
	{
		this.isSet_inType = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금형태", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String inType  = null;
	
	/**
	 * @Description 입금형태
	 */
	public java.lang.String getInType(){
		return inType;
	}
	
	/**
	 * @Description 입금형태
	 */
	@JsonProperty("inType")
	public void setInType( java.lang.String inType ) {
		isSet_inType = true;
		this.inType = inType;
	}
	
	/** Property set << inType >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << transYn >> [[ */
	
	@XmlTransient
	private boolean isSet_transYn = false;
	
	protected boolean isSet_transYn()
	{
		return this.isSet_transYn;
	}
	
	protected void setIsSet_transYn(boolean value)
	{
		this.isSet_transYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이체여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String transYn  = null;
	
	/**
	 * @Description 이체여부
	 */
	public java.lang.String getTransYn(){
		return transYn;
	}
	
	/**
	 * @Description 이체여부
	 */
	@JsonProperty("transYn")
	public void setTransYn( java.lang.String transYn ) {
		isSet_transYn = true;
		this.transYn = transYn;
	}
	
	/** Property set << transYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cardNo >> [[ */
	
	@XmlTransient
	private boolean isSet_cardNo = false;
	
	protected boolean isSet_cardNo()
	{
		return this.isSet_cardNo;
	}
	
	protected void setIsSet_cardNo(boolean value)
	{
		this.isSet_cardNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="카드번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String cardNo  = null;
	
	/**
	 * @Description 카드번호
	 */
	public java.lang.String getCardNo(){
		return cardNo;
	}
	
	/**
	 * @Description 카드번호
	 */
	@JsonProperty("cardNo")
	public void setCardNo( java.lang.String cardNo ) {
		isSet_cardNo = true;
		this.cardNo = cardNo;
	}
	
	/** Property set << cardNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modYn >> [[ */
	
	@XmlTransient
	private boolean isSet_modYn = false;
	
	protected boolean isSet_modYn()
	{
		return this.isSet_modYn;
	}
	
	protected void setIsSet_modYn(boolean value)
	{
		this.isSet_modYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="조정여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String modYn  = null;
	
	/**
	 * @Description 조정여부
	 */
	public java.lang.String getModYn(){
		return modYn;
	}
	
	/**
	 * @Description 조정여부
	 */
	@JsonProperty("modYn")
	public void setModYn( java.lang.String modYn ) {
		isSet_modYn = true;
		this.modYn = modYn;
	}
	
	/** Property set << modYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modDelayAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_modDelayAmt = false;
	
	protected boolean isSet_modDelayAmt()
	{
		return this.isSet_modDelayAmt;
	}
	
	protected void setIsSet_modDelayAmt(boolean value)
	{
		this.isSet_modDelayAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 조정연체료
	 */
	public void setModDelayAmt(java.lang.String value) {
		isSet_modDelayAmt = true;
		this.modDelayAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 조정연체료
	 */
	public void setModDelayAmt(double value) {
		isSet_modDelayAmt = true;
		this.modDelayAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 조정연체료
	 */
	public void setModDelayAmt(long value) {
		isSet_modDelayAmt = true;
		this.modDelayAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="조정연체료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal modDelayAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 조정연체료
	 */
	public java.math.BigDecimal getModDelayAmt(){
		return modDelayAmt;
	}
	
	/**
	 * @Description 조정연체료
	 */
	@JsonProperty("modDelayAmt")
	public void setModDelayAmt( java.math.BigDecimal modDelayAmt ) {
		isSet_modDelayAmt = true;
		this.modDelayAmt = modDelayAmt;
	}
	
	/** Property set << modDelayAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modDiscAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_modDiscAmt = false;
	
	protected boolean isSet_modDiscAmt()
	{
		return this.isSet_modDiscAmt;
	}
	
	protected void setIsSet_modDiscAmt(boolean value)
	{
		this.isSet_modDiscAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 조정할인료
	 */
	public void setModDiscAmt(java.lang.String value) {
		isSet_modDiscAmt = true;
		this.modDiscAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 조정할인료
	 */
	public void setModDiscAmt(double value) {
		isSet_modDiscAmt = true;
		this.modDiscAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 조정할인료
	 */
	public void setModDiscAmt(long value) {
		isSet_modDiscAmt = true;
		this.modDiscAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="조정할인료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal modDiscAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 조정할인료
	 */
	public java.math.BigDecimal getModDiscAmt(){
		return modDiscAmt;
	}
	
	/**
	 * @Description 조정할인료
	 */
	@JsonProperty("modDiscAmt")
	public void setModDiscAmt( java.math.BigDecimal modDiscAmt ) {
		isSet_modDiscAmt = true;
		this.modDiscAmt = modDiscAmt;
	}
	
	/** Property set << modDiscAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 변경담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 변경담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 변경일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 변경일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vdepositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_vdepositNo = false;
	
	protected boolean isSet_vdepositNo()
	{
		return this.isSet_vdepositNo;
	}
	
	protected void setIsSet_vdepositNo(boolean value)
	{
		this.isSet_vdepositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String vdepositNo  = null;
	
	/**
	 * @Description 가상계좌
	 */
	public java.lang.String getVdepositNo(){
		return vdepositNo;
	}
	
	/**
	 * @Description 가상계좌
	 */
	@JsonProperty("vdepositNo")
	public void setVdepositNo( java.lang.String vdepositNo ) {
		isSet_vdepositNo = true;
		this.vdepositNo = vdepositNo;
	}
	
	/** Property set << vdepositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outDt >> [[ */
	
	@XmlTransient
	private boolean isSet_outDt = false;
	
	protected boolean isSet_outDt()
	{
		return this.isSet_outDt;
	}
	
	protected void setIsSet_outDt(boolean value)
	{
		this.isSet_outDt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String outDt  = null;
	
	/**
	 * @Description 외부입력일자
	 */
	public java.lang.String getOutDt(){
		return outDt;
	}
	
	/**
	 * @Description 외부입력일자
	 */
	@JsonProperty("outDt")
	public void setOutDt( java.lang.String outDt ) {
		isSet_outDt = true;
		this.outDt = outDt;
	}
	
	/** Property set << outDt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outTm >> [[ */
	
	@XmlTransient
	private boolean isSet_outTm = false;
	
	protected boolean isSet_outTm()
	{
		return this.isSet_outTm;
	}
	
	protected void setIsSet_outTm(boolean value)
	{
		this.isSet_outTm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력시간", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String outTm  = null;
	
	/**
	 * @Description 외부입력시간
	 */
	public java.lang.String getOutTm(){
		return outTm;
	}
	
	/**
	 * @Description 외부입력시간
	 */
	@JsonProperty("outTm")
	public void setOutTm( java.lang.String outTm ) {
		isSet_outTm = true;
		this.outTm = outTm;
	}
	
	/** Property set << outTm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_outSeq = false;
	
	protected boolean isSet_outSeq()
	{
		return this.isSet_outSeq;
	}
	
	protected void setIsSet_outSeq(boolean value)
	{
		this.isSet_outSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float outSeq  = .0F;
	
	/**
	 * @Description 외부입력순번
	 */
	public java.lang.Float getOutSeq(){
		return outSeq;
	}
	
	/**
	 * @Description 외부입력순번
	 */
	@JsonProperty("outSeq")
	public void setOutSeq( java.lang.Float outSeq ) {
		isSet_outSeq = true;
		this.outSeq = outSeq;
	}
	
	/** Property set << outSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outBank >> [[ */
	
	@XmlTransient
	private boolean isSet_outBank = false;
	
	protected boolean isSet_outBank()
	{
		return this.isSet_outBank;
	}
	
	protected void setIsSet_outBank(boolean value)
	{
		this.isSet_outBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력은행", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String outBank  = null;
	
	/**
	 * @Description 외부입력은행
	 */
	public java.lang.String getOutBank(){
		return outBank;
	}
	
	/**
	 * @Description 외부입력은행
	 */
	@JsonProperty("outBank")
	public void setOutBank( java.lang.String outBank ) {
		isSet_outBank = true;
		this.outBank = outBank;
	}
	
	/** Property set << outBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentGurtIncomeDailyAdj01IO clone(){
		try{
			DHDRentGurtIncomeDailyAdj01IO object= (DHDRentGurtIncomeDailyAdj01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.inDate== null ) object.inDate = null;
			else{
				object.inDate = this.inDate;
			}
			if ( this.inSeq== null ) object.inSeq = null;
			else{
				object.inSeq = new java.math.BigDecimal(inSeq.toString());
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.inAmt== null ) object.inAmt = null;
			else{
				object.inAmt = new java.math.BigDecimal(inAmt.toString());
			}
			if ( this.inGubun== null ) object.inGubun = null;
			else{
				object.inGubun = this.inGubun;
			}
			if ( this.inType== null ) object.inType = null;
			else{
				object.inType = this.inType;
			}
			if ( this.transYn== null ) object.transYn = null;
			else{
				object.transYn = this.transYn;
			}
			if ( this.cardNo== null ) object.cardNo = null;
			else{
				object.cardNo = this.cardNo;
			}
			if ( this.modYn== null ) object.modYn = null;
			else{
				object.modYn = this.modYn;
			}
			if ( this.modDelayAmt== null ) object.modDelayAmt = null;
			else{
				object.modDelayAmt = new java.math.BigDecimal(modDelayAmt.toString());
			}
			if ( this.modDiscAmt== null ) object.modDiscAmt = null;
			else{
				object.modDiscAmt = new java.math.BigDecimal(modDiscAmt.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.vdepositNo== null ) object.vdepositNo = null;
			else{
				object.vdepositNo = this.vdepositNo;
			}
			if ( this.outDt== null ) object.outDt = null;
			else{
				object.outDt = this.outDt;
			}
			if ( this.outTm== null ) object.outTm = null;
			else{
				object.outTm = this.outTm;
			}
			if ( this.outSeq== null ) object.outSeq = null;
			else{
				object.outSeq = this.outSeq;
			}
			if ( this.outBank== null ) object.outBank = null;
			else{
				object.outBank = this.outBank;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((inDate==null)?0:inDate.hashCode());
		result = prime * result + ((inSeq==null)?0:inSeq.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((inAmt==null)?0:inAmt.hashCode());
		result = prime * result + ((inGubun==null)?0:inGubun.hashCode());
		result = prime * result + ((inType==null)?0:inType.hashCode());
		result = prime * result + ((transYn==null)?0:transYn.hashCode());
		result = prime * result + ((cardNo==null)?0:cardNo.hashCode());
		result = prime * result + ((modYn==null)?0:modYn.hashCode());
		result = prime * result + ((modDelayAmt==null)?0:modDelayAmt.hashCode());
		result = prime * result + ((modDiscAmt==null)?0:modDiscAmt.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((vdepositNo==null)?0:vdepositNo.hashCode());
		result = prime * result + ((outDt==null)?0:outDt.hashCode());
		result = prime * result + ((outTm==null)?0:outTm.hashCode());
		result = prime * result + ((outSeq==null)?0:outSeq.hashCode());
		result = prime * result + ((outBank==null)?0:outBank.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO other = (kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( inDate == null ){
			if ( other.inDate != null ) return false;
		}
		else if ( !inDate.equals(other.inDate) )
			return false;
		if ( inSeq == null ){
			if ( other.inSeq != null ) return false;
		}
		else if ( !inSeq.equals(other.inSeq) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( inAmt == null ){
			if ( other.inAmt != null ) return false;
		}
		else if ( !inAmt.equals(other.inAmt) )
			return false;
		if ( inGubun == null ){
			if ( other.inGubun != null ) return false;
		}
		else if ( !inGubun.equals(other.inGubun) )
			return false;
		if ( inType == null ){
			if ( other.inType != null ) return false;
		}
		else if ( !inType.equals(other.inType) )
			return false;
		if ( transYn == null ){
			if ( other.transYn != null ) return false;
		}
		else if ( !transYn.equals(other.transYn) )
			return false;
		if ( cardNo == null ){
			if ( other.cardNo != null ) return false;
		}
		else if ( !cardNo.equals(other.cardNo) )
			return false;
		if ( modYn == null ){
			if ( other.modYn != null ) return false;
		}
		else if ( !modYn.equals(other.modYn) )
			return false;
		if ( modDelayAmt == null ){
			if ( other.modDelayAmt != null ) return false;
		}
		else if ( !modDelayAmt.equals(other.modDelayAmt) )
			return false;
		if ( modDiscAmt == null ){
			if ( other.modDiscAmt != null ) return false;
		}
		else if ( !modDiscAmt.equals(other.modDiscAmt) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( vdepositNo == null ){
			if ( other.vdepositNo != null ) return false;
		}
		else if ( !vdepositNo.equals(other.vdepositNo) )
			return false;
		if ( outDt == null ){
			if ( other.outDt != null ) return false;
		}
		else if ( !outDt.equals(other.outDt) )
			return false;
		if ( outTm == null ){
			if ( other.outTm != null ) return false;
		}
		else if ( !outTm.equals(other.outTm) )
			return false;
		if ( outSeq == null ){
			if ( other.outSeq != null ) return false;
		}
		else if ( !outSeq.equals(other.outSeq) )
			return false;
		if ( outBank == null ){
			if ( other.outBank != null ) return false;
		}
		else if ( !outBank.equals(other.outBank) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tinDate: ");
		sb.append(inDate==null?"null":getInDate());
		sb.append("\n");
		sb.append("\tinSeq: ");
		sb.append(inSeq==null?"null":getInSeq());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\tinAmt: ");
		sb.append(inAmt==null?"null":getInAmt());
		sb.append("\n");
		sb.append("\tinGubun: ");
		sb.append(inGubun==null?"null":getInGubun());
		sb.append("\n");
		sb.append("\tinType: ");
		sb.append(inType==null?"null":getInType());
		sb.append("\n");
		sb.append("\ttransYn: ");
		sb.append(transYn==null?"null":getTransYn());
		sb.append("\n");
		sb.append("\tcardNo: ");
		sb.append(cardNo==null?"null":getCardNo());
		sb.append("\n");
		sb.append("\tmodYn: ");
		sb.append(modYn==null?"null":getModYn());
		sb.append("\n");
		sb.append("\tmodDelayAmt: ");
		sb.append(modDelayAmt==null?"null":getModDelayAmt());
		sb.append("\n");
		sb.append("\tmodDiscAmt: ");
		sb.append(modDiscAmt==null?"null":getModDiscAmt());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tvdepositNo: ");
		sb.append(vdepositNo==null?"null":getVdepositNo());
		sb.append("\n");
		sb.append("\toutDt: ");
		sb.append(outDt==null?"null":getOutDt());
		sb.append("\n");
		sb.append("\toutTm: ");
		sb.append(outTm==null?"null":getOutTm());
		sb.append("\n");
		sb.append("\toutSeq: ");
		sb.append(outSeq==null?"null":getOutSeq());
		sb.append("\n");
		sb.append("\toutBank: ");
		sb.append(outBank==null?"null":getOutBank());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 8; /* inDate */
		messageLen+= 22; /* inSeq */
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 30; /* depositNo */
		messageLen+= 22; /* inAmt */
		messageLen+= 2; /* inGubun */
		messageLen+= 2; /* inType */
		messageLen+= 1; /* transYn */
		messageLen+= 20; /* cardNo */
		messageLen+= 1; /* modYn */
		messageLen+= 22; /* modDelayAmt */
		messageLen+= 22; /* modDiscAmt */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 30; /* vdepositNo */
		messageLen+= 8; /* outDt */
		messageLen+= 6; /* outTm */
		messageLen+= 22; /* outSeq */
		messageLen+= 6; /* outBank */
		messageLen+= 200; /* remark */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("inDate");
	
		fieldNames.add("inSeq");
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("inAmt");
	
		fieldNames.add("inGubun");
	
		fieldNames.add("inType");
	
		fieldNames.add("transYn");
	
		fieldNames.add("cardNo");
	
		fieldNames.add("modYn");
	
		fieldNames.add("modDelayAmt");
	
		fieldNames.add("modDiscAmt");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("vdepositNo");
	
		fieldNames.add("outDt");
	
		fieldNames.add("outTm");
	
		fieldNames.add("outSeq");
	
		fieldNames.add("outBank");
	
		fieldNames.add("remark");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("inDate", get("inDate"));
	
		fieldValueMap.put("inSeq", get("inSeq"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("inAmt", get("inAmt"));
	
		fieldValueMap.put("inGubun", get("inGubun"));
	
		fieldValueMap.put("inType", get("inType"));
	
		fieldValueMap.put("transYn", get("transYn"));
	
		fieldValueMap.put("cardNo", get("cardNo"));
	
		fieldValueMap.put("modYn", get("modYn"));
	
		fieldValueMap.put("modDelayAmt", get("modDelayAmt"));
	
		fieldValueMap.put("modDiscAmt", get("modDiscAmt"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("vdepositNo", get("vdepositNo"));
	
		fieldValueMap.put("outDt", get("outDt"));
	
		fieldValueMap.put("outTm", get("outTm"));
	
		fieldValueMap.put("outSeq", get("outSeq"));
	
		fieldValueMap.put("outBank", get("outBank"));
	
		fieldValueMap.put("remark", get("remark"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -1185196429 : /* inDate */
			return getInDate();
		case 100329722 : /* inSeq */
			return getInSeq();
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 100312675 : /* inAmt */
			return getInAmt();
		case 1916966056 : /* inGubun */
			return getInGubun();
		case -1184696833 : /* inType */
			return getInType();
		case -1067060259 : /* transYn */
			return getTransYn();
		case -1367605007 : /* cardNo */
			return getCardNo();
		case 104069559 : /* modYn */
			return getModYn();
		case 1886592615 : /* modDelayAmt */
			return getModDelayAmt();
		case -1480721775 : /* modDiscAmt */
			return getModDiscAmt();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 1763054921 : /* vdepositNo */
			return getVdepositNo();
		case 106110078 : /* outDt */
			return getOutDt();
		case 106110567 : /* outTm */
			return getOutTm();
		case -1005540815 : /* outSeq */
			return getOutSeq();
		case -1107504470 : /* outBank */
			return getOutBank();
		case -934624384 : /* remark */
			return getRemark();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -1185196429 : /* inDate */
			setInDate((java.lang.String) value);
			return;
		case 100329722 : /* inSeq */
			setInSeq((java.math.BigDecimal) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 100312675 : /* inAmt */
			setInAmt((java.math.BigDecimal) value);
			return;
		case 1916966056 : /* inGubun */
			setInGubun((java.lang.String) value);
			return;
		case -1184696833 : /* inType */
			setInType((java.lang.String) value);
			return;
		case -1067060259 : /* transYn */
			setTransYn((java.lang.String) value);
			return;
		case -1367605007 : /* cardNo */
			setCardNo((java.lang.String) value);
			return;
		case 104069559 : /* modYn */
			setModYn((java.lang.String) value);
			return;
		case 1886592615 : /* modDelayAmt */
			setModDelayAmt((java.math.BigDecimal) value);
			return;
		case -1480721775 : /* modDiscAmt */
			setModDiscAmt((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 1763054921 : /* vdepositNo */
			setVdepositNo((java.lang.String) value);
			return;
		case 106110078 : /* outDt */
			setOutDt((java.lang.String) value);
			return;
		case 106110567 : /* outTm */
			setOutTm((java.lang.String) value);
			return;
		case -1005540815 : /* outSeq */
			setOutSeq((java.lang.Float) value);
			return;
		case -1107504470 : /* outBank */
			setOutBank((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
