/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_임대료변경내역 ( HD_RENT_DETAIL_RENT )
 */
@XmlType(propOrder={"custCode", "seq", "rentChgSeq", "applyYymm", "rentSupply", "rentVat", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "rentIns"}, name="DHDRentDetailRent01IO")
@XmlRootElement(name="DHDRentDetailRent01IO")
@SuppressWarnings("all")
public class DHDRentDetailRent01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 588430894L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_임대료변경내역 ( HD_RENT_DETAIL_RENT )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012603(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012603(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012603(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012604(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012604(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012604(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012604(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012604(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012604(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_rentChgSeq = false;
	
	protected boolean isSet_rentChgSeq()
	{
		return this.isSet_rentChgSeq;
	}
	
	protected void setIsSet_rentChgSeq(boolean value)
	{
		this.isSet_rentChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료변경차수 [SYS_C0012605(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public void setRentChgSeq(java.lang.String value) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료변경차수 [SYS_C0012605(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public void setRentChgSeq(double value) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료변경차수 [SYS_C0012605(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public void setRentChgSeq(long value) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료변경차수 [SYS_C0012605(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료변경차수 [SYS_C0012605(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	public java.math.BigDecimal getRentChgSeq(){
		return rentChgSeq;
	}
	
	/**
	 * @Description 임대료변경차수 [SYS_C0012605(C),SYS_C0012987(P) SYS_C0012987(UNIQUE)]
	 */
	@JsonProperty("rentChgSeq")
	public void setRentChgSeq( java.math.BigDecimal rentChgSeq ) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = rentChgSeq;
	}
	
	/** Property set << rentChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << applyYymm >> [[ */
	
	@XmlTransient
	private boolean isSet_applyYymm = false;
	
	protected boolean isSet_applyYymm()
	{
		return this.isSet_applyYymm;
	}
	
	protected void setIsSet_applyYymm(boolean value)
	{
		this.isSet_applyYymm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="적용시작년월", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String applyYymm  = null;
	
	/**
	 * @Description 적용시작년월
	 */
	public java.lang.String getApplyYymm(){
		return applyYymm;
	}
	
	/**
	 * @Description 적용시작년월
	 */
	@JsonProperty("applyYymm")
	public void setApplyYymm( java.lang.String applyYymm ) {
		isSet_applyYymm = true;
		this.applyYymm = applyYymm;
	}
	
	/** Property set << applyYymm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentSupply >> [[ */
	
	@XmlTransient
	private boolean isSet_rentSupply = false;
	
	protected boolean isSet_rentSupply()
	{
		return this.isSet_rentSupply;
	}
	
	protected void setIsSet_rentSupply(boolean value)
	{
		this.isSet_rentSupply = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(java.lang.String value) {
		isSet_rentSupply = true;
		this.rentSupply = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(double value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(long value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료공급가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentSupply  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료공급가
	 */
	public java.math.BigDecimal getRentSupply(){
		return rentSupply;
	}
	
	/**
	 * @Description 임대료공급가
	 */
	@JsonProperty("rentSupply")
	public void setRentSupply( java.math.BigDecimal rentSupply ) {
		isSet_rentSupply = true;
		this.rentSupply = rentSupply;
	}
	
	/** Property set << rentSupply >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentVat >> [[ */
	
	@XmlTransient
	private boolean isSet_rentVat = false;
	
	protected boolean isSet_rentVat()
	{
		return this.isSet_rentVat;
	}
	
	protected void setIsSet_rentVat(boolean value)
	{
		this.isSet_rentVat = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(java.lang.String value) {
		isSet_rentVat = true;
		this.rentVat = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(double value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(long value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료부가세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentVat  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료부가세
	 */
	public java.math.BigDecimal getRentVat(){
		return rentVat;
	}
	
	/**
	 * @Description 임대료부가세
	 */
	@JsonProperty("rentVat")
	public void setRentVat( java.math.BigDecimal rentVat ) {
		isSet_rentVat = true;
		this.rentVat = rentVat;
	}
	
	/** Property set << rentVat >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentIns >> [[ */
	
	@XmlTransient
	private boolean isSet_rentIns = false;
	
	protected boolean isSet_rentIns()
	{
		return this.isSet_rentIns;
	}
	
	protected void setIsSet_rentIns(boolean value)
	{
		this.isSet_rentIns = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(java.lang.String value) {
		isSet_rentIns = true;
		this.rentIns = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(double value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(long value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료보증보험료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentIns  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료보증보험료
	 */
	public java.math.BigDecimal getRentIns(){
		return rentIns;
	}
	
	/**
	 * @Description 임대료보증보험료
	 */
	@JsonProperty("rentIns")
	public void setRentIns( java.math.BigDecimal rentIns ) {
		isSet_rentIns = true;
		this.rentIns = rentIns;
	}
	
	/** Property set << rentIns >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentDetailRent01IO clone(){
		try{
			DHDRentDetailRent01IO object= (DHDRentDetailRent01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.rentChgSeq== null ) object.rentChgSeq = null;
			else{
				object.rentChgSeq = new java.math.BigDecimal(rentChgSeq.toString());
			}
			if ( this.applyYymm== null ) object.applyYymm = null;
			else{
				object.applyYymm = this.applyYymm;
			}
			if ( this.rentSupply== null ) object.rentSupply = null;
			else{
				object.rentSupply = new java.math.BigDecimal(rentSupply.toString());
			}
			if ( this.rentVat== null ) object.rentVat = null;
			else{
				object.rentVat = new java.math.BigDecimal(rentVat.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.rentIns== null ) object.rentIns = null;
			else{
				object.rentIns = new java.math.BigDecimal(rentIns.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((rentChgSeq==null)?0:rentChgSeq.hashCode());
		result = prime * result + ((applyYymm==null)?0:applyYymm.hashCode());
		result = prime * result + ((rentSupply==null)?0:rentSupply.hashCode());
		result = prime * result + ((rentVat==null)?0:rentVat.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((rentIns==null)?0:rentIns.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentDetailRent01IO other = (kait.hd.rent.onl.dao.dto.DHDRentDetailRent01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( rentChgSeq == null ){
			if ( other.rentChgSeq != null ) return false;
		}
		else if ( !rentChgSeq.equals(other.rentChgSeq) )
			return false;
		if ( applyYymm == null ){
			if ( other.applyYymm != null ) return false;
		}
		else if ( !applyYymm.equals(other.applyYymm) )
			return false;
		if ( rentSupply == null ){
			if ( other.rentSupply != null ) return false;
		}
		else if ( !rentSupply.equals(other.rentSupply) )
			return false;
		if ( rentVat == null ){
			if ( other.rentVat != null ) return false;
		}
		else if ( !rentVat.equals(other.rentVat) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( rentIns == null ){
			if ( other.rentIns != null ) return false;
		}
		else if ( !rentIns.equals(other.rentIns) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentDetailRent01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\trentChgSeq: ");
		sb.append(rentChgSeq==null?"null":getRentChgSeq());
		sb.append("\n");
		sb.append("\tapplyYymm: ");
		sb.append(applyYymm==null?"null":getApplyYymm());
		sb.append("\n");
		sb.append("\trentSupply: ");
		sb.append(rentSupply==null?"null":getRentSupply());
		sb.append("\n");
		sb.append("\trentVat: ");
		sb.append(rentVat==null?"null":getRentVat());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\trentIns: ");
		sb.append(rentIns==null?"null":getRentIns());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* rentChgSeq */
		messageLen+= 8; /* applyYymm */
		messageLen+= 22; /* rentSupply */
		messageLen+= 22; /* rentVat */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* rentIns */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("rentChgSeq");
	
		fieldNames.add("applyYymm");
	
		fieldNames.add("rentSupply");
	
		fieldNames.add("rentVat");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("rentIns");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("rentChgSeq", get("rentChgSeq"));
	
		fieldValueMap.put("applyYymm", get("applyYymm"));
	
		fieldValueMap.put("rentSupply", get("rentSupply"));
	
		fieldValueMap.put("rentVat", get("rentVat"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("rentIns", get("rentIns"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 1527161078 : /* rentChgSeq */
			return getRentChgSeq();
		case -2075499186 : /* applyYymm */
			return getApplyYymm();
		case 1997529480 : /* rentSupply */
			return getRentSupply();
		case 1092877616 : /* rentVat */
			return getRentVat();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 1092865525 : /* rentIns */
			return getRentIns();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1527161078 : /* rentChgSeq */
			setRentChgSeq((java.math.BigDecimal) value);
			return;
		case -2075499186 : /* applyYymm */
			setApplyYymm((java.lang.String) value);
			return;
		case 1997529480 : /* rentSupply */
			setRentSupply((java.math.BigDecimal) value);
			return;
		case 1092877616 : /* rentVat */
			setRentVat((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 1092865525 : /* rentIns */
			setRentIns((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
