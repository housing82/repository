/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_임대기간변경내역 ( HD_RENT_DETAIL_TERM )
 */
@XmlType(propOrder={"custCode", "seq", "termChgSeq", "applyDate", "rentSdate", "rentEdate", "vatYn", "guaranteeAmt", "rentSupply", "rentVat", "agreeDd", "agreeMmTag", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "rentIns", "remark", "changecontdt"}, name="DHDRentDetailTerm01IO")
@XmlRootElement(name="DHDRentDetailTerm01IO")
@SuppressWarnings("all")
public class DHDRentDetailTerm01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -112863775L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_임대기간변경내역 ( HD_RENT_DETAIL_TERM )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012606(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012606(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012606(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012607(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012607(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012607(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012607(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012607(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012607(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << termChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_termChgSeq = false;
	
	protected boolean isSet_termChgSeq()
	{
		return this.isSet_termChgSeq;
	}
	
	protected void setIsSet_termChgSeq(boolean value)
	{
		this.isSet_termChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약차수 [SYS_C0012608(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public void setTermChgSeq(java.lang.String value) {
		isSet_termChgSeq = true;
		this.termChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약차수 [SYS_C0012608(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public void setTermChgSeq(double value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약차수 [SYS_C0012608(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public void setTermChgSeq(long value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약차수 [SYS_C0012608(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal termChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약차수 [SYS_C0012608(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	public java.math.BigDecimal getTermChgSeq(){
		return termChgSeq;
	}
	
	/**
	 * @Description 계약차수 [SYS_C0012608(C),SYS_C0012988(P) SYS_C0012988(UNIQUE)]
	 */
	@JsonProperty("termChgSeq")
	public void setTermChgSeq( java.math.BigDecimal termChgSeq ) {
		isSet_termChgSeq = true;
		this.termChgSeq = termChgSeq;
	}
	
	/** Property set << termChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << applyDate >> [[ */
	
	@XmlTransient
	private boolean isSet_applyDate = false;
	
	protected boolean isSet_applyDate()
	{
		return this.isSet_applyDate;
	}
	
	protected void setIsSet_applyDate(boolean value)
	{
		this.isSet_applyDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="적용시작일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String applyDate  = null;
	
	/**
	 * @Description 적용시작일
	 */
	public java.lang.String getApplyDate(){
		return applyDate;
	}
	
	/**
	 * @Description 적용시작일
	 */
	@JsonProperty("applyDate")
	public void setApplyDate( java.lang.String applyDate ) {
		isSet_applyDate = true;
		this.applyDate = applyDate;
	}
	
	/** Property set << applyDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_rentSdate = false;
	
	protected boolean isSet_rentSdate()
	{
		return this.isSet_rentSdate;
	}
	
	protected void setIsSet_rentSdate(boolean value)
	{
		this.isSet_rentSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대시작일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String rentSdate  = null;
	
	/**
	 * @Description 임대시작일
	 */
	public java.lang.String getRentSdate(){
		return rentSdate;
	}
	
	/**
	 * @Description 임대시작일
	 */
	@JsonProperty("rentSdate")
	public void setRentSdate( java.lang.String rentSdate ) {
		isSet_rentSdate = true;
		this.rentSdate = rentSdate;
	}
	
	/** Property set << rentSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentEdate >> [[ */
	
	@XmlTransient
	private boolean isSet_rentEdate = false;
	
	protected boolean isSet_rentEdate()
	{
		return this.isSet_rentEdate;
	}
	
	protected void setIsSet_rentEdate(boolean value)
	{
		this.isSet_rentEdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대종료일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String rentEdate  = null;
	
	/**
	 * @Description 임대종료일
	 */
	public java.lang.String getRentEdate(){
		return rentEdate;
	}
	
	/**
	 * @Description 임대종료일
	 */
	@JsonProperty("rentEdate")
	public void setRentEdate( java.lang.String rentEdate ) {
		isSet_rentEdate = true;
		this.rentEdate = rentEdate;
	}
	
	/** Property set << rentEdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatYn >> [[ */
	
	@XmlTransient
	private boolean isSet_vatYn = false;
	
	protected boolean isSet_vatYn()
	{
		return this.isSet_vatYn;
	}
	
	protected void setIsSet_vatYn(boolean value)
	{
		this.isSet_vatYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String vatYn  = null;
	
	/**
	 * @Description 부가세여부
	 */
	public java.lang.String getVatYn(){
		return vatYn;
	}
	
	/**
	 * @Description 부가세여부
	 */
	@JsonProperty("vatYn")
	public void setVatYn( java.lang.String vatYn ) {
		isSet_vatYn = true;
		this.vatYn = vatYn;
	}
	
	/** Property set << vatYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << guaranteeAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_guaranteeAmt = false;
	
	protected boolean isSet_guaranteeAmt()
	{
		return this.isSet_guaranteeAmt;
	}
	
	protected void setIsSet_guaranteeAmt(boolean value)
	{
		this.isSet_guaranteeAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대보증금
	 */
	public void setGuaranteeAmt(java.lang.String value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대보증금
	 */
	public void setGuaranteeAmt(double value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대보증금
	 */
	public void setGuaranteeAmt(long value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대보증금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal guaranteeAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대보증금
	 */
	public java.math.BigDecimal getGuaranteeAmt(){
		return guaranteeAmt;
	}
	
	/**
	 * @Description 임대보증금
	 */
	@JsonProperty("guaranteeAmt")
	public void setGuaranteeAmt( java.math.BigDecimal guaranteeAmt ) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = guaranteeAmt;
	}
	
	/** Property set << guaranteeAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentSupply >> [[ */
	
	@XmlTransient
	private boolean isSet_rentSupply = false;
	
	protected boolean isSet_rentSupply()
	{
		return this.isSet_rentSupply;
	}
	
	protected void setIsSet_rentSupply(boolean value)
	{
		this.isSet_rentSupply = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(java.lang.String value) {
		isSet_rentSupply = true;
		this.rentSupply = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(double value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(long value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료공급가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentSupply  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료공급가
	 */
	public java.math.BigDecimal getRentSupply(){
		return rentSupply;
	}
	
	/**
	 * @Description 임대료공급가
	 */
	@JsonProperty("rentSupply")
	public void setRentSupply( java.math.BigDecimal rentSupply ) {
		isSet_rentSupply = true;
		this.rentSupply = rentSupply;
	}
	
	/** Property set << rentSupply >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentVat >> [[ */
	
	@XmlTransient
	private boolean isSet_rentVat = false;
	
	protected boolean isSet_rentVat()
	{
		return this.isSet_rentVat;
	}
	
	protected void setIsSet_rentVat(boolean value)
	{
		this.isSet_rentVat = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(java.lang.String value) {
		isSet_rentVat = true;
		this.rentVat = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(double value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(long value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료부가세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentVat  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료부가세
	 */
	public java.math.BigDecimal getRentVat(){
		return rentVat;
	}
	
	/**
	 * @Description 임대료부가세
	 */
	@JsonProperty("rentVat")
	public void setRentVat( java.math.BigDecimal rentVat ) {
		isSet_rentVat = true;
		this.rentVat = rentVat;
	}
	
	/** Property set << rentVat >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeDd >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeDd = false;
	
	protected boolean isSet_agreeDd()
	{
		return this.isSet_agreeDd;
	}
	
	protected void setIsSet_agreeDd(boolean value)
	{
		this.isSet_agreeDd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정생성일", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeDd  = null;
	
	/**
	 * @Description 약정생성일
	 */
	public java.lang.String getAgreeDd(){
		return agreeDd;
	}
	
	/**
	 * @Description 약정생성일
	 */
	@JsonProperty("agreeDd")
	public void setAgreeDd( java.lang.String agreeDd ) {
		isSet_agreeDd = true;
		this.agreeDd = agreeDd;
	}
	
	/** Property set << agreeDd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeMmTag >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeMmTag = false;
	
	protected boolean isSet_agreeMmTag()
	{
		return this.isSet_agreeMmTag;
	}
	
	protected void setIsSet_agreeMmTag(boolean value)
	{
		this.isSet_agreeMmTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정생성월구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeMmTag  = null;
	
	/**
	 * @Description 약정생성월구분
	 */
	public java.lang.String getAgreeMmTag(){
		return agreeMmTag;
	}
	
	/**
	 * @Description 약정생성월구분
	 */
	@JsonProperty("agreeMmTag")
	public void setAgreeMmTag( java.lang.String agreeMmTag ) {
		isSet_agreeMmTag = true;
		this.agreeMmTag = agreeMmTag;
	}
	
	/** Property set << agreeMmTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentIns >> [[ */
	
	@XmlTransient
	private boolean isSet_rentIns = false;
	
	protected boolean isSet_rentIns()
	{
		return this.isSet_rentIns;
	}
	
	protected void setIsSet_rentIns(boolean value)
	{
		this.isSet_rentIns = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(java.lang.String value) {
		isSet_rentIns = true;
		this.rentIns = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(double value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(long value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료보증보험료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentIns  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료보증보험료
	 */
	public java.math.BigDecimal getRentIns(){
		return rentIns;
	}
	
	/**
	 * @Description 임대료보증보험료
	 */
	@JsonProperty("rentIns")
	public void setRentIns( java.math.BigDecimal rentIns ) {
		isSet_rentIns = true;
		this.rentIns = rentIns;
	}
	
	/** Property set << rentIns >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changecontdt >> [[ */
	
	@XmlTransient
	private boolean isSet_changecontdt = false;
	
	protected boolean isSet_changecontdt()
	{
		return this.isSet_changecontdt;
	}
	
	protected void setIsSet_changecontdt(boolean value)
	{
		this.isSet_changecontdt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String changecontdt  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChangecontdt(){
		return changecontdt;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("changecontdt")
	public void setChangecontdt( java.lang.String changecontdt ) {
		isSet_changecontdt = true;
		this.changecontdt = changecontdt;
	}
	
	/** Property set << changecontdt >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentDetailTerm01IO clone(){
		try{
			DHDRentDetailTerm01IO object= (DHDRentDetailTerm01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.termChgSeq== null ) object.termChgSeq = null;
			else{
				object.termChgSeq = new java.math.BigDecimal(termChgSeq.toString());
			}
			if ( this.applyDate== null ) object.applyDate = null;
			else{
				object.applyDate = this.applyDate;
			}
			if ( this.rentSdate== null ) object.rentSdate = null;
			else{
				object.rentSdate = this.rentSdate;
			}
			if ( this.rentEdate== null ) object.rentEdate = null;
			else{
				object.rentEdate = this.rentEdate;
			}
			if ( this.vatYn== null ) object.vatYn = null;
			else{
				object.vatYn = this.vatYn;
			}
			if ( this.guaranteeAmt== null ) object.guaranteeAmt = null;
			else{
				object.guaranteeAmt = new java.math.BigDecimal(guaranteeAmt.toString());
			}
			if ( this.rentSupply== null ) object.rentSupply = null;
			else{
				object.rentSupply = new java.math.BigDecimal(rentSupply.toString());
			}
			if ( this.rentVat== null ) object.rentVat = null;
			else{
				object.rentVat = new java.math.BigDecimal(rentVat.toString());
			}
			if ( this.agreeDd== null ) object.agreeDd = null;
			else{
				object.agreeDd = this.agreeDd;
			}
			if ( this.agreeMmTag== null ) object.agreeMmTag = null;
			else{
				object.agreeMmTag = this.agreeMmTag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.rentIns== null ) object.rentIns = null;
			else{
				object.rentIns = new java.math.BigDecimal(rentIns.toString());
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.changecontdt== null ) object.changecontdt = null;
			else{
				object.changecontdt = this.changecontdt;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((termChgSeq==null)?0:termChgSeq.hashCode());
		result = prime * result + ((applyDate==null)?0:applyDate.hashCode());
		result = prime * result + ((rentSdate==null)?0:rentSdate.hashCode());
		result = prime * result + ((rentEdate==null)?0:rentEdate.hashCode());
		result = prime * result + ((vatYn==null)?0:vatYn.hashCode());
		result = prime * result + ((guaranteeAmt==null)?0:guaranteeAmt.hashCode());
		result = prime * result + ((rentSupply==null)?0:rentSupply.hashCode());
		result = prime * result + ((rentVat==null)?0:rentVat.hashCode());
		result = prime * result + ((agreeDd==null)?0:agreeDd.hashCode());
		result = prime * result + ((agreeMmTag==null)?0:agreeMmTag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((rentIns==null)?0:rentIns.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((changecontdt==null)?0:changecontdt.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentDetailTerm01IO other = (kait.hd.rent.onl.dao.dto.DHDRentDetailTerm01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( termChgSeq == null ){
			if ( other.termChgSeq != null ) return false;
		}
		else if ( !termChgSeq.equals(other.termChgSeq) )
			return false;
		if ( applyDate == null ){
			if ( other.applyDate != null ) return false;
		}
		else if ( !applyDate.equals(other.applyDate) )
			return false;
		if ( rentSdate == null ){
			if ( other.rentSdate != null ) return false;
		}
		else if ( !rentSdate.equals(other.rentSdate) )
			return false;
		if ( rentEdate == null ){
			if ( other.rentEdate != null ) return false;
		}
		else if ( !rentEdate.equals(other.rentEdate) )
			return false;
		if ( vatYn == null ){
			if ( other.vatYn != null ) return false;
		}
		else if ( !vatYn.equals(other.vatYn) )
			return false;
		if ( guaranteeAmt == null ){
			if ( other.guaranteeAmt != null ) return false;
		}
		else if ( !guaranteeAmt.equals(other.guaranteeAmt) )
			return false;
		if ( rentSupply == null ){
			if ( other.rentSupply != null ) return false;
		}
		else if ( !rentSupply.equals(other.rentSupply) )
			return false;
		if ( rentVat == null ){
			if ( other.rentVat != null ) return false;
		}
		else if ( !rentVat.equals(other.rentVat) )
			return false;
		if ( agreeDd == null ){
			if ( other.agreeDd != null ) return false;
		}
		else if ( !agreeDd.equals(other.agreeDd) )
			return false;
		if ( agreeMmTag == null ){
			if ( other.agreeMmTag != null ) return false;
		}
		else if ( !agreeMmTag.equals(other.agreeMmTag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( rentIns == null ){
			if ( other.rentIns != null ) return false;
		}
		else if ( !rentIns.equals(other.rentIns) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( changecontdt == null ){
			if ( other.changecontdt != null ) return false;
		}
		else if ( !changecontdt.equals(other.changecontdt) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentDetailTerm01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\ttermChgSeq: ");
		sb.append(termChgSeq==null?"null":getTermChgSeq());
		sb.append("\n");
		sb.append("\tapplyDate: ");
		sb.append(applyDate==null?"null":getApplyDate());
		sb.append("\n");
		sb.append("\trentSdate: ");
		sb.append(rentSdate==null?"null":getRentSdate());
		sb.append("\n");
		sb.append("\trentEdate: ");
		sb.append(rentEdate==null?"null":getRentEdate());
		sb.append("\n");
		sb.append("\tvatYn: ");
		sb.append(vatYn==null?"null":getVatYn());
		sb.append("\n");
		sb.append("\tguaranteeAmt: ");
		sb.append(guaranteeAmt==null?"null":getGuaranteeAmt());
		sb.append("\n");
		sb.append("\trentSupply: ");
		sb.append(rentSupply==null?"null":getRentSupply());
		sb.append("\n");
		sb.append("\trentVat: ");
		sb.append(rentVat==null?"null":getRentVat());
		sb.append("\n");
		sb.append("\tagreeDd: ");
		sb.append(agreeDd==null?"null":getAgreeDd());
		sb.append("\n");
		sb.append("\tagreeMmTag: ");
		sb.append(agreeMmTag==null?"null":getAgreeMmTag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\trentIns: ");
		sb.append(rentIns==null?"null":getRentIns());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tchangecontdt: ");
		sb.append(changecontdt==null?"null":getChangecontdt());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* termChgSeq */
		messageLen+= 8; /* applyDate */
		messageLen+= 8; /* rentSdate */
		messageLen+= 8; /* rentEdate */
		messageLen+= 1; /* vatYn */
		messageLen+= 22; /* guaranteeAmt */
		messageLen+= 22; /* rentSupply */
		messageLen+= 22; /* rentVat */
		messageLen+= 2; /* agreeDd */
		messageLen+= 1; /* agreeMmTag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* rentIns */
		messageLen+= 200; /* remark */
		messageLen+= 8; /* changecontdt */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("termChgSeq");
	
		fieldNames.add("applyDate");
	
		fieldNames.add("rentSdate");
	
		fieldNames.add("rentEdate");
	
		fieldNames.add("vatYn");
	
		fieldNames.add("guaranteeAmt");
	
		fieldNames.add("rentSupply");
	
		fieldNames.add("rentVat");
	
		fieldNames.add("agreeDd");
	
		fieldNames.add("agreeMmTag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("rentIns");
	
		fieldNames.add("remark");
	
		fieldNames.add("changecontdt");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("termChgSeq", get("termChgSeq"));
	
		fieldValueMap.put("applyDate", get("applyDate"));
	
		fieldValueMap.put("rentSdate", get("rentSdate"));
	
		fieldValueMap.put("rentEdate", get("rentEdate"));
	
		fieldValueMap.put("vatYn", get("vatYn"));
	
		fieldValueMap.put("guaranteeAmt", get("guaranteeAmt"));
	
		fieldValueMap.put("rentSupply", get("rentSupply"));
	
		fieldValueMap.put("rentVat", get("rentVat"));
	
		fieldValueMap.put("agreeDd", get("agreeDd"));
	
		fieldValueMap.put("agreeMmTag", get("agreeMmTag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("rentIns", get("rentIns"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("changecontdt", get("changecontdt"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 1892849641 : /* termChgSeq */
			return getTermChgSeq();
		case -2076147652 : /* applyDate */
			return getApplyDate();
		case -2014294296 : /* rentSdate */
			return getRentSdate();
		case -2027223590 : /* rentEdate */
			return getRentEdate();
		case 111979550 : /* vatYn */
			return getVatYn();
		case -1640212960 : /* guaranteeAmt */
			return getGuaranteeAmt();
		case 1997529480 : /* rentSupply */
			return getRentSupply();
		case 1092877616 : /* rentVat */
			return getRentVat();
		case -1049264052 : /* agreeDd */
			return getAgreeDd();
		case 155270798 : /* agreeMmTag */
			return getAgreeMmTag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 1092865525 : /* rentIns */
			return getRentIns();
		case -934624384 : /* remark */
			return getRemark();
		case 361055986 : /* changecontdt */
			return getChangecontdt();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1892849641 : /* termChgSeq */
			setTermChgSeq((java.math.BigDecimal) value);
			return;
		case -2076147652 : /* applyDate */
			setApplyDate((java.lang.String) value);
			return;
		case -2014294296 : /* rentSdate */
			setRentSdate((java.lang.String) value);
			return;
		case -2027223590 : /* rentEdate */
			setRentEdate((java.lang.String) value);
			return;
		case 111979550 : /* vatYn */
			setVatYn((java.lang.String) value);
			return;
		case -1640212960 : /* guaranteeAmt */
			setGuaranteeAmt((java.math.BigDecimal) value);
			return;
		case 1997529480 : /* rentSupply */
			setRentSupply((java.math.BigDecimal) value);
			return;
		case 1092877616 : /* rentVat */
			setRentVat((java.math.BigDecimal) value);
			return;
		case -1049264052 : /* agreeDd */
			setAgreeDd((java.lang.String) value);
			return;
		case 155270798 : /* agreeMmTag */
			setAgreeMmTag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 1092865525 : /* rentIns */
			setRentIns((java.math.BigDecimal) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case 361055986 : /* changecontdt */
			setChangecontdt((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
