/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_지로발행 ( HD_RENT_GIRO )
 */
@XmlType(propOrder={"custCode", "seq", "giroTag", "billYm", "endDate", "makeDate", "jAmt", "jDamt", "dAmt", "dSamt", "dVamt", "dIamt", "amt", "giroNo", "custNo", "amtNo", "depositNo", "depositTag", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "jym1", "jymamt1", "jym2", "jymamt2", "jym3", "jymamt3", "printYn"}, name="DHDRentGiro01IO")
@XmlRootElement(name="DHDRentGiro01IO")
@SuppressWarnings("all")
public class DHDRentGiro01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -946050845L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_지로발행 ( HD_RENT_GIRO )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012620(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012620(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012620(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012621(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012621(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012621(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012621(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012621(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012621(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << giroTag >> [[ */
	
	@XmlTransient
	private boolean isSet_giroTag = false;
	
	protected boolean isSet_giroTag()
	{
		return this.isSet_giroTag;
	}
	
	protected void setIsSet_giroTag(boolean value)
	{
		this.isSet_giroTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="지로구분 [SYS_C0012622(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String giroTag  = null;
	
	/**
	 * @Description 지로구분 [SYS_C0012622(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public java.lang.String getGiroTag(){
		return giroTag;
	}
	
	/**
	 * @Description 지로구분 [SYS_C0012622(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	@JsonProperty("giroTag")
	public void setGiroTag( java.lang.String giroTag ) {
		isSet_giroTag = true;
		this.giroTag = giroTag;
	}
	
	/** Property set << giroTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << billYm >> [[ */
	
	@XmlTransient
	private boolean isSet_billYm = false;
	
	protected boolean isSet_billYm()
	{
		return this.isSet_billYm;
	}
	
	protected void setIsSet_billYm(boolean value)
	{
		this.isSet_billYm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="발행년월 [SYS_C0012623(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String billYm  = null;
	
	/**
	 * @Description 발행년월 [SYS_C0012623(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	public java.lang.String getBillYm(){
		return billYm;
	}
	
	/**
	 * @Description 발행년월 [SYS_C0012623(C),SYS_C0012992(P) SYS_C0012992(UNIQUE)]
	 */
	@JsonProperty("billYm")
	public void setBillYm( java.lang.String billYm ) {
		isSet_billYm = true;
		this.billYm = billYm;
	}
	
	/** Property set << billYm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endDate >> [[ */
	
	@XmlTransient
	private boolean isSet_endDate = false;
	
	protected boolean isSet_endDate()
	{
		return this.isSet_endDate;
	}
	
	protected void setIsSet_endDate(boolean value)
	{
		this.isSet_endDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String endDate  = null;
	
	/**
	 * @Description 납입일자
	 */
	public java.lang.String getEndDate(){
		return endDate;
	}
	
	/**
	 * @Description 납입일자
	 */
	@JsonProperty("endDate")
	public void setEndDate( java.lang.String endDate ) {
		isSet_endDate = true;
		this.endDate = endDate;
	}
	
	/** Property set << endDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << makeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_makeDate = false;
	
	protected boolean isSet_makeDate()
	{
		return this.isSet_makeDate;
	}
	
	protected void setIsSet_makeDate(boolean value)
	{
		this.isSet_makeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="생성일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String makeDate  = null;
	
	/**
	 * @Description 생성일자
	 */
	public java.lang.String getMakeDate(){
		return makeDate;
	}
	
	/**
	 * @Description 생성일자
	 */
	@JsonProperty("makeDate")
	public void setMakeDate( java.lang.String makeDate ) {
		isSet_makeDate = true;
		this.makeDate = makeDate;
	}
	
	/** Property set << makeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_jAmt = false;
	
	protected boolean isSet_jAmt()
	{
		return this.isSet_jAmt;
	}
	
	protected void setIsSet_jAmt(boolean value)
	{
		this.isSet_jAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전월미납료
	 */
	public void setjAmt(java.lang.String value) {
		isSet_jAmt = true;
		this.jAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전월미납료
	 */
	public void setjAmt(double value) {
		isSet_jAmt = true;
		this.jAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전월미납료
	 */
	public void setjAmt(long value) {
		isSet_jAmt = true;
		this.jAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전월미납료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal jAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전월미납료
	 */
	public java.math.BigDecimal getjAmt(){
		return jAmt;
	}
	
	/**
	 * @Description 전월미납료
	 */
	@JsonProperty("jAmt")
	public void setjAmt( java.math.BigDecimal jAmt ) {
		isSet_jAmt = true;
		this.jAmt = jAmt;
	}
	
	/** Property set << jAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jDamt >> [[ */
	
	@XmlTransient
	private boolean isSet_jDamt = false;
	
	protected boolean isSet_jDamt()
	{
		return this.isSet_jDamt;
	}
	
	protected void setIsSet_jDamt(boolean value)
	{
		this.isSet_jDamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전월미납연체료
	 */
	public void setjDamt(java.lang.String value) {
		isSet_jDamt = true;
		this.jDamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전월미납연체료
	 */
	public void setjDamt(double value) {
		isSet_jDamt = true;
		this.jDamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전월미납연체료
	 */
	public void setjDamt(long value) {
		isSet_jDamt = true;
		this.jDamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전월미납연체료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal jDamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전월미납연체료
	 */
	public java.math.BigDecimal getjDamt(){
		return jDamt;
	}
	
	/**
	 * @Description 전월미납연체료
	 */
	@JsonProperty("jDamt")
	public void setjDamt( java.math.BigDecimal jDamt ) {
		isSet_jDamt = true;
		this.jDamt = jDamt;
	}
	
	/** Property set << jDamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_dAmt = false;
	
	protected boolean isSet_dAmt()
	{
		return this.isSet_dAmt;
	}
	
	protected void setIsSet_dAmt(boolean value)
	{
		this.isSet_dAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 당월임대료
	 */
	public void setdAmt(java.lang.String value) {
		isSet_dAmt = true;
		this.dAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 당월임대료
	 */
	public void setdAmt(double value) {
		isSet_dAmt = true;
		this.dAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 당월임대료
	 */
	public void setdAmt(long value) {
		isSet_dAmt = true;
		this.dAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="당월임대료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal dAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 당월임대료
	 */
	public java.math.BigDecimal getdAmt(){
		return dAmt;
	}
	
	/**
	 * @Description 당월임대료
	 */
	@JsonProperty("dAmt")
	public void setdAmt( java.math.BigDecimal dAmt ) {
		isSet_dAmt = true;
		this.dAmt = dAmt;
	}
	
	/** Property set << dAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dSamt >> [[ */
	
	@XmlTransient
	private boolean isSet_dSamt = false;
	
	protected boolean isSet_dSamt()
	{
		return this.isSet_dSamt;
	}
	
	protected void setIsSet_dSamt(boolean value)
	{
		this.isSet_dSamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 당월공급가
	 */
	public void setdSamt(java.lang.String value) {
		isSet_dSamt = true;
		this.dSamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 당월공급가
	 */
	public void setdSamt(double value) {
		isSet_dSamt = true;
		this.dSamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 당월공급가
	 */
	public void setdSamt(long value) {
		isSet_dSamt = true;
		this.dSamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="당월공급가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal dSamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 당월공급가
	 */
	public java.math.BigDecimal getdSamt(){
		return dSamt;
	}
	
	/**
	 * @Description 당월공급가
	 */
	@JsonProperty("dSamt")
	public void setdSamt( java.math.BigDecimal dSamt ) {
		isSet_dSamt = true;
		this.dSamt = dSamt;
	}
	
	/** Property set << dSamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dVamt >> [[ */
	
	@XmlTransient
	private boolean isSet_dVamt = false;
	
	protected boolean isSet_dVamt()
	{
		return this.isSet_dVamt;
	}
	
	protected void setIsSet_dVamt(boolean value)
	{
		this.isSet_dVamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 당월부가세
	 */
	public void setdVamt(java.lang.String value) {
		isSet_dVamt = true;
		this.dVamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 당월부가세
	 */
	public void setdVamt(double value) {
		isSet_dVamt = true;
		this.dVamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 당월부가세
	 */
	public void setdVamt(long value) {
		isSet_dVamt = true;
		this.dVamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="당월부가세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal dVamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 당월부가세
	 */
	public java.math.BigDecimal getdVamt(){
		return dVamt;
	}
	
	/**
	 * @Description 당월부가세
	 */
	@JsonProperty("dVamt")
	public void setdVamt( java.math.BigDecimal dVamt ) {
		isSet_dVamt = true;
		this.dVamt = dVamt;
	}
	
	/** Property set << dVamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dIamt >> [[ */
	
	@XmlTransient
	private boolean isSet_dIamt = false;
	
	protected boolean isSet_dIamt()
	{
		return this.isSet_dIamt;
	}
	
	protected void setIsSet_dIamt(boolean value)
	{
		this.isSet_dIamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 당월보증보험료
	 */
	public void setdIamt(java.lang.String value) {
		isSet_dIamt = true;
		this.dIamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 당월보증보험료
	 */
	public void setdIamt(double value) {
		isSet_dIamt = true;
		this.dIamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 당월보증보험료
	 */
	public void setdIamt(long value) {
		isSet_dIamt = true;
		this.dIamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="당월보증보험료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal dIamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 당월보증보험료
	 */
	public java.math.BigDecimal getdIamt(){
		return dIamt;
	}
	
	/**
	 * @Description 당월보증보험료
	 */
	@JsonProperty("dIamt")
	public void setdIamt( java.math.BigDecimal dIamt ) {
		isSet_dIamt = true;
		this.dIamt = dIamt;
	}
	
	/** Property set << dIamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amt >> [[ */
	
	@XmlTransient
	private boolean isSet_amt = false;
	
	protected boolean isSet_amt()
	{
		return this.isSet_amt;
	}
	
	protected void setIsSet_amt(boolean value)
	{
		this.isSet_amt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고지금액
	 */
	public void setAmt(java.lang.String value) {
		isSet_amt = true;
		this.amt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고지금액
	 */
	public void setAmt(double value) {
		isSet_amt = true;
		this.amt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고지금액
	 */
	public void setAmt(long value) {
		isSet_amt = true;
		this.amt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고지금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal amt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고지금액
	 */
	public java.math.BigDecimal getAmt(){
		return amt;
	}
	
	/**
	 * @Description 고지금액
	 */
	@JsonProperty("amt")
	public void setAmt( java.math.BigDecimal amt ) {
		isSet_amt = true;
		this.amt = amt;
	}
	
	/** Property set << amt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << giroNo >> [[ */
	
	@XmlTransient
	private boolean isSet_giroNo = false;
	
	protected boolean isSet_giroNo()
	{
		return this.isSet_giroNo;
	}
	
	protected void setIsSet_giroNo(boolean value)
	{
		this.isSet_giroNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="지로번호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String giroNo  = null;
	
	/**
	 * @Description 지로번호
	 */
	public java.lang.String getGiroNo(){
		return giroNo;
	}
	
	/**
	 * @Description 지로번호
	 */
	@JsonProperty("giroNo")
	public void setGiroNo( java.lang.String giroNo ) {
		isSet_giroNo = true;
		this.giroNo = giroNo;
	}
	
	/** Property set << giroNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custNo >> [[ */
	
	@XmlTransient
	private boolean isSet_custNo = false;
	
	protected boolean isSet_custNo()
	{
		return this.isSet_custNo;
	}
	
	protected void setIsSet_custNo(boolean value)
	{
		this.isSet_custNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custNo  = null;
	
	/**
	 * @Description 고객번호
	 */
	public java.lang.String getCustNo(){
		return custNo;
	}
	
	/**
	 * @Description 고객번호
	 */
	@JsonProperty("custNo")
	public void setCustNo( java.lang.String custNo ) {
		isSet_custNo = true;
		this.custNo = custNo;
	}
	
	/** Property set << custNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amtNo >> [[ */
	
	@XmlTransient
	private boolean isSet_amtNo = false;
	
	protected boolean isSet_amtNo()
	{
		return this.isSet_amtNo;
	}
	
	protected void setIsSet_amtNo(boolean value)
	{
		this.isSet_amtNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="금액번호", formatType="", format="", align="left", length=15, decimal=0, arrayReference="", fill="")
	private java.lang.String amtNo  = null;
	
	/**
	 * @Description 금액번호
	 */
	public java.lang.String getAmtNo(){
		return amtNo;
	}
	
	/**
	 * @Description 금액번호
	 */
	@JsonProperty("amtNo")
	public void setAmtNo( java.lang.String amtNo ) {
		isSet_amtNo = true;
		this.amtNo = amtNo;
	}
	
	/** Property set << amtNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositTag >> [[ */
	
	@XmlTransient
	private boolean isSet_depositTag = false;
	
	protected boolean isSet_depositTag()
	{
		return this.isSet_depositTag;
	}
	
	protected void setIsSet_depositTag(boolean value)
	{
		this.isSet_depositTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String depositTag  = null;
	
	/**
	 * @Description 계좌구분
	 */
	public java.lang.String getDepositTag(){
		return depositTag;
	}
	
	/**
	 * @Description 계좌구분
	 */
	@JsonProperty("depositTag")
	public void setDepositTag( java.lang.String depositTag ) {
		isSet_depositTag = true;
		this.depositTag = depositTag;
	}
	
	/** Property set << depositTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jym1 >> [[ */
	
	@XmlTransient
	private boolean isSet_jym1 = false;
	
	protected boolean isSet_jym1()
	{
		return this.isSet_jym1;
	}
	
	protected void setIsSet_jym1(boolean value)
	{
		this.isSet_jym1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납전월", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String jym1  = null;
	
	/**
	 * @Description 미납전월
	 */
	public java.lang.String getJym1(){
		return jym1;
	}
	
	/**
	 * @Description 미납전월
	 */
	@JsonProperty("jym1")
	public void setJym1( java.lang.String jym1 ) {
		isSet_jym1 = true;
		this.jym1 = jym1;
	}
	
	/** Property set << jym1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jymamt1 >> [[ */
	
	@XmlTransient
	private boolean isSet_jymamt1 = false;
	
	protected boolean isSet_jymamt1()
	{
		return this.isSet_jymamt1;
	}
	
	protected void setIsSet_jymamt1(boolean value)
	{
		this.isSet_jymamt1 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 미납전월금액
	 */
	public void setJymamt1(java.lang.String value) {
		isSet_jymamt1 = true;
		this.jymamt1 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 미납전월금액
	 */
	public void setJymamt1(double value) {
		isSet_jymamt1 = true;
		this.jymamt1 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 미납전월금액
	 */
	public void setJymamt1(long value) {
		isSet_jymamt1 = true;
		this.jymamt1 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="미납전월금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal jymamt1  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 미납전월금액
	 */
	public java.math.BigDecimal getJymamt1(){
		return jymamt1;
	}
	
	/**
	 * @Description 미납전월금액
	 */
	@JsonProperty("jymamt1")
	public void setJymamt1( java.math.BigDecimal jymamt1 ) {
		isSet_jymamt1 = true;
		this.jymamt1 = jymamt1;
	}
	
	/** Property set << jymamt1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jym2 >> [[ */
	
	@XmlTransient
	private boolean isSet_jym2 = false;
	
	protected boolean isSet_jym2()
	{
		return this.isSet_jym2;
	}
	
	protected void setIsSet_jym2(boolean value)
	{
		this.isSet_jym2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납전전월", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String jym2  = null;
	
	/**
	 * @Description 미납전전월
	 */
	public java.lang.String getJym2(){
		return jym2;
	}
	
	/**
	 * @Description 미납전전월
	 */
	@JsonProperty("jym2")
	public void setJym2( java.lang.String jym2 ) {
		isSet_jym2 = true;
		this.jym2 = jym2;
	}
	
	/** Property set << jym2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jymamt2 >> [[ */
	
	@XmlTransient
	private boolean isSet_jymamt2 = false;
	
	protected boolean isSet_jymamt2()
	{
		return this.isSet_jymamt2;
	}
	
	protected void setIsSet_jymamt2(boolean value)
	{
		this.isSet_jymamt2 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 미납전전월금액
	 */
	public void setJymamt2(java.lang.String value) {
		isSet_jymamt2 = true;
		this.jymamt2 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 미납전전월금액
	 */
	public void setJymamt2(double value) {
		isSet_jymamt2 = true;
		this.jymamt2 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 미납전전월금액
	 */
	public void setJymamt2(long value) {
		isSet_jymamt2 = true;
		this.jymamt2 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="미납전전월금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal jymamt2  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 미납전전월금액
	 */
	public java.math.BigDecimal getJymamt2(){
		return jymamt2;
	}
	
	/**
	 * @Description 미납전전월금액
	 */
	@JsonProperty("jymamt2")
	public void setJymamt2( java.math.BigDecimal jymamt2 ) {
		isSet_jymamt2 = true;
		this.jymamt2 = jymamt2;
	}
	
	/** Property set << jymamt2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jym3 >> [[ */
	
	@XmlTransient
	private boolean isSet_jym3 = false;
	
	protected boolean isSet_jym3()
	{
		return this.isSet_jym3;
	}
	
	protected void setIsSet_jym3(boolean value)
	{
		this.isSet_jym3 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납전전전월", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String jym3  = null;
	
	/**
	 * @Description 미납전전전월
	 */
	public java.lang.String getJym3(){
		return jym3;
	}
	
	/**
	 * @Description 미납전전전월
	 */
	@JsonProperty("jym3")
	public void setJym3( java.lang.String jym3 ) {
		isSet_jym3 = true;
		this.jym3 = jym3;
	}
	
	/** Property set << jym3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jymamt3 >> [[ */
	
	@XmlTransient
	private boolean isSet_jymamt3 = false;
	
	protected boolean isSet_jymamt3()
	{
		return this.isSet_jymamt3;
	}
	
	protected void setIsSet_jymamt3(boolean value)
	{
		this.isSet_jymamt3 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 미납전전전월금액누계
	 */
	public void setJymamt3(java.lang.String value) {
		isSet_jymamt3 = true;
		this.jymamt3 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 미납전전전월금액누계
	 */
	public void setJymamt3(double value) {
		isSet_jymamt3 = true;
		this.jymamt3 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 미납전전전월금액누계
	 */
	public void setJymamt3(long value) {
		isSet_jymamt3 = true;
		this.jymamt3 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="미납전전전월금액누계", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal jymamt3  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 미납전전전월금액누계
	 */
	public java.math.BigDecimal getJymamt3(){
		return jymamt3;
	}
	
	/**
	 * @Description 미납전전전월금액누계
	 */
	@JsonProperty("jymamt3")
	public void setJymamt3( java.math.BigDecimal jymamt3 ) {
		isSet_jymamt3 = true;
		this.jymamt3 = jymamt3;
	}
	
	/** Property set << jymamt3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printYn >> [[ */
	
	@XmlTransient
	private boolean isSet_printYn = false;
	
	protected boolean isSet_printYn()
	{
		return this.isSet_printYn;
	}
	
	protected void setIsSet_printYn(boolean value)
	{
		this.isSet_printYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String printYn  = null;
	
	/**
	 * @Description 출력여부
	 */
	public java.lang.String getPrintYn(){
		return printYn;
	}
	
	/**
	 * @Description 출력여부
	 */
	@JsonProperty("printYn")
	public void setPrintYn( java.lang.String printYn ) {
		isSet_printYn = true;
		this.printYn = printYn;
	}
	
	/** Property set << printYn >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentGiro01IO clone(){
		try{
			DHDRentGiro01IO object= (DHDRentGiro01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.giroTag== null ) object.giroTag = null;
			else{
				object.giroTag = this.giroTag;
			}
			if ( this.billYm== null ) object.billYm = null;
			else{
				object.billYm = this.billYm;
			}
			if ( this.endDate== null ) object.endDate = null;
			else{
				object.endDate = this.endDate;
			}
			if ( this.makeDate== null ) object.makeDate = null;
			else{
				object.makeDate = this.makeDate;
			}
			if ( this.jAmt== null ) object.jAmt = null;
			else{
				object.jAmt = new java.math.BigDecimal(jAmt.toString());
			}
			if ( this.jDamt== null ) object.jDamt = null;
			else{
				object.jDamt = new java.math.BigDecimal(jDamt.toString());
			}
			if ( this.dAmt== null ) object.dAmt = null;
			else{
				object.dAmt = new java.math.BigDecimal(dAmt.toString());
			}
			if ( this.dSamt== null ) object.dSamt = null;
			else{
				object.dSamt = new java.math.BigDecimal(dSamt.toString());
			}
			if ( this.dVamt== null ) object.dVamt = null;
			else{
				object.dVamt = new java.math.BigDecimal(dVamt.toString());
			}
			if ( this.dIamt== null ) object.dIamt = null;
			else{
				object.dIamt = new java.math.BigDecimal(dIamt.toString());
			}
			if ( this.amt== null ) object.amt = null;
			else{
				object.amt = new java.math.BigDecimal(amt.toString());
			}
			if ( this.giroNo== null ) object.giroNo = null;
			else{
				object.giroNo = this.giroNo;
			}
			if ( this.custNo== null ) object.custNo = null;
			else{
				object.custNo = this.custNo;
			}
			if ( this.amtNo== null ) object.amtNo = null;
			else{
				object.amtNo = this.amtNo;
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.depositTag== null ) object.depositTag = null;
			else{
				object.depositTag = this.depositTag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.jym1== null ) object.jym1 = null;
			else{
				object.jym1 = this.jym1;
			}
			if ( this.jymamt1== null ) object.jymamt1 = null;
			else{
				object.jymamt1 = new java.math.BigDecimal(jymamt1.toString());
			}
			if ( this.jym2== null ) object.jym2 = null;
			else{
				object.jym2 = this.jym2;
			}
			if ( this.jymamt2== null ) object.jymamt2 = null;
			else{
				object.jymamt2 = new java.math.BigDecimal(jymamt2.toString());
			}
			if ( this.jym3== null ) object.jym3 = null;
			else{
				object.jym3 = this.jym3;
			}
			if ( this.jymamt3== null ) object.jymamt3 = null;
			else{
				object.jymamt3 = new java.math.BigDecimal(jymamt3.toString());
			}
			if ( this.printYn== null ) object.printYn = null;
			else{
				object.printYn = this.printYn;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((giroTag==null)?0:giroTag.hashCode());
		result = prime * result + ((billYm==null)?0:billYm.hashCode());
		result = prime * result + ((endDate==null)?0:endDate.hashCode());
		result = prime * result + ((makeDate==null)?0:makeDate.hashCode());
		result = prime * result + ((jAmt==null)?0:jAmt.hashCode());
		result = prime * result + ((jDamt==null)?0:jDamt.hashCode());
		result = prime * result + ((dAmt==null)?0:dAmt.hashCode());
		result = prime * result + ((dSamt==null)?0:dSamt.hashCode());
		result = prime * result + ((dVamt==null)?0:dVamt.hashCode());
		result = prime * result + ((dIamt==null)?0:dIamt.hashCode());
		result = prime * result + ((amt==null)?0:amt.hashCode());
		result = prime * result + ((giroNo==null)?0:giroNo.hashCode());
		result = prime * result + ((custNo==null)?0:custNo.hashCode());
		result = prime * result + ((amtNo==null)?0:amtNo.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((depositTag==null)?0:depositTag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((jym1==null)?0:jym1.hashCode());
		result = prime * result + ((jymamt1==null)?0:jymamt1.hashCode());
		result = prime * result + ((jym2==null)?0:jym2.hashCode());
		result = prime * result + ((jymamt2==null)?0:jymamt2.hashCode());
		result = prime * result + ((jym3==null)?0:jym3.hashCode());
		result = prime * result + ((jymamt3==null)?0:jymamt3.hashCode());
		result = prime * result + ((printYn==null)?0:printYn.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentGiro01IO other = (kait.hd.rent.onl.dao.dto.DHDRentGiro01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( giroTag == null ){
			if ( other.giroTag != null ) return false;
		}
		else if ( !giroTag.equals(other.giroTag) )
			return false;
		if ( billYm == null ){
			if ( other.billYm != null ) return false;
		}
		else if ( !billYm.equals(other.billYm) )
			return false;
		if ( endDate == null ){
			if ( other.endDate != null ) return false;
		}
		else if ( !endDate.equals(other.endDate) )
			return false;
		if ( makeDate == null ){
			if ( other.makeDate != null ) return false;
		}
		else if ( !makeDate.equals(other.makeDate) )
			return false;
		if ( jAmt == null ){
			if ( other.jAmt != null ) return false;
		}
		else if ( !jAmt.equals(other.jAmt) )
			return false;
		if ( jDamt == null ){
			if ( other.jDamt != null ) return false;
		}
		else if ( !jDamt.equals(other.jDamt) )
			return false;
		if ( dAmt == null ){
			if ( other.dAmt != null ) return false;
		}
		else if ( !dAmt.equals(other.dAmt) )
			return false;
		if ( dSamt == null ){
			if ( other.dSamt != null ) return false;
		}
		else if ( !dSamt.equals(other.dSamt) )
			return false;
		if ( dVamt == null ){
			if ( other.dVamt != null ) return false;
		}
		else if ( !dVamt.equals(other.dVamt) )
			return false;
		if ( dIamt == null ){
			if ( other.dIamt != null ) return false;
		}
		else if ( !dIamt.equals(other.dIamt) )
			return false;
		if ( amt == null ){
			if ( other.amt != null ) return false;
		}
		else if ( !amt.equals(other.amt) )
			return false;
		if ( giroNo == null ){
			if ( other.giroNo != null ) return false;
		}
		else if ( !giroNo.equals(other.giroNo) )
			return false;
		if ( custNo == null ){
			if ( other.custNo != null ) return false;
		}
		else if ( !custNo.equals(other.custNo) )
			return false;
		if ( amtNo == null ){
			if ( other.amtNo != null ) return false;
		}
		else if ( !amtNo.equals(other.amtNo) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( depositTag == null ){
			if ( other.depositTag != null ) return false;
		}
		else if ( !depositTag.equals(other.depositTag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( jym1 == null ){
			if ( other.jym1 != null ) return false;
		}
		else if ( !jym1.equals(other.jym1) )
			return false;
		if ( jymamt1 == null ){
			if ( other.jymamt1 != null ) return false;
		}
		else if ( !jymamt1.equals(other.jymamt1) )
			return false;
		if ( jym2 == null ){
			if ( other.jym2 != null ) return false;
		}
		else if ( !jym2.equals(other.jym2) )
			return false;
		if ( jymamt2 == null ){
			if ( other.jymamt2 != null ) return false;
		}
		else if ( !jymamt2.equals(other.jymamt2) )
			return false;
		if ( jym3 == null ){
			if ( other.jym3 != null ) return false;
		}
		else if ( !jym3.equals(other.jym3) )
			return false;
		if ( jymamt3 == null ){
			if ( other.jymamt3 != null ) return false;
		}
		else if ( !jymamt3.equals(other.jymamt3) )
			return false;
		if ( printYn == null ){
			if ( other.printYn != null ) return false;
		}
		else if ( !printYn.equals(other.printYn) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentGiro01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tgiroTag: ");
		sb.append(giroTag==null?"null":getGiroTag());
		sb.append("\n");
		sb.append("\tbillYm: ");
		sb.append(billYm==null?"null":getBillYm());
		sb.append("\n");
		sb.append("\tendDate: ");
		sb.append(endDate==null?"null":getEndDate());
		sb.append("\n");
		sb.append("\tmakeDate: ");
		sb.append(makeDate==null?"null":getMakeDate());
		sb.append("\n");
		sb.append("\tjAmt: ");
		sb.append(jAmt==null?"null":getjAmt());
		sb.append("\n");
		sb.append("\tjDamt: ");
		sb.append(jDamt==null?"null":getjDamt());
		sb.append("\n");
		sb.append("\tdAmt: ");
		sb.append(dAmt==null?"null":getdAmt());
		sb.append("\n");
		sb.append("\tdSamt: ");
		sb.append(dSamt==null?"null":getdSamt());
		sb.append("\n");
		sb.append("\tdVamt: ");
		sb.append(dVamt==null?"null":getdVamt());
		sb.append("\n");
		sb.append("\tdIamt: ");
		sb.append(dIamt==null?"null":getdIamt());
		sb.append("\n");
		sb.append("\tamt: ");
		sb.append(amt==null?"null":getAmt());
		sb.append("\n");
		sb.append("\tgiroNo: ");
		sb.append(giroNo==null?"null":getGiroNo());
		sb.append("\n");
		sb.append("\tcustNo: ");
		sb.append(custNo==null?"null":getCustNo());
		sb.append("\n");
		sb.append("\tamtNo: ");
		sb.append(amtNo==null?"null":getAmtNo());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\tdepositTag: ");
		sb.append(depositTag==null?"null":getDepositTag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tjym1: ");
		sb.append(jym1==null?"null":getJym1());
		sb.append("\n");
		sb.append("\tjymamt1: ");
		sb.append(jymamt1==null?"null":getJymamt1());
		sb.append("\n");
		sb.append("\tjym2: ");
		sb.append(jym2==null?"null":getJym2());
		sb.append("\n");
		sb.append("\tjymamt2: ");
		sb.append(jymamt2==null?"null":getJymamt2());
		sb.append("\n");
		sb.append("\tjym3: ");
		sb.append(jym3==null?"null":getJym3());
		sb.append("\n");
		sb.append("\tjymamt3: ");
		sb.append(jymamt3==null?"null":getJymamt3());
		sb.append("\n");
		sb.append("\tprintYn: ");
		sb.append(printYn==null?"null":getPrintYn());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 1; /* giroTag */
		messageLen+= 6; /* billYm */
		messageLen+= 8; /* endDate */
		messageLen+= 8; /* makeDate */
		messageLen+= 22; /* jAmt */
		messageLen+= 22; /* jDamt */
		messageLen+= 22; /* dAmt */
		messageLen+= 22; /* dSamt */
		messageLen+= 22; /* dVamt */
		messageLen+= 22; /* dIamt */
		messageLen+= 22; /* amt */
		messageLen+= 10; /* giroNo */
		messageLen+= 20; /* custNo */
		messageLen+= 15; /* amtNo */
		messageLen+= 100; /* depositNo */
		messageLen+= 1; /* depositTag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 6; /* jym1 */
		messageLen+= 22; /* jymamt1 */
		messageLen+= 6; /* jym2 */
		messageLen+= 22; /* jymamt2 */
		messageLen+= 6; /* jym3 */
		messageLen+= 22; /* jymamt3 */
		messageLen+= 1; /* printYn */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("giroTag");
	
		fieldNames.add("billYm");
	
		fieldNames.add("endDate");
	
		fieldNames.add("makeDate");
	
		fieldNames.add("jAmt");
	
		fieldNames.add("jDamt");
	
		fieldNames.add("dAmt");
	
		fieldNames.add("dSamt");
	
		fieldNames.add("dVamt");
	
		fieldNames.add("dIamt");
	
		fieldNames.add("amt");
	
		fieldNames.add("giroNo");
	
		fieldNames.add("custNo");
	
		fieldNames.add("amtNo");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("depositTag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("jym1");
	
		fieldNames.add("jymamt1");
	
		fieldNames.add("jym2");
	
		fieldNames.add("jymamt2");
	
		fieldNames.add("jym3");
	
		fieldNames.add("jymamt3");
	
		fieldNames.add("printYn");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("giroTag", get("giroTag"));
	
		fieldValueMap.put("billYm", get("billYm"));
	
		fieldValueMap.put("endDate", get("endDate"));
	
		fieldValueMap.put("makeDate", get("makeDate"));
	
		fieldValueMap.put("jAmt", get("jAmt"));
	
		fieldValueMap.put("jDamt", get("jDamt"));
	
		fieldValueMap.put("dAmt", get("dAmt"));
	
		fieldValueMap.put("dSamt", get("dSamt"));
	
		fieldValueMap.put("dVamt", get("dVamt"));
	
		fieldValueMap.put("dIamt", get("dIamt"));
	
		fieldValueMap.put("amt", get("amt"));
	
		fieldValueMap.put("giroNo", get("giroNo"));
	
		fieldValueMap.put("custNo", get("custNo"));
	
		fieldValueMap.put("amtNo", get("amtNo"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("depositTag", get("depositTag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("jym1", get("jym1"));
	
		fieldValueMap.put("jymamt1", get("jymamt1"));
	
		fieldValueMap.put("jym2", get("jym2"));
	
		fieldValueMap.put("jymamt2", get("jymamt2"));
	
		fieldValueMap.put("jym3", get("jym3"));
	
		fieldValueMap.put("jymamt3", get("jymamt3"));
	
		fieldValueMap.put("printYn", get("printYn"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 38331515 : /* giroTag */
			return getGiroTag();
		case -1389016709 : /* billYm */
			return getBillYm();
		case -1607727319 : /* endDate */
			return getEndDate();
		case 40026812 : /* makeDate */
			return getMakeDate();
		case 3223806 : /* jAmt */
			return getjAmt();
		case 100015726 : /* jDamt */
			return getjDamt();
		case 3045060 : /* dAmt */
			return getdAmt();
		case 94921465 : /* dSamt */
			return getdSamt();
		case 95010838 : /* dVamt */
			return getdVamt();
		case 94623555 : /* dIamt */
			return getdIamt();
		case 96712 : /* amt */
			return getAmt();
		case -1245689664 : /* giroNo */
			return getGiroNo();
		case -1349089420 : /* custNo */
			return getCustNo();
		case 92942761 : /* amtNo */
			return getAmtNo();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 406995996 : /* depositTag */
			return getDepositTag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 3277555 : /* jym1 */
			return getJym1();
		case -1141068441 : /* jymamt1 */
			return getJymamt1();
		case 3277556 : /* jym2 */
			return getJym2();
		case -1141068440 : /* jymamt2 */
			return getJymamt2();
		case 3277557 : /* jym3 */
			return getJym3();
		case -1141068439 : /* jymamt3 */
			return getJymamt3();
		case -314718558 : /* printYn */
			return getPrintYn();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 38331515 : /* giroTag */
			setGiroTag((java.lang.String) value);
			return;
		case -1389016709 : /* billYm */
			setBillYm((java.lang.String) value);
			return;
		case -1607727319 : /* endDate */
			setEndDate((java.lang.String) value);
			return;
		case 40026812 : /* makeDate */
			setMakeDate((java.lang.String) value);
			return;
		case 3223806 : /* jAmt */
			setjAmt((java.math.BigDecimal) value);
			return;
		case 100015726 : /* jDamt */
			setjDamt((java.math.BigDecimal) value);
			return;
		case 3045060 : /* dAmt */
			setdAmt((java.math.BigDecimal) value);
			return;
		case 94921465 : /* dSamt */
			setdSamt((java.math.BigDecimal) value);
			return;
		case 95010838 : /* dVamt */
			setdVamt((java.math.BigDecimal) value);
			return;
		case 94623555 : /* dIamt */
			setdIamt((java.math.BigDecimal) value);
			return;
		case 96712 : /* amt */
			setAmt((java.math.BigDecimal) value);
			return;
		case -1245689664 : /* giroNo */
			setGiroNo((java.lang.String) value);
			return;
		case -1349089420 : /* custNo */
			setCustNo((java.lang.String) value);
			return;
		case 92942761 : /* amtNo */
			setAmtNo((java.lang.String) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 406995996 : /* depositTag */
			setDepositTag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 3277555 : /* jym1 */
			setJym1((java.lang.String) value);
			return;
		case -1141068441 : /* jymamt1 */
			setJymamt1((java.math.BigDecimal) value);
			return;
		case 3277556 : /* jym2 */
			setJym2((java.lang.String) value);
			return;
		case -1141068440 : /* jymamt2 */
			setJymamt2((java.math.BigDecimal) value);
			return;
		case 3277557 : /* jym3 */
			setJym3((java.lang.String) value);
			return;
		case -1141068439 : /* jymamt3 */
			setJymamt3((java.math.BigDecimal) value);
			return;
		case -314718558 : /* printYn */
			setPrintYn((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
