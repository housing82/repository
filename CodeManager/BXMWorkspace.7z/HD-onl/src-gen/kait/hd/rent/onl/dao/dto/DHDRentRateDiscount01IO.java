/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_세대별할인율 ( HD_RENT_RATE_DISCOUNT )
 */
@XmlType(propOrder={"custCode", "seq", "rateTag", "startdate", "enddate", "discntrate", "discntcut", "discntunit", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDRentRateDiscount01IO")
@XmlRootElement(name="DHDRentRateDiscount01IO")
@SuppressWarnings("all")
public class DHDRentRateDiscount01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -708807035L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_세대별할인율 ( HD_RENT_RATE_DISCOUNT )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012718(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012718(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012718(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012719(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012719(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012719(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012719(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012719(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012719(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rateTag >> [[ */
	
	@XmlTransient
	private boolean isSet_rateTag = false;
	
	protected boolean isSet_rateTag()
	{
		return this.isSet_rateTag;
	}
	
	protected void setIsSet_rateTag(boolean value)
	{
		this.isSet_rateTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이율종류 [SYS_C0012720(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String rateTag  = null;
	
	/**
	 * @Description 이율종류 [SYS_C0012720(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public java.lang.String getRateTag(){
		return rateTag;
	}
	
	/**
	 * @Description 이율종류 [SYS_C0012720(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	@JsonProperty("rateTag")
	public void setRateTag( java.lang.String rateTag ) {
		isSet_rateTag = true;
		this.rateTag = rateTag;
	}
	
	/** Property set << rateTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << startdate >> [[ */
	
	@XmlTransient
	private boolean isSet_startdate = false;
	
	protected boolean isSet_startdate()
	{
		return this.isSet_startdate;
	}
	
	protected void setIsSet_startdate(boolean value)
	{
		this.isSet_startdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시작일자 [SYS_C0012721(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String startdate  = null;
	
	/**
	 * @Description 시작일자 [SYS_C0012721(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	public java.lang.String getStartdate(){
		return startdate;
	}
	
	/**
	 * @Description 시작일자 [SYS_C0012721(C),SYS_C0013005(P) SYS_C0013005(UNIQUE)]
	 */
	@JsonProperty("startdate")
	public void setStartdate( java.lang.String startdate ) {
		isSet_startdate = true;
		this.startdate = startdate;
	}
	
	/** Property set << startdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << enddate >> [[ */
	
	@XmlTransient
	private boolean isSet_enddate = false;
	
	protected boolean isSet_enddate()
	{
		return this.isSet_enddate;
	}
	
	protected void setIsSet_enddate(boolean value)
	{
		this.isSet_enddate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="종료일자 [SYS_C0012722(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String enddate  = null;
	
	/**
	 * @Description 종료일자 [SYS_C0012722(C)]
	 */
	public java.lang.String getEnddate(){
		return enddate;
	}
	
	/**
	 * @Description 종료일자 [SYS_C0012722(C)]
	 */
	@JsonProperty("enddate")
	public void setEnddate( java.lang.String enddate ) {
		isSet_enddate = true;
		this.enddate = enddate;
	}
	
	/** Property set << enddate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntrate >> [[ */
	
	@XmlTransient
	private boolean isSet_discntrate = false;
	
	protected boolean isSet_discntrate()
	{
		return this.isSet_discntrate;
	}
	
	protected void setIsSet_discntrate(boolean value)
	{
		this.isSet_discntrate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="할인율 [SYS_C0012723(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float discntrate  = .0F;
	
	/**
	 * @Description 할인율 [SYS_C0012723(C)]
	 */
	public java.lang.Float getDiscntrate(){
		return discntrate;
	}
	
	/**
	 * @Description 할인율 [SYS_C0012723(C)]
	 */
	@JsonProperty("discntrate")
	public void setDiscntrate( java.lang.Float discntrate ) {
		isSet_discntrate = true;
		this.discntrate = discntrate;
	}
	
	/** Property set << discntrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntcut >> [[ */
	
	@XmlTransient
	private boolean isSet_discntcut = false;
	
	protected boolean isSet_discntcut()
	{
		return this.isSet_discntcut;
	}
	
	protected void setIsSet_discntcut(boolean value)
	{
		this.isSet_discntcut = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="할인절사기준 [SYS_C0012724(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String discntcut  = null;
	
	/**
	 * @Description 할인절사기준 [SYS_C0012724(C)]
	 */
	public java.lang.String getDiscntcut(){
		return discntcut;
	}
	
	/**
	 * @Description 할인절사기준 [SYS_C0012724(C)]
	 */
	@JsonProperty("discntcut")
	public void setDiscntcut( java.lang.String discntcut ) {
		isSet_discntcut = true;
		this.discntcut = discntcut;
	}
	
	/** Property set << discntcut >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntunit >> [[ */
	
	@XmlTransient
	private boolean isSet_discntunit = false;
	
	protected boolean isSet_discntunit()
	{
		return this.isSet_discntunit;
	}
	
	protected void setIsSet_discntunit(boolean value)
	{
		this.isSet_discntunit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="할인절사단위 [SYS_C0012725(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String discntunit  = null;
	
	/**
	 * @Description 할인절사단위 [SYS_C0012725(C)]
	 */
	public java.lang.String getDiscntunit(){
		return discntunit;
	}
	
	/**
	 * @Description 할인절사단위 [SYS_C0012725(C)]
	 */
	@JsonProperty("discntunit")
	public void setDiscntunit( java.lang.String discntunit ) {
		isSet_discntunit = true;
		this.discntunit = discntunit;
	}
	
	/** Property set << discntunit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentRateDiscount01IO clone(){
		try{
			DHDRentRateDiscount01IO object= (DHDRentRateDiscount01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.rateTag== null ) object.rateTag = null;
			else{
				object.rateTag = this.rateTag;
			}
			if ( this.startdate== null ) object.startdate = null;
			else{
				object.startdate = this.startdate;
			}
			if ( this.enddate== null ) object.enddate = null;
			else{
				object.enddate = this.enddate;
			}
			if ( this.discntrate== null ) object.discntrate = null;
			else{
				object.discntrate = this.discntrate;
			}
			if ( this.discntcut== null ) object.discntcut = null;
			else{
				object.discntcut = this.discntcut;
			}
			if ( this.discntunit== null ) object.discntunit = null;
			else{
				object.discntunit = this.discntunit;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((rateTag==null)?0:rateTag.hashCode());
		result = prime * result + ((startdate==null)?0:startdate.hashCode());
		result = prime * result + ((enddate==null)?0:enddate.hashCode());
		result = prime * result + ((discntrate==null)?0:discntrate.hashCode());
		result = prime * result + ((discntcut==null)?0:discntcut.hashCode());
		result = prime * result + ((discntunit==null)?0:discntunit.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO other = (kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( rateTag == null ){
			if ( other.rateTag != null ) return false;
		}
		else if ( !rateTag.equals(other.rateTag) )
			return false;
		if ( startdate == null ){
			if ( other.startdate != null ) return false;
		}
		else if ( !startdate.equals(other.startdate) )
			return false;
		if ( enddate == null ){
			if ( other.enddate != null ) return false;
		}
		else if ( !enddate.equals(other.enddate) )
			return false;
		if ( discntrate == null ){
			if ( other.discntrate != null ) return false;
		}
		else if ( !discntrate.equals(other.discntrate) )
			return false;
		if ( discntcut == null ){
			if ( other.discntcut != null ) return false;
		}
		else if ( !discntcut.equals(other.discntcut) )
			return false;
		if ( discntunit == null ){
			if ( other.discntunit != null ) return false;
		}
		else if ( !discntunit.equals(other.discntunit) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\trateTag: ");
		sb.append(rateTag==null?"null":getRateTag());
		sb.append("\n");
		sb.append("\tstartdate: ");
		sb.append(startdate==null?"null":getStartdate());
		sb.append("\n");
		sb.append("\tenddate: ");
		sb.append(enddate==null?"null":getEnddate());
		sb.append("\n");
		sb.append("\tdiscntrate: ");
		sb.append(discntrate==null?"null":getDiscntrate());
		sb.append("\n");
		sb.append("\tdiscntcut: ");
		sb.append(discntcut==null?"null":getDiscntcut());
		sb.append("\n");
		sb.append("\tdiscntunit: ");
		sb.append(discntunit==null?"null":getDiscntunit());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 2; /* rateTag */
		messageLen+= 8; /* startdate */
		messageLen+= 8; /* enddate */
		messageLen+= 22; /* discntrate */
		messageLen+= 1; /* discntcut */
		messageLen+= 1; /* discntunit */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("rateTag");
	
		fieldNames.add("startdate");
	
		fieldNames.add("enddate");
	
		fieldNames.add("discntrate");
	
		fieldNames.add("discntcut");
	
		fieldNames.add("discntunit");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("rateTag", get("rateTag"));
	
		fieldValueMap.put("startdate", get("startdate"));
	
		fieldValueMap.put("enddate", get("enddate"));
	
		fieldValueMap.put("discntrate", get("discntrate"));
	
		fieldValueMap.put("discntcut", get("discntcut"));
	
		fieldValueMap.put("discntunit", get("discntunit"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 983453338 : /* rateTag */
			return getRateTag();
		case -2128825584 : /* startdate */
			return getStartdate();
		case -1606774007 : /* enddate */
			return getEnddate();
		case 507433339 : /* discntrate */
			return getDiscntrate();
		case -122192313 : /* discntcut */
			return getDiscntcut();
		case 507534879 : /* discntunit */
			return getDiscntunit();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 983453338 : /* rateTag */
			setRateTag((java.lang.String) value);
			return;
		case -2128825584 : /* startdate */
			setStartdate((java.lang.String) value);
			return;
		case -1606774007 : /* enddate */
			setEnddate((java.lang.String) value);
			return;
		case 507433339 : /* discntrate */
			setDiscntrate((java.lang.Float) value);
			return;
		case -122192313 : /* discntcut */
			setDiscntcut((java.lang.String) value);
			return;
		case 507534879 : /* discntunit */
			setDiscntunit((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
