/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_임대료약정사항_정산 ( HD_RENT_RENT_AGREE_ADJ )
 */
@XmlType(propOrder={"custCode", "seq", "termChgSeq", "counts", "agreeDate", "agreeSdate", "agreeEdate", "agreeDays", "rentAmt", "vatYn", "rentSupply", "rentVat", "perpectTag", "receiptAmt", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "rentIns", "slipDate", "slipSeq"}, name="DHDRentRentAgreeAdj01IO")
@XmlRootElement(name="DHDRentRentAgreeAdj01IO")
@SuppressWarnings("all")
public class DHDRentRentAgreeAdj01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -2313352L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_임대료약정사항_정산 ( HD_RENT_RENT_AGREE_ADJ )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012737(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012737(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012737(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012738(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012738(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012738(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012738(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012738(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012738(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << termChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_termChgSeq = false;
	
	protected boolean isSet_termChgSeq()
	{
		return this.isSet_termChgSeq;
	}
	
	protected void setIsSet_termChgSeq(boolean value)
	{
		this.isSet_termChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약차수 [SYS_C0012739(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public void setTermChgSeq(java.lang.String value) {
		isSet_termChgSeq = true;
		this.termChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약차수 [SYS_C0012739(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public void setTermChgSeq(double value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약차수 [SYS_C0012739(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public void setTermChgSeq(long value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약차수 [SYS_C0012739(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal termChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약차수 [SYS_C0012739(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public java.math.BigDecimal getTermChgSeq(){
		return termChgSeq;
	}
	
	/**
	 * @Description 계약차수 [SYS_C0012739(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	@JsonProperty("termChgSeq")
	public void setTermChgSeq( java.math.BigDecimal termChgSeq ) {
		isSet_termChgSeq = true;
		this.termChgSeq = termChgSeq;
	}
	
	/** Property set << termChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << counts >> [[ */
	
	@XmlTransient
	private boolean isSet_counts = false;
	
	protected boolean isSet_counts()
	{
		return this.isSet_counts;
	}
	
	protected void setIsSet_counts(boolean value)
	{
		this.isSet_counts = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정차수 [SYS_C0012740(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String counts  = null;
	
	/**
	 * @Description 약정차수 [SYS_C0012740(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	public java.lang.String getCounts(){
		return counts;
	}
	
	/**
	 * @Description 약정차수 [SYS_C0012740(C),SYS_C0013009(P) XPKHD_RENT_RENT_AGREE_ADJ(UNIQUE)]
	 */
	@JsonProperty("counts")
	public void setCounts( java.lang.String counts ) {
		isSet_counts = true;
		this.counts = counts;
	}
	
	/** Property set << counts >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeDate = false;
	
	protected boolean isSet_agreeDate()
	{
		return this.isSet_agreeDate;
	}
	
	protected void setIsSet_agreeDate(boolean value)
	{
		this.isSet_agreeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정일자 [SYS_C0012741(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeDate  = null;
	
	/**
	 * @Description 약정일자 [SYS_C0012741(C)]
	 */
	public java.lang.String getAgreeDate(){
		return agreeDate;
	}
	
	/**
	 * @Description 약정일자 [SYS_C0012741(C)]
	 */
	@JsonProperty("agreeDate")
	public void setAgreeDate( java.lang.String agreeDate ) {
		isSet_agreeDate = true;
		this.agreeDate = agreeDate;
	}
	
	/** Property set << agreeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeSdate = false;
	
	protected boolean isSet_agreeSdate()
	{
		return this.isSet_agreeSdate;
	}
	
	protected void setIsSet_agreeSdate(boolean value)
	{
		this.isSet_agreeSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정시작일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeSdate  = null;
	
	/**
	 * @Description 약정시작일
	 */
	public java.lang.String getAgreeSdate(){
		return agreeSdate;
	}
	
	/**
	 * @Description 약정시작일
	 */
	@JsonProperty("agreeSdate")
	public void setAgreeSdate( java.lang.String agreeSdate ) {
		isSet_agreeSdate = true;
		this.agreeSdate = agreeSdate;
	}
	
	/** Property set << agreeSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeEdate >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeEdate = false;
	
	protected boolean isSet_agreeEdate()
	{
		return this.isSet_agreeEdate;
	}
	
	protected void setIsSet_agreeEdate(boolean value)
	{
		this.isSet_agreeEdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정종료일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeEdate  = null;
	
	/**
	 * @Description 약정종료일
	 */
	public java.lang.String getAgreeEdate(){
		return agreeEdate;
	}
	
	/**
	 * @Description 약정종료일
	 */
	@JsonProperty("agreeEdate")
	public void setAgreeEdate( java.lang.String agreeEdate ) {
		isSet_agreeEdate = true;
		this.agreeEdate = agreeEdate;
	}
	
	/** Property set << agreeEdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeDays >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeDays = false;
	
	protected boolean isSet_agreeDays()
	{
		return this.isSet_agreeDays;
	}
	
	protected void setIsSet_agreeDays(boolean value)
	{
		this.isSet_agreeDays = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 약정일수
	 */
	public void setAgreeDays(java.lang.String value) {
		isSet_agreeDays = true;
		this.agreeDays = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 약정일수
	 */
	public void setAgreeDays(double value) {
		isSet_agreeDays = true;
		this.agreeDays = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 약정일수
	 */
	public void setAgreeDays(long value) {
		isSet_agreeDays = true;
		this.agreeDays = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="약정일수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal agreeDays  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 약정일수
	 */
	public java.math.BigDecimal getAgreeDays(){
		return agreeDays;
	}
	
	/**
	 * @Description 약정일수
	 */
	@JsonProperty("agreeDays")
	public void setAgreeDays( java.math.BigDecimal agreeDays ) {
		isSet_agreeDays = true;
		this.agreeDays = agreeDays;
	}
	
	/** Property set << agreeDays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_rentAmt = false;
	
	protected boolean isSet_rentAmt()
	{
		return this.isSet_rentAmt;
	}
	
	protected void setIsSet_rentAmt(boolean value)
	{
		this.isSet_rentAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료금액
	 */
	public void setRentAmt(java.lang.String value) {
		isSet_rentAmt = true;
		this.rentAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료금액
	 */
	public void setRentAmt(double value) {
		isSet_rentAmt = true;
		this.rentAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료금액
	 */
	public void setRentAmt(long value) {
		isSet_rentAmt = true;
		this.rentAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료금액
	 */
	public java.math.BigDecimal getRentAmt(){
		return rentAmt;
	}
	
	/**
	 * @Description 임대료금액
	 */
	@JsonProperty("rentAmt")
	public void setRentAmt( java.math.BigDecimal rentAmt ) {
		isSet_rentAmt = true;
		this.rentAmt = rentAmt;
	}
	
	/** Property set << rentAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatYn >> [[ */
	
	@XmlTransient
	private boolean isSet_vatYn = false;
	
	protected boolean isSet_vatYn()
	{
		return this.isSet_vatYn;
	}
	
	protected void setIsSet_vatYn(boolean value)
	{
		this.isSet_vatYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String vatYn  = null;
	
	/**
	 * @Description 부가세여부
	 */
	public java.lang.String getVatYn(){
		return vatYn;
	}
	
	/**
	 * @Description 부가세여부
	 */
	@JsonProperty("vatYn")
	public void setVatYn( java.lang.String vatYn ) {
		isSet_vatYn = true;
		this.vatYn = vatYn;
	}
	
	/** Property set << vatYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentSupply >> [[ */
	
	@XmlTransient
	private boolean isSet_rentSupply = false;
	
	protected boolean isSet_rentSupply()
	{
		return this.isSet_rentSupply;
	}
	
	protected void setIsSet_rentSupply(boolean value)
	{
		this.isSet_rentSupply = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(java.lang.String value) {
		isSet_rentSupply = true;
		this.rentSupply = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(double value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(long value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료공급가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentSupply  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료공급가
	 */
	public java.math.BigDecimal getRentSupply(){
		return rentSupply;
	}
	
	/**
	 * @Description 임대료공급가
	 */
	@JsonProperty("rentSupply")
	public void setRentSupply( java.math.BigDecimal rentSupply ) {
		isSet_rentSupply = true;
		this.rentSupply = rentSupply;
	}
	
	/** Property set << rentSupply >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentVat >> [[ */
	
	@XmlTransient
	private boolean isSet_rentVat = false;
	
	protected boolean isSet_rentVat()
	{
		return this.isSet_rentVat;
	}
	
	protected void setIsSet_rentVat(boolean value)
	{
		this.isSet_rentVat = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(java.lang.String value) {
		isSet_rentVat = true;
		this.rentVat = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(double value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(long value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료부가세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentVat  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료부가세
	 */
	public java.math.BigDecimal getRentVat(){
		return rentVat;
	}
	
	/**
	 * @Description 임대료부가세
	 */
	@JsonProperty("rentVat")
	public void setRentVat( java.math.BigDecimal rentVat ) {
		isSet_rentVat = true;
		this.rentVat = rentVat;
	}
	
	/** Property set << rentVat >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << perpectTag >> [[ */
	
	@XmlTransient
	private boolean isSet_perpectTag = false;
	
	protected boolean isSet_perpectTag()
	{
		return this.isSet_perpectTag;
	}
	
	protected void setIsSet_perpectTag(boolean value)
	{
		this.isSet_perpectTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="완료구분 [SYS_C0012742(C),SYS_C0013008(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String perpectTag  = null;
	
	/**
	 * @Description 완료구분 [SYS_C0012742(C),SYS_C0013008(C)]
	 */
	public java.lang.String getPerpectTag(){
		return perpectTag;
	}
	
	/**
	 * @Description 완료구분 [SYS_C0012742(C),SYS_C0013008(C)]
	 */
	@JsonProperty("perpectTag")
	public void setPerpectTag( java.lang.String perpectTag ) {
		isSet_perpectTag = true;
		this.perpectTag = perpectTag;
	}
	
	/** Property set << perpectTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptAmt = false;
	
	protected boolean isSet_receiptAmt()
	{
		return this.isSet_receiptAmt;
	}
	
	protected void setIsSet_receiptAmt(boolean value)
	{
		this.isSet_receiptAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 입금합계 [SYS_C0012743(C)]
	 */
	public void setReceiptAmt(java.lang.String value) {
		isSet_receiptAmt = true;
		this.receiptAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 입금합계 [SYS_C0012743(C)]
	 */
	public void setReceiptAmt(double value) {
		isSet_receiptAmt = true;
		this.receiptAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 입금합계 [SYS_C0012743(C)]
	 */
	public void setReceiptAmt(long value) {
		isSet_receiptAmt = true;
		this.receiptAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="입금합계 [SYS_C0012743(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 입금합계 [SYS_C0012743(C)]
	 */
	public java.math.BigDecimal getReceiptAmt(){
		return receiptAmt;
	}
	
	/**
	 * @Description 입금합계 [SYS_C0012743(C)]
	 */
	@JsonProperty("receiptAmt")
	public void setReceiptAmt( java.math.BigDecimal receiptAmt ) {
		isSet_receiptAmt = true;
		this.receiptAmt = receiptAmt;
	}
	
	/** Property set << receiptAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentIns >> [[ */
	
	@XmlTransient
	private boolean isSet_rentIns = false;
	
	protected boolean isSet_rentIns()
	{
		return this.isSet_rentIns;
	}
	
	protected void setIsSet_rentIns(boolean value)
	{
		this.isSet_rentIns = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(java.lang.String value) {
		isSet_rentIns = true;
		this.rentIns = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(double value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(long value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료보증보험료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentIns  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료보증보험료
	 */
	public java.math.BigDecimal getRentIns(){
		return rentIns;
	}
	
	/**
	 * @Description 임대료보증보험료
	 */
	@JsonProperty("rentIns")
	public void setRentIns( java.math.BigDecimal rentIns ) {
		isSet_rentIns = true;
		this.rentIns = rentIns;
	}
	
	/** Property set << rentIns >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipDate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipDate = false;
	
	protected boolean isSet_slipDate()
	{
		return this.isSet_slipDate;
	}
	
	protected void setIsSet_slipDate(boolean value)
	{
		this.isSet_slipDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipDate  = null;
	
	/**
	 * @Description 전표일자
	 */
	public java.lang.String getSlipDate(){
		return slipDate;
	}
	
	/**
	 * @Description 전표일자
	 */
	@JsonProperty("slipDate")
	public void setSlipDate( java.lang.String slipDate ) {
		isSet_slipDate = true;
		this.slipDate = slipDate;
	}
	
	/** Property set << slipDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipSeq = false;
	
	protected boolean isSet_slipSeq()
	{
		return this.isSet_slipSeq;
	}
	
	protected void setIsSet_slipSeq(boolean value)
	{
		this.isSet_slipSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(java.lang.String value) {
		isSet_slipSeq = true;
		this.slipSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(double value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(long value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번
	 */
	public java.math.BigDecimal getSlipSeq(){
		return slipSeq;
	}
	
	/**
	 * @Description 전표순번
	 */
	@JsonProperty("slipSeq")
	public void setSlipSeq( java.math.BigDecimal slipSeq ) {
		isSet_slipSeq = true;
		this.slipSeq = slipSeq;
	}
	
	/** Property set << slipSeq >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentRentAgreeAdj01IO clone(){
		try{
			DHDRentRentAgreeAdj01IO object= (DHDRentRentAgreeAdj01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.termChgSeq== null ) object.termChgSeq = null;
			else{
				object.termChgSeq = new java.math.BigDecimal(termChgSeq.toString());
			}
			if ( this.counts== null ) object.counts = null;
			else{
				object.counts = this.counts;
			}
			if ( this.agreeDate== null ) object.agreeDate = null;
			else{
				object.agreeDate = this.agreeDate;
			}
			if ( this.agreeSdate== null ) object.agreeSdate = null;
			else{
				object.agreeSdate = this.agreeSdate;
			}
			if ( this.agreeEdate== null ) object.agreeEdate = null;
			else{
				object.agreeEdate = this.agreeEdate;
			}
			if ( this.agreeDays== null ) object.agreeDays = null;
			else{
				object.agreeDays = new java.math.BigDecimal(agreeDays.toString());
			}
			if ( this.rentAmt== null ) object.rentAmt = null;
			else{
				object.rentAmt = new java.math.BigDecimal(rentAmt.toString());
			}
			if ( this.vatYn== null ) object.vatYn = null;
			else{
				object.vatYn = this.vatYn;
			}
			if ( this.rentSupply== null ) object.rentSupply = null;
			else{
				object.rentSupply = new java.math.BigDecimal(rentSupply.toString());
			}
			if ( this.rentVat== null ) object.rentVat = null;
			else{
				object.rentVat = new java.math.BigDecimal(rentVat.toString());
			}
			if ( this.perpectTag== null ) object.perpectTag = null;
			else{
				object.perpectTag = this.perpectTag;
			}
			if ( this.receiptAmt== null ) object.receiptAmt = null;
			else{
				object.receiptAmt = new java.math.BigDecimal(receiptAmt.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.rentIns== null ) object.rentIns = null;
			else{
				object.rentIns = new java.math.BigDecimal(rentIns.toString());
			}
			if ( this.slipDate== null ) object.slipDate = null;
			else{
				object.slipDate = this.slipDate;
			}
			if ( this.slipSeq== null ) object.slipSeq = null;
			else{
				object.slipSeq = new java.math.BigDecimal(slipSeq.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((termChgSeq==null)?0:termChgSeq.hashCode());
		result = prime * result + ((counts==null)?0:counts.hashCode());
		result = prime * result + ((agreeDate==null)?0:agreeDate.hashCode());
		result = prime * result + ((agreeSdate==null)?0:agreeSdate.hashCode());
		result = prime * result + ((agreeEdate==null)?0:agreeEdate.hashCode());
		result = prime * result + ((agreeDays==null)?0:agreeDays.hashCode());
		result = prime * result + ((rentAmt==null)?0:rentAmt.hashCode());
		result = prime * result + ((vatYn==null)?0:vatYn.hashCode());
		result = prime * result + ((rentSupply==null)?0:rentSupply.hashCode());
		result = prime * result + ((rentVat==null)?0:rentVat.hashCode());
		result = prime * result + ((perpectTag==null)?0:perpectTag.hashCode());
		result = prime * result + ((receiptAmt==null)?0:receiptAmt.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((rentIns==null)?0:rentIns.hashCode());
		result = prime * result + ((slipDate==null)?0:slipDate.hashCode());
		result = prime * result + ((slipSeq==null)?0:slipSeq.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO other = (kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( termChgSeq == null ){
			if ( other.termChgSeq != null ) return false;
		}
		else if ( !termChgSeq.equals(other.termChgSeq) )
			return false;
		if ( counts == null ){
			if ( other.counts != null ) return false;
		}
		else if ( !counts.equals(other.counts) )
			return false;
		if ( agreeDate == null ){
			if ( other.agreeDate != null ) return false;
		}
		else if ( !agreeDate.equals(other.agreeDate) )
			return false;
		if ( agreeSdate == null ){
			if ( other.agreeSdate != null ) return false;
		}
		else if ( !agreeSdate.equals(other.agreeSdate) )
			return false;
		if ( agreeEdate == null ){
			if ( other.agreeEdate != null ) return false;
		}
		else if ( !agreeEdate.equals(other.agreeEdate) )
			return false;
		if ( agreeDays == null ){
			if ( other.agreeDays != null ) return false;
		}
		else if ( !agreeDays.equals(other.agreeDays) )
			return false;
		if ( rentAmt == null ){
			if ( other.rentAmt != null ) return false;
		}
		else if ( !rentAmt.equals(other.rentAmt) )
			return false;
		if ( vatYn == null ){
			if ( other.vatYn != null ) return false;
		}
		else if ( !vatYn.equals(other.vatYn) )
			return false;
		if ( rentSupply == null ){
			if ( other.rentSupply != null ) return false;
		}
		else if ( !rentSupply.equals(other.rentSupply) )
			return false;
		if ( rentVat == null ){
			if ( other.rentVat != null ) return false;
		}
		else if ( !rentVat.equals(other.rentVat) )
			return false;
		if ( perpectTag == null ){
			if ( other.perpectTag != null ) return false;
		}
		else if ( !perpectTag.equals(other.perpectTag) )
			return false;
		if ( receiptAmt == null ){
			if ( other.receiptAmt != null ) return false;
		}
		else if ( !receiptAmt.equals(other.receiptAmt) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( rentIns == null ){
			if ( other.rentIns != null ) return false;
		}
		else if ( !rentIns.equals(other.rentIns) )
			return false;
		if ( slipDate == null ){
			if ( other.slipDate != null ) return false;
		}
		else if ( !slipDate.equals(other.slipDate) )
			return false;
		if ( slipSeq == null ){
			if ( other.slipSeq != null ) return false;
		}
		else if ( !slipSeq.equals(other.slipSeq) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\ttermChgSeq: ");
		sb.append(termChgSeq==null?"null":getTermChgSeq());
		sb.append("\n");
		sb.append("\tcounts: ");
		sb.append(counts==null?"null":getCounts());
		sb.append("\n");
		sb.append("\tagreeDate: ");
		sb.append(agreeDate==null?"null":getAgreeDate());
		sb.append("\n");
		sb.append("\tagreeSdate: ");
		sb.append(agreeSdate==null?"null":getAgreeSdate());
		sb.append("\n");
		sb.append("\tagreeEdate: ");
		sb.append(agreeEdate==null?"null":getAgreeEdate());
		sb.append("\n");
		sb.append("\tagreeDays: ");
		sb.append(agreeDays==null?"null":getAgreeDays());
		sb.append("\n");
		sb.append("\trentAmt: ");
		sb.append(rentAmt==null?"null":getRentAmt());
		sb.append("\n");
		sb.append("\tvatYn: ");
		sb.append(vatYn==null?"null":getVatYn());
		sb.append("\n");
		sb.append("\trentSupply: ");
		sb.append(rentSupply==null?"null":getRentSupply());
		sb.append("\n");
		sb.append("\trentVat: ");
		sb.append(rentVat==null?"null":getRentVat());
		sb.append("\n");
		sb.append("\tperpectTag: ");
		sb.append(perpectTag==null?"null":getPerpectTag());
		sb.append("\n");
		sb.append("\treceiptAmt: ");
		sb.append(receiptAmt==null?"null":getReceiptAmt());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\trentIns: ");
		sb.append(rentIns==null?"null":getRentIns());
		sb.append("\n");
		sb.append("\tslipDate: ");
		sb.append(slipDate==null?"null":getSlipDate());
		sb.append("\n");
		sb.append("\tslipSeq: ");
		sb.append(slipSeq==null?"null":getSlipSeq());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* termChgSeq */
		messageLen+= 2; /* counts */
		messageLen+= 8; /* agreeDate */
		messageLen+= 8; /* agreeSdate */
		messageLen+= 8; /* agreeEdate */
		messageLen+= 22; /* agreeDays */
		messageLen+= 22; /* rentAmt */
		messageLen+= 1; /* vatYn */
		messageLen+= 22; /* rentSupply */
		messageLen+= 22; /* rentVat */
		messageLen+= 1; /* perpectTag */
		messageLen+= 22; /* receiptAmt */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* rentIns */
		messageLen+= 8; /* slipDate */
		messageLen+= 22; /* slipSeq */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("termChgSeq");
	
		fieldNames.add("counts");
	
		fieldNames.add("agreeDate");
	
		fieldNames.add("agreeSdate");
	
		fieldNames.add("agreeEdate");
	
		fieldNames.add("agreeDays");
	
		fieldNames.add("rentAmt");
	
		fieldNames.add("vatYn");
	
		fieldNames.add("rentSupply");
	
		fieldNames.add("rentVat");
	
		fieldNames.add("perpectTag");
	
		fieldNames.add("receiptAmt");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("rentIns");
	
		fieldNames.add("slipDate");
	
		fieldNames.add("slipSeq");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("termChgSeq", get("termChgSeq"));
	
		fieldValueMap.put("counts", get("counts"));
	
		fieldValueMap.put("agreeDate", get("agreeDate"));
	
		fieldValueMap.put("agreeSdate", get("agreeSdate"));
	
		fieldValueMap.put("agreeEdate", get("agreeEdate"));
	
		fieldValueMap.put("agreeDays", get("agreeDays"));
	
		fieldValueMap.put("rentAmt", get("rentAmt"));
	
		fieldValueMap.put("vatYn", get("vatYn"));
	
		fieldValueMap.put("rentSupply", get("rentSupply"));
	
		fieldValueMap.put("rentVat", get("rentVat"));
	
		fieldValueMap.put("perpectTag", get("perpectTag"));
	
		fieldValueMap.put("receiptAmt", get("receiptAmt"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("rentIns", get("rentIns"));
	
		fieldValueMap.put("slipDate", get("slipDate"));
	
		fieldValueMap.put("slipSeq", get("slipSeq"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 1892849641 : /* termChgSeq */
			return getTermChgSeq();
		case -1354575548 : /* counts */
			return getCounts();
		case 974561402 : /* agreeDate */
			return getAgreeDate();
		case 160556885 : /* agreeSdate */
			return getAgreeSdate();
		case 147627591 : /* agreeEdate */
			return getAgreeEdate();
		case 974561571 : /* agreeDays */
			return getAgreeDays();
		case 1092857807 : /* rentAmt */
			return getRentAmt();
		case 111979550 : /* vatYn */
			return getVatYn();
		case 1997529480 : /* rentSupply */
			return getRentSupply();
		case 1092877616 : /* rentVat */
			return getRentVat();
		case 2015609047 : /* perpectTag */
			return getPerpectTag();
		case 204129392 : /* receiptAmt */
			return getReceiptAmt();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 1092865525 : /* rentIns */
			return getRentIns();
		case -1262506738 : /* slipDate */
			return getSlipDate();
		case -2118921473 : /* slipSeq */
			return getSlipSeq();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1892849641 : /* termChgSeq */
			setTermChgSeq((java.math.BigDecimal) value);
			return;
		case -1354575548 : /* counts */
			setCounts((java.lang.String) value);
			return;
		case 974561402 : /* agreeDate */
			setAgreeDate((java.lang.String) value);
			return;
		case 160556885 : /* agreeSdate */
			setAgreeSdate((java.lang.String) value);
			return;
		case 147627591 : /* agreeEdate */
			setAgreeEdate((java.lang.String) value);
			return;
		case 974561571 : /* agreeDays */
			setAgreeDays((java.math.BigDecimal) value);
			return;
		case 1092857807 : /* rentAmt */
			setRentAmt((java.math.BigDecimal) value);
			return;
		case 111979550 : /* vatYn */
			setVatYn((java.lang.String) value);
			return;
		case 1997529480 : /* rentSupply */
			setRentSupply((java.math.BigDecimal) value);
			return;
		case 1092877616 : /* rentVat */
			setRentVat((java.math.BigDecimal) value);
			return;
		case 2015609047 : /* perpectTag */
			setPerpectTag((java.lang.String) value);
			return;
		case 204129392 : /* receiptAmt */
			setReceiptAmt((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 1092865525 : /* rentIns */
			setRentIns((java.math.BigDecimal) value);
			return;
		case -1262506738 : /* slipDate */
			setSlipDate((java.lang.String) value);
			return;
		case -2118921473 : /* slipSeq */
			setSlipSeq((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
