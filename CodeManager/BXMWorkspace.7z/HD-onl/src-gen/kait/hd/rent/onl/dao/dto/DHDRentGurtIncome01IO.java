/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_보증금납입사항 ( HD_RENT_GURT_INCOME )
 */
@XmlType(propOrder={"custCode", "seq", "termChgSeq", "counts", "times", "deptCode", "housetag", "inDate", "inSeq", "depositNo", "receiptDate", "receiptAmt", "delayDays", "delayAmt", "discntDays", "discntAmt", "realincomAmt", "bankCode", "bankName", "payTag", "incomType", "modYn", "realPayTag", "slipDate", "slipSeq", "taxDate", "taxSeq", "slipType", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "vdepositNo", "outDt", "outTm", "outSeq", "outBank", "remark"}, name="DHDRentGurtIncome01IO")
@XmlRootElement(name="DHDRentGurtIncome01IO")
@SuppressWarnings("all")
public class DHDRentGurtIncome01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1110919421L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_보증금납입사항 ( HD_RENT_GURT_INCOME )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012646(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012646(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012646(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012647(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012647(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012647(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012647(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012647(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012647(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << termChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_termChgSeq = false;
	
	protected boolean isSet_termChgSeq()
	{
		return this.isSet_termChgSeq;
	}
	
	protected void setIsSet_termChgSeq(boolean value)
	{
		this.isSet_termChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약차수 [SYS_C0012648(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public void setTermChgSeq(java.lang.String value) {
		isSet_termChgSeq = true;
		this.termChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약차수 [SYS_C0012648(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public void setTermChgSeq(double value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약차수 [SYS_C0012648(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public void setTermChgSeq(long value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약차수 [SYS_C0012648(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal termChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약차수 [SYS_C0012648(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public java.math.BigDecimal getTermChgSeq(){
		return termChgSeq;
	}
	
	/**
	 * @Description 계약차수 [SYS_C0012648(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	@JsonProperty("termChgSeq")
	public void setTermChgSeq( java.math.BigDecimal termChgSeq ) {
		isSet_termChgSeq = true;
		this.termChgSeq = termChgSeq;
	}
	
	/** Property set << termChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << counts >> [[ */
	
	@XmlTransient
	private boolean isSet_counts = false;
	
	protected boolean isSet_counts()
	{
		return this.isSet_counts;
	}
	
	protected void setIsSet_counts(boolean value)
	{
		this.isSet_counts = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정차수 [SYS_C0012649(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String counts  = null;
	
	/**
	 * @Description 약정차수 [SYS_C0012649(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public java.lang.String getCounts(){
		return counts;
	}
	
	/**
	 * @Description 약정차수 [SYS_C0012649(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	@JsonProperty("counts")
	public void setCounts( java.lang.String counts ) {
		isSet_counts = true;
		this.counts = counts;
	}
	
	/** Property set << counts >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << times >> [[ */
	
	@XmlTransient
	private boolean isSet_times = false;
	
	protected boolean isSet_times()
	{
		return this.isSet_times;
	}
	
	protected void setIsSet_times(boolean value)
	{
		this.isSet_times = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="회수 [SYS_C0012650(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float times  = .0F;
	
	/**
	 * @Description 회수 [SYS_C0012650(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	public java.lang.Float getTimes(){
		return times;
	}
	
	/**
	 * @Description 회수 [SYS_C0012650(C),SYS_C0012996(P) SYS_C0012996(UNIQUE)]
	 */
	@JsonProperty("times")
	public void setTimes( java.lang.Float times ) {
		isSet_times = true;
		this.times = times;
	}
	
	/** Property set << times >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inDate = false;
	
	protected boolean isSet_inDate()
	{
		return this.isSet_inDate;
	}
	
	protected void setIsSet_inDate(boolean value)
	{
		this.isSet_inDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String inDate  = null;
	
	/**
	 * @Description 입금일자
	 */
	public java.lang.String getInDate(){
		return inDate;
	}
	
	/**
	 * @Description 입금일자
	 */
	@JsonProperty("inDate")
	public void setInDate( java.lang.String inDate ) {
		isSet_inDate = true;
		this.inDate = inDate;
	}
	
	/** Property set << inDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_inSeq = false;
	
	protected boolean isSet_inSeq()
	{
		return this.isSet_inSeq;
	}
	
	protected void setIsSet_inSeq(boolean value)
	{
		this.isSet_inSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번
	 */
	public void setInSeq(java.lang.String value) {
		isSet_inSeq = true;
		this.inSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번
	 */
	public void setInSeq(double value) {
		isSet_inSeq = true;
		this.inSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번
	 */
	public void setInSeq(long value) {
		isSet_inSeq = true;
		this.inSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번
	 */
	public java.math.BigDecimal getInSeq(){
		return inSeq;
	}
	
	/**
	 * @Description 순번
	 */
	@JsonProperty("inSeq")
	public void setInSeq( java.math.BigDecimal inSeq ) {
		isSet_inSeq = true;
		this.inSeq = inSeq;
	}
	
	/** Property set << inSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptDate >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptDate = false;
	
	protected boolean isSet_receiptDate()
	{
		return this.isSet_receiptDate;
	}
	
	protected void setIsSet_receiptDate(boolean value)
	{
		this.isSet_receiptDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입일자 [SYS_C0012651(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String receiptDate  = null;
	
	/**
	 * @Description 납입일자 [SYS_C0012651(C)]
	 */
	public java.lang.String getReceiptDate(){
		return receiptDate;
	}
	
	/**
	 * @Description 납입일자 [SYS_C0012651(C)]
	 */
	@JsonProperty("receiptDate")
	public void setReceiptDate( java.lang.String receiptDate ) {
		isSet_receiptDate = true;
		this.receiptDate = receiptDate;
	}
	
	/** Property set << receiptDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptAmt = false;
	
	protected boolean isSet_receiptAmt()
	{
		return this.isSet_receiptAmt;
	}
	
	protected void setIsSet_receiptAmt(boolean value)
	{
		this.isSet_receiptAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 납입인정금액 [SYS_C0012652(C)]
	 */
	public void setReceiptAmt(java.lang.String value) {
		isSet_receiptAmt = true;
		this.receiptAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 납입인정금액 [SYS_C0012652(C)]
	 */
	public void setReceiptAmt(double value) {
		isSet_receiptAmt = true;
		this.receiptAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 납입인정금액 [SYS_C0012652(C)]
	 */
	public void setReceiptAmt(long value) {
		isSet_receiptAmt = true;
		this.receiptAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="납입인정금액 [SYS_C0012652(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 납입인정금액 [SYS_C0012652(C)]
	 */
	public java.math.BigDecimal getReceiptAmt(){
		return receiptAmt;
	}
	
	/**
	 * @Description 납입인정금액 [SYS_C0012652(C)]
	 */
	@JsonProperty("receiptAmt")
	public void setReceiptAmt( java.math.BigDecimal receiptAmt ) {
		isSet_receiptAmt = true;
		this.receiptAmt = receiptAmt;
	}
	
	/** Property set << receiptAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayDays >> [[ */
	
	@XmlTransient
	private boolean isSet_delayDays = false;
	
	protected boolean isSet_delayDays()
	{
		return this.isSet_delayDays;
	}
	
	protected void setIsSet_delayDays(boolean value)
	{
		this.isSet_delayDays = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 연체일수 [SYS_C0012653(C)]
	 */
	public void setDelayDays(java.lang.String value) {
		isSet_delayDays = true;
		this.delayDays = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 연체일수 [SYS_C0012653(C)]
	 */
	public void setDelayDays(double value) {
		isSet_delayDays = true;
		this.delayDays = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 연체일수 [SYS_C0012653(C)]
	 */
	public void setDelayDays(long value) {
		isSet_delayDays = true;
		this.delayDays = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="연체일수 [SYS_C0012653(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayDays  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 연체일수 [SYS_C0012653(C)]
	 */
	public java.math.BigDecimal getDelayDays(){
		return delayDays;
	}
	
	/**
	 * @Description 연체일수 [SYS_C0012653(C)]
	 */
	@JsonProperty("delayDays")
	public void setDelayDays( java.math.BigDecimal delayDays ) {
		isSet_delayDays = true;
		this.delayDays = delayDays;
	}
	
	/** Property set << delayDays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_delayAmt = false;
	
	protected boolean isSet_delayAmt()
	{
		return this.isSet_delayAmt;
	}
	
	protected void setIsSet_delayAmt(boolean value)
	{
		this.isSet_delayAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 연체료 [SYS_C0012654(C)]
	 */
	public void setDelayAmt(java.lang.String value) {
		isSet_delayAmt = true;
		this.delayAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 연체료 [SYS_C0012654(C)]
	 */
	public void setDelayAmt(double value) {
		isSet_delayAmt = true;
		this.delayAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 연체료 [SYS_C0012654(C)]
	 */
	public void setDelayAmt(long value) {
		isSet_delayAmt = true;
		this.delayAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="연체료 [SYS_C0012654(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 연체료 [SYS_C0012654(C)]
	 */
	public java.math.BigDecimal getDelayAmt(){
		return delayAmt;
	}
	
	/**
	 * @Description 연체료 [SYS_C0012654(C)]
	 */
	@JsonProperty("delayAmt")
	public void setDelayAmt( java.math.BigDecimal delayAmt ) {
		isSet_delayAmt = true;
		this.delayAmt = delayAmt;
	}
	
	/** Property set << delayAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntDays >> [[ */
	
	@XmlTransient
	private boolean isSet_discntDays = false;
	
	protected boolean isSet_discntDays()
	{
		return this.isSet_discntDays;
	}
	
	protected void setIsSet_discntDays(boolean value)
	{
		this.isSet_discntDays = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 할인일수 [SYS_C0012655(C)]
	 */
	public void setDiscntDays(java.lang.String value) {
		isSet_discntDays = true;
		this.discntDays = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 할인일수 [SYS_C0012655(C)]
	 */
	public void setDiscntDays(double value) {
		isSet_discntDays = true;
		this.discntDays = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 할인일수 [SYS_C0012655(C)]
	 */
	public void setDiscntDays(long value) {
		isSet_discntDays = true;
		this.discntDays = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="할인일수 [SYS_C0012655(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal discntDays  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 할인일수 [SYS_C0012655(C)]
	 */
	public java.math.BigDecimal getDiscntDays(){
		return discntDays;
	}
	
	/**
	 * @Description 할인일수 [SYS_C0012655(C)]
	 */
	@JsonProperty("discntDays")
	public void setDiscntDays( java.math.BigDecimal discntDays ) {
		isSet_discntDays = true;
		this.discntDays = discntDays;
	}
	
	/** Property set << discntDays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_discntAmt = false;
	
	protected boolean isSet_discntAmt()
	{
		return this.isSet_discntAmt;
	}
	
	protected void setIsSet_discntAmt(boolean value)
	{
		this.isSet_discntAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 할인료 [SYS_C0012656(C)]
	 */
	public void setDiscntAmt(java.lang.String value) {
		isSet_discntAmt = true;
		this.discntAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 할인료 [SYS_C0012656(C)]
	 */
	public void setDiscntAmt(double value) {
		isSet_discntAmt = true;
		this.discntAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 할인료 [SYS_C0012656(C)]
	 */
	public void setDiscntAmt(long value) {
		isSet_discntAmt = true;
		this.discntAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="할인료 [SYS_C0012656(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal discntAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 할인료 [SYS_C0012656(C)]
	 */
	public java.math.BigDecimal getDiscntAmt(){
		return discntAmt;
	}
	
	/**
	 * @Description 할인료 [SYS_C0012656(C)]
	 */
	@JsonProperty("discntAmt")
	public void setDiscntAmt( java.math.BigDecimal discntAmt ) {
		isSet_discntAmt = true;
		this.discntAmt = discntAmt;
	}
	
	/** Property set << discntAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realincomAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_realincomAmt = false;
	
	protected boolean isSet_realincomAmt()
	{
		return this.isSet_realincomAmt;
	}
	
	protected void setIsSet_realincomAmt(boolean value)
	{
		this.isSet_realincomAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실납입금액 [SYS_C0012657(C)]
	 */
	public void setRealincomAmt(java.lang.String value) {
		isSet_realincomAmt = true;
		this.realincomAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실납입금액 [SYS_C0012657(C)]
	 */
	public void setRealincomAmt(double value) {
		isSet_realincomAmt = true;
		this.realincomAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실납입금액 [SYS_C0012657(C)]
	 */
	public void setRealincomAmt(long value) {
		isSet_realincomAmt = true;
		this.realincomAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실납입금액 [SYS_C0012657(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal realincomAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실납입금액 [SYS_C0012657(C)]
	 */
	public java.math.BigDecimal getRealincomAmt(){
		return realincomAmt;
	}
	
	/**
	 * @Description 실납입금액 [SYS_C0012657(C)]
	 */
	@JsonProperty("realincomAmt")
	public void setRealincomAmt( java.math.BigDecimal realincomAmt ) {
		isSet_realincomAmt = true;
		this.realincomAmt = realincomAmt;
	}
	
	/** Property set << realincomAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankCode = false;
	
	protected boolean isSet_bankCode()
	{
		return this.isSet_bankCode;
	}
	
	protected void setIsSet_bankCode(boolean value)
	{
		this.isSet_bankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행코드 [SYS_C0012658(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String bankCode  = null;
	
	/**
	 * @Description 은행코드 [SYS_C0012658(C)]
	 */
	public java.lang.String getBankCode(){
		return bankCode;
	}
	
	/**
	 * @Description 은행코드 [SYS_C0012658(C)]
	 */
	@JsonProperty("bankCode")
	public void setBankCode( java.lang.String bankCode ) {
		isSet_bankCode = true;
		this.bankCode = bankCode;
	}
	
	/** Property set << bankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankName >> [[ */
	
	@XmlTransient
	private boolean isSet_bankName = false;
	
	protected boolean isSet_bankName()
	{
		return this.isSet_bankName;
	}
	
	protected void setIsSet_bankName(boolean value)
	{
		this.isSet_bankName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String bankName  = null;
	
	/**
	 * @Description 은행명칭
	 */
	public java.lang.String getBankName(){
		return bankName;
	}
	
	/**
	 * @Description 은행명칭
	 */
	@JsonProperty("bankName")
	public void setBankName( java.lang.String bankName ) {
		isSet_bankName = true;
		this.bankName = bankName;
	}
	
	/** Property set << bankName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << payTag >> [[ */
	
	@XmlTransient
	private boolean isSet_payTag = false;
	
	protected boolean isSet_payTag()
	{
		return this.isSet_payTag;
	}
	
	protected void setIsSet_payTag(boolean value)
	{
		this.isSet_payTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금구분 [SYS_C0012659(C)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String payTag  = null;
	
	/**
	 * @Description 입금구분 [SYS_C0012659(C)]
	 */
	public java.lang.String getPayTag(){
		return payTag;
	}
	
	/**
	 * @Description 입금구분 [SYS_C0012659(C)]
	 */
	@JsonProperty("payTag")
	public void setPayTag( java.lang.String payTag ) {
		isSet_payTag = true;
		this.payTag = payTag;
	}
	
	/** Property set << payTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << incomType >> [[ */
	
	@XmlTransient
	private boolean isSet_incomType = false;
	
	protected boolean isSet_incomType()
	{
		return this.isSet_incomType;
	}
	
	protected void setIsSet_incomType(boolean value)
	{
		this.isSet_incomType = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금형태", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String incomType  = null;
	
	/**
	 * @Description 입금형태
	 */
	public java.lang.String getIncomType(){
		return incomType;
	}
	
	/**
	 * @Description 입금형태
	 */
	@JsonProperty("incomType")
	public void setIncomType( java.lang.String incomType ) {
		isSet_incomType = true;
		this.incomType = incomType;
	}
	
	/** Property set << incomType >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modYn >> [[ */
	
	@XmlTransient
	private boolean isSet_modYn = false;
	
	protected boolean isSet_modYn()
	{
		return this.isSet_modYn;
	}
	
	protected void setIsSet_modYn(boolean value)
	{
		this.isSet_modYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="조정여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String modYn  = null;
	
	/**
	 * @Description 조정여부
	 */
	public java.lang.String getModYn(){
		return modYn;
	}
	
	/**
	 * @Description 조정여부
	 */
	@JsonProperty("modYn")
	public void setModYn( java.lang.String modYn ) {
		isSet_modYn = true;
		this.modYn = modYn;
	}
	
	/** Property set << modYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realPayTag >> [[ */
	
	@XmlTransient
	private boolean isSet_realPayTag = false;
	
	protected boolean isSet_realPayTag()
	{
		return this.isSet_realPayTag;
	}
	
	protected void setIsSet_realPayTag(boolean value)
	{
		this.isSet_realPayTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="실제납입TAG", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String realPayTag  = null;
	
	/**
	 * @Description 실제납입TAG
	 */
	public java.lang.String getRealPayTag(){
		return realPayTag;
	}
	
	/**
	 * @Description 실제납입TAG
	 */
	@JsonProperty("realPayTag")
	public void setRealPayTag( java.lang.String realPayTag ) {
		isSet_realPayTag = true;
		this.realPayTag = realPayTag;
	}
	
	/** Property set << realPayTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipDate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipDate = false;
	
	protected boolean isSet_slipDate()
	{
		return this.isSet_slipDate;
	}
	
	protected void setIsSet_slipDate(boolean value)
	{
		this.isSet_slipDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipDate  = null;
	
	/**
	 * @Description 전표일자
	 */
	public java.lang.String getSlipDate(){
		return slipDate;
	}
	
	/**
	 * @Description 전표일자
	 */
	@JsonProperty("slipDate")
	public void setSlipDate( java.lang.String slipDate ) {
		isSet_slipDate = true;
		this.slipDate = slipDate;
	}
	
	/** Property set << slipDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipSeq = false;
	
	protected boolean isSet_slipSeq()
	{
		return this.isSet_slipSeq;
	}
	
	protected void setIsSet_slipSeq(boolean value)
	{
		this.isSet_slipSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(java.lang.String value) {
		isSet_slipSeq = true;
		this.slipSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(double value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(long value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번
	 */
	public java.math.BigDecimal getSlipSeq(){
		return slipSeq;
	}
	
	/**
	 * @Description 전표순번
	 */
	@JsonProperty("slipSeq")
	public void setSlipSeq( java.math.BigDecimal slipSeq ) {
		isSet_slipSeq = true;
		this.slipSeq = slipSeq;
	}
	
	/** Property set << slipSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << taxDate >> [[ */
	
	@XmlTransient
	private boolean isSet_taxDate = false;
	
	protected boolean isSet_taxDate()
	{
		return this.isSet_taxDate;
	}
	
	protected void setIsSet_taxDate(boolean value)
	{
		this.isSet_taxDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="세금계산서발행일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String taxDate  = null;
	
	/**
	 * @Description 세금계산서발행일자
	 */
	public java.lang.String getTaxDate(){
		return taxDate;
	}
	
	/**
	 * @Description 세금계산서발행일자
	 */
	@JsonProperty("taxDate")
	public void setTaxDate( java.lang.String taxDate ) {
		isSet_taxDate = true;
		this.taxDate = taxDate;
	}
	
	/** Property set << taxDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << taxSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_taxSeq = false;
	
	protected boolean isSet_taxSeq()
	{
		return this.isSet_taxSeq;
	}
	
	protected void setIsSet_taxSeq(boolean value)
	{
		this.isSet_taxSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 세금계산서발행순번
	 */
	public void setTaxSeq(java.lang.String value) {
		isSet_taxSeq = true;
		this.taxSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 세금계산서발행순번
	 */
	public void setTaxSeq(double value) {
		isSet_taxSeq = true;
		this.taxSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 세금계산서발행순번
	 */
	public void setTaxSeq(long value) {
		isSet_taxSeq = true;
		this.taxSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="세금계산서발행순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal taxSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 세금계산서발행순번
	 */
	public java.math.BigDecimal getTaxSeq(){
		return taxSeq;
	}
	
	/**
	 * @Description 세금계산서발행순번
	 */
	@JsonProperty("taxSeq")
	public void setTaxSeq( java.math.BigDecimal taxSeq ) {
		isSet_taxSeq = true;
		this.taxSeq = taxSeq;
	}
	
	/** Property set << taxSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipType >> [[ */
	
	@XmlTransient
	private boolean isSet_slipType = false;
	
	protected boolean isSet_slipType()
	{
		return this.isSet_slipType;
	}
	
	protected void setIsSet_slipType(boolean value)
	{
		this.isSet_slipType = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String slipType  = null;
	
	/**
	 * @Description 전표구분
	 */
	public java.lang.String getSlipType(){
		return slipType;
	}
	
	/**
	 * @Description 전표구분
	 */
	@JsonProperty("slipType")
	public void setSlipType( java.lang.String slipType ) {
		isSet_slipType = true;
		this.slipType = slipType;
	}
	
	/** Property set << slipType >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 변경담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 변경담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 변경일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 변경일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vdepositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_vdepositNo = false;
	
	protected boolean isSet_vdepositNo()
	{
		return this.isSet_vdepositNo;
	}
	
	protected void setIsSet_vdepositNo(boolean value)
	{
		this.isSet_vdepositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String vdepositNo  = null;
	
	/**
	 * @Description 가상계좌
	 */
	public java.lang.String getVdepositNo(){
		return vdepositNo;
	}
	
	/**
	 * @Description 가상계좌
	 */
	@JsonProperty("vdepositNo")
	public void setVdepositNo( java.lang.String vdepositNo ) {
		isSet_vdepositNo = true;
		this.vdepositNo = vdepositNo;
	}
	
	/** Property set << vdepositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outDt >> [[ */
	
	@XmlTransient
	private boolean isSet_outDt = false;
	
	protected boolean isSet_outDt()
	{
		return this.isSet_outDt;
	}
	
	protected void setIsSet_outDt(boolean value)
	{
		this.isSet_outDt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String outDt  = null;
	
	/**
	 * @Description 외부입력일자
	 */
	public java.lang.String getOutDt(){
		return outDt;
	}
	
	/**
	 * @Description 외부입력일자
	 */
	@JsonProperty("outDt")
	public void setOutDt( java.lang.String outDt ) {
		isSet_outDt = true;
		this.outDt = outDt;
	}
	
	/** Property set << outDt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outTm >> [[ */
	
	@XmlTransient
	private boolean isSet_outTm = false;
	
	protected boolean isSet_outTm()
	{
		return this.isSet_outTm;
	}
	
	protected void setIsSet_outTm(boolean value)
	{
		this.isSet_outTm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력시간", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String outTm  = null;
	
	/**
	 * @Description 외부입력시간
	 */
	public java.lang.String getOutTm(){
		return outTm;
	}
	
	/**
	 * @Description 외부입력시간
	 */
	@JsonProperty("outTm")
	public void setOutTm( java.lang.String outTm ) {
		isSet_outTm = true;
		this.outTm = outTm;
	}
	
	/** Property set << outTm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_outSeq = false;
	
	protected boolean isSet_outSeq()
	{
		return this.isSet_outSeq;
	}
	
	protected void setIsSet_outSeq(boolean value)
	{
		this.isSet_outSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float outSeq  = .0F;
	
	/**
	 * @Description 외부입력순번
	 */
	public java.lang.Float getOutSeq(){
		return outSeq;
	}
	
	/**
	 * @Description 외부입력순번
	 */
	@JsonProperty("outSeq")
	public void setOutSeq( java.lang.Float outSeq ) {
		isSet_outSeq = true;
		this.outSeq = outSeq;
	}
	
	/** Property set << outSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outBank >> [[ */
	
	@XmlTransient
	private boolean isSet_outBank = false;
	
	protected boolean isSet_outBank()
	{
		return this.isSet_outBank;
	}
	
	protected void setIsSet_outBank(boolean value)
	{
		this.isSet_outBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력은행", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String outBank  = null;
	
	/**
	 * @Description 외부입력은행
	 */
	public java.lang.String getOutBank(){
		return outBank;
	}
	
	/**
	 * @Description 외부입력은행
	 */
	@JsonProperty("outBank")
	public void setOutBank( java.lang.String outBank ) {
		isSet_outBank = true;
		this.outBank = outBank;
	}
	
	/** Property set << outBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentGurtIncome01IO clone(){
		try{
			DHDRentGurtIncome01IO object= (DHDRentGurtIncome01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.termChgSeq== null ) object.termChgSeq = null;
			else{
				object.termChgSeq = new java.math.BigDecimal(termChgSeq.toString());
			}
			if ( this.counts== null ) object.counts = null;
			else{
				object.counts = this.counts;
			}
			if ( this.times== null ) object.times = null;
			else{
				object.times = this.times;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.inDate== null ) object.inDate = null;
			else{
				object.inDate = this.inDate;
			}
			if ( this.inSeq== null ) object.inSeq = null;
			else{
				object.inSeq = new java.math.BigDecimal(inSeq.toString());
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.receiptDate== null ) object.receiptDate = null;
			else{
				object.receiptDate = this.receiptDate;
			}
			if ( this.receiptAmt== null ) object.receiptAmt = null;
			else{
				object.receiptAmt = new java.math.BigDecimal(receiptAmt.toString());
			}
			if ( this.delayDays== null ) object.delayDays = null;
			else{
				object.delayDays = new java.math.BigDecimal(delayDays.toString());
			}
			if ( this.delayAmt== null ) object.delayAmt = null;
			else{
				object.delayAmt = new java.math.BigDecimal(delayAmt.toString());
			}
			if ( this.discntDays== null ) object.discntDays = null;
			else{
				object.discntDays = new java.math.BigDecimal(discntDays.toString());
			}
			if ( this.discntAmt== null ) object.discntAmt = null;
			else{
				object.discntAmt = new java.math.BigDecimal(discntAmt.toString());
			}
			if ( this.realincomAmt== null ) object.realincomAmt = null;
			else{
				object.realincomAmt = new java.math.BigDecimal(realincomAmt.toString());
			}
			if ( this.bankCode== null ) object.bankCode = null;
			else{
				object.bankCode = this.bankCode;
			}
			if ( this.bankName== null ) object.bankName = null;
			else{
				object.bankName = this.bankName;
			}
			if ( this.payTag== null ) object.payTag = null;
			else{
				object.payTag = this.payTag;
			}
			if ( this.incomType== null ) object.incomType = null;
			else{
				object.incomType = this.incomType;
			}
			if ( this.modYn== null ) object.modYn = null;
			else{
				object.modYn = this.modYn;
			}
			if ( this.realPayTag== null ) object.realPayTag = null;
			else{
				object.realPayTag = this.realPayTag;
			}
			if ( this.slipDate== null ) object.slipDate = null;
			else{
				object.slipDate = this.slipDate;
			}
			if ( this.slipSeq== null ) object.slipSeq = null;
			else{
				object.slipSeq = new java.math.BigDecimal(slipSeq.toString());
			}
			if ( this.taxDate== null ) object.taxDate = null;
			else{
				object.taxDate = this.taxDate;
			}
			if ( this.taxSeq== null ) object.taxSeq = null;
			else{
				object.taxSeq = new java.math.BigDecimal(taxSeq.toString());
			}
			if ( this.slipType== null ) object.slipType = null;
			else{
				object.slipType = this.slipType;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.vdepositNo== null ) object.vdepositNo = null;
			else{
				object.vdepositNo = this.vdepositNo;
			}
			if ( this.outDt== null ) object.outDt = null;
			else{
				object.outDt = this.outDt;
			}
			if ( this.outTm== null ) object.outTm = null;
			else{
				object.outTm = this.outTm;
			}
			if ( this.outSeq== null ) object.outSeq = null;
			else{
				object.outSeq = this.outSeq;
			}
			if ( this.outBank== null ) object.outBank = null;
			else{
				object.outBank = this.outBank;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((termChgSeq==null)?0:termChgSeq.hashCode());
		result = prime * result + ((counts==null)?0:counts.hashCode());
		result = prime * result + ((times==null)?0:times.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((inDate==null)?0:inDate.hashCode());
		result = prime * result + ((inSeq==null)?0:inSeq.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((receiptDate==null)?0:receiptDate.hashCode());
		result = prime * result + ((receiptAmt==null)?0:receiptAmt.hashCode());
		result = prime * result + ((delayDays==null)?0:delayDays.hashCode());
		result = prime * result + ((delayAmt==null)?0:delayAmt.hashCode());
		result = prime * result + ((discntDays==null)?0:discntDays.hashCode());
		result = prime * result + ((discntAmt==null)?0:discntAmt.hashCode());
		result = prime * result + ((realincomAmt==null)?0:realincomAmt.hashCode());
		result = prime * result + ((bankCode==null)?0:bankCode.hashCode());
		result = prime * result + ((bankName==null)?0:bankName.hashCode());
		result = prime * result + ((payTag==null)?0:payTag.hashCode());
		result = prime * result + ((incomType==null)?0:incomType.hashCode());
		result = prime * result + ((modYn==null)?0:modYn.hashCode());
		result = prime * result + ((realPayTag==null)?0:realPayTag.hashCode());
		result = prime * result + ((slipDate==null)?0:slipDate.hashCode());
		result = prime * result + ((slipSeq==null)?0:slipSeq.hashCode());
		result = prime * result + ((taxDate==null)?0:taxDate.hashCode());
		result = prime * result + ((taxSeq==null)?0:taxSeq.hashCode());
		result = prime * result + ((slipType==null)?0:slipType.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((vdepositNo==null)?0:vdepositNo.hashCode());
		result = prime * result + ((outDt==null)?0:outDt.hashCode());
		result = prime * result + ((outTm==null)?0:outTm.hashCode());
		result = prime * result + ((outSeq==null)?0:outSeq.hashCode());
		result = prime * result + ((outBank==null)?0:outBank.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentGurtIncome01IO other = (kait.hd.rent.onl.dao.dto.DHDRentGurtIncome01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( termChgSeq == null ){
			if ( other.termChgSeq != null ) return false;
		}
		else if ( !termChgSeq.equals(other.termChgSeq) )
			return false;
		if ( counts == null ){
			if ( other.counts != null ) return false;
		}
		else if ( !counts.equals(other.counts) )
			return false;
		if ( times == null ){
			if ( other.times != null ) return false;
		}
		else if ( !times.equals(other.times) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( inDate == null ){
			if ( other.inDate != null ) return false;
		}
		else if ( !inDate.equals(other.inDate) )
			return false;
		if ( inSeq == null ){
			if ( other.inSeq != null ) return false;
		}
		else if ( !inSeq.equals(other.inSeq) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( receiptDate == null ){
			if ( other.receiptDate != null ) return false;
		}
		else if ( !receiptDate.equals(other.receiptDate) )
			return false;
		if ( receiptAmt == null ){
			if ( other.receiptAmt != null ) return false;
		}
		else if ( !receiptAmt.equals(other.receiptAmt) )
			return false;
		if ( delayDays == null ){
			if ( other.delayDays != null ) return false;
		}
		else if ( !delayDays.equals(other.delayDays) )
			return false;
		if ( delayAmt == null ){
			if ( other.delayAmt != null ) return false;
		}
		else if ( !delayAmt.equals(other.delayAmt) )
			return false;
		if ( discntDays == null ){
			if ( other.discntDays != null ) return false;
		}
		else if ( !discntDays.equals(other.discntDays) )
			return false;
		if ( discntAmt == null ){
			if ( other.discntAmt != null ) return false;
		}
		else if ( !discntAmt.equals(other.discntAmt) )
			return false;
		if ( realincomAmt == null ){
			if ( other.realincomAmt != null ) return false;
		}
		else if ( !realincomAmt.equals(other.realincomAmt) )
			return false;
		if ( bankCode == null ){
			if ( other.bankCode != null ) return false;
		}
		else if ( !bankCode.equals(other.bankCode) )
			return false;
		if ( bankName == null ){
			if ( other.bankName != null ) return false;
		}
		else if ( !bankName.equals(other.bankName) )
			return false;
		if ( payTag == null ){
			if ( other.payTag != null ) return false;
		}
		else if ( !payTag.equals(other.payTag) )
			return false;
		if ( incomType == null ){
			if ( other.incomType != null ) return false;
		}
		else if ( !incomType.equals(other.incomType) )
			return false;
		if ( modYn == null ){
			if ( other.modYn != null ) return false;
		}
		else if ( !modYn.equals(other.modYn) )
			return false;
		if ( realPayTag == null ){
			if ( other.realPayTag != null ) return false;
		}
		else if ( !realPayTag.equals(other.realPayTag) )
			return false;
		if ( slipDate == null ){
			if ( other.slipDate != null ) return false;
		}
		else if ( !slipDate.equals(other.slipDate) )
			return false;
		if ( slipSeq == null ){
			if ( other.slipSeq != null ) return false;
		}
		else if ( !slipSeq.equals(other.slipSeq) )
			return false;
		if ( taxDate == null ){
			if ( other.taxDate != null ) return false;
		}
		else if ( !taxDate.equals(other.taxDate) )
			return false;
		if ( taxSeq == null ){
			if ( other.taxSeq != null ) return false;
		}
		else if ( !taxSeq.equals(other.taxSeq) )
			return false;
		if ( slipType == null ){
			if ( other.slipType != null ) return false;
		}
		else if ( !slipType.equals(other.slipType) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( vdepositNo == null ){
			if ( other.vdepositNo != null ) return false;
		}
		else if ( !vdepositNo.equals(other.vdepositNo) )
			return false;
		if ( outDt == null ){
			if ( other.outDt != null ) return false;
		}
		else if ( !outDt.equals(other.outDt) )
			return false;
		if ( outTm == null ){
			if ( other.outTm != null ) return false;
		}
		else if ( !outTm.equals(other.outTm) )
			return false;
		if ( outSeq == null ){
			if ( other.outSeq != null ) return false;
		}
		else if ( !outSeq.equals(other.outSeq) )
			return false;
		if ( outBank == null ){
			if ( other.outBank != null ) return false;
		}
		else if ( !outBank.equals(other.outBank) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentGurtIncome01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\ttermChgSeq: ");
		sb.append(termChgSeq==null?"null":getTermChgSeq());
		sb.append("\n");
		sb.append("\tcounts: ");
		sb.append(counts==null?"null":getCounts());
		sb.append("\n");
		sb.append("\ttimes: ");
		sb.append(times==null?"null":getTimes());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tinDate: ");
		sb.append(inDate==null?"null":getInDate());
		sb.append("\n");
		sb.append("\tinSeq: ");
		sb.append(inSeq==null?"null":getInSeq());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\treceiptDate: ");
		sb.append(receiptDate==null?"null":getReceiptDate());
		sb.append("\n");
		sb.append("\treceiptAmt: ");
		sb.append(receiptAmt==null?"null":getReceiptAmt());
		sb.append("\n");
		sb.append("\tdelayDays: ");
		sb.append(delayDays==null?"null":getDelayDays());
		sb.append("\n");
		sb.append("\tdelayAmt: ");
		sb.append(delayAmt==null?"null":getDelayAmt());
		sb.append("\n");
		sb.append("\tdiscntDays: ");
		sb.append(discntDays==null?"null":getDiscntDays());
		sb.append("\n");
		sb.append("\tdiscntAmt: ");
		sb.append(discntAmt==null?"null":getDiscntAmt());
		sb.append("\n");
		sb.append("\trealincomAmt: ");
		sb.append(realincomAmt==null?"null":getRealincomAmt());
		sb.append("\n");
		sb.append("\tbankCode: ");
		sb.append(bankCode==null?"null":getBankCode());
		sb.append("\n");
		sb.append("\tbankName: ");
		sb.append(bankName==null?"null":getBankName());
		sb.append("\n");
		sb.append("\tpayTag: ");
		sb.append(payTag==null?"null":getPayTag());
		sb.append("\n");
		sb.append("\tincomType: ");
		sb.append(incomType==null?"null":getIncomType());
		sb.append("\n");
		sb.append("\tmodYn: ");
		sb.append(modYn==null?"null":getModYn());
		sb.append("\n");
		sb.append("\trealPayTag: ");
		sb.append(realPayTag==null?"null":getRealPayTag());
		sb.append("\n");
		sb.append("\tslipDate: ");
		sb.append(slipDate==null?"null":getSlipDate());
		sb.append("\n");
		sb.append("\tslipSeq: ");
		sb.append(slipSeq==null?"null":getSlipSeq());
		sb.append("\n");
		sb.append("\ttaxDate: ");
		sb.append(taxDate==null?"null":getTaxDate());
		sb.append("\n");
		sb.append("\ttaxSeq: ");
		sb.append(taxSeq==null?"null":getTaxSeq());
		sb.append("\n");
		sb.append("\tslipType: ");
		sb.append(slipType==null?"null":getSlipType());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tvdepositNo: ");
		sb.append(vdepositNo==null?"null":getVdepositNo());
		sb.append("\n");
		sb.append("\toutDt: ");
		sb.append(outDt==null?"null":getOutDt());
		sb.append("\n");
		sb.append("\toutTm: ");
		sb.append(outTm==null?"null":getOutTm());
		sb.append("\n");
		sb.append("\toutSeq: ");
		sb.append(outSeq==null?"null":getOutSeq());
		sb.append("\n");
		sb.append("\toutBank: ");
		sb.append(outBank==null?"null":getOutBank());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* termChgSeq */
		messageLen+= 2; /* counts */
		messageLen+= 22; /* times */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 8; /* inDate */
		messageLen+= 22; /* inSeq */
		messageLen+= 30; /* depositNo */
		messageLen+= 8; /* receiptDate */
		messageLen+= 22; /* receiptAmt */
		messageLen+= 22; /* delayDays */
		messageLen+= 22; /* delayAmt */
		messageLen+= 22; /* discntDays */
		messageLen+= 22; /* discntAmt */
		messageLen+= 22; /* realincomAmt */
		messageLen+= 8; /* bankCode */
		messageLen+= 30; /* bankName */
		messageLen+= 2; /* payTag */
		messageLen+= 2; /* incomType */
		messageLen+= 1; /* modYn */
		messageLen+= 1; /* realPayTag */
		messageLen+= 8; /* slipDate */
		messageLen+= 22; /* slipSeq */
		messageLen+= 8; /* taxDate */
		messageLen+= 22; /* taxSeq */
		messageLen+= 1; /* slipType */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 30; /* vdepositNo */
		messageLen+= 8; /* outDt */
		messageLen+= 6; /* outTm */
		messageLen+= 22; /* outSeq */
		messageLen+= 6; /* outBank */
		messageLen+= 200; /* remark */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("termChgSeq");
	
		fieldNames.add("counts");
	
		fieldNames.add("times");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("inDate");
	
		fieldNames.add("inSeq");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("receiptDate");
	
		fieldNames.add("receiptAmt");
	
		fieldNames.add("delayDays");
	
		fieldNames.add("delayAmt");
	
		fieldNames.add("discntDays");
	
		fieldNames.add("discntAmt");
	
		fieldNames.add("realincomAmt");
	
		fieldNames.add("bankCode");
	
		fieldNames.add("bankName");
	
		fieldNames.add("payTag");
	
		fieldNames.add("incomType");
	
		fieldNames.add("modYn");
	
		fieldNames.add("realPayTag");
	
		fieldNames.add("slipDate");
	
		fieldNames.add("slipSeq");
	
		fieldNames.add("taxDate");
	
		fieldNames.add("taxSeq");
	
		fieldNames.add("slipType");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("vdepositNo");
	
		fieldNames.add("outDt");
	
		fieldNames.add("outTm");
	
		fieldNames.add("outSeq");
	
		fieldNames.add("outBank");
	
		fieldNames.add("remark");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("termChgSeq", get("termChgSeq"));
	
		fieldValueMap.put("counts", get("counts"));
	
		fieldValueMap.put("times", get("times"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("inDate", get("inDate"));
	
		fieldValueMap.put("inSeq", get("inSeq"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("receiptDate", get("receiptDate"));
	
		fieldValueMap.put("receiptAmt", get("receiptAmt"));
	
		fieldValueMap.put("delayDays", get("delayDays"));
	
		fieldValueMap.put("delayAmt", get("delayAmt"));
	
		fieldValueMap.put("discntDays", get("discntDays"));
	
		fieldValueMap.put("discntAmt", get("discntAmt"));
	
		fieldValueMap.put("realincomAmt", get("realincomAmt"));
	
		fieldValueMap.put("bankCode", get("bankCode"));
	
		fieldValueMap.put("bankName", get("bankName"));
	
		fieldValueMap.put("payTag", get("payTag"));
	
		fieldValueMap.put("incomType", get("incomType"));
	
		fieldValueMap.put("modYn", get("modYn"));
	
		fieldValueMap.put("realPayTag", get("realPayTag"));
	
		fieldValueMap.put("slipDate", get("slipDate"));
	
		fieldValueMap.put("slipSeq", get("slipSeq"));
	
		fieldValueMap.put("taxDate", get("taxDate"));
	
		fieldValueMap.put("taxSeq", get("taxSeq"));
	
		fieldValueMap.put("slipType", get("slipType"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("vdepositNo", get("vdepositNo"));
	
		fieldValueMap.put("outDt", get("outDt"));
	
		fieldValueMap.put("outTm", get("outTm"));
	
		fieldValueMap.put("outSeq", get("outSeq"));
	
		fieldValueMap.put("outBank", get("outBank"));
	
		fieldValueMap.put("remark", get("remark"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 1892849641 : /* termChgSeq */
			return getTermChgSeq();
		case -1354575548 : /* counts */
			return getCounts();
		case 110364486 : /* times */
			return getTimes();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -1185196429 : /* inDate */
			return getInDate();
		case 100329722 : /* inSeq */
			return getInSeq();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 2033121798 : /* receiptDate */
			return getReceiptDate();
		case 204129392 : /* receiptAmt */
			return getReceiptAmt();
		case -469588870 : /* delayDays */
			return getDelayDays();
		case 816133445 : /* delayAmt */
			return getDelayAmt();
		case 506063122 : /* discntDays */
			return getDiscntDays();
		case -122225235 : /* discntAmt */
			return getDiscntAmt();
		case 1301298570 : /* realincomAmt */
			return getRealincomAmt();
		case -1859605943 : /* bankCode */
			return getBankCode();
		case -1859291417 : /* bankName */
			return getBankName();
		case -995232302 : /* payTag */
			return getPayTag();
		case -1418876010 : /* incomType */
			return getIncomType();
		case 104069559 : /* modYn */
			return getModYn();
		case -2093347568 : /* realPayTag */
			return getRealPayTag();
		case -1262506738 : /* slipDate */
			return getSlipDate();
		case -2118921473 : /* slipSeq */
			return getSlipSeq();
		case -1533782535 : /* taxDate */
			return getTaxDate();
		case -880746316 : /* taxSeq */
			return getTaxSeq();
		case -1262007142 : /* slipType */
			return getSlipType();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 1763054921 : /* vdepositNo */
			return getVdepositNo();
		case 106110078 : /* outDt */
			return getOutDt();
		case 106110567 : /* outTm */
			return getOutTm();
		case -1005540815 : /* outSeq */
			return getOutSeq();
		case -1107504470 : /* outBank */
			return getOutBank();
		case -934624384 : /* remark */
			return getRemark();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1892849641 : /* termChgSeq */
			setTermChgSeq((java.math.BigDecimal) value);
			return;
		case -1354575548 : /* counts */
			setCounts((java.lang.String) value);
			return;
		case 110364486 : /* times */
			setTimes((java.lang.Float) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -1185196429 : /* inDate */
			setInDate((java.lang.String) value);
			return;
		case 100329722 : /* inSeq */
			setInSeq((java.math.BigDecimal) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 2033121798 : /* receiptDate */
			setReceiptDate((java.lang.String) value);
			return;
		case 204129392 : /* receiptAmt */
			setReceiptAmt((java.math.BigDecimal) value);
			return;
		case -469588870 : /* delayDays */
			setDelayDays((java.math.BigDecimal) value);
			return;
		case 816133445 : /* delayAmt */
			setDelayAmt((java.math.BigDecimal) value);
			return;
		case 506063122 : /* discntDays */
			setDiscntDays((java.math.BigDecimal) value);
			return;
		case -122225235 : /* discntAmt */
			setDiscntAmt((java.math.BigDecimal) value);
			return;
		case 1301298570 : /* realincomAmt */
			setRealincomAmt((java.math.BigDecimal) value);
			return;
		case -1859605943 : /* bankCode */
			setBankCode((java.lang.String) value);
			return;
		case -1859291417 : /* bankName */
			setBankName((java.lang.String) value);
			return;
		case -995232302 : /* payTag */
			setPayTag((java.lang.String) value);
			return;
		case -1418876010 : /* incomType */
			setIncomType((java.lang.String) value);
			return;
		case 104069559 : /* modYn */
			setModYn((java.lang.String) value);
			return;
		case -2093347568 : /* realPayTag */
			setRealPayTag((java.lang.String) value);
			return;
		case -1262506738 : /* slipDate */
			setSlipDate((java.lang.String) value);
			return;
		case -2118921473 : /* slipSeq */
			setSlipSeq((java.math.BigDecimal) value);
			return;
		case -1533782535 : /* taxDate */
			setTaxDate((java.lang.String) value);
			return;
		case -880746316 : /* taxSeq */
			setTaxSeq((java.math.BigDecimal) value);
			return;
		case -1262007142 : /* slipType */
			setSlipType((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 1763054921 : /* vdepositNo */
			setVdepositNo((java.lang.String) value);
			return;
		case 106110078 : /* outDt */
			setOutDt((java.lang.String) value);
			return;
		case 106110567 : /* outTm */
			setOutTm((java.lang.String) value);
			return;
		case -1005540815 : /* outSeq */
			setOutSeq((java.lang.Float) value);
			return;
		case -1107504470 : /* outBank */
			setOutBank((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
