/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_임대대장 ( HD_RENT_MASTER )
 */
@XmlType(propOrder={"custCode", "seq", "deptCode", "housetag", "buildno", "houseno", "custName", "contDate", "contNo", "contType", "vatYn", "guaranteeAmt", "rentSupply", "rentVat", "rentSdate", "rentEdate", "realCustName", "realInDate", "changeTag", "changeDate", "lastChangeDate", "rentChgSeq", "termChgSeq", "relaCustcode", "relaSeq", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "renthdYn", "renthdSeq", "daymonthTag", "fixrateTag", "virYn", "vdeposit", "rentIns", "fixrate", "fixrate2", "fixrateDay", "hopeHouseTag", "returnYn", "returnDate", "rGurtamt", "rRentamt", "rDelayamt", "rPenaltyamt", "rEtcamt1", "rEtcamt2", "rEtcamt3", "returnAmt", "slipDate", "slipSeq", "housecontamt", "rBank", "rDeposit", "rDepositor", "slipSeq2"}, name="DHDRentMaster01IO")
@XmlRootElement(name="DHDRentMaster01IO")
@SuppressWarnings("all")
public class DHDRentMaster01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 940854246L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_임대대장 ( HD_RENT_MASTER )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012705(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012705(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012705(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012706(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012706(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012706(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012706(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012706(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012706(C),SYS_C0013003(P) SYS_C0013003(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custName >> [[ */
	
	@XmlTransient
	private boolean isSet_custName = false;
	
	protected boolean isSet_custName()
	{
		return this.isSet_custName;
	}
	
	protected void setIsSet_custName(boolean value)
	{
		this.isSet_custName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객명", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String custName  = null;
	
	/**
	 * @Description 고객명
	 */
	public java.lang.String getCustName(){
		return custName;
	}
	
	/**
	 * @Description 고객명
	 */
	@JsonProperty("custName")
	public void setCustName( java.lang.String custName ) {
		isSet_custName = true;
		this.custName = custName;
	}
	
	/** Property set << custName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contDate >> [[ */
	
	@XmlTransient
	private boolean isSet_contDate = false;
	
	protected boolean isSet_contDate()
	{
		return this.isSet_contDate;
	}
	
	protected void setIsSet_contDate(boolean value)
	{
		this.isSet_contDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약일자 [SYS_C0012707(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String contDate  = null;
	
	/**
	 * @Description 계약일자 [SYS_C0012707(C)]
	 */
	public java.lang.String getContDate(){
		return contDate;
	}
	
	/**
	 * @Description 계약일자 [SYS_C0012707(C)]
	 */
	@JsonProperty("contDate")
	public void setContDate( java.lang.String contDate ) {
		isSet_contDate = true;
		this.contDate = contDate;
	}
	
	/** Property set << contDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contNo >> [[ */
	
	@XmlTransient
	private boolean isSet_contNo = false;
	
	protected boolean isSet_contNo()
	{
		return this.isSet_contNo;
	}
	
	protected void setIsSet_contNo(boolean value)
	{
		this.isSet_contNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약번호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String contNo  = null;
	
	/**
	 * @Description 계약번호
	 */
	public java.lang.String getContNo(){
		return contNo;
	}
	
	/**
	 * @Description 계약번호
	 */
	@JsonProperty("contNo")
	public void setContNo( java.lang.String contNo ) {
		isSet_contNo = true;
		this.contNo = contNo;
	}
	
	/** Property set << contNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contType >> [[ */
	
	@XmlTransient
	private boolean isSet_contType = false;
	
	protected boolean isSet_contType()
	{
		return this.isSet_contType;
	}
	
	protected void setIsSet_contType(boolean value)
	{
		this.isSet_contType = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약종류", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String contType  = null;
	
	/**
	 * @Description 계약종류
	 */
	public java.lang.String getContType(){
		return contType;
	}
	
	/**
	 * @Description 계약종류
	 */
	@JsonProperty("contType")
	public void setContType( java.lang.String contType ) {
		isSet_contType = true;
		this.contType = contType;
	}
	
	/** Property set << contType >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vatYn >> [[ */
	
	@XmlTransient
	private boolean isSet_vatYn = false;
	
	protected boolean isSet_vatYn()
	{
		return this.isSet_vatYn;
	}
	
	protected void setIsSet_vatYn(boolean value)
	{
		this.isSet_vatYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String vatYn  = null;
	
	/**
	 * @Description 부가세여부
	 */
	public java.lang.String getVatYn(){
		return vatYn;
	}
	
	/**
	 * @Description 부가세여부
	 */
	@JsonProperty("vatYn")
	public void setVatYn( java.lang.String vatYn ) {
		isSet_vatYn = true;
		this.vatYn = vatYn;
	}
	
	/** Property set << vatYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << guaranteeAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_guaranteeAmt = false;
	
	protected boolean isSet_guaranteeAmt()
	{
		return this.isSet_guaranteeAmt;
	}
	
	protected void setIsSet_guaranteeAmt(boolean value)
	{
		this.isSet_guaranteeAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대보증금
	 */
	public void setGuaranteeAmt(java.lang.String value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대보증금
	 */
	public void setGuaranteeAmt(double value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대보증금
	 */
	public void setGuaranteeAmt(long value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대보증금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal guaranteeAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대보증금
	 */
	public java.math.BigDecimal getGuaranteeAmt(){
		return guaranteeAmt;
	}
	
	/**
	 * @Description 임대보증금
	 */
	@JsonProperty("guaranteeAmt")
	public void setGuaranteeAmt( java.math.BigDecimal guaranteeAmt ) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = guaranteeAmt;
	}
	
	/** Property set << guaranteeAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentSupply >> [[ */
	
	@XmlTransient
	private boolean isSet_rentSupply = false;
	
	protected boolean isSet_rentSupply()
	{
		return this.isSet_rentSupply;
	}
	
	protected void setIsSet_rentSupply(boolean value)
	{
		this.isSet_rentSupply = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(java.lang.String value) {
		isSet_rentSupply = true;
		this.rentSupply = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(double value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료공급가
	 */
	public void setRentSupply(long value) {
		isSet_rentSupply = true;
		this.rentSupply = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료공급가", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentSupply  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료공급가
	 */
	public java.math.BigDecimal getRentSupply(){
		return rentSupply;
	}
	
	/**
	 * @Description 임대료공급가
	 */
	@JsonProperty("rentSupply")
	public void setRentSupply( java.math.BigDecimal rentSupply ) {
		isSet_rentSupply = true;
		this.rentSupply = rentSupply;
	}
	
	/** Property set << rentSupply >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentVat >> [[ */
	
	@XmlTransient
	private boolean isSet_rentVat = false;
	
	protected boolean isSet_rentVat()
	{
		return this.isSet_rentVat;
	}
	
	protected void setIsSet_rentVat(boolean value)
	{
		this.isSet_rentVat = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(java.lang.String value) {
		isSet_rentVat = true;
		this.rentVat = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(double value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료부가세
	 */
	public void setRentVat(long value) {
		isSet_rentVat = true;
		this.rentVat = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료부가세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentVat  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료부가세
	 */
	public java.math.BigDecimal getRentVat(){
		return rentVat;
	}
	
	/**
	 * @Description 임대료부가세
	 */
	@JsonProperty("rentVat")
	public void setRentVat( java.math.BigDecimal rentVat ) {
		isSet_rentVat = true;
		this.rentVat = rentVat;
	}
	
	/** Property set << rentVat >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_rentSdate = false;
	
	protected boolean isSet_rentSdate()
	{
		return this.isSet_rentSdate;
	}
	
	protected void setIsSet_rentSdate(boolean value)
	{
		this.isSet_rentSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대시작일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String rentSdate  = null;
	
	/**
	 * @Description 임대시작일
	 */
	public java.lang.String getRentSdate(){
		return rentSdate;
	}
	
	/**
	 * @Description 임대시작일
	 */
	@JsonProperty("rentSdate")
	public void setRentSdate( java.lang.String rentSdate ) {
		isSet_rentSdate = true;
		this.rentSdate = rentSdate;
	}
	
	/** Property set << rentSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentEdate >> [[ */
	
	@XmlTransient
	private boolean isSet_rentEdate = false;
	
	protected boolean isSet_rentEdate()
	{
		return this.isSet_rentEdate;
	}
	
	protected void setIsSet_rentEdate(boolean value)
	{
		this.isSet_rentEdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대종료일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String rentEdate  = null;
	
	/**
	 * @Description 임대종료일
	 */
	public java.lang.String getRentEdate(){
		return rentEdate;
	}
	
	/**
	 * @Description 임대종료일
	 */
	@JsonProperty("rentEdate")
	public void setRentEdate( java.lang.String rentEdate ) {
		isSet_rentEdate = true;
		this.rentEdate = rentEdate;
	}
	
	/** Property set << rentEdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realCustName >> [[ */
	
	@XmlTransient
	private boolean isSet_realCustName = false;
	
	protected boolean isSet_realCustName()
	{
		return this.isSet_realCustName;
	}
	
	protected void setIsSet_realCustName(boolean value)
	{
		this.isSet_realCustName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="실거주자", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String realCustName  = null;
	
	/**
	 * @Description 실거주자
	 */
	public java.lang.String getRealCustName(){
		return realCustName;
	}
	
	/**
	 * @Description 실거주자
	 */
	@JsonProperty("realCustName")
	public void setRealCustName( java.lang.String realCustName ) {
		isSet_realCustName = true;
		this.realCustName = realCustName;
	}
	
	/** Property set << realCustName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realInDate >> [[ */
	
	@XmlTransient
	private boolean isSet_realInDate = false;
	
	protected boolean isSet_realInDate()
	{
		return this.isSet_realInDate;
	}
	
	protected void setIsSet_realInDate(boolean value)
	{
		this.isSet_realInDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="실입주일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String realInDate  = null;
	
	/**
	 * @Description 실입주일
	 */
	public java.lang.String getRealInDate(){
		return realInDate;
	}
	
	/**
	 * @Description 실입주일
	 */
	@JsonProperty("realInDate")
	public void setRealInDate( java.lang.String realInDate ) {
		isSet_realInDate = true;
		this.realInDate = realInDate;
	}
	
	/** Property set << realInDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changeTag >> [[ */
	
	@XmlTransient
	private boolean isSet_changeTag = false;
	
	protected boolean isSet_changeTag()
	{
		return this.isSet_changeTag;
	}
	
	protected void setIsSet_changeTag(boolean value)
	{
		this.isSet_changeTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String changeTag  = null;
	
	/**
	 * @Description 변경구분
	 */
	public java.lang.String getChangeTag(){
		return changeTag;
	}
	
	/**
	 * @Description 변경구분
	 */
	@JsonProperty("changeTag")
	public void setChangeTag( java.lang.String changeTag ) {
		isSet_changeTag = true;
		this.changeTag = changeTag;
	}
	
	/** Property set << changeTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_changeDate = false;
	
	protected boolean isSet_changeDate()
	{
		return this.isSet_changeDate;
	}
	
	protected void setIsSet_changeDate(boolean value)
	{
		this.isSet_changeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String changeDate  = null;
	
	/**
	 * @Description 변경일
	 */
	public java.lang.String getChangeDate(){
		return changeDate;
	}
	
	/**
	 * @Description 변경일
	 */
	@JsonProperty("changeDate")
	public void setChangeDate( java.lang.String changeDate ) {
		isSet_changeDate = true;
		this.changeDate = changeDate;
	}
	
	/** Property set << changeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << lastChangeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_lastChangeDate = false;
	
	protected boolean isSet_lastChangeDate()
	{
		return this.isSet_lastChangeDate;
	}
	
	protected void setIsSet_lastChangeDate(boolean value)
	{
		this.isSet_lastChangeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경계약일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String lastChangeDate  = null;
	
	/**
	 * @Description 변경계약일
	 */
	public java.lang.String getLastChangeDate(){
		return lastChangeDate;
	}
	
	/**
	 * @Description 변경계약일
	 */
	@JsonProperty("lastChangeDate")
	public void setLastChangeDate( java.lang.String lastChangeDate ) {
		isSet_lastChangeDate = true;
		this.lastChangeDate = lastChangeDate;
	}
	
	/** Property set << lastChangeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_rentChgSeq = false;
	
	protected boolean isSet_rentChgSeq()
	{
		return this.isSet_rentChgSeq;
	}
	
	protected void setIsSet_rentChgSeq(boolean value)
	{
		this.isSet_rentChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료변경차수
	 */
	public void setRentChgSeq(java.lang.String value) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료변경차수
	 */
	public void setRentChgSeq(double value) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료변경차수
	 */
	public void setRentChgSeq(long value) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료변경차수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료변경차수
	 */
	public java.math.BigDecimal getRentChgSeq(){
		return rentChgSeq;
	}
	
	/**
	 * @Description 임대료변경차수
	 */
	@JsonProperty("rentChgSeq")
	public void setRentChgSeq( java.math.BigDecimal rentChgSeq ) {
		isSet_rentChgSeq = true;
		this.rentChgSeq = rentChgSeq;
	}
	
	/** Property set << rentChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << termChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_termChgSeq = false;
	
	protected boolean isSet_termChgSeq()
	{
		return this.isSet_termChgSeq;
	}
	
	protected void setIsSet_termChgSeq(boolean value)
	{
		this.isSet_termChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대기간변경차수
	 */
	public void setTermChgSeq(java.lang.String value) {
		isSet_termChgSeq = true;
		this.termChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대기간변경차수
	 */
	public void setTermChgSeq(double value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대기간변경차수
	 */
	public void setTermChgSeq(long value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대기간변경차수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal termChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대기간변경차수
	 */
	public java.math.BigDecimal getTermChgSeq(){
		return termChgSeq;
	}
	
	/**
	 * @Description 임대기간변경차수
	 */
	@JsonProperty("termChgSeq")
	public void setTermChgSeq( java.math.BigDecimal termChgSeq ) {
		isSet_termChgSeq = true;
		this.termChgSeq = termChgSeq;
	}
	
	/** Property set << termChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << relaCustcode >> [[ */
	
	@XmlTransient
	private boolean isSet_relaCustcode = false;
	
	protected boolean isSet_relaCustcode()
	{
		return this.isSet_relaCustcode;
	}
	
	protected void setIsSet_relaCustcode(boolean value)
	{
		this.isSet_relaCustcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연계고객코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String relaCustcode  = null;
	
	/**
	 * @Description 연계고객코드
	 */
	public java.lang.String getRelaCustcode(){
		return relaCustcode;
	}
	
	/**
	 * @Description 연계고객코드
	 */
	@JsonProperty("relaCustcode")
	public void setRelaCustcode( java.lang.String relaCustcode ) {
		isSet_relaCustcode = true;
		this.relaCustcode = relaCustcode;
	}
	
	/** Property set << relaCustcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << relaSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_relaSeq = false;
	
	protected boolean isSet_relaSeq()
	{
		return this.isSet_relaSeq;
	}
	
	protected void setIsSet_relaSeq(boolean value)
	{
		this.isSet_relaSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 연계고객순번
	 */
	public void setRelaSeq(java.lang.String value) {
		isSet_relaSeq = true;
		this.relaSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 연계고객순번
	 */
	public void setRelaSeq(double value) {
		isSet_relaSeq = true;
		this.relaSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 연계고객순번
	 */
	public void setRelaSeq(long value) {
		isSet_relaSeq = true;
		this.relaSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="연계고객순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal relaSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 연계고객순번
	 */
	public java.math.BigDecimal getRelaSeq(){
		return relaSeq;
	}
	
	/**
	 * @Description 연계고객순번
	 */
	@JsonProperty("relaSeq")
	public void setRelaSeq( java.math.BigDecimal relaSeq ) {
		isSet_relaSeq = true;
		this.relaSeq = relaSeq;
	}
	
	/** Property set << relaSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << renthdYn >> [[ */
	
	@XmlTransient
	private boolean isSet_renthdYn = false;
	
	protected boolean isSet_renthdYn()
	{
		return this.isSet_renthdYn;
	}
	
	protected void setIsSet_renthdYn(boolean value)
	{
		this.isSet_renthdYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대분양전환여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String renthdYn  = null;
	
	/**
	 * @Description 임대분양전환여부
	 */
	public java.lang.String getRenthdYn(){
		return renthdYn;
	}
	
	/**
	 * @Description 임대분양전환여부
	 */
	@JsonProperty("renthdYn")
	public void setRenthdYn( java.lang.String renthdYn ) {
		isSet_renthdYn = true;
		this.renthdYn = renthdYn;
	}
	
	/** Property set << renthdYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << renthdSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_renthdSeq = false;
	
	protected boolean isSet_renthdSeq()
	{
		return this.isSet_renthdSeq;
	}
	
	protected void setIsSet_renthdSeq(boolean value)
	{
		this.isSet_renthdSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 분양순번
	 */
	public void setRenthdSeq(java.lang.String value) {
		isSet_renthdSeq = true;
		this.renthdSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 분양순번
	 */
	public void setRenthdSeq(double value) {
		isSet_renthdSeq = true;
		this.renthdSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 분양순번
	 */
	public void setRenthdSeq(long value) {
		isSet_renthdSeq = true;
		this.renthdSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="분양순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal renthdSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 분양순번
	 */
	public java.math.BigDecimal getRenthdSeq(){
		return renthdSeq;
	}
	
	/**
	 * @Description 분양순번
	 */
	@JsonProperty("renthdSeq")
	public void setRenthdSeq( java.math.BigDecimal renthdSeq ) {
		isSet_renthdSeq = true;
		this.renthdSeq = renthdSeq;
	}
	
	/** Property set << renthdSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << daymonthTag >> [[ */
	
	@XmlTransient
	private boolean isSet_daymonthTag = false;
	
	protected boolean isSet_daymonthTag()
	{
		return this.isSet_daymonthTag;
	}
	
	protected void setIsSet_daymonthTag(boolean value)
	{
		this.isSet_daymonthTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체일/월계산구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String daymonthTag  = null;
	
	/**
	 * @Description 연체일/월계산구분
	 */
	public java.lang.String getDaymonthTag(){
		return daymonthTag;
	}
	
	/**
	 * @Description 연체일/월계산구분
	 */
	@JsonProperty("daymonthTag")
	public void setDaymonthTag( java.lang.String daymonthTag ) {
		isSet_daymonthTag = true;
		this.daymonthTag = daymonthTag;
	}
	
	/** Property set << daymonthTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fixrateTag >> [[ */
	
	@XmlTransient
	private boolean isSet_fixrateTag = false;
	
	protected boolean isSet_fixrateTag()
	{
		return this.isSet_fixrateTag;
	}
	
	protected void setIsSet_fixrateTag(boolean value)
	{
		this.isSet_fixrateTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="일계산,고정이율계산구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String fixrateTag  = null;
	
	/**
	 * @Description 일계산,고정이율계산구분
	 */
	public java.lang.String getFixrateTag(){
		return fixrateTag;
	}
	
	/**
	 * @Description 일계산,고정이율계산구분
	 */
	@JsonProperty("fixrateTag")
	public void setFixrateTag( java.lang.String fixrateTag ) {
		isSet_fixrateTag = true;
		this.fixrateTag = fixrateTag;
	}
	
	/** Property set << fixrateTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virYn >> [[ */
	
	@XmlTransient
	private boolean isSet_virYn = false;
	
	protected boolean isSet_virYn()
	{
		return this.isSet_virYn;
	}
	
	protected void setIsSet_virYn(boolean value)
	{
		this.isSet_virYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String virYn  = null;
	
	/**
	 * @Description 가상계좌여부
	 */
	public java.lang.String getVirYn(){
		return virYn;
	}
	
	/**
	 * @Description 가상계좌여부
	 */
	@JsonProperty("virYn")
	public void setVirYn( java.lang.String virYn ) {
		isSet_virYn = true;
		this.virYn = virYn;
	}
	
	/** Property set << virYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vdeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_vdeposit = false;
	
	protected boolean isSet_vdeposit()
	{
		return this.isSet_vdeposit;
	}
	
	protected void setIsSet_vdeposit(boolean value)
	{
		this.isSet_vdeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌번호", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String vdeposit  = null;
	
	/**
	 * @Description 가상계좌번호
	 */
	public java.lang.String getVdeposit(){
		return vdeposit;
	}
	
	/**
	 * @Description 가상계좌번호
	 */
	@JsonProperty("vdeposit")
	public void setVdeposit( java.lang.String vdeposit ) {
		isSet_vdeposit = true;
		this.vdeposit = vdeposit;
	}
	
	/** Property set << vdeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentIns >> [[ */
	
	@XmlTransient
	private boolean isSet_rentIns = false;
	
	protected boolean isSet_rentIns()
	{
		return this.isSet_rentIns;
	}
	
	protected void setIsSet_rentIns(boolean value)
	{
		this.isSet_rentIns = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(java.lang.String value) {
		isSet_rentIns = true;
		this.rentIns = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(double value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대료보증보험료
	 */
	public void setRentIns(long value) {
		isSet_rentIns = true;
		this.rentIns = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대료보증보험료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rentIns  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대료보증보험료
	 */
	public java.math.BigDecimal getRentIns(){
		return rentIns;
	}
	
	/**
	 * @Description 임대료보증보험료
	 */
	@JsonProperty("rentIns")
	public void setRentIns( java.math.BigDecimal rentIns ) {
		isSet_rentIns = true;
		this.rentIns = rentIns;
	}
	
	/** Property set << rentIns >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fixrate >> [[ */
	
	@XmlTransient
	private boolean isSet_fixrate = false;
	
	protected boolean isSet_fixrate()
	{
		return this.isSet_fixrate;
	}
	
	protected void setIsSet_fixrate(boolean value)
	{
		this.isSet_fixrate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이내이율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float fixrate  = .0F;
	
	/**
	 * @Description 기간이내이율
	 */
	public java.lang.Float getFixrate(){
		return fixrate;
	}
	
	/**
	 * @Description 기간이내이율
	 */
	@JsonProperty("fixrate")
	public void setFixrate( java.lang.Float fixrate ) {
		isSet_fixrate = true;
		this.fixrate = fixrate;
	}
	
	/** Property set << fixrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fixrate2 >> [[ */
	
	@XmlTransient
	private boolean isSet_fixrate2 = false;
	
	protected boolean isSet_fixrate2()
	{
		return this.isSet_fixrate2;
	}
	
	protected void setIsSet_fixrate2(boolean value)
	{
		this.isSet_fixrate2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이후이율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float fixrate2  = .0F;
	
	/**
	 * @Description 기간이후이율
	 */
	public java.lang.Float getFixrate2(){
		return fixrate2;
	}
	
	/**
	 * @Description 기간이후이율
	 */
	@JsonProperty("fixrate2")
	public void setFixrate2( java.lang.Float fixrate2 ) {
		isSet_fixrate2 = true;
		this.fixrate2 = fixrate2;
	}
	
	/** Property set << fixrate2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fixrateDay >> [[ */
	
	@XmlTransient
	private boolean isSet_fixrateDay = false;
	
	protected boolean isSet_fixrateDay()
	{
		return this.isSet_fixrateDay;
	}
	
	protected void setIsSet_fixrateDay(boolean value)
	{
		this.isSet_fixrateDay = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고정일자
	 */
	public void setFixrateDay(java.lang.String value) {
		isSet_fixrateDay = true;
		this.fixrateDay = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고정일자
	 */
	public void setFixrateDay(double value) {
		isSet_fixrateDay = true;
		this.fixrateDay = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고정일자
	 */
	public void setFixrateDay(long value) {
		isSet_fixrateDay = true;
		this.fixrateDay = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고정일자", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal fixrateDay  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고정일자
	 */
	public java.math.BigDecimal getFixrateDay(){
		return fixrateDay;
	}
	
	/**
	 * @Description 고정일자
	 */
	@JsonProperty("fixrateDay")
	public void setFixrateDay( java.math.BigDecimal fixrateDay ) {
		isSet_fixrateDay = true;
		this.fixrateDay = fixrateDay;
	}
	
	/** Property set << fixrateDay >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << hopeHouseTag >> [[ */
	
	@XmlTransient
	private boolean isSet_hopeHouseTag = false;
	
	protected boolean isSet_hopeHouseTag()
	{
		return this.isSet_hopeHouseTag;
	}
	
	protected void setIsSet_hopeHouseTag(boolean value)
	{
		this.isSet_hopeHouseTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양전환희망여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String hopeHouseTag  = null;
	
	/**
	 * @Description 분양전환희망여부
	 */
	public java.lang.String getHopeHouseTag(){
		return hopeHouseTag;
	}
	
	/**
	 * @Description 분양전환희망여부
	 */
	@JsonProperty("hopeHouseTag")
	public void setHopeHouseTag( java.lang.String hopeHouseTag ) {
		isSet_hopeHouseTag = true;
		this.hopeHouseTag = hopeHouseTag;
	}
	
	/** Property set << hopeHouseTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnYn >> [[ */
	
	@XmlTransient
	private boolean isSet_returnYn = false;
	
	protected boolean isSet_returnYn()
	{
		return this.isSet_returnYn;
	}
	
	protected void setIsSet_returnYn(boolean value)
	{
		this.isSet_returnYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String returnYn  = null;
	
	/**
	 * @Description 환불여부
	 */
	public java.lang.String getReturnYn(){
		return returnYn;
	}
	
	/**
	 * @Description 환불여부
	 */
	@JsonProperty("returnYn")
	public void setReturnYn( java.lang.String returnYn ) {
		isSet_returnYn = true;
		this.returnYn = returnYn;
	}
	
	/** Property set << returnYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnDate >> [[ */
	
	@XmlTransient
	private boolean isSet_returnDate = false;
	
	protected boolean isSet_returnDate()
	{
		return this.isSet_returnDate;
	}
	
	protected void setIsSet_returnDate(boolean value)
	{
		this.isSet_returnDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String returnDate  = null;
	
	/**
	 * @Description 환불일자
	 */
	public java.lang.String getReturnDate(){
		return returnDate;
	}
	
	/**
	 * @Description 환불일자
	 */
	@JsonProperty("returnDate")
	public void setReturnDate( java.lang.String returnDate ) {
		isSet_returnDate = true;
		this.returnDate = returnDate;
	}
	
	/** Property set << returnDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rGurtamt >> [[ */
	
	@XmlTransient
	private boolean isSet_rGurtamt = false;
	
	protected boolean isSet_rGurtamt()
	{
		return this.isSet_rGurtamt;
	}
	
	protected void setIsSet_rGurtamt(boolean value)
	{
		this.isSet_rGurtamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 환불시납입보증금
	 */
	public void setrGurtamt(java.lang.String value) {
		isSet_rGurtamt = true;
		this.rGurtamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 환불시납입보증금
	 */
	public void setrGurtamt(double value) {
		isSet_rGurtamt = true;
		this.rGurtamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 환불시납입보증금
	 */
	public void setrGurtamt(long value) {
		isSet_rGurtamt = true;
		this.rGurtamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="환불시납입보증금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rGurtamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 환불시납입보증금
	 */
	public java.math.BigDecimal getrGurtamt(){
		return rGurtamt;
	}
	
	/**
	 * @Description 환불시납입보증금
	 */
	@JsonProperty("rGurtamt")
	public void setrGurtamt( java.math.BigDecimal rGurtamt ) {
		isSet_rGurtamt = true;
		this.rGurtamt = rGurtamt;
	}
	
	/** Property set << rGurtamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rRentamt >> [[ */
	
	@XmlTransient
	private boolean isSet_rRentamt = false;
	
	protected boolean isSet_rRentamt()
	{
		return this.isSet_rRentamt;
	}
	
	protected void setIsSet_rRentamt(boolean value)
	{
		this.isSet_rRentamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 환불시미납임대료
	 */
	public void setrRentamt(java.lang.String value) {
		isSet_rRentamt = true;
		this.rRentamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 환불시미납임대료
	 */
	public void setrRentamt(double value) {
		isSet_rRentamt = true;
		this.rRentamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 환불시미납임대료
	 */
	public void setrRentamt(long value) {
		isSet_rRentamt = true;
		this.rRentamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="환불시미납임대료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rRentamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 환불시미납임대료
	 */
	public java.math.BigDecimal getrRentamt(){
		return rRentamt;
	}
	
	/**
	 * @Description 환불시미납임대료
	 */
	@JsonProperty("rRentamt")
	public void setrRentamt( java.math.BigDecimal rRentamt ) {
		isSet_rRentamt = true;
		this.rRentamt = rRentamt;
	}
	
	/** Property set << rRentamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rDelayamt >> [[ */
	
	@XmlTransient
	private boolean isSet_rDelayamt = false;
	
	protected boolean isSet_rDelayamt()
	{
		return this.isSet_rDelayamt;
	}
	
	protected void setIsSet_rDelayamt(boolean value)
	{
		this.isSet_rDelayamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 환불시연체료
	 */
	public void setrDelayamt(java.lang.String value) {
		isSet_rDelayamt = true;
		this.rDelayamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 환불시연체료
	 */
	public void setrDelayamt(double value) {
		isSet_rDelayamt = true;
		this.rDelayamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 환불시연체료
	 */
	public void setrDelayamt(long value) {
		isSet_rDelayamt = true;
		this.rDelayamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="환불시연체료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rDelayamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 환불시연체료
	 */
	public java.math.BigDecimal getrDelayamt(){
		return rDelayamt;
	}
	
	/**
	 * @Description 환불시연체료
	 */
	@JsonProperty("rDelayamt")
	public void setrDelayamt( java.math.BigDecimal rDelayamt ) {
		isSet_rDelayamt = true;
		this.rDelayamt = rDelayamt;
	}
	
	/** Property set << rDelayamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rPenaltyamt >> [[ */
	
	@XmlTransient
	private boolean isSet_rPenaltyamt = false;
	
	protected boolean isSet_rPenaltyamt()
	{
		return this.isSet_rPenaltyamt;
	}
	
	protected void setIsSet_rPenaltyamt(boolean value)
	{
		this.isSet_rPenaltyamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 위약금
	 */
	public void setrPenaltyamt(java.lang.String value) {
		isSet_rPenaltyamt = true;
		this.rPenaltyamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 위약금
	 */
	public void setrPenaltyamt(double value) {
		isSet_rPenaltyamt = true;
		this.rPenaltyamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 위약금
	 */
	public void setrPenaltyamt(long value) {
		isSet_rPenaltyamt = true;
		this.rPenaltyamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="위약금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rPenaltyamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 위약금
	 */
	public java.math.BigDecimal getrPenaltyamt(){
		return rPenaltyamt;
	}
	
	/**
	 * @Description 위약금
	 */
	@JsonProperty("rPenaltyamt")
	public void setrPenaltyamt( java.math.BigDecimal rPenaltyamt ) {
		isSet_rPenaltyamt = true;
		this.rPenaltyamt = rPenaltyamt;
	}
	
	/** Property set << rPenaltyamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rEtcamt1 >> [[ */
	
	@XmlTransient
	private boolean isSet_rEtcamt1 = false;
	
	protected boolean isSet_rEtcamt1()
	{
		return this.isSet_rEtcamt1;
	}
	
	protected void setIsSet_rEtcamt1(boolean value)
	{
		this.isSet_rEtcamt1 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공제1
	 */
	public void setrEtcamt1(java.lang.String value) {
		isSet_rEtcamt1 = true;
		this.rEtcamt1 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공제1
	 */
	public void setrEtcamt1(double value) {
		isSet_rEtcamt1 = true;
		this.rEtcamt1 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공제1
	 */
	public void setrEtcamt1(long value) {
		isSet_rEtcamt1 = true;
		this.rEtcamt1 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공제1", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rEtcamt1  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공제1
	 */
	public java.math.BigDecimal getrEtcamt1(){
		return rEtcamt1;
	}
	
	/**
	 * @Description 기타공제1
	 */
	@JsonProperty("rEtcamt1")
	public void setrEtcamt1( java.math.BigDecimal rEtcamt1 ) {
		isSet_rEtcamt1 = true;
		this.rEtcamt1 = rEtcamt1;
	}
	
	/** Property set << rEtcamt1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rEtcamt2 >> [[ */
	
	@XmlTransient
	private boolean isSet_rEtcamt2 = false;
	
	protected boolean isSet_rEtcamt2()
	{
		return this.isSet_rEtcamt2;
	}
	
	protected void setIsSet_rEtcamt2(boolean value)
	{
		this.isSet_rEtcamt2 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공제2
	 */
	public void setrEtcamt2(java.lang.String value) {
		isSet_rEtcamt2 = true;
		this.rEtcamt2 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공제2
	 */
	public void setrEtcamt2(double value) {
		isSet_rEtcamt2 = true;
		this.rEtcamt2 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공제2
	 */
	public void setrEtcamt2(long value) {
		isSet_rEtcamt2 = true;
		this.rEtcamt2 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공제2", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rEtcamt2  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공제2
	 */
	public java.math.BigDecimal getrEtcamt2(){
		return rEtcamt2;
	}
	
	/**
	 * @Description 기타공제2
	 */
	@JsonProperty("rEtcamt2")
	public void setrEtcamt2( java.math.BigDecimal rEtcamt2 ) {
		isSet_rEtcamt2 = true;
		this.rEtcamt2 = rEtcamt2;
	}
	
	/** Property set << rEtcamt2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rEtcamt3 >> [[ */
	
	@XmlTransient
	private boolean isSet_rEtcamt3 = false;
	
	protected boolean isSet_rEtcamt3()
	{
		return this.isSet_rEtcamt3;
	}
	
	protected void setIsSet_rEtcamt3(boolean value)
	{
		this.isSet_rEtcamt3 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공제3
	 */
	public void setrEtcamt3(java.lang.String value) {
		isSet_rEtcamt3 = true;
		this.rEtcamt3 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공제3
	 */
	public void setrEtcamt3(double value) {
		isSet_rEtcamt3 = true;
		this.rEtcamt3 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공제3
	 */
	public void setrEtcamt3(long value) {
		isSet_rEtcamt3 = true;
		this.rEtcamt3 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공제3", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rEtcamt3  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공제3
	 */
	public java.math.BigDecimal getrEtcamt3(){
		return rEtcamt3;
	}
	
	/**
	 * @Description 기타공제3
	 */
	@JsonProperty("rEtcamt3")
	public void setrEtcamt3( java.math.BigDecimal rEtcamt3 ) {
		isSet_rEtcamt3 = true;
		this.rEtcamt3 = rEtcamt3;
	}
	
	/** Property set << rEtcamt3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_returnAmt = false;
	
	protected boolean isSet_returnAmt()
	{
		return this.isSet_returnAmt;
	}
	
	protected void setIsSet_returnAmt(boolean value)
	{
		this.isSet_returnAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 환불금
	 */
	public void setReturnAmt(java.lang.String value) {
		isSet_returnAmt = true;
		this.returnAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 환불금
	 */
	public void setReturnAmt(double value) {
		isSet_returnAmt = true;
		this.returnAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 환불금
	 */
	public void setReturnAmt(long value) {
		isSet_returnAmt = true;
		this.returnAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="환불금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal returnAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 환불금
	 */
	public java.math.BigDecimal getReturnAmt(){
		return returnAmt;
	}
	
	/**
	 * @Description 환불금
	 */
	@JsonProperty("returnAmt")
	public void setReturnAmt( java.math.BigDecimal returnAmt ) {
		isSet_returnAmt = true;
		this.returnAmt = returnAmt;
	}
	
	/** Property set << returnAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipDate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipDate = false;
	
	protected boolean isSet_slipDate()
	{
		return this.isSet_slipDate;
	}
	
	protected void setIsSet_slipDate(boolean value)
	{
		this.isSet_slipDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipDate  = null;
	
	/**
	 * @Description 전표일자
	 */
	public java.lang.String getSlipDate(){
		return slipDate;
	}
	
	/**
	 * @Description 전표일자
	 */
	@JsonProperty("slipDate")
	public void setSlipDate( java.lang.String slipDate ) {
		isSet_slipDate = true;
		this.slipDate = slipDate;
	}
	
	/** Property set << slipDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipSeq = false;
	
	protected boolean isSet_slipSeq()
	{
		return this.isSet_slipSeq;
	}
	
	protected void setIsSet_slipSeq(boolean value)
	{
		this.isSet_slipSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(java.lang.String value) {
		isSet_slipSeq = true;
		this.slipSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(double value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(long value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번
	 */
	public java.math.BigDecimal getSlipSeq(){
		return slipSeq;
	}
	
	/**
	 * @Description 전표순번
	 */
	@JsonProperty("slipSeq")
	public void setSlipSeq( java.math.BigDecimal slipSeq ) {
		isSet_slipSeq = true;
		this.slipSeq = slipSeq;
	}
	
	/** Property set << slipSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housecontamt >> [[ */
	
	@XmlTransient
	private boolean isSet_housecontamt = false;
	
	protected boolean isSet_housecontamt()
	{
		return this.isSet_housecontamt;
	}
	
	protected void setIsSet_housecontamt(boolean value)
	{
		this.isSet_housecontamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 분양전환금
	 */
	public void setHousecontamt(java.lang.String value) {
		isSet_housecontamt = true;
		this.housecontamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 분양전환금
	 */
	public void setHousecontamt(double value) {
		isSet_housecontamt = true;
		this.housecontamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 분양전환금
	 */
	public void setHousecontamt(long value) {
		isSet_housecontamt = true;
		this.housecontamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="분양전환금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal housecontamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 분양전환금
	 */
	public java.math.BigDecimal getHousecontamt(){
		return housecontamt;
	}
	
	/**
	 * @Description 분양전환금
	 */
	@JsonProperty("housecontamt")
	public void setHousecontamt( java.math.BigDecimal housecontamt ) {
		isSet_housecontamt = true;
		this.housecontamt = housecontamt;
	}
	
	/** Property set << housecontamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rBank >> [[ */
	
	@XmlTransient
	private boolean isSet_rBank = false;
	
	protected boolean isSet_rBank()
	{
		return this.isSet_rBank;
	}
	
	protected void setIsSet_rBank(boolean value)
	{
		this.isSet_rBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불은행", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String rBank  = null;
	
	/**
	 * @Description 환불은행
	 */
	public java.lang.String getrBank(){
		return rBank;
	}
	
	/**
	 * @Description 환불은행
	 */
	@JsonProperty("rBank")
	public void setrBank( java.lang.String rBank ) {
		isSet_rBank = true;
		this.rBank = rBank;
	}
	
	/** Property set << rBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rDeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_rDeposit = false;
	
	protected boolean isSet_rDeposit()
	{
		return this.isSet_rDeposit;
	}
	
	protected void setIsSet_rDeposit(boolean value)
	{
		this.isSet_rDeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불계좌", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String rDeposit  = null;
	
	/**
	 * @Description 환불계좌
	 */
	public java.lang.String getrDeposit(){
		return rDeposit;
	}
	
	/**
	 * @Description 환불계좌
	 */
	@JsonProperty("rDeposit")
	public void setrDeposit( java.lang.String rDeposit ) {
		isSet_rDeposit = true;
		this.rDeposit = rDeposit;
	}
	
	/** Property set << rDeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rDepositor >> [[ */
	
	@XmlTransient
	private boolean isSet_rDepositor = false;
	
	protected boolean isSet_rDepositor()
	{
		return this.isSet_rDepositor;
	}
	
	protected void setIsSet_rDepositor(boolean value)
	{
		this.isSet_rDepositor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불예금주", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String rDepositor  = null;
	
	/**
	 * @Description 환불예금주
	 */
	public java.lang.String getrDepositor(){
		return rDepositor;
	}
	
	/**
	 * @Description 환불예금주
	 */
	@JsonProperty("rDepositor")
	public void setrDepositor( java.lang.String rDepositor ) {
		isSet_rDepositor = true;
		this.rDepositor = rDepositor;
	}
	
	/** Property set << rDepositor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipSeq2 >> [[ */
	
	@XmlTransient
	private boolean isSet_slipSeq2 = false;
	
	protected boolean isSet_slipSeq2()
	{
		return this.isSet_slipSeq2;
	}
	
	protected void setIsSet_slipSeq2(boolean value)
	{
		this.isSet_slipSeq2 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 
	 */
	public void setSlipSeq2(java.lang.String value) {
		isSet_slipSeq2 = true;
		this.slipSeq2 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 
	 */
	public void setSlipSeq2(double value) {
		isSet_slipSeq2 = true;
		this.slipSeq2 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 
	 */
	public void setSlipSeq2(long value) {
		isSet_slipSeq2 = true;
		this.slipSeq2 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipSeq2  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 
	 */
	public java.math.BigDecimal getSlipSeq2(){
		return slipSeq2;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("slipSeq2")
	public void setSlipSeq2( java.math.BigDecimal slipSeq2 ) {
		isSet_slipSeq2 = true;
		this.slipSeq2 = slipSeq2;
	}
	
	/** Property set << slipSeq2 >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentMaster01IO clone(){
		try{
			DHDRentMaster01IO object= (DHDRentMaster01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.custName== null ) object.custName = null;
			else{
				object.custName = this.custName;
			}
			if ( this.contDate== null ) object.contDate = null;
			else{
				object.contDate = this.contDate;
			}
			if ( this.contNo== null ) object.contNo = null;
			else{
				object.contNo = this.contNo;
			}
			if ( this.contType== null ) object.contType = null;
			else{
				object.contType = this.contType;
			}
			if ( this.vatYn== null ) object.vatYn = null;
			else{
				object.vatYn = this.vatYn;
			}
			if ( this.guaranteeAmt== null ) object.guaranteeAmt = null;
			else{
				object.guaranteeAmt = new java.math.BigDecimal(guaranteeAmt.toString());
			}
			if ( this.rentSupply== null ) object.rentSupply = null;
			else{
				object.rentSupply = new java.math.BigDecimal(rentSupply.toString());
			}
			if ( this.rentVat== null ) object.rentVat = null;
			else{
				object.rentVat = new java.math.BigDecimal(rentVat.toString());
			}
			if ( this.rentSdate== null ) object.rentSdate = null;
			else{
				object.rentSdate = this.rentSdate;
			}
			if ( this.rentEdate== null ) object.rentEdate = null;
			else{
				object.rentEdate = this.rentEdate;
			}
			if ( this.realCustName== null ) object.realCustName = null;
			else{
				object.realCustName = this.realCustName;
			}
			if ( this.realInDate== null ) object.realInDate = null;
			else{
				object.realInDate = this.realInDate;
			}
			if ( this.changeTag== null ) object.changeTag = null;
			else{
				object.changeTag = this.changeTag;
			}
			if ( this.changeDate== null ) object.changeDate = null;
			else{
				object.changeDate = this.changeDate;
			}
			if ( this.lastChangeDate== null ) object.lastChangeDate = null;
			else{
				object.lastChangeDate = this.lastChangeDate;
			}
			if ( this.rentChgSeq== null ) object.rentChgSeq = null;
			else{
				object.rentChgSeq = new java.math.BigDecimal(rentChgSeq.toString());
			}
			if ( this.termChgSeq== null ) object.termChgSeq = null;
			else{
				object.termChgSeq = new java.math.BigDecimal(termChgSeq.toString());
			}
			if ( this.relaCustcode== null ) object.relaCustcode = null;
			else{
				object.relaCustcode = this.relaCustcode;
			}
			if ( this.relaSeq== null ) object.relaSeq = null;
			else{
				object.relaSeq = new java.math.BigDecimal(relaSeq.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.renthdYn== null ) object.renthdYn = null;
			else{
				object.renthdYn = this.renthdYn;
			}
			if ( this.renthdSeq== null ) object.renthdSeq = null;
			else{
				object.renthdSeq = new java.math.BigDecimal(renthdSeq.toString());
			}
			if ( this.daymonthTag== null ) object.daymonthTag = null;
			else{
				object.daymonthTag = this.daymonthTag;
			}
			if ( this.fixrateTag== null ) object.fixrateTag = null;
			else{
				object.fixrateTag = this.fixrateTag;
			}
			if ( this.virYn== null ) object.virYn = null;
			else{
				object.virYn = this.virYn;
			}
			if ( this.vdeposit== null ) object.vdeposit = null;
			else{
				object.vdeposit = this.vdeposit;
			}
			if ( this.rentIns== null ) object.rentIns = null;
			else{
				object.rentIns = new java.math.BigDecimal(rentIns.toString());
			}
			if ( this.fixrate== null ) object.fixrate = null;
			else{
				object.fixrate = this.fixrate;
			}
			if ( this.fixrate2== null ) object.fixrate2 = null;
			else{
				object.fixrate2 = this.fixrate2;
			}
			if ( this.fixrateDay== null ) object.fixrateDay = null;
			else{
				object.fixrateDay = new java.math.BigDecimal(fixrateDay.toString());
			}
			if ( this.hopeHouseTag== null ) object.hopeHouseTag = null;
			else{
				object.hopeHouseTag = this.hopeHouseTag;
			}
			if ( this.returnYn== null ) object.returnYn = null;
			else{
				object.returnYn = this.returnYn;
			}
			if ( this.returnDate== null ) object.returnDate = null;
			else{
				object.returnDate = this.returnDate;
			}
			if ( this.rGurtamt== null ) object.rGurtamt = null;
			else{
				object.rGurtamt = new java.math.BigDecimal(rGurtamt.toString());
			}
			if ( this.rRentamt== null ) object.rRentamt = null;
			else{
				object.rRentamt = new java.math.BigDecimal(rRentamt.toString());
			}
			if ( this.rDelayamt== null ) object.rDelayamt = null;
			else{
				object.rDelayamt = new java.math.BigDecimal(rDelayamt.toString());
			}
			if ( this.rPenaltyamt== null ) object.rPenaltyamt = null;
			else{
				object.rPenaltyamt = new java.math.BigDecimal(rPenaltyamt.toString());
			}
			if ( this.rEtcamt1== null ) object.rEtcamt1 = null;
			else{
				object.rEtcamt1 = new java.math.BigDecimal(rEtcamt1.toString());
			}
			if ( this.rEtcamt2== null ) object.rEtcamt2 = null;
			else{
				object.rEtcamt2 = new java.math.BigDecimal(rEtcamt2.toString());
			}
			if ( this.rEtcamt3== null ) object.rEtcamt3 = null;
			else{
				object.rEtcamt3 = new java.math.BigDecimal(rEtcamt3.toString());
			}
			if ( this.returnAmt== null ) object.returnAmt = null;
			else{
				object.returnAmt = new java.math.BigDecimal(returnAmt.toString());
			}
			if ( this.slipDate== null ) object.slipDate = null;
			else{
				object.slipDate = this.slipDate;
			}
			if ( this.slipSeq== null ) object.slipSeq = null;
			else{
				object.slipSeq = new java.math.BigDecimal(slipSeq.toString());
			}
			if ( this.housecontamt== null ) object.housecontamt = null;
			else{
				object.housecontamt = new java.math.BigDecimal(housecontamt.toString());
			}
			if ( this.rBank== null ) object.rBank = null;
			else{
				object.rBank = this.rBank;
			}
			if ( this.rDeposit== null ) object.rDeposit = null;
			else{
				object.rDeposit = this.rDeposit;
			}
			if ( this.rDepositor== null ) object.rDepositor = null;
			else{
				object.rDepositor = this.rDepositor;
			}
			if ( this.slipSeq2== null ) object.slipSeq2 = null;
			else{
				object.slipSeq2 = new java.math.BigDecimal(slipSeq2.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((custName==null)?0:custName.hashCode());
		result = prime * result + ((contDate==null)?0:contDate.hashCode());
		result = prime * result + ((contNo==null)?0:contNo.hashCode());
		result = prime * result + ((contType==null)?0:contType.hashCode());
		result = prime * result + ((vatYn==null)?0:vatYn.hashCode());
		result = prime * result + ((guaranteeAmt==null)?0:guaranteeAmt.hashCode());
		result = prime * result + ((rentSupply==null)?0:rentSupply.hashCode());
		result = prime * result + ((rentVat==null)?0:rentVat.hashCode());
		result = prime * result + ((rentSdate==null)?0:rentSdate.hashCode());
		result = prime * result + ((rentEdate==null)?0:rentEdate.hashCode());
		result = prime * result + ((realCustName==null)?0:realCustName.hashCode());
		result = prime * result + ((realInDate==null)?0:realInDate.hashCode());
		result = prime * result + ((changeTag==null)?0:changeTag.hashCode());
		result = prime * result + ((changeDate==null)?0:changeDate.hashCode());
		result = prime * result + ((lastChangeDate==null)?0:lastChangeDate.hashCode());
		result = prime * result + ((rentChgSeq==null)?0:rentChgSeq.hashCode());
		result = prime * result + ((termChgSeq==null)?0:termChgSeq.hashCode());
		result = prime * result + ((relaCustcode==null)?0:relaCustcode.hashCode());
		result = prime * result + ((relaSeq==null)?0:relaSeq.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((renthdYn==null)?0:renthdYn.hashCode());
		result = prime * result + ((renthdSeq==null)?0:renthdSeq.hashCode());
		result = prime * result + ((daymonthTag==null)?0:daymonthTag.hashCode());
		result = prime * result + ((fixrateTag==null)?0:fixrateTag.hashCode());
		result = prime * result + ((virYn==null)?0:virYn.hashCode());
		result = prime * result + ((vdeposit==null)?0:vdeposit.hashCode());
		result = prime * result + ((rentIns==null)?0:rentIns.hashCode());
		result = prime * result + ((fixrate==null)?0:fixrate.hashCode());
		result = prime * result + ((fixrate2==null)?0:fixrate2.hashCode());
		result = prime * result + ((fixrateDay==null)?0:fixrateDay.hashCode());
		result = prime * result + ((hopeHouseTag==null)?0:hopeHouseTag.hashCode());
		result = prime * result + ((returnYn==null)?0:returnYn.hashCode());
		result = prime * result + ((returnDate==null)?0:returnDate.hashCode());
		result = prime * result + ((rGurtamt==null)?0:rGurtamt.hashCode());
		result = prime * result + ((rRentamt==null)?0:rRentamt.hashCode());
		result = prime * result + ((rDelayamt==null)?0:rDelayamt.hashCode());
		result = prime * result + ((rPenaltyamt==null)?0:rPenaltyamt.hashCode());
		result = prime * result + ((rEtcamt1==null)?0:rEtcamt1.hashCode());
		result = prime * result + ((rEtcamt2==null)?0:rEtcamt2.hashCode());
		result = prime * result + ((rEtcamt3==null)?0:rEtcamt3.hashCode());
		result = prime * result + ((returnAmt==null)?0:returnAmt.hashCode());
		result = prime * result + ((slipDate==null)?0:slipDate.hashCode());
		result = prime * result + ((slipSeq==null)?0:slipSeq.hashCode());
		result = prime * result + ((housecontamt==null)?0:housecontamt.hashCode());
		result = prime * result + ((rBank==null)?0:rBank.hashCode());
		result = prime * result + ((rDeposit==null)?0:rDeposit.hashCode());
		result = prime * result + ((rDepositor==null)?0:rDepositor.hashCode());
		result = prime * result + ((slipSeq2==null)?0:slipSeq2.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentMaster01IO other = (kait.hd.rent.onl.dao.dto.DHDRentMaster01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( custName == null ){
			if ( other.custName != null ) return false;
		}
		else if ( !custName.equals(other.custName) )
			return false;
		if ( contDate == null ){
			if ( other.contDate != null ) return false;
		}
		else if ( !contDate.equals(other.contDate) )
			return false;
		if ( contNo == null ){
			if ( other.contNo != null ) return false;
		}
		else if ( !contNo.equals(other.contNo) )
			return false;
		if ( contType == null ){
			if ( other.contType != null ) return false;
		}
		else if ( !contType.equals(other.contType) )
			return false;
		if ( vatYn == null ){
			if ( other.vatYn != null ) return false;
		}
		else if ( !vatYn.equals(other.vatYn) )
			return false;
		if ( guaranteeAmt == null ){
			if ( other.guaranteeAmt != null ) return false;
		}
		else if ( !guaranteeAmt.equals(other.guaranteeAmt) )
			return false;
		if ( rentSupply == null ){
			if ( other.rentSupply != null ) return false;
		}
		else if ( !rentSupply.equals(other.rentSupply) )
			return false;
		if ( rentVat == null ){
			if ( other.rentVat != null ) return false;
		}
		else if ( !rentVat.equals(other.rentVat) )
			return false;
		if ( rentSdate == null ){
			if ( other.rentSdate != null ) return false;
		}
		else if ( !rentSdate.equals(other.rentSdate) )
			return false;
		if ( rentEdate == null ){
			if ( other.rentEdate != null ) return false;
		}
		else if ( !rentEdate.equals(other.rentEdate) )
			return false;
		if ( realCustName == null ){
			if ( other.realCustName != null ) return false;
		}
		else if ( !realCustName.equals(other.realCustName) )
			return false;
		if ( realInDate == null ){
			if ( other.realInDate != null ) return false;
		}
		else if ( !realInDate.equals(other.realInDate) )
			return false;
		if ( changeTag == null ){
			if ( other.changeTag != null ) return false;
		}
		else if ( !changeTag.equals(other.changeTag) )
			return false;
		if ( changeDate == null ){
			if ( other.changeDate != null ) return false;
		}
		else if ( !changeDate.equals(other.changeDate) )
			return false;
		if ( lastChangeDate == null ){
			if ( other.lastChangeDate != null ) return false;
		}
		else if ( !lastChangeDate.equals(other.lastChangeDate) )
			return false;
		if ( rentChgSeq == null ){
			if ( other.rentChgSeq != null ) return false;
		}
		else if ( !rentChgSeq.equals(other.rentChgSeq) )
			return false;
		if ( termChgSeq == null ){
			if ( other.termChgSeq != null ) return false;
		}
		else if ( !termChgSeq.equals(other.termChgSeq) )
			return false;
		if ( relaCustcode == null ){
			if ( other.relaCustcode != null ) return false;
		}
		else if ( !relaCustcode.equals(other.relaCustcode) )
			return false;
		if ( relaSeq == null ){
			if ( other.relaSeq != null ) return false;
		}
		else if ( !relaSeq.equals(other.relaSeq) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( renthdYn == null ){
			if ( other.renthdYn != null ) return false;
		}
		else if ( !renthdYn.equals(other.renthdYn) )
			return false;
		if ( renthdSeq == null ){
			if ( other.renthdSeq != null ) return false;
		}
		else if ( !renthdSeq.equals(other.renthdSeq) )
			return false;
		if ( daymonthTag == null ){
			if ( other.daymonthTag != null ) return false;
		}
		else if ( !daymonthTag.equals(other.daymonthTag) )
			return false;
		if ( fixrateTag == null ){
			if ( other.fixrateTag != null ) return false;
		}
		else if ( !fixrateTag.equals(other.fixrateTag) )
			return false;
		if ( virYn == null ){
			if ( other.virYn != null ) return false;
		}
		else if ( !virYn.equals(other.virYn) )
			return false;
		if ( vdeposit == null ){
			if ( other.vdeposit != null ) return false;
		}
		else if ( !vdeposit.equals(other.vdeposit) )
			return false;
		if ( rentIns == null ){
			if ( other.rentIns != null ) return false;
		}
		else if ( !rentIns.equals(other.rentIns) )
			return false;
		if ( fixrate == null ){
			if ( other.fixrate != null ) return false;
		}
		else if ( !fixrate.equals(other.fixrate) )
			return false;
		if ( fixrate2 == null ){
			if ( other.fixrate2 != null ) return false;
		}
		else if ( !fixrate2.equals(other.fixrate2) )
			return false;
		if ( fixrateDay == null ){
			if ( other.fixrateDay != null ) return false;
		}
		else if ( !fixrateDay.equals(other.fixrateDay) )
			return false;
		if ( hopeHouseTag == null ){
			if ( other.hopeHouseTag != null ) return false;
		}
		else if ( !hopeHouseTag.equals(other.hopeHouseTag) )
			return false;
		if ( returnYn == null ){
			if ( other.returnYn != null ) return false;
		}
		else if ( !returnYn.equals(other.returnYn) )
			return false;
		if ( returnDate == null ){
			if ( other.returnDate != null ) return false;
		}
		else if ( !returnDate.equals(other.returnDate) )
			return false;
		if ( rGurtamt == null ){
			if ( other.rGurtamt != null ) return false;
		}
		else if ( !rGurtamt.equals(other.rGurtamt) )
			return false;
		if ( rRentamt == null ){
			if ( other.rRentamt != null ) return false;
		}
		else if ( !rRentamt.equals(other.rRentamt) )
			return false;
		if ( rDelayamt == null ){
			if ( other.rDelayamt != null ) return false;
		}
		else if ( !rDelayamt.equals(other.rDelayamt) )
			return false;
		if ( rPenaltyamt == null ){
			if ( other.rPenaltyamt != null ) return false;
		}
		else if ( !rPenaltyamt.equals(other.rPenaltyamt) )
			return false;
		if ( rEtcamt1 == null ){
			if ( other.rEtcamt1 != null ) return false;
		}
		else if ( !rEtcamt1.equals(other.rEtcamt1) )
			return false;
		if ( rEtcamt2 == null ){
			if ( other.rEtcamt2 != null ) return false;
		}
		else if ( !rEtcamt2.equals(other.rEtcamt2) )
			return false;
		if ( rEtcamt3 == null ){
			if ( other.rEtcamt3 != null ) return false;
		}
		else if ( !rEtcamt3.equals(other.rEtcamt3) )
			return false;
		if ( returnAmt == null ){
			if ( other.returnAmt != null ) return false;
		}
		else if ( !returnAmt.equals(other.returnAmt) )
			return false;
		if ( slipDate == null ){
			if ( other.slipDate != null ) return false;
		}
		else if ( !slipDate.equals(other.slipDate) )
			return false;
		if ( slipSeq == null ){
			if ( other.slipSeq != null ) return false;
		}
		else if ( !slipSeq.equals(other.slipSeq) )
			return false;
		if ( housecontamt == null ){
			if ( other.housecontamt != null ) return false;
		}
		else if ( !housecontamt.equals(other.housecontamt) )
			return false;
		if ( rBank == null ){
			if ( other.rBank != null ) return false;
		}
		else if ( !rBank.equals(other.rBank) )
			return false;
		if ( rDeposit == null ){
			if ( other.rDeposit != null ) return false;
		}
		else if ( !rDeposit.equals(other.rDeposit) )
			return false;
		if ( rDepositor == null ){
			if ( other.rDepositor != null ) return false;
		}
		else if ( !rDepositor.equals(other.rDepositor) )
			return false;
		if ( slipSeq2 == null ){
			if ( other.slipSeq2 != null ) return false;
		}
		else if ( !slipSeq2.equals(other.slipSeq2) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentMaster01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tcustName: ");
		sb.append(custName==null?"null":getCustName());
		sb.append("\n");
		sb.append("\tcontDate: ");
		sb.append(contDate==null?"null":getContDate());
		sb.append("\n");
		sb.append("\tcontNo: ");
		sb.append(contNo==null?"null":getContNo());
		sb.append("\n");
		sb.append("\tcontType: ");
		sb.append(contType==null?"null":getContType());
		sb.append("\n");
		sb.append("\tvatYn: ");
		sb.append(vatYn==null?"null":getVatYn());
		sb.append("\n");
		sb.append("\tguaranteeAmt: ");
		sb.append(guaranteeAmt==null?"null":getGuaranteeAmt());
		sb.append("\n");
		sb.append("\trentSupply: ");
		sb.append(rentSupply==null?"null":getRentSupply());
		sb.append("\n");
		sb.append("\trentVat: ");
		sb.append(rentVat==null?"null":getRentVat());
		sb.append("\n");
		sb.append("\trentSdate: ");
		sb.append(rentSdate==null?"null":getRentSdate());
		sb.append("\n");
		sb.append("\trentEdate: ");
		sb.append(rentEdate==null?"null":getRentEdate());
		sb.append("\n");
		sb.append("\trealCustName: ");
		sb.append(realCustName==null?"null":getRealCustName());
		sb.append("\n");
		sb.append("\trealInDate: ");
		sb.append(realInDate==null?"null":getRealInDate());
		sb.append("\n");
		sb.append("\tchangeTag: ");
		sb.append(changeTag==null?"null":getChangeTag());
		sb.append("\n");
		sb.append("\tchangeDate: ");
		sb.append(changeDate==null?"null":getChangeDate());
		sb.append("\n");
		sb.append("\tlastChangeDate: ");
		sb.append(lastChangeDate==null?"null":getLastChangeDate());
		sb.append("\n");
		sb.append("\trentChgSeq: ");
		sb.append(rentChgSeq==null?"null":getRentChgSeq());
		sb.append("\n");
		sb.append("\ttermChgSeq: ");
		sb.append(termChgSeq==null?"null":getTermChgSeq());
		sb.append("\n");
		sb.append("\trelaCustcode: ");
		sb.append(relaCustcode==null?"null":getRelaCustcode());
		sb.append("\n");
		sb.append("\trelaSeq: ");
		sb.append(relaSeq==null?"null":getRelaSeq());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\trenthdYn: ");
		sb.append(renthdYn==null?"null":getRenthdYn());
		sb.append("\n");
		sb.append("\trenthdSeq: ");
		sb.append(renthdSeq==null?"null":getRenthdSeq());
		sb.append("\n");
		sb.append("\tdaymonthTag: ");
		sb.append(daymonthTag==null?"null":getDaymonthTag());
		sb.append("\n");
		sb.append("\tfixrateTag: ");
		sb.append(fixrateTag==null?"null":getFixrateTag());
		sb.append("\n");
		sb.append("\tvirYn: ");
		sb.append(virYn==null?"null":getVirYn());
		sb.append("\n");
		sb.append("\tvdeposit: ");
		sb.append(vdeposit==null?"null":getVdeposit());
		sb.append("\n");
		sb.append("\trentIns: ");
		sb.append(rentIns==null?"null":getRentIns());
		sb.append("\n");
		sb.append("\tfixrate: ");
		sb.append(fixrate==null?"null":getFixrate());
		sb.append("\n");
		sb.append("\tfixrate2: ");
		sb.append(fixrate2==null?"null":getFixrate2());
		sb.append("\n");
		sb.append("\tfixrateDay: ");
		sb.append(fixrateDay==null?"null":getFixrateDay());
		sb.append("\n");
		sb.append("\thopeHouseTag: ");
		sb.append(hopeHouseTag==null?"null":getHopeHouseTag());
		sb.append("\n");
		sb.append("\treturnYn: ");
		sb.append(returnYn==null?"null":getReturnYn());
		sb.append("\n");
		sb.append("\treturnDate: ");
		sb.append(returnDate==null?"null":getReturnDate());
		sb.append("\n");
		sb.append("\trGurtamt: ");
		sb.append(rGurtamt==null?"null":getrGurtamt());
		sb.append("\n");
		sb.append("\trRentamt: ");
		sb.append(rRentamt==null?"null":getrRentamt());
		sb.append("\n");
		sb.append("\trDelayamt: ");
		sb.append(rDelayamt==null?"null":getrDelayamt());
		sb.append("\n");
		sb.append("\trPenaltyamt: ");
		sb.append(rPenaltyamt==null?"null":getrPenaltyamt());
		sb.append("\n");
		sb.append("\trEtcamt1: ");
		sb.append(rEtcamt1==null?"null":getrEtcamt1());
		sb.append("\n");
		sb.append("\trEtcamt2: ");
		sb.append(rEtcamt2==null?"null":getrEtcamt2());
		sb.append("\n");
		sb.append("\trEtcamt3: ");
		sb.append(rEtcamt3==null?"null":getrEtcamt3());
		sb.append("\n");
		sb.append("\treturnAmt: ");
		sb.append(returnAmt==null?"null":getReturnAmt());
		sb.append("\n");
		sb.append("\tslipDate: ");
		sb.append(slipDate==null?"null":getSlipDate());
		sb.append("\n");
		sb.append("\tslipSeq: ");
		sb.append(slipSeq==null?"null":getSlipSeq());
		sb.append("\n");
		sb.append("\thousecontamt: ");
		sb.append(housecontamt==null?"null":getHousecontamt());
		sb.append("\n");
		sb.append("\trBank: ");
		sb.append(rBank==null?"null":getrBank());
		sb.append("\n");
		sb.append("\trDeposit: ");
		sb.append(rDeposit==null?"null":getrDeposit());
		sb.append("\n");
		sb.append("\trDepositor: ");
		sb.append(rDepositor==null?"null":getrDepositor());
		sb.append("\n");
		sb.append("\tslipSeq2: ");
		sb.append(slipSeq2==null?"null":getSlipSeq2());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 50; /* custName */
		messageLen+= 8; /* contDate */
		messageLen+= 10; /* contNo */
		messageLen+= 2; /* contType */
		messageLen+= 1; /* vatYn */
		messageLen+= 22; /* guaranteeAmt */
		messageLen+= 22; /* rentSupply */
		messageLen+= 22; /* rentVat */
		messageLen+= 8; /* rentSdate */
		messageLen+= 8; /* rentEdate */
		messageLen+= 30; /* realCustName */
		messageLen+= 8; /* realInDate */
		messageLen+= 1; /* changeTag */
		messageLen+= 8; /* changeDate */
		messageLen+= 8; /* lastChangeDate */
		messageLen+= 22; /* rentChgSeq */
		messageLen+= 22; /* termChgSeq */
		messageLen+= 20; /* relaCustcode */
		messageLen+= 22; /* relaSeq */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 1; /* renthdYn */
		messageLen+= 22; /* renthdSeq */
		messageLen+= 1; /* daymonthTag */
		messageLen+= 1; /* fixrateTag */
		messageLen+= 1; /* virYn */
		messageLen+= 50; /* vdeposit */
		messageLen+= 22; /* rentIns */
		messageLen+= 22; /* fixrate */
		messageLen+= 22; /* fixrate2 */
		messageLen+= 22; /* fixrateDay */
		messageLen+= 1; /* hopeHouseTag */
		messageLen+= 1; /* returnYn */
		messageLen+= 8; /* returnDate */
		messageLen+= 22; /* rGurtamt */
		messageLen+= 22; /* rRentamt */
		messageLen+= 22; /* rDelayamt */
		messageLen+= 22; /* rPenaltyamt */
		messageLen+= 22; /* rEtcamt1 */
		messageLen+= 22; /* rEtcamt2 */
		messageLen+= 22; /* rEtcamt3 */
		messageLen+= 22; /* returnAmt */
		messageLen+= 8; /* slipDate */
		messageLen+= 22; /* slipSeq */
		messageLen+= 22; /* housecontamt */
		messageLen+= 40; /* rBank */
		messageLen+= 30; /* rDeposit */
		messageLen+= 100; /* rDepositor */
		messageLen+= 22; /* slipSeq2 */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("custName");
	
		fieldNames.add("contDate");
	
		fieldNames.add("contNo");
	
		fieldNames.add("contType");
	
		fieldNames.add("vatYn");
	
		fieldNames.add("guaranteeAmt");
	
		fieldNames.add("rentSupply");
	
		fieldNames.add("rentVat");
	
		fieldNames.add("rentSdate");
	
		fieldNames.add("rentEdate");
	
		fieldNames.add("realCustName");
	
		fieldNames.add("realInDate");
	
		fieldNames.add("changeTag");
	
		fieldNames.add("changeDate");
	
		fieldNames.add("lastChangeDate");
	
		fieldNames.add("rentChgSeq");
	
		fieldNames.add("termChgSeq");
	
		fieldNames.add("relaCustcode");
	
		fieldNames.add("relaSeq");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("renthdYn");
	
		fieldNames.add("renthdSeq");
	
		fieldNames.add("daymonthTag");
	
		fieldNames.add("fixrateTag");
	
		fieldNames.add("virYn");
	
		fieldNames.add("vdeposit");
	
		fieldNames.add("rentIns");
	
		fieldNames.add("fixrate");
	
		fieldNames.add("fixrate2");
	
		fieldNames.add("fixrateDay");
	
		fieldNames.add("hopeHouseTag");
	
		fieldNames.add("returnYn");
	
		fieldNames.add("returnDate");
	
		fieldNames.add("rGurtamt");
	
		fieldNames.add("rRentamt");
	
		fieldNames.add("rDelayamt");
	
		fieldNames.add("rPenaltyamt");
	
		fieldNames.add("rEtcamt1");
	
		fieldNames.add("rEtcamt2");
	
		fieldNames.add("rEtcamt3");
	
		fieldNames.add("returnAmt");
	
		fieldNames.add("slipDate");
	
		fieldNames.add("slipSeq");
	
		fieldNames.add("housecontamt");
	
		fieldNames.add("rBank");
	
		fieldNames.add("rDeposit");
	
		fieldNames.add("rDepositor");
	
		fieldNames.add("slipSeq2");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("custName", get("custName"));
	
		fieldValueMap.put("contDate", get("contDate"));
	
		fieldValueMap.put("contNo", get("contNo"));
	
		fieldValueMap.put("contType", get("contType"));
	
		fieldValueMap.put("vatYn", get("vatYn"));
	
		fieldValueMap.put("guaranteeAmt", get("guaranteeAmt"));
	
		fieldValueMap.put("rentSupply", get("rentSupply"));
	
		fieldValueMap.put("rentVat", get("rentVat"));
	
		fieldValueMap.put("rentSdate", get("rentSdate"));
	
		fieldValueMap.put("rentEdate", get("rentEdate"));
	
		fieldValueMap.put("realCustName", get("realCustName"));
	
		fieldValueMap.put("realInDate", get("realInDate"));
	
		fieldValueMap.put("changeTag", get("changeTag"));
	
		fieldValueMap.put("changeDate", get("changeDate"));
	
		fieldValueMap.put("lastChangeDate", get("lastChangeDate"));
	
		fieldValueMap.put("rentChgSeq", get("rentChgSeq"));
	
		fieldValueMap.put("termChgSeq", get("termChgSeq"));
	
		fieldValueMap.put("relaCustcode", get("relaCustcode"));
	
		fieldValueMap.put("relaSeq", get("relaSeq"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("renthdYn", get("renthdYn"));
	
		fieldValueMap.put("renthdSeq", get("renthdSeq"));
	
		fieldValueMap.put("daymonthTag", get("daymonthTag"));
	
		fieldValueMap.put("fixrateTag", get("fixrateTag"));
	
		fieldValueMap.put("virYn", get("virYn"));
	
		fieldValueMap.put("vdeposit", get("vdeposit"));
	
		fieldValueMap.put("rentIns", get("rentIns"));
	
		fieldValueMap.put("fixrate", get("fixrate"));
	
		fieldValueMap.put("fixrate2", get("fixrate2"));
	
		fieldValueMap.put("fixrateDay", get("fixrateDay"));
	
		fieldValueMap.put("hopeHouseTag", get("hopeHouseTag"));
	
		fieldValueMap.put("returnYn", get("returnYn"));
	
		fieldValueMap.put("returnDate", get("returnDate"));
	
		fieldValueMap.put("rGurtamt", get("rGurtamt"));
	
		fieldValueMap.put("rRentamt", get("rRentamt"));
	
		fieldValueMap.put("rDelayamt", get("rDelayamt"));
	
		fieldValueMap.put("rPenaltyamt", get("rPenaltyamt"));
	
		fieldValueMap.put("rEtcamt1", get("rEtcamt1"));
	
		fieldValueMap.put("rEtcamt2", get("rEtcamt2"));
	
		fieldValueMap.put("rEtcamt3", get("rEtcamt3"));
	
		fieldValueMap.put("returnAmt", get("returnAmt"));
	
		fieldValueMap.put("slipDate", get("slipDate"));
	
		fieldValueMap.put("slipSeq", get("slipSeq"));
	
		fieldValueMap.put("housecontamt", get("housecontamt"));
	
		fieldValueMap.put("rBank", get("rBank"));
	
		fieldValueMap.put("rDeposit", get("rDeposit"));
	
		fieldValueMap.put("rDepositor", get("rDepositor"));
	
		fieldValueMap.put("slipSeq2", get("slipSeq2"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 605180798 : /* custName */
			return getCustName();
		case -568317440 : /* contDate */
			return getContDate();
		case -1354779501 : /* contNo */
			return getContNo();
		case -567817844 : /* contType */
			return getContType();
		case 111979550 : /* vatYn */
			return getVatYn();
		case -1640212960 : /* guaranteeAmt */
			return getGuaranteeAmt();
		case 1997529480 : /* rentSupply */
			return getRentSupply();
		case 1092877616 : /* rentVat */
			return getRentVat();
		case -2014294296 : /* rentSdate */
			return getRentSdate();
		case -2027223590 : /* rentEdate */
			return getRentEdate();
		case 1878364988 : /* realCustName */
			return getRealCustName();
		case 2011655601 : /* realInDate */
			return getRealInDate();
		case 1455248842 : /* changeTag */
			return getChangeTag();
		case -2132402306 : /* changeDate */
			return getChangeDate();
		case -1923298636 : /* lastChangeDate */
			return getLastChangeDate();
		case 1527161078 : /* rentChgSeq */
			return getRentChgSeq();
		case 1892849641 : /* termChgSeq */
			return getTermChgSeq();
		case -1875482168 : /* relaCustcode */
			return getRelaCustcode();
		case 1090461783 : /* relaSeq */
			return getRelaSeq();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -479993878 : /* renthdYn */
			return getRenthdYn();
		case -1994914262 : /* renthdSeq */
			return getRenthdSeq();
		case -1166132074 : /* daymonthTag */
			return getDaymonthTag();
		case 293597413 : /* fixrateTag */
			return getFixrateTag();
		case 112215956 : /* virYn */
			return getVirYn();
		case 1047643496 : /* vdeposit */
			return getVdeposit();
		case 1092865525 : /* rentIns */
			return getRentIns();
		case -843528587 : /* fixrate */
			return getFixrate();
		case -379582371 : /* fixrate2 */
			return getFixrate2();
		case 293582055 : /* fixrateDay */
			return getFixrateDay();
		case 63506870 : /* hopeHouseTag */
			return getHopeHouseTag();
		case -306987931 : /* returnYn */
			return getReturnYn();
		case 1336707326 : /* returnDate */
			return getReturnDate();
		case -1136388282 : /* rGurtamt */
			return getrGurtamt();
		case -425542883 : /* rRentamt */
			return getrRentamt();
		case 989429751 : /* rDelayamt */
			return getrDelayamt();
		case -1867579727 : /* rPenaltyamt */
			return getrPenaltyamt();
		case 1340535339 : /* rEtcamt1 */
			return getrEtcamt1();
		case 1340535340 : /* rEtcamt2 */
			return getrEtcamt2();
		case 1340535341 : /* rEtcamt3 */
			return getrEtcamt3();
		case -926714248 : /* returnAmt */
			return getReturnAmt();
		case -1262506738 : /* slipDate */
			return getSlipDate();
		case -2118921473 : /* slipSeq */
			return getSlipSeq();
		case 607197750 : /* housecontamt */
			return getHousecontamt();
		case 107344334 : /* rBank */
			return getrBank();
		case 36022732 : /* rDeposit */
			return getrDeposit();
		case 258110639 : /* rDepositor */
			return getrDepositor();
		case -1262056173 : /* slipSeq2 */
			return getSlipSeq2();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 605180798 : /* custName */
			setCustName((java.lang.String) value);
			return;
		case -568317440 : /* contDate */
			setContDate((java.lang.String) value);
			return;
		case -1354779501 : /* contNo */
			setContNo((java.lang.String) value);
			return;
		case -567817844 : /* contType */
			setContType((java.lang.String) value);
			return;
		case 111979550 : /* vatYn */
			setVatYn((java.lang.String) value);
			return;
		case -1640212960 : /* guaranteeAmt */
			setGuaranteeAmt((java.math.BigDecimal) value);
			return;
		case 1997529480 : /* rentSupply */
			setRentSupply((java.math.BigDecimal) value);
			return;
		case 1092877616 : /* rentVat */
			setRentVat((java.math.BigDecimal) value);
			return;
		case -2014294296 : /* rentSdate */
			setRentSdate((java.lang.String) value);
			return;
		case -2027223590 : /* rentEdate */
			setRentEdate((java.lang.String) value);
			return;
		case 1878364988 : /* realCustName */
			setRealCustName((java.lang.String) value);
			return;
		case 2011655601 : /* realInDate */
			setRealInDate((java.lang.String) value);
			return;
		case 1455248842 : /* changeTag */
			setChangeTag((java.lang.String) value);
			return;
		case -2132402306 : /* changeDate */
			setChangeDate((java.lang.String) value);
			return;
		case -1923298636 : /* lastChangeDate */
			setLastChangeDate((java.lang.String) value);
			return;
		case 1527161078 : /* rentChgSeq */
			setRentChgSeq((java.math.BigDecimal) value);
			return;
		case 1892849641 : /* termChgSeq */
			setTermChgSeq((java.math.BigDecimal) value);
			return;
		case -1875482168 : /* relaCustcode */
			setRelaCustcode((java.lang.String) value);
			return;
		case 1090461783 : /* relaSeq */
			setRelaSeq((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -479993878 : /* renthdYn */
			setRenthdYn((java.lang.String) value);
			return;
		case -1994914262 : /* renthdSeq */
			setRenthdSeq((java.math.BigDecimal) value);
			return;
		case -1166132074 : /* daymonthTag */
			setDaymonthTag((java.lang.String) value);
			return;
		case 293597413 : /* fixrateTag */
			setFixrateTag((java.lang.String) value);
			return;
		case 112215956 : /* virYn */
			setVirYn((java.lang.String) value);
			return;
		case 1047643496 : /* vdeposit */
			setVdeposit((java.lang.String) value);
			return;
		case 1092865525 : /* rentIns */
			setRentIns((java.math.BigDecimal) value);
			return;
		case -843528587 : /* fixrate */
			setFixrate((java.lang.Float) value);
			return;
		case -379582371 : /* fixrate2 */
			setFixrate2((java.lang.Float) value);
			return;
		case 293582055 : /* fixrateDay */
			setFixrateDay((java.math.BigDecimal) value);
			return;
		case 63506870 : /* hopeHouseTag */
			setHopeHouseTag((java.lang.String) value);
			return;
		case -306987931 : /* returnYn */
			setReturnYn((java.lang.String) value);
			return;
		case 1336707326 : /* returnDate */
			setReturnDate((java.lang.String) value);
			return;
		case -1136388282 : /* rGurtamt */
			setrGurtamt((java.math.BigDecimal) value);
			return;
		case -425542883 : /* rRentamt */
			setrRentamt((java.math.BigDecimal) value);
			return;
		case 989429751 : /* rDelayamt */
			setrDelayamt((java.math.BigDecimal) value);
			return;
		case -1867579727 : /* rPenaltyamt */
			setrPenaltyamt((java.math.BigDecimal) value);
			return;
		case 1340535339 : /* rEtcamt1 */
			setrEtcamt1((java.math.BigDecimal) value);
			return;
		case 1340535340 : /* rEtcamt2 */
			setrEtcamt2((java.math.BigDecimal) value);
			return;
		case 1340535341 : /* rEtcamt3 */
			setrEtcamt3((java.math.BigDecimal) value);
			return;
		case -926714248 : /* returnAmt */
			setReturnAmt((java.math.BigDecimal) value);
			return;
		case -1262506738 : /* slipDate */
			setSlipDate((java.lang.String) value);
			return;
		case -2118921473 : /* slipSeq */
			setSlipSeq((java.math.BigDecimal) value);
			return;
		case 607197750 : /* housecontamt */
			setHousecontamt((java.math.BigDecimal) value);
			return;
		case 107344334 : /* rBank */
			setrBank((java.lang.String) value);
			return;
		case 36022732 : /* rDeposit */
			setrDeposit((java.lang.String) value);
			return;
		case 258110639 : /* rDepositor */
			setrDepositor((java.lang.String) value);
			return;
		case -1262056173 : /* slipSeq2 */
			setSlipSeq2((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
