/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_고정연체이율 ( HD_RENT_FIXRATE )
 */
@XmlType(propOrder={"deptCode", "housetag", "workmm", "rate1", "rate2", "startTag", "endTag", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDRentFixrate01IO")
@XmlRootElement(name="DHDRentFixrate01IO")
@SuppressWarnings("all")
public class DHDRentFixrate01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1563526433L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_고정연체이율 ( HD_RENT_FIXRATE )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012617(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012617(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012617(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012618(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012618(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012618(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << workmm >> [[ */
	
	@XmlTransient
	private boolean isSet_workmm = false;
	
	protected boolean isSet_workmm()
	{
		return this.isSet_workmm;
	}
	
	protected void setIsSet_workmm(boolean value)
	{
		this.isSet_workmm = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 작업월 [SYS_C0012619(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	public void setWorkmm(java.lang.String value) {
		isSet_workmm = true;
		this.workmm = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 작업월 [SYS_C0012619(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	public void setWorkmm(double value) {
		isSet_workmm = true;
		this.workmm = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 작업월 [SYS_C0012619(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	public void setWorkmm(long value) {
		isSet_workmm = true;
		this.workmm = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="작업월 [SYS_C0012619(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal workmm  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 작업월 [SYS_C0012619(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	public java.math.BigDecimal getWorkmm(){
		return workmm;
	}
	
	/**
	 * @Description 작업월 [SYS_C0012619(C),SYS_C0012991(P) SYS_C0012991(UNIQUE)]
	 */
	@JsonProperty("workmm")
	public void setWorkmm( java.math.BigDecimal workmm ) {
		isSet_workmm = true;
		this.workmm = workmm;
	}
	
	/** Property set << workmm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rate1 >> [[ */
	
	@XmlTransient
	private boolean isSet_rate1 = false;
	
	protected boolean isSet_rate1()
	{
		return this.isSet_rate1;
	}
	
	protected void setIsSet_rate1(boolean value)
	{
		this.isSet_rate1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납기내", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float rate1  = .0F;
	
	/**
	 * @Description 납기내
	 */
	public java.lang.Float getRate1(){
		return rate1;
	}
	
	/**
	 * @Description 납기내
	 */
	@JsonProperty("rate1")
	public void setRate1( java.lang.Float rate1 ) {
		isSet_rate1 = true;
		this.rate1 = rate1;
	}
	
	/** Property set << rate1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rate2 >> [[ */
	
	@XmlTransient
	private boolean isSet_rate2 = false;
	
	protected boolean isSet_rate2()
	{
		return this.isSet_rate2;
	}
	
	protected void setIsSet_rate2(boolean value)
	{
		this.isSet_rate2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납기후", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float rate2  = .0F;
	
	/**
	 * @Description 납기후
	 */
	public java.lang.Float getRate2(){
		return rate2;
	}
	
	/**
	 * @Description 납기후
	 */
	@JsonProperty("rate2")
	public void setRate2( java.lang.Float rate2 ) {
		isSet_rate2 = true;
		this.rate2 = rate2;
	}
	
	/** Property set << rate2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << startTag >> [[ */
	
	@XmlTransient
	private boolean isSet_startTag = false;
	
	protected boolean isSet_startTag()
	{
		return this.isSet_startTag;
	}
	
	protected void setIsSet_startTag(boolean value)
	{
		this.isSet_startTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시작월수_포함구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String startTag  = null;
	
	/**
	 * @Description 시작월수_포함구분
	 */
	public java.lang.String getStartTag(){
		return startTag;
	}
	
	/**
	 * @Description 시작월수_포함구분
	 */
	@JsonProperty("startTag")
	public void setStartTag( java.lang.String startTag ) {
		isSet_startTag = true;
		this.startTag = startTag;
	}
	
	/** Property set << startTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endTag >> [[ */
	
	@XmlTransient
	private boolean isSet_endTag = false;
	
	protected boolean isSet_endTag()
	{
		return this.isSet_endTag;
	}
	
	protected void setIsSet_endTag(boolean value)
	{
		this.isSet_endTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="종료월수_포함구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String endTag  = null;
	
	/**
	 * @Description 종료월수_포함구분
	 */
	public java.lang.String getEndTag(){
		return endTag;
	}
	
	/**
	 * @Description 종료월수_포함구분
	 */
	@JsonProperty("endTag")
	public void setEndTag( java.lang.String endTag ) {
		isSet_endTag = true;
		this.endTag = endTag;
	}
	
	/** Property set << endTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentFixrate01IO clone(){
		try{
			DHDRentFixrate01IO object= (DHDRentFixrate01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.workmm== null ) object.workmm = null;
			else{
				object.workmm = new java.math.BigDecimal(workmm.toString());
			}
			if ( this.rate1== null ) object.rate1 = null;
			else{
				object.rate1 = this.rate1;
			}
			if ( this.rate2== null ) object.rate2 = null;
			else{
				object.rate2 = this.rate2;
			}
			if ( this.startTag== null ) object.startTag = null;
			else{
				object.startTag = this.startTag;
			}
			if ( this.endTag== null ) object.endTag = null;
			else{
				object.endTag = this.endTag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((workmm==null)?0:workmm.hashCode());
		result = prime * result + ((rate1==null)?0:rate1.hashCode());
		result = prime * result + ((rate2==null)?0:rate2.hashCode());
		result = prime * result + ((startTag==null)?0:startTag.hashCode());
		result = prime * result + ((endTag==null)?0:endTag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentFixrate01IO other = (kait.hd.rent.onl.dao.dto.DHDRentFixrate01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( workmm == null ){
			if ( other.workmm != null ) return false;
		}
		else if ( !workmm.equals(other.workmm) )
			return false;
		if ( rate1 == null ){
			if ( other.rate1 != null ) return false;
		}
		else if ( !rate1.equals(other.rate1) )
			return false;
		if ( rate2 == null ){
			if ( other.rate2 != null ) return false;
		}
		else if ( !rate2.equals(other.rate2) )
			return false;
		if ( startTag == null ){
			if ( other.startTag != null ) return false;
		}
		else if ( !startTag.equals(other.startTag) )
			return false;
		if ( endTag == null ){
			if ( other.endTag != null ) return false;
		}
		else if ( !endTag.equals(other.endTag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentFixrate01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tworkmm: ");
		sb.append(workmm==null?"null":getWorkmm());
		sb.append("\n");
		sb.append("\trate1: ");
		sb.append(rate1==null?"null":getRate1());
		sb.append("\n");
		sb.append("\trate2: ");
		sb.append(rate2==null?"null":getRate2());
		sb.append("\n");
		sb.append("\tstartTag: ");
		sb.append(startTag==null?"null":getStartTag());
		sb.append("\n");
		sb.append("\tendTag: ");
		sb.append(endTag==null?"null":getEndTag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* workmm */
		messageLen+= 22; /* rate1 */
		messageLen+= 22; /* rate2 */
		messageLen+= 1; /* startTag */
		messageLen+= 1; /* endTag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("workmm");
	
		fieldNames.add("rate1");
	
		fieldNames.add("rate2");
	
		fieldNames.add("startTag");
	
		fieldNames.add("endTag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("workmm", get("workmm"));
	
		fieldValueMap.put("rate1", get("rate1"));
	
		fieldValueMap.put("rate2", get("rate2"));
	
		fieldValueMap.put("startTag", get("startTag"));
	
		fieldValueMap.put("endTag", get("endTag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -782085007 : /* workmm */
			return getWorkmm();
		case 108285777 : /* rate1 */
			return getRate1();
		case 108285778 : /* rate2 */
			return getRate2();
		case 1316786136 : /* startTag */
			return getStartTag();
		case -1298772801 : /* endTag */
			return getEndTag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -782085007 : /* workmm */
			setWorkmm((java.math.BigDecimal) value);
			return;
		case 108285777 : /* rate1 */
			setRate1((java.lang.Float) value);
			return;
		case 108285778 : /* rate2 */
			setRate2((java.lang.Float) value);
			return;
		case 1316786136 : /* startTag */
			setStartTag((java.lang.String) value);
			return;
		case -1298772801 : /* endTag */
			setEndTag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
