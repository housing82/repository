/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_보증금약정사항 ( HD_RENT_GURT_AGREE )
 */
@XmlType(propOrder={"custCode", "seq", "termChgSeq", "counts", "agreeDate", "agreeAmt", "discntYn", "delayYn", "perpectTag", "receiptAmt", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "slipDate", "slipSeq"}, name="DHDRentGurtAgree01IO")
@XmlRootElement(name="DHDRentGurtAgree01IO")
@SuppressWarnings("all")
public class DHDRentGurtAgree01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 488533254L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_보증금약정사항 ( HD_RENT_GURT_AGREE )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012624(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012624(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012624(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012625(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012625(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012625(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012625(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012625(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012625(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << termChgSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_termChgSeq = false;
	
	protected boolean isSet_termChgSeq()
	{
		return this.isSet_termChgSeq;
	}
	
	protected void setIsSet_termChgSeq(boolean value)
	{
		this.isSet_termChgSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약차수 [SYS_C0012626(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public void setTermChgSeq(java.lang.String value) {
		isSet_termChgSeq = true;
		this.termChgSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약차수 [SYS_C0012626(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public void setTermChgSeq(double value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약차수 [SYS_C0012626(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public void setTermChgSeq(long value) {
		isSet_termChgSeq = true;
		this.termChgSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약차수 [SYS_C0012626(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal termChgSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약차수 [SYS_C0012626(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public java.math.BigDecimal getTermChgSeq(){
		return termChgSeq;
	}
	
	/**
	 * @Description 계약차수 [SYS_C0012626(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	@JsonProperty("termChgSeq")
	public void setTermChgSeq( java.math.BigDecimal termChgSeq ) {
		isSet_termChgSeq = true;
		this.termChgSeq = termChgSeq;
	}
	
	/** Property set << termChgSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << counts >> [[ */
	
	@XmlTransient
	private boolean isSet_counts = false;
	
	protected boolean isSet_counts()
	{
		return this.isSet_counts;
	}
	
	protected void setIsSet_counts(boolean value)
	{
		this.isSet_counts = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정차수 [SYS_C0012627(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String counts  = null;
	
	/**
	 * @Description 약정차수 [SYS_C0012627(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	public java.lang.String getCounts(){
		return counts;
	}
	
	/**
	 * @Description 약정차수 [SYS_C0012627(C),SYS_C0012993(P) SYS_C0012993(UNIQUE)]
	 */
	@JsonProperty("counts")
	public void setCounts( java.lang.String counts ) {
		isSet_counts = true;
		this.counts = counts;
	}
	
	/** Property set << counts >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeDate = false;
	
	protected boolean isSet_agreeDate()
	{
		return this.isSet_agreeDate;
	}
	
	protected void setIsSet_agreeDate(boolean value)
	{
		this.isSet_agreeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="약정일자 [SYS_C0012628(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeDate  = null;
	
	/**
	 * @Description 약정일자 [SYS_C0012628(C)]
	 */
	public java.lang.String getAgreeDate(){
		return agreeDate;
	}
	
	/**
	 * @Description 약정일자 [SYS_C0012628(C)]
	 */
	@JsonProperty("agreeDate")
	public void setAgreeDate( java.lang.String agreeDate ) {
		isSet_agreeDate = true;
		this.agreeDate = agreeDate;
	}
	
	/** Property set << agreeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeAmt = false;
	
	protected boolean isSet_agreeAmt()
	{
		return this.isSet_agreeAmt;
	}
	
	protected void setIsSet_agreeAmt(boolean value)
	{
		this.isSet_agreeAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 보증금금액
	 */
	public void setAgreeAmt(java.lang.String value) {
		isSet_agreeAmt = true;
		this.agreeAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 보증금금액
	 */
	public void setAgreeAmt(double value) {
		isSet_agreeAmt = true;
		this.agreeAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 보증금금액
	 */
	public void setAgreeAmt(long value) {
		isSet_agreeAmt = true;
		this.agreeAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="보증금금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal agreeAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 보증금금액
	 */
	public java.math.BigDecimal getAgreeAmt(){
		return agreeAmt;
	}
	
	/**
	 * @Description 보증금금액
	 */
	@JsonProperty("agreeAmt")
	public void setAgreeAmt( java.math.BigDecimal agreeAmt ) {
		isSet_agreeAmt = true;
		this.agreeAmt = agreeAmt;
	}
	
	/** Property set << agreeAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntYn >> [[ */
	
	@XmlTransient
	private boolean isSet_discntYn = false;
	
	protected boolean isSet_discntYn()
	{
		return this.isSet_discntYn;
	}
	
	protected void setIsSet_discntYn(boolean value)
	{
		this.isSet_discntYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="할인계산여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String discntYn  = null;
	
	/**
	 * @Description 할인계산여부
	 */
	public java.lang.String getDiscntYn(){
		return discntYn;
	}
	
	/**
	 * @Description 할인계산여부
	 */
	@JsonProperty("discntYn")
	public void setDiscntYn( java.lang.String discntYn ) {
		isSet_discntYn = true;
		this.discntYn = discntYn;
	}
	
	/** Property set << discntYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayYn >> [[ */
	
	@XmlTransient
	private boolean isSet_delayYn = false;
	
	protected boolean isSet_delayYn()
	{
		return this.isSet_delayYn;
	}
	
	protected void setIsSet_delayYn(boolean value)
	{
		this.isSet_delayYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체계산여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String delayYn  = null;
	
	/**
	 * @Description 연체계산여부
	 */
	public java.lang.String getDelayYn(){
		return delayYn;
	}
	
	/**
	 * @Description 연체계산여부
	 */
	@JsonProperty("delayYn")
	public void setDelayYn( java.lang.String delayYn ) {
		isSet_delayYn = true;
		this.delayYn = delayYn;
	}
	
	/** Property set << delayYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << perpectTag >> [[ */
	
	@XmlTransient
	private boolean isSet_perpectTag = false;
	
	protected boolean isSet_perpectTag()
	{
		return this.isSet_perpectTag;
	}
	
	protected void setIsSet_perpectTag(boolean value)
	{
		this.isSet_perpectTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="완료구분 [SYS_C0012629(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String perpectTag  = null;
	
	/**
	 * @Description 완료구분 [SYS_C0012629(C)]
	 */
	public java.lang.String getPerpectTag(){
		return perpectTag;
	}
	
	/**
	 * @Description 완료구분 [SYS_C0012629(C)]
	 */
	@JsonProperty("perpectTag")
	public void setPerpectTag( java.lang.String perpectTag ) {
		isSet_perpectTag = true;
		this.perpectTag = perpectTag;
	}
	
	/** Property set << perpectTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptAmt = false;
	
	protected boolean isSet_receiptAmt()
	{
		return this.isSet_receiptAmt;
	}
	
	protected void setIsSet_receiptAmt(boolean value)
	{
		this.isSet_receiptAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 입금합계 [SYS_C0012630(C)]
	 */
	public void setReceiptAmt(java.lang.String value) {
		isSet_receiptAmt = true;
		this.receiptAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 입금합계 [SYS_C0012630(C)]
	 */
	public void setReceiptAmt(double value) {
		isSet_receiptAmt = true;
		this.receiptAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 입금합계 [SYS_C0012630(C)]
	 */
	public void setReceiptAmt(long value) {
		isSet_receiptAmt = true;
		this.receiptAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="입금합계 [SYS_C0012630(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 입금합계 [SYS_C0012630(C)]
	 */
	public java.math.BigDecimal getReceiptAmt(){
		return receiptAmt;
	}
	
	/**
	 * @Description 입금합계 [SYS_C0012630(C)]
	 */
	@JsonProperty("receiptAmt")
	public void setReceiptAmt( java.math.BigDecimal receiptAmt ) {
		isSet_receiptAmt = true;
		this.receiptAmt = receiptAmt;
	}
	
	/** Property set << receiptAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipDate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipDate = false;
	
	protected boolean isSet_slipDate()
	{
		return this.isSet_slipDate;
	}
	
	protected void setIsSet_slipDate(boolean value)
	{
		this.isSet_slipDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipDate  = null;
	
	/**
	 * @Description 전표일자
	 */
	public java.lang.String getSlipDate(){
		return slipDate;
	}
	
	/**
	 * @Description 전표일자
	 */
	@JsonProperty("slipDate")
	public void setSlipDate( java.lang.String slipDate ) {
		isSet_slipDate = true;
		this.slipDate = slipDate;
	}
	
	/** Property set << slipDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipSeq = false;
	
	protected boolean isSet_slipSeq()
	{
		return this.isSet_slipSeq;
	}
	
	protected void setIsSet_slipSeq(boolean value)
	{
		this.isSet_slipSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(java.lang.String value) {
		isSet_slipSeq = true;
		this.slipSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(double value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번
	 */
	public void setSlipSeq(long value) {
		isSet_slipSeq = true;
		this.slipSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번
	 */
	public java.math.BigDecimal getSlipSeq(){
		return slipSeq;
	}
	
	/**
	 * @Description 전표순번
	 */
	@JsonProperty("slipSeq")
	public void setSlipSeq( java.math.BigDecimal slipSeq ) {
		isSet_slipSeq = true;
		this.slipSeq = slipSeq;
	}
	
	/** Property set << slipSeq >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentGurtAgree01IO clone(){
		try{
			DHDRentGurtAgree01IO object= (DHDRentGurtAgree01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.termChgSeq== null ) object.termChgSeq = null;
			else{
				object.termChgSeq = new java.math.BigDecimal(termChgSeq.toString());
			}
			if ( this.counts== null ) object.counts = null;
			else{
				object.counts = this.counts;
			}
			if ( this.agreeDate== null ) object.agreeDate = null;
			else{
				object.agreeDate = this.agreeDate;
			}
			if ( this.agreeAmt== null ) object.agreeAmt = null;
			else{
				object.agreeAmt = new java.math.BigDecimal(agreeAmt.toString());
			}
			if ( this.discntYn== null ) object.discntYn = null;
			else{
				object.discntYn = this.discntYn;
			}
			if ( this.delayYn== null ) object.delayYn = null;
			else{
				object.delayYn = this.delayYn;
			}
			if ( this.perpectTag== null ) object.perpectTag = null;
			else{
				object.perpectTag = this.perpectTag;
			}
			if ( this.receiptAmt== null ) object.receiptAmt = null;
			else{
				object.receiptAmt = new java.math.BigDecimal(receiptAmt.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.slipDate== null ) object.slipDate = null;
			else{
				object.slipDate = this.slipDate;
			}
			if ( this.slipSeq== null ) object.slipSeq = null;
			else{
				object.slipSeq = new java.math.BigDecimal(slipSeq.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((termChgSeq==null)?0:termChgSeq.hashCode());
		result = prime * result + ((counts==null)?0:counts.hashCode());
		result = prime * result + ((agreeDate==null)?0:agreeDate.hashCode());
		result = prime * result + ((agreeAmt==null)?0:agreeAmt.hashCode());
		result = prime * result + ((discntYn==null)?0:discntYn.hashCode());
		result = prime * result + ((delayYn==null)?0:delayYn.hashCode());
		result = prime * result + ((perpectTag==null)?0:perpectTag.hashCode());
		result = prime * result + ((receiptAmt==null)?0:receiptAmt.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((slipDate==null)?0:slipDate.hashCode());
		result = prime * result + ((slipSeq==null)?0:slipSeq.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO other = (kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( termChgSeq == null ){
			if ( other.termChgSeq != null ) return false;
		}
		else if ( !termChgSeq.equals(other.termChgSeq) )
			return false;
		if ( counts == null ){
			if ( other.counts != null ) return false;
		}
		else if ( !counts.equals(other.counts) )
			return false;
		if ( agreeDate == null ){
			if ( other.agreeDate != null ) return false;
		}
		else if ( !agreeDate.equals(other.agreeDate) )
			return false;
		if ( agreeAmt == null ){
			if ( other.agreeAmt != null ) return false;
		}
		else if ( !agreeAmt.equals(other.agreeAmt) )
			return false;
		if ( discntYn == null ){
			if ( other.discntYn != null ) return false;
		}
		else if ( !discntYn.equals(other.discntYn) )
			return false;
		if ( delayYn == null ){
			if ( other.delayYn != null ) return false;
		}
		else if ( !delayYn.equals(other.delayYn) )
			return false;
		if ( perpectTag == null ){
			if ( other.perpectTag != null ) return false;
		}
		else if ( !perpectTag.equals(other.perpectTag) )
			return false;
		if ( receiptAmt == null ){
			if ( other.receiptAmt != null ) return false;
		}
		else if ( !receiptAmt.equals(other.receiptAmt) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( slipDate == null ){
			if ( other.slipDate != null ) return false;
		}
		else if ( !slipDate.equals(other.slipDate) )
			return false;
		if ( slipSeq == null ){
			if ( other.slipSeq != null ) return false;
		}
		else if ( !slipSeq.equals(other.slipSeq) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\ttermChgSeq: ");
		sb.append(termChgSeq==null?"null":getTermChgSeq());
		sb.append("\n");
		sb.append("\tcounts: ");
		sb.append(counts==null?"null":getCounts());
		sb.append("\n");
		sb.append("\tagreeDate: ");
		sb.append(agreeDate==null?"null":getAgreeDate());
		sb.append("\n");
		sb.append("\tagreeAmt: ");
		sb.append(agreeAmt==null?"null":getAgreeAmt());
		sb.append("\n");
		sb.append("\tdiscntYn: ");
		sb.append(discntYn==null?"null":getDiscntYn());
		sb.append("\n");
		sb.append("\tdelayYn: ");
		sb.append(delayYn==null?"null":getDelayYn());
		sb.append("\n");
		sb.append("\tperpectTag: ");
		sb.append(perpectTag==null?"null":getPerpectTag());
		sb.append("\n");
		sb.append("\treceiptAmt: ");
		sb.append(receiptAmt==null?"null":getReceiptAmt());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tslipDate: ");
		sb.append(slipDate==null?"null":getSlipDate());
		sb.append("\n");
		sb.append("\tslipSeq: ");
		sb.append(slipSeq==null?"null":getSlipSeq());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* termChgSeq */
		messageLen+= 2; /* counts */
		messageLen+= 8; /* agreeDate */
		messageLen+= 22; /* agreeAmt */
		messageLen+= 1; /* discntYn */
		messageLen+= 1; /* delayYn */
		messageLen+= 1; /* perpectTag */
		messageLen+= 22; /* receiptAmt */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 8; /* slipDate */
		messageLen+= 22; /* slipSeq */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("termChgSeq");
	
		fieldNames.add("counts");
	
		fieldNames.add("agreeDate");
	
		fieldNames.add("agreeAmt");
	
		fieldNames.add("discntYn");
	
		fieldNames.add("delayYn");
	
		fieldNames.add("perpectTag");
	
		fieldNames.add("receiptAmt");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("slipDate");
	
		fieldNames.add("slipSeq");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("termChgSeq", get("termChgSeq"));
	
		fieldValueMap.put("counts", get("counts"));
	
		fieldValueMap.put("agreeDate", get("agreeDate"));
	
		fieldValueMap.put("agreeAmt", get("agreeAmt"));
	
		fieldValueMap.put("discntYn", get("discntYn"));
	
		fieldValueMap.put("delayYn", get("delayYn"));
	
		fieldValueMap.put("perpectTag", get("perpectTag"));
	
		fieldValueMap.put("receiptAmt", get("receiptAmt"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("slipDate", get("slipDate"));
	
		fieldValueMap.put("slipSeq", get("slipSeq"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 1892849641 : /* termChgSeq */
			return getTermChgSeq();
		case -1354575548 : /* counts */
			return getCounts();
		case 974561402 : /* agreeDate */
			return getAgreeDate();
		case 1832550268 : /* agreeAmt */
			return getAgreeAmt();
		case 273152656 : /* discntYn */
			return getDiscntYn();
		case 1550348280 : /* delayYn */
			return getDelayYn();
		case 2015609047 : /* perpectTag */
			return getPerpectTag();
		case 204129392 : /* receiptAmt */
			return getReceiptAmt();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -1262506738 : /* slipDate */
			return getSlipDate();
		case -2118921473 : /* slipSeq */
			return getSlipSeq();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1892849641 : /* termChgSeq */
			setTermChgSeq((java.math.BigDecimal) value);
			return;
		case -1354575548 : /* counts */
			setCounts((java.lang.String) value);
			return;
		case 974561402 : /* agreeDate */
			setAgreeDate((java.lang.String) value);
			return;
		case 1832550268 : /* agreeAmt */
			setAgreeAmt((java.math.BigDecimal) value);
			return;
		case 273152656 : /* discntYn */
			setDiscntYn((java.lang.String) value);
			return;
		case 1550348280 : /* delayYn */
			setDelayYn((java.lang.String) value);
			return;
		case 2015609047 : /* perpectTag */
			setPerpectTag((java.lang.String) value);
			return;
		case 204129392 : /* receiptAmt */
			setReceiptAmt((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -1262506738 : /* slipDate */
			setSlipDate((java.lang.String) value);
			return;
		case -2118921473 : /* slipSeq */
			setSlipSeq((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
