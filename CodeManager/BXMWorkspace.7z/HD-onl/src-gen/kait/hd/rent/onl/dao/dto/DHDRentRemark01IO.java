/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_세대별특이사항 ( HD_RENT_REMARK )
 */
@XmlType(propOrder={"custCode", "seq", "remarkSeq", "remarkDate", "remark", "userId", "confirmDate", "endYn", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDRentRemark01IO")
@XmlRootElement(name="DHDRentRemark01IO")
@SuppressWarnings("all")
public class DHDRentRemark01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 134489604L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_세대별특이사항 ( HD_RENT_REMARK )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012726(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012726(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012726(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012727(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012727(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012727(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012727(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012727(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012727(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remarkSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_remarkSeq = false;
	
	protected boolean isSet_remarkSeq()
	{
		return this.isSet_remarkSeq;
	}
	
	protected void setIsSet_remarkSeq(boolean value)
	{
		this.isSet_remarkSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 입력순번 [SYS_C0012728(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public void setRemarkSeq(java.lang.String value) {
		isSet_remarkSeq = true;
		this.remarkSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 입력순번 [SYS_C0012728(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public void setRemarkSeq(double value) {
		isSet_remarkSeq = true;
		this.remarkSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 입력순번 [SYS_C0012728(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public void setRemarkSeq(long value) {
		isSet_remarkSeq = true;
		this.remarkSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="입력순번 [SYS_C0012728(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal remarkSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 입력순번 [SYS_C0012728(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	public java.math.BigDecimal getRemarkSeq(){
		return remarkSeq;
	}
	
	/**
	 * @Description 입력순번 [SYS_C0012728(C),SYS_C0013006(P) SYS_C0013006(UNIQUE)]
	 */
	@JsonProperty("remarkSeq")
	public void setRemarkSeq( java.math.BigDecimal remarkSeq ) {
		isSet_remarkSeq = true;
		this.remarkSeq = remarkSeq;
	}
	
	/** Property set << remarkSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remarkDate >> [[ */
	
	@XmlTransient
	private boolean isSet_remarkDate = false;
	
	protected boolean isSet_remarkDate()
	{
		return this.isSet_remarkDate;
	}
	
	protected void setIsSet_remarkDate(boolean value)
	{
		this.isSet_remarkDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String remarkDate  = null;
	
	/**
	 * @Description 입력일자
	 */
	public java.lang.String getRemarkDate(){
		return remarkDate;
	}
	
	/**
	 * @Description 입력일자
	 */
	@JsonProperty("remarkDate")
	public void setRemarkDate( java.lang.String remarkDate ) {
		isSet_remarkDate = true;
		this.remarkDate = remarkDate;
	}
	
	/** Property set << remarkDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="특이사항", formatType="", format="", align="left", length=500, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 특이사항
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 특이사항
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << userId >> [[ */
	
	@XmlTransient
	private boolean isSet_userId = false;
	
	protected boolean isSet_userId()
	{
		return this.isSet_userId;
	}
	
	protected void setIsSet_userId(boolean value)
	{
		this.isSet_userId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="등록자 [SYS_C0012729(C)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String userId  = null;
	
	/**
	 * @Description 등록자 [SYS_C0012729(C)]
	 */
	public java.lang.String getUserId(){
		return userId;
	}
	
	/**
	 * @Description 등록자 [SYS_C0012729(C)]
	 */
	@JsonProperty("userId")
	public void setUserId( java.lang.String userId ) {
		isSet_userId = true;
		this.userId = userId;
	}
	
	/** Property set << userId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << confirmDate >> [[ */
	
	@XmlTransient
	private boolean isSet_confirmDate = false;
	
	protected boolean isSet_confirmDate()
	{
		return this.isSet_confirmDate;
	}
	
	protected void setIsSet_confirmDate(boolean value)
	{
		this.isSet_confirmDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="확인일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String confirmDate  = null;
	
	/**
	 * @Description 확인일자
	 */
	public java.lang.String getConfirmDate(){
		return confirmDate;
	}
	
	/**
	 * @Description 확인일자
	 */
	@JsonProperty("confirmDate")
	public void setConfirmDate( java.lang.String confirmDate ) {
		isSet_confirmDate = true;
		this.confirmDate = confirmDate;
	}
	
	/** Property set << confirmDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endYn >> [[ */
	
	@XmlTransient
	private boolean isSet_endYn = false;
	
	protected boolean isSet_endYn()
	{
		return this.isSet_endYn;
	}
	
	protected void setIsSet_endYn(boolean value)
	{
		this.isSet_endYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="완료유무", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String endYn  = null;
	
	/**
	 * @Description 완료유무
	 */
	public java.lang.String getEndYn(){
		return endYn;
	}
	
	/**
	 * @Description 완료유무
	 */
	@JsonProperty("endYn")
	public void setEndYn( java.lang.String endYn ) {
		isSet_endYn = true;
		this.endYn = endYn;
	}
	
	/** Property set << endYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentRemark01IO clone(){
		try{
			DHDRentRemark01IO object= (DHDRentRemark01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.remarkSeq== null ) object.remarkSeq = null;
			else{
				object.remarkSeq = new java.math.BigDecimal(remarkSeq.toString());
			}
			if ( this.remarkDate== null ) object.remarkDate = null;
			else{
				object.remarkDate = this.remarkDate;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.userId== null ) object.userId = null;
			else{
				object.userId = this.userId;
			}
			if ( this.confirmDate== null ) object.confirmDate = null;
			else{
				object.confirmDate = this.confirmDate;
			}
			if ( this.endYn== null ) object.endYn = null;
			else{
				object.endYn = this.endYn;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((remarkSeq==null)?0:remarkSeq.hashCode());
		result = prime * result + ((remarkDate==null)?0:remarkDate.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((userId==null)?0:userId.hashCode());
		result = prime * result + ((confirmDate==null)?0:confirmDate.hashCode());
		result = prime * result + ((endYn==null)?0:endYn.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentRemark01IO other = (kait.hd.rent.onl.dao.dto.DHDRentRemark01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( remarkSeq == null ){
			if ( other.remarkSeq != null ) return false;
		}
		else if ( !remarkSeq.equals(other.remarkSeq) )
			return false;
		if ( remarkDate == null ){
			if ( other.remarkDate != null ) return false;
		}
		else if ( !remarkDate.equals(other.remarkDate) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( userId == null ){
			if ( other.userId != null ) return false;
		}
		else if ( !userId.equals(other.userId) )
			return false;
		if ( confirmDate == null ){
			if ( other.confirmDate != null ) return false;
		}
		else if ( !confirmDate.equals(other.confirmDate) )
			return false;
		if ( endYn == null ){
			if ( other.endYn != null ) return false;
		}
		else if ( !endYn.equals(other.endYn) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentRemark01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tremarkSeq: ");
		sb.append(remarkSeq==null?"null":getRemarkSeq());
		sb.append("\n");
		sb.append("\tremarkDate: ");
		sb.append(remarkDate==null?"null":getRemarkDate());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tuserId: ");
		sb.append(userId==null?"null":getUserId());
		sb.append("\n");
		sb.append("\tconfirmDate: ");
		sb.append(confirmDate==null?"null":getConfirmDate());
		sb.append("\n");
		sb.append("\tendYn: ");
		sb.append(endYn==null?"null":getEndYn());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* remarkSeq */
		messageLen+= 8; /* remarkDate */
		messageLen+= 500; /* remark */
		messageLen+= 20; /* userId */
		messageLen+= 8; /* confirmDate */
		messageLen+= 1; /* endYn */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("remarkSeq");
	
		fieldNames.add("remarkDate");
	
		fieldNames.add("remark");
	
		fieldNames.add("userId");
	
		fieldNames.add("confirmDate");
	
		fieldNames.add("endYn");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("remarkSeq", get("remarkSeq"));
	
		fieldValueMap.put("remarkDate", get("remarkDate"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("userId", get("userId"));
	
		fieldValueMap.put("confirmDate", get("confirmDate"));
	
		fieldValueMap.put("endYn", get("endYn"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 878039231 : /* remarkSeq */
			return getRemarkSeq();
		case 1448961870 : /* remarkDate */
			return getRemarkDate();
		case -934624384 : /* remark */
			return getRemark();
		case -836030906 : /* userId */
			return getUserId();
		case 343927438 : /* confirmDate */
			return getConfirmDate();
		case 96651600 : /* endYn */
			return getEndYn();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 878039231 : /* remarkSeq */
			setRemarkSeq((java.math.BigDecimal) value);
			return;
		case 1448961870 : /* remarkDate */
			setRemarkDate((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -836030906 : /* userId */
			setUserId((java.lang.String) value);
			return;
		case 343927438 : /* confirmDate */
			setConfirmDate((java.lang.String) value);
			return;
		case 96651600 : /* endYn */
			setEndYn((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
