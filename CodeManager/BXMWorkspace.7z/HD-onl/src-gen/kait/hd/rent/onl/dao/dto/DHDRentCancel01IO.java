/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.rent.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_임대_해약요청 ( HD_RENT_CANCEL )
 */
@XmlType(propOrder={"custCode", "seq", "processTag", "wantDate", "takeDate", "cancelDate", "cancelTag", "cancelText", "penaltyTag", "penaltyText", "yrate", "penaltyAmt", "returnDeposit", "returnBank", "returnDepositor", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDRentCancel01IO")
@XmlRootElement(name="DHDRentCancel01IO")
@SuppressWarnings("all")
public class DHDRentCancel01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 573670398L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_임대_해약요청 ( HD_RENT_CANCEL )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012601(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012601(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012601(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012602(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012602(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012602(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012602(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012602(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012602(C),SYS_C0012986(P) XPKHD_RENT_CANCEL(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << processTag >> [[ */
	
	@XmlTransient
	private boolean isSet_processTag = false;
	
	protected boolean isSet_processTag()
	{
		return this.isSet_processTag;
	}
	
	protected void setIsSet_processTag(boolean value)
	{
		this.isSet_processTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="처리구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String processTag  = null;
	
	/**
	 * @Description 처리구분
	 */
	public java.lang.String getProcessTag(){
		return processTag;
	}
	
	/**
	 * @Description 처리구분
	 */
	@JsonProperty("processTag")
	public void setProcessTag( java.lang.String processTag ) {
		isSet_processTag = true;
		this.processTag = processTag;
	}
	
	/** Property set << processTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << wantDate >> [[ */
	
	@XmlTransient
	private boolean isSet_wantDate = false;
	
	protected boolean isSet_wantDate()
	{
		return this.isSet_wantDate;
	}
	
	protected void setIsSet_wantDate(boolean value)
	{
		this.isSet_wantDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약요청일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String wantDate  = null;
	
	/**
	 * @Description 해약요청일
	 */
	public java.lang.String getWantDate(){
		return wantDate;
	}
	
	/**
	 * @Description 해약요청일
	 */
	@JsonProperty("wantDate")
	public void setWantDate( java.lang.String wantDate ) {
		isSet_wantDate = true;
		this.wantDate = wantDate;
	}
	
	/** Property set << wantDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << takeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_takeDate = false;
	
	protected boolean isSet_takeDate()
	{
		return this.isSet_takeDate;
	}
	
	protected void setIsSet_takeDate(boolean value)
	{
		this.isSet_takeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약접수일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String takeDate  = null;
	
	/**
	 * @Description 해약접수일
	 */
	public java.lang.String getTakeDate(){
		return takeDate;
	}
	
	/**
	 * @Description 해약접수일
	 */
	@JsonProperty("takeDate")
	public void setTakeDate( java.lang.String takeDate ) {
		isSet_takeDate = true;
		this.takeDate = takeDate;
	}
	
	/** Property set << takeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelDate >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelDate = false;
	
	protected boolean isSet_cancelDate()
	{
		return this.isSet_cancelDate;
	}
	
	protected void setIsSet_cancelDate(boolean value)
	{
		this.isSet_cancelDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약처리일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelDate  = null;
	
	/**
	 * @Description 해약처리일
	 */
	public java.lang.String getCancelDate(){
		return cancelDate;
	}
	
	/**
	 * @Description 해약처리일
	 */
	@JsonProperty("cancelDate")
	public void setCancelDate( java.lang.String cancelDate ) {
		isSet_cancelDate = true;
		this.cancelDate = cancelDate;
	}
	
	/** Property set << cancelDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelTag >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelTag = false;
	
	protected boolean isSet_cancelTag()
	{
		return this.isSet_cancelTag;
	}
	
	protected void setIsSet_cancelTag(boolean value)
	{
		this.isSet_cancelTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelTag  = null;
	
	/**
	 * @Description 해약구분
	 */
	public java.lang.String getCancelTag(){
		return cancelTag;
	}
	
	/**
	 * @Description 해약구분
	 */
	@JsonProperty("cancelTag")
	public void setCancelTag( java.lang.String cancelTag ) {
		isSet_cancelTag = true;
		this.cancelTag = cancelTag;
	}
	
	/** Property set << cancelTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelText >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelText = false;
	
	protected boolean isSet_cancelText()
	{
		return this.isSet_cancelText;
	}
	
	protected void setIsSet_cancelText(boolean value)
	{
		this.isSet_cancelText = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약사유", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelText  = null;
	
	/**
	 * @Description 해약사유
	 */
	public java.lang.String getCancelText(){
		return cancelText;
	}
	
	/**
	 * @Description 해약사유
	 */
	@JsonProperty("cancelText")
	public void setCancelText( java.lang.String cancelText ) {
		isSet_cancelText = true;
		this.cancelText = cancelText;
	}
	
	/** Property set << cancelText >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << penaltyTag >> [[ */
	
	@XmlTransient
	private boolean isSet_penaltyTag = false;
	
	protected boolean isSet_penaltyTag()
	{
		return this.isSet_penaltyTag;
	}
	
	protected void setIsSet_penaltyTag(boolean value)
	{
		this.isSet_penaltyTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="위약금면제구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String penaltyTag  = null;
	
	/**
	 * @Description 위약금면제구분
	 */
	public java.lang.String getPenaltyTag(){
		return penaltyTag;
	}
	
	/**
	 * @Description 위약금면제구분
	 */
	@JsonProperty("penaltyTag")
	public void setPenaltyTag( java.lang.String penaltyTag ) {
		isSet_penaltyTag = true;
		this.penaltyTag = penaltyTag;
	}
	
	/** Property set << penaltyTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << penaltyText >> [[ */
	
	@XmlTransient
	private boolean isSet_penaltyText = false;
	
	protected boolean isSet_penaltyText()
	{
		return this.isSet_penaltyText;
	}
	
	protected void setIsSet_penaltyText(boolean value)
	{
		this.isSet_penaltyText = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="위약금면제사유", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String penaltyText  = null;
	
	/**
	 * @Description 위약금면제사유
	 */
	public java.lang.String getPenaltyText(){
		return penaltyText;
	}
	
	/**
	 * @Description 위약금면제사유
	 */
	@JsonProperty("penaltyText")
	public void setPenaltyText( java.lang.String penaltyText ) {
		isSet_penaltyText = true;
		this.penaltyText = penaltyText;
	}
	
	/** Property set << penaltyText >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << yrate >> [[ */
	
	@XmlTransient
	private boolean isSet_yrate = false;
	
	protected boolean isSet_yrate()
	{
		return this.isSet_yrate;
	}
	
	protected void setIsSet_yrate(boolean value)
	{
		this.isSet_yrate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="정기예금이율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float yrate  = .0F;
	
	/**
	 * @Description 정기예금이율
	 */
	public java.lang.Float getYrate(){
		return yrate;
	}
	
	/**
	 * @Description 정기예금이율
	 */
	@JsonProperty("yrate")
	public void setYrate( java.lang.Float yrate ) {
		isSet_yrate = true;
		this.yrate = yrate;
	}
	
	/** Property set << yrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << penaltyAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_penaltyAmt = false;
	
	protected boolean isSet_penaltyAmt()
	{
		return this.isSet_penaltyAmt;
	}
	
	protected void setIsSet_penaltyAmt(boolean value)
	{
		this.isSet_penaltyAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 위약금
	 */
	public void setPenaltyAmt(java.lang.String value) {
		isSet_penaltyAmt = true;
		this.penaltyAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 위약금
	 */
	public void setPenaltyAmt(double value) {
		isSet_penaltyAmt = true;
		this.penaltyAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 위약금
	 */
	public void setPenaltyAmt(long value) {
		isSet_penaltyAmt = true;
		this.penaltyAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="위약금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal penaltyAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 위약금
	 */
	public java.math.BigDecimal getPenaltyAmt(){
		return penaltyAmt;
	}
	
	/**
	 * @Description 위약금
	 */
	@JsonProperty("penaltyAmt")
	public void setPenaltyAmt( java.math.BigDecimal penaltyAmt ) {
		isSet_penaltyAmt = true;
		this.penaltyAmt = penaltyAmt;
	}
	
	/** Property set << penaltyAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnDeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_returnDeposit = false;
	
	protected boolean isSet_returnDeposit()
	{
		return this.isSet_returnDeposit;
	}
	
	protected void setIsSet_returnDeposit(boolean value)
	{
		this.isSet_returnDeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="반환계좌", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String returnDeposit  = null;
	
	/**
	 * @Description 반환계좌
	 */
	public java.lang.String getReturnDeposit(){
		return returnDeposit;
	}
	
	/**
	 * @Description 반환계좌
	 */
	@JsonProperty("returnDeposit")
	public void setReturnDeposit( java.lang.String returnDeposit ) {
		isSet_returnDeposit = true;
		this.returnDeposit = returnDeposit;
	}
	
	/** Property set << returnDeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnBank >> [[ */
	
	@XmlTransient
	private boolean isSet_returnBank = false;
	
	protected boolean isSet_returnBank()
	{
		return this.isSet_returnBank;
	}
	
	protected void setIsSet_returnBank(boolean value)
	{
		this.isSet_returnBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="반환은행", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String returnBank  = null;
	
	/**
	 * @Description 반환은행
	 */
	public java.lang.String getReturnBank(){
		return returnBank;
	}
	
	/**
	 * @Description 반환은행
	 */
	@JsonProperty("returnBank")
	public void setReturnBank( java.lang.String returnBank ) {
		isSet_returnBank = true;
		this.returnBank = returnBank;
	}
	
	/** Property set << returnBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnDepositor >> [[ */
	
	@XmlTransient
	private boolean isSet_returnDepositor = false;
	
	protected boolean isSet_returnDepositor()
	{
		return this.isSet_returnDepositor;
	}
	
	protected void setIsSet_returnDepositor(boolean value)
	{
		this.isSet_returnDepositor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="반환예금주", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String returnDepositor  = null;
	
	/**
	 * @Description 반환예금주
	 */
	public java.lang.String getReturnDepositor(){
		return returnDepositor;
	}
	
	/**
	 * @Description 반환예금주
	 */
	@JsonProperty("returnDepositor")
	public void setReturnDepositor( java.lang.String returnDepositor ) {
		isSet_returnDepositor = true;
		this.returnDepositor = returnDepositor;
	}
	
	/** Property set << returnDepositor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDRentCancel01IO clone(){
		try{
			DHDRentCancel01IO object= (DHDRentCancel01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.processTag== null ) object.processTag = null;
			else{
				object.processTag = this.processTag;
			}
			if ( this.wantDate== null ) object.wantDate = null;
			else{
				object.wantDate = this.wantDate;
			}
			if ( this.takeDate== null ) object.takeDate = null;
			else{
				object.takeDate = this.takeDate;
			}
			if ( this.cancelDate== null ) object.cancelDate = null;
			else{
				object.cancelDate = this.cancelDate;
			}
			if ( this.cancelTag== null ) object.cancelTag = null;
			else{
				object.cancelTag = this.cancelTag;
			}
			if ( this.cancelText== null ) object.cancelText = null;
			else{
				object.cancelText = this.cancelText;
			}
			if ( this.penaltyTag== null ) object.penaltyTag = null;
			else{
				object.penaltyTag = this.penaltyTag;
			}
			if ( this.penaltyText== null ) object.penaltyText = null;
			else{
				object.penaltyText = this.penaltyText;
			}
			if ( this.yrate== null ) object.yrate = null;
			else{
				object.yrate = this.yrate;
			}
			if ( this.penaltyAmt== null ) object.penaltyAmt = null;
			else{
				object.penaltyAmt = new java.math.BigDecimal(penaltyAmt.toString());
			}
			if ( this.returnDeposit== null ) object.returnDeposit = null;
			else{
				object.returnDeposit = this.returnDeposit;
			}
			if ( this.returnBank== null ) object.returnBank = null;
			else{
				object.returnBank = this.returnBank;
			}
			if ( this.returnDepositor== null ) object.returnDepositor = null;
			else{
				object.returnDepositor = this.returnDepositor;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((processTag==null)?0:processTag.hashCode());
		result = prime * result + ((wantDate==null)?0:wantDate.hashCode());
		result = prime * result + ((takeDate==null)?0:takeDate.hashCode());
		result = prime * result + ((cancelDate==null)?0:cancelDate.hashCode());
		result = prime * result + ((cancelTag==null)?0:cancelTag.hashCode());
		result = prime * result + ((cancelText==null)?0:cancelText.hashCode());
		result = prime * result + ((penaltyTag==null)?0:penaltyTag.hashCode());
		result = prime * result + ((penaltyText==null)?0:penaltyText.hashCode());
		result = prime * result + ((yrate==null)?0:yrate.hashCode());
		result = prime * result + ((penaltyAmt==null)?0:penaltyAmt.hashCode());
		result = prime * result + ((returnDeposit==null)?0:returnDeposit.hashCode());
		result = prime * result + ((returnBank==null)?0:returnBank.hashCode());
		result = prime * result + ((returnDepositor==null)?0:returnDepositor.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.rent.onl.dao.dto.DHDRentCancel01IO other = (kait.hd.rent.onl.dao.dto.DHDRentCancel01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( processTag == null ){
			if ( other.processTag != null ) return false;
		}
		else if ( !processTag.equals(other.processTag) )
			return false;
		if ( wantDate == null ){
			if ( other.wantDate != null ) return false;
		}
		else if ( !wantDate.equals(other.wantDate) )
			return false;
		if ( takeDate == null ){
			if ( other.takeDate != null ) return false;
		}
		else if ( !takeDate.equals(other.takeDate) )
			return false;
		if ( cancelDate == null ){
			if ( other.cancelDate != null ) return false;
		}
		else if ( !cancelDate.equals(other.cancelDate) )
			return false;
		if ( cancelTag == null ){
			if ( other.cancelTag != null ) return false;
		}
		else if ( !cancelTag.equals(other.cancelTag) )
			return false;
		if ( cancelText == null ){
			if ( other.cancelText != null ) return false;
		}
		else if ( !cancelText.equals(other.cancelText) )
			return false;
		if ( penaltyTag == null ){
			if ( other.penaltyTag != null ) return false;
		}
		else if ( !penaltyTag.equals(other.penaltyTag) )
			return false;
		if ( penaltyText == null ){
			if ( other.penaltyText != null ) return false;
		}
		else if ( !penaltyText.equals(other.penaltyText) )
			return false;
		if ( yrate == null ){
			if ( other.yrate != null ) return false;
		}
		else if ( !yrate.equals(other.yrate) )
			return false;
		if ( penaltyAmt == null ){
			if ( other.penaltyAmt != null ) return false;
		}
		else if ( !penaltyAmt.equals(other.penaltyAmt) )
			return false;
		if ( returnDeposit == null ){
			if ( other.returnDeposit != null ) return false;
		}
		else if ( !returnDeposit.equals(other.returnDeposit) )
			return false;
		if ( returnBank == null ){
			if ( other.returnBank != null ) return false;
		}
		else if ( !returnBank.equals(other.returnBank) )
			return false;
		if ( returnDepositor == null ){
			if ( other.returnDepositor != null ) return false;
		}
		else if ( !returnDepositor.equals(other.returnDepositor) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.rent.onl.dao.dto.DHDRentCancel01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tprocessTag: ");
		sb.append(processTag==null?"null":getProcessTag());
		sb.append("\n");
		sb.append("\twantDate: ");
		sb.append(wantDate==null?"null":getWantDate());
		sb.append("\n");
		sb.append("\ttakeDate: ");
		sb.append(takeDate==null?"null":getTakeDate());
		sb.append("\n");
		sb.append("\tcancelDate: ");
		sb.append(cancelDate==null?"null":getCancelDate());
		sb.append("\n");
		sb.append("\tcancelTag: ");
		sb.append(cancelTag==null?"null":getCancelTag());
		sb.append("\n");
		sb.append("\tcancelText: ");
		sb.append(cancelText==null?"null":getCancelText());
		sb.append("\n");
		sb.append("\tpenaltyTag: ");
		sb.append(penaltyTag==null?"null":getPenaltyTag());
		sb.append("\n");
		sb.append("\tpenaltyText: ");
		sb.append(penaltyText==null?"null":getPenaltyText());
		sb.append("\n");
		sb.append("\tyrate: ");
		sb.append(yrate==null?"null":getYrate());
		sb.append("\n");
		sb.append("\tpenaltyAmt: ");
		sb.append(penaltyAmt==null?"null":getPenaltyAmt());
		sb.append("\n");
		sb.append("\treturnDeposit: ");
		sb.append(returnDeposit==null?"null":getReturnDeposit());
		sb.append("\n");
		sb.append("\treturnBank: ");
		sb.append(returnBank==null?"null":getReturnBank());
		sb.append("\n");
		sb.append("\treturnDepositor: ");
		sb.append(returnDepositor==null?"null":getReturnDepositor());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 1; /* processTag */
		messageLen+= 8; /* wantDate */
		messageLen+= 8; /* takeDate */
		messageLen+= 8; /* cancelDate */
		messageLen+= 2; /* cancelTag */
		messageLen+= 200; /* cancelText */
		messageLen+= 2; /* penaltyTag */
		messageLen+= 200; /* penaltyText */
		messageLen+= 22; /* yrate */
		messageLen+= 22; /* penaltyAmt */
		messageLen+= 30; /* returnDeposit */
		messageLen+= 40; /* returnBank */
		messageLen+= 100; /* returnDepositor */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("processTag");
	
		fieldNames.add("wantDate");
	
		fieldNames.add("takeDate");
	
		fieldNames.add("cancelDate");
	
		fieldNames.add("cancelTag");
	
		fieldNames.add("cancelText");
	
		fieldNames.add("penaltyTag");
	
		fieldNames.add("penaltyText");
	
		fieldNames.add("yrate");
	
		fieldNames.add("penaltyAmt");
	
		fieldNames.add("returnDeposit");
	
		fieldNames.add("returnBank");
	
		fieldNames.add("returnDepositor");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("processTag", get("processTag"));
	
		fieldValueMap.put("wantDate", get("wantDate"));
	
		fieldValueMap.put("takeDate", get("takeDate"));
	
		fieldValueMap.put("cancelDate", get("cancelDate"));
	
		fieldValueMap.put("cancelTag", get("cancelTag"));
	
		fieldValueMap.put("cancelText", get("cancelText"));
	
		fieldValueMap.put("penaltyTag", get("penaltyTag"));
	
		fieldValueMap.put("penaltyText", get("penaltyText"));
	
		fieldValueMap.put("yrate", get("yrate"));
	
		fieldValueMap.put("penaltyAmt", get("penaltyAmt"));
	
		fieldValueMap.put("returnDeposit", get("returnDeposit"));
	
		fieldValueMap.put("returnBank", get("returnBank"));
	
		fieldValueMap.put("returnDepositor", get("returnDepositor"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 422174379 : /* processTag */
			return getProcessTag();
		case 388001246 : /* wantDate */
			return getWantDate();
		case -645202731 : /* takeDate */
			return getTakeDate();
		case 1888142664 : /* cancelDate */
			return getCancelDate();
		case 476565184 : /* cancelTag */
			return getCancelTag();
		case 1888623303 : /* cancelText */
			return getCancelText();
		case -872065455 : /* penaltyTag */
			return getPenaltyTag();
		case -1264220842 : /* penaltyText */
			return getPenaltyText();
		case 115239129 : /* yrate */
			return getYrate();
		case -872083329 : /* penaltyAmt */
			return getPenaltyAmt();
		case -977585330 : /* returnDeposit */
			return getReturnDeposit();
		case 1336647564 : /* returnBank */
			return getReturnBank();
		case 1138339249 : /* returnDepositor */
			return getReturnDepositor();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 422174379 : /* processTag */
			setProcessTag((java.lang.String) value);
			return;
		case 388001246 : /* wantDate */
			setWantDate((java.lang.String) value);
			return;
		case -645202731 : /* takeDate */
			setTakeDate((java.lang.String) value);
			return;
		case 1888142664 : /* cancelDate */
			setCancelDate((java.lang.String) value);
			return;
		case 476565184 : /* cancelTag */
			setCancelTag((java.lang.String) value);
			return;
		case 1888623303 : /* cancelText */
			setCancelText((java.lang.String) value);
			return;
		case -872065455 : /* penaltyTag */
			setPenaltyTag((java.lang.String) value);
			return;
		case -1264220842 : /* penaltyText */
			setPenaltyText((java.lang.String) value);
			return;
		case 115239129 : /* yrate */
			setYrate((java.lang.Float) value);
			return;
		case -872083329 : /* penaltyAmt */
			setPenaltyAmt((java.math.BigDecimal) value);
			return;
		case -977585330 : /* returnDeposit */
			setReturnDeposit((java.lang.String) value);
			return;
		case 1336647564 : /* returnBank */
			setReturnBank((java.lang.String) value);
			return;
		case 1138339249 : /* returnDepositor */
			setReturnDepositor((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
