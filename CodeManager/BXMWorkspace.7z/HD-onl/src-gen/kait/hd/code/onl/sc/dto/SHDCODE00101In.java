/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.sc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 현장 다건조회 In
 */
@XmlType(propOrder={"inSHDCODE00101Sub01", "inSHDCODE00101Sub02", "inSHDCODE00101Sub03", "inSHDCODE00101Sub04", "inSHDCODE00101Sub05", "inSHDCODE00101Sub06", "inSHDCODE00101Sub07", "inSHDCODE00101Sub08"}, name="SHDCODE00101In")
@XmlRootElement(name="SHDCODE00101In")
@SuppressWarnings("all")
public class SHDCODE00101In  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1934480757L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "현장 다건조회 In";

	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub01 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub01 = false;
	
	protected boolean isSet_inSHDCODE00101Sub01()
	{
		return this.isSet_inSHDCODE00101Sub01;
	}
	
	protected void setIsSet_inSHDCODE00101Sub01(boolean value)
	{
		this.isSet_inSHDCODE00101Sub01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_ACMAST_E", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub01 inSHDCODE00101Sub01  = null;
	
	/**
	 * @Description HD_ACMAST_E
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub01 getInSHDCODE00101Sub01(){
		return inSHDCODE00101Sub01;
	}
	
	/**
	 * @Description HD_ACMAST_E
	 */
	@JsonProperty("inSHDCODE00101Sub01")
	public void setInSHDCODE00101Sub01( kait.hd.code.onl.sc.dto.SHDCODE00101Sub01 inSHDCODE00101Sub01 ) {
		isSet_inSHDCODE00101Sub01 = true;
		this.inSHDCODE00101Sub01 = inSHDCODE00101Sub01;
	}
	
	/** Property set << inSHDCODE00101Sub01 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub02 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub02 = false;
	
	protected boolean isSet_inSHDCODE00101Sub02()
	{
		return this.isSet_inSHDCODE00101Sub02;
	}
	
	protected void setIsSet_inSHDCODE00101Sub02(boolean value)
	{
		this.isSet_inSHDCODE00101Sub02 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub02 inSHDCODE00101Sub02  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub02 getInSHDCODE00101Sub02(){
		return inSHDCODE00101Sub02;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inSHDCODE00101Sub02")
	public void setInSHDCODE00101Sub02( kait.hd.code.onl.sc.dto.SHDCODE00101Sub02 inSHDCODE00101Sub02 ) {
		isSet_inSHDCODE00101Sub02 = true;
		this.inSHDCODE00101Sub02 = inSHDCODE00101Sub02;
	}
	
	/** Property set << inSHDCODE00101Sub02 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub03 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub03 = false;
	
	protected boolean isSet_inSHDCODE00101Sub03()
	{
		return this.isSet_inSHDCODE00101Sub03;
	}
	
	protected void setIsSet_inSHDCODE00101Sub03(boolean value)
	{
		this.isSet_inSHDCODE00101Sub03 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub03 inSHDCODE00101Sub03  = null;
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub03 getInSHDCODE00101Sub03(){
		return inSHDCODE00101Sub03;
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	@JsonProperty("inSHDCODE00101Sub03")
	public void setInSHDCODE00101Sub03( kait.hd.code.onl.sc.dto.SHDCODE00101Sub03 inSHDCODE00101Sub03 ) {
		isSet_inSHDCODE00101Sub03 = true;
		this.inSHDCODE00101Sub03 = inSHDCODE00101Sub03;
	}
	
	/** Property set << inSHDCODE00101Sub03 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub04 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub04 = false;
	
	protected boolean isSet_inSHDCODE00101Sub04()
	{
		return this.isSet_inSHDCODE00101Sub04;
	}
	
	protected void setIsSet_inSHDCODE00101Sub04(boolean value)
	{
		this.isSet_inSHDCODE00101Sub04 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub04 inSHDCODE00101Sub04  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub04 getInSHDCODE00101Sub04(){
		return inSHDCODE00101Sub04;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inSHDCODE00101Sub04")
	public void setInSHDCODE00101Sub04( kait.hd.code.onl.sc.dto.SHDCODE00101Sub04 inSHDCODE00101Sub04 ) {
		isSet_inSHDCODE00101Sub04 = true;
		this.inSHDCODE00101Sub04 = inSHDCODE00101Sub04;
	}
	
	/** Property set << inSHDCODE00101Sub04 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub05 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub05 = false;
	
	protected boolean isSet_inSHDCODE00101Sub05()
	{
		return this.isSet_inSHDCODE00101Sub05;
	}
	
	protected void setIsSet_inSHDCODE00101Sub05(boolean value)
	{
		this.isSet_inSHDCODE00101Sub05 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_ACMAST_E", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub05 inSHDCODE00101Sub05  = null;
	
	/**
	 * @Description HD_ACMAST_E
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub05 getInSHDCODE00101Sub05(){
		return inSHDCODE00101Sub05;
	}
	
	/**
	 * @Description HD_ACMAST_E
	 */
	@JsonProperty("inSHDCODE00101Sub05")
	public void setInSHDCODE00101Sub05( kait.hd.code.onl.sc.dto.SHDCODE00101Sub05 inSHDCODE00101Sub05 ) {
		isSet_inSHDCODE00101Sub05 = true;
		this.inSHDCODE00101Sub05 = inSHDCODE00101Sub05;
	}
	
	/** Property set << inSHDCODE00101Sub05 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub06 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub06 = false;
	
	protected boolean isSet_inSHDCODE00101Sub06()
	{
		return this.isSet_inSHDCODE00101Sub06;
	}
	
	protected void setIsSet_inSHDCODE00101Sub06(boolean value)
	{
		this.isSet_inSHDCODE00101Sub06 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub06 inSHDCODE00101Sub06  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub06 getInSHDCODE00101Sub06(){
		return inSHDCODE00101Sub06;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inSHDCODE00101Sub06")
	public void setInSHDCODE00101Sub06( kait.hd.code.onl.sc.dto.SHDCODE00101Sub06 inSHDCODE00101Sub06 ) {
		isSet_inSHDCODE00101Sub06 = true;
		this.inSHDCODE00101Sub06 = inSHDCODE00101Sub06;
	}
	
	/** Property set << inSHDCODE00101Sub06 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub07 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub07 = false;
	
	protected boolean isSet_inSHDCODE00101Sub07()
	{
		return this.isSet_inSHDCODE00101Sub07;
	}
	
	protected void setIsSet_inSHDCODE00101Sub07(boolean value)
	{
		this.isSet_inSHDCODE00101Sub07 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub07 inSHDCODE00101Sub07  = null;
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub07 getInSHDCODE00101Sub07(){
		return inSHDCODE00101Sub07;
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	@JsonProperty("inSHDCODE00101Sub07")
	public void setInSHDCODE00101Sub07( kait.hd.code.onl.sc.dto.SHDCODE00101Sub07 inSHDCODE00101Sub07 ) {
		isSet_inSHDCODE00101Sub07 = true;
		this.inSHDCODE00101Sub07 = inSHDCODE00101Sub07;
	}
	
	/** Property set << inSHDCODE00101Sub07 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inSHDCODE00101Sub08 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00101Sub08 = false;
	
	protected boolean isSet_inSHDCODE00101Sub08()
	{
		return this.isSet_inSHDCODE00101Sub08;
	}
	
	protected void setIsSet_inSHDCODE00101Sub08(boolean value)
	{
		this.isSet_inSHDCODE00101Sub08 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00101Sub08 inSHDCODE00101Sub08  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00101Sub08 getInSHDCODE00101Sub08(){
		return inSHDCODE00101Sub08;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inSHDCODE00101Sub08")
	public void setInSHDCODE00101Sub08( kait.hd.code.onl.sc.dto.SHDCODE00101Sub08 inSHDCODE00101Sub08 ) {
		isSet_inSHDCODE00101Sub08 = true;
		this.inSHDCODE00101Sub08 = inSHDCODE00101Sub08;
	}
	
	/** Property set << inSHDCODE00101Sub08 >> ]]
	*******************************************************************************************************************************/

	@Override
	public SHDCODE00101In clone(){
		try{
			SHDCODE00101In object= (SHDCODE00101In)super.clone();
			if ( this.inSHDCODE00101Sub01== null ) object.inSHDCODE00101Sub01 = null;
			else{
				object.inSHDCODE00101Sub01 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub01)this.inSHDCODE00101Sub01.clone();
			}
			if ( this.inSHDCODE00101Sub02== null ) object.inSHDCODE00101Sub02 = null;
			else{
				object.inSHDCODE00101Sub02 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub02)this.inSHDCODE00101Sub02.clone();
			}
			if ( this.inSHDCODE00101Sub03== null ) object.inSHDCODE00101Sub03 = null;
			else{
				object.inSHDCODE00101Sub03 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub03)this.inSHDCODE00101Sub03.clone();
			}
			if ( this.inSHDCODE00101Sub04== null ) object.inSHDCODE00101Sub04 = null;
			else{
				object.inSHDCODE00101Sub04 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub04)this.inSHDCODE00101Sub04.clone();
			}
			if ( this.inSHDCODE00101Sub05== null ) object.inSHDCODE00101Sub05 = null;
			else{
				object.inSHDCODE00101Sub05 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub05)this.inSHDCODE00101Sub05.clone();
			}
			if ( this.inSHDCODE00101Sub06== null ) object.inSHDCODE00101Sub06 = null;
			else{
				object.inSHDCODE00101Sub06 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub06)this.inSHDCODE00101Sub06.clone();
			}
			if ( this.inSHDCODE00101Sub07== null ) object.inSHDCODE00101Sub07 = null;
			else{
				object.inSHDCODE00101Sub07 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub07)this.inSHDCODE00101Sub07.clone();
			}
			if ( this.inSHDCODE00101Sub08== null ) object.inSHDCODE00101Sub08 = null;
			else{
				object.inSHDCODE00101Sub08 = (kait.hd.code.onl.sc.dto.SHDCODE00101Sub08)this.inSHDCODE00101Sub08.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((inSHDCODE00101Sub01==null)?0:inSHDCODE00101Sub01.hashCode());
		result = prime * result + ((inSHDCODE00101Sub02==null)?0:inSHDCODE00101Sub02.hashCode());
		result = prime * result + ((inSHDCODE00101Sub03==null)?0:inSHDCODE00101Sub03.hashCode());
		result = prime * result + ((inSHDCODE00101Sub04==null)?0:inSHDCODE00101Sub04.hashCode());
		result = prime * result + ((inSHDCODE00101Sub05==null)?0:inSHDCODE00101Sub05.hashCode());
		result = prime * result + ((inSHDCODE00101Sub06==null)?0:inSHDCODE00101Sub06.hashCode());
		result = prime * result + ((inSHDCODE00101Sub07==null)?0:inSHDCODE00101Sub07.hashCode());
		result = prime * result + ((inSHDCODE00101Sub08==null)?0:inSHDCODE00101Sub08.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.sc.dto.SHDCODE00101In other = (kait.hd.code.onl.sc.dto.SHDCODE00101In)obj;
		if ( inSHDCODE00101Sub01 == null ){
			if ( other.inSHDCODE00101Sub01 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub01.equals(other.inSHDCODE00101Sub01) )
			return false;
		if ( inSHDCODE00101Sub02 == null ){
			if ( other.inSHDCODE00101Sub02 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub02.equals(other.inSHDCODE00101Sub02) )
			return false;
		if ( inSHDCODE00101Sub03 == null ){
			if ( other.inSHDCODE00101Sub03 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub03.equals(other.inSHDCODE00101Sub03) )
			return false;
		if ( inSHDCODE00101Sub04 == null ){
			if ( other.inSHDCODE00101Sub04 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub04.equals(other.inSHDCODE00101Sub04) )
			return false;
		if ( inSHDCODE00101Sub05 == null ){
			if ( other.inSHDCODE00101Sub05 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub05.equals(other.inSHDCODE00101Sub05) )
			return false;
		if ( inSHDCODE00101Sub06 == null ){
			if ( other.inSHDCODE00101Sub06 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub06.equals(other.inSHDCODE00101Sub06) )
			return false;
		if ( inSHDCODE00101Sub07 == null ){
			if ( other.inSHDCODE00101Sub07 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub07.equals(other.inSHDCODE00101Sub07) )
			return false;
		if ( inSHDCODE00101Sub08 == null ){
			if ( other.inSHDCODE00101Sub08 != null ) return false;
		}
		else if ( !inSHDCODE00101Sub08.equals(other.inSHDCODE00101Sub08) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.sc.dto.SHDCODE00101In:\n");
		sb.append("\tinSHDCODE00101Sub01: ");
		sb.append(inSHDCODE00101Sub01==null?"null":getInSHDCODE00101Sub01());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub02: ");
		sb.append(inSHDCODE00101Sub02==null?"null":getInSHDCODE00101Sub02());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub03: ");
		sb.append(inSHDCODE00101Sub03==null?"null":getInSHDCODE00101Sub03());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub04: ");
		sb.append(inSHDCODE00101Sub04==null?"null":getInSHDCODE00101Sub04());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub05: ");
		sb.append(inSHDCODE00101Sub05==null?"null":getInSHDCODE00101Sub05());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub06: ");
		sb.append(inSHDCODE00101Sub06==null?"null":getInSHDCODE00101Sub06());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub07: ");
		sb.append(inSHDCODE00101Sub07==null?"null":getInSHDCODE00101Sub07());
		sb.append("\n");
		sb.append("\tinSHDCODE00101Sub08: ");
		sb.append(inSHDCODE00101Sub08==null?"null":getInSHDCODE00101Sub08());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		if ( inSHDCODE00101Sub01 != null && !(inSHDCODE00101Sub01 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub01 temp= inSHDCODE00101Sub01;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub01();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub01 */
		}
		if ( inSHDCODE00101Sub02 != null && !(inSHDCODE00101Sub02 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub02 temp= inSHDCODE00101Sub02;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub02();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub02 */
		}
		if ( inSHDCODE00101Sub03 != null && !(inSHDCODE00101Sub03 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub03 temp= inSHDCODE00101Sub03;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub03();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub03 */
		}
		if ( inSHDCODE00101Sub04 != null && !(inSHDCODE00101Sub04 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub04 temp= inSHDCODE00101Sub04;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub04();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub04 */
		}
		if ( inSHDCODE00101Sub05 != null && !(inSHDCODE00101Sub05 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub05 temp= inSHDCODE00101Sub05;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub05();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub05 */
		}
		if ( inSHDCODE00101Sub06 != null && !(inSHDCODE00101Sub06 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub06 temp= inSHDCODE00101Sub06;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub06();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub06 */
		}
		if ( inSHDCODE00101Sub07 != null && !(inSHDCODE00101Sub07 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub07 temp= inSHDCODE00101Sub07;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub07();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub07 */
		}
		if ( inSHDCODE00101Sub08 != null && !(inSHDCODE00101Sub08 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00101Sub08 temp= inSHDCODE00101Sub08;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00101Sub08();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00101Sub08 */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("inSHDCODE00101Sub01");
	
		fieldNames.add("inSHDCODE00101Sub02");
	
		fieldNames.add("inSHDCODE00101Sub03");
	
		fieldNames.add("inSHDCODE00101Sub04");
	
		fieldNames.add("inSHDCODE00101Sub05");
	
		fieldNames.add("inSHDCODE00101Sub06");
	
		fieldNames.add("inSHDCODE00101Sub07");
	
		fieldNames.add("inSHDCODE00101Sub08");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("inSHDCODE00101Sub01", get("inSHDCODE00101Sub01"));
	
		fieldValueMap.put("inSHDCODE00101Sub02", get("inSHDCODE00101Sub02"));
	
		fieldValueMap.put("inSHDCODE00101Sub03", get("inSHDCODE00101Sub03"));
	
		fieldValueMap.put("inSHDCODE00101Sub04", get("inSHDCODE00101Sub04"));
	
		fieldValueMap.put("inSHDCODE00101Sub05", get("inSHDCODE00101Sub05"));
	
		fieldValueMap.put("inSHDCODE00101Sub06", get("inSHDCODE00101Sub06"));
	
		fieldValueMap.put("inSHDCODE00101Sub07", get("inSHDCODE00101Sub07"));
	
		fieldValueMap.put("inSHDCODE00101Sub08", get("inSHDCODE00101Sub08"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -326749978 : /* inSHDCODE00101Sub01 */
			return getInSHDCODE00101Sub01();
		case -326749977 : /* inSHDCODE00101Sub02 */
			return getInSHDCODE00101Sub02();
		case -326749976 : /* inSHDCODE00101Sub03 */
			return getInSHDCODE00101Sub03();
		case -326749975 : /* inSHDCODE00101Sub04 */
			return getInSHDCODE00101Sub04();
		case -326749974 : /* inSHDCODE00101Sub05 */
			return getInSHDCODE00101Sub05();
		case -326749973 : /* inSHDCODE00101Sub06 */
			return getInSHDCODE00101Sub06();
		case -326749972 : /* inSHDCODE00101Sub07 */
			return getInSHDCODE00101Sub07();
		case -326749971 : /* inSHDCODE00101Sub08 */
			return getInSHDCODE00101Sub08();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -326749978 : /* inSHDCODE00101Sub01 */
			setInSHDCODE00101Sub01((kait.hd.code.onl.sc.dto.SHDCODE00101Sub01) value);
			return;
		case -326749977 : /* inSHDCODE00101Sub02 */
			setInSHDCODE00101Sub02((kait.hd.code.onl.sc.dto.SHDCODE00101Sub02) value);
			return;
		case -326749976 : /* inSHDCODE00101Sub03 */
			setInSHDCODE00101Sub03((kait.hd.code.onl.sc.dto.SHDCODE00101Sub03) value);
			return;
		case -326749975 : /* inSHDCODE00101Sub04 */
			setInSHDCODE00101Sub04((kait.hd.code.onl.sc.dto.SHDCODE00101Sub04) value);
			return;
		case -326749974 : /* inSHDCODE00101Sub05 */
			setInSHDCODE00101Sub05((kait.hd.code.onl.sc.dto.SHDCODE00101Sub05) value);
			return;
		case -326749973 : /* inSHDCODE00101Sub06 */
			setInSHDCODE00101Sub06((kait.hd.code.onl.sc.dto.SHDCODE00101Sub06) value);
			return;
		case -326749972 : /* inSHDCODE00101Sub07 */
			setInSHDCODE00101Sub07((kait.hd.code.onl.sc.dto.SHDCODE00101Sub07) value);
			return;
		case -326749971 : /* inSHDCODE00101Sub08 */
			setInSHDCODE00101Sub08((kait.hd.code.onl.sc.dto.SHDCODE00101Sub08) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
