/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_코드_사업코드_이력 ( HD_CODE_DEPT_HIST )
 */
@XmlType(propOrder={"histDate", "deptCode", "deptName", "tel", "zip", "addr1", "addr2", "listtag", "jobtag", "companyCode", "amisDeptcode", "taxTag", "sihangVendor", "sihangName", "sihangDepyo", "sihangUpte", "sihangUpjong", "sihangZip", "sihangAddr1", "sihangAddr2", "sigongName", "sigongDepyo", "sigongCharge", "sigongTel", "modelZip", "modelAddr1", "modelAddr2", "modelTel", "deptTypeCode", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "smsName", "smsTel", "oldDeptcode", "triTag", "modtag", "zipOrg", "addr1Org", "addr2Org", "addrTag", "sihangZipOrg", "sihangAddr1Org", "sihangAddr2Org", "sihangAddrTag", "modelZipOrg", "modelAddr1Org", "modelAddr2Org", "modelAddrTag"}, name="DHDCodeDeptHist01IO")
@XmlRootElement(name="DHDCodeDeptHist01IO")
@SuppressWarnings("all")
public class DHDCodeDeptHist01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 2073551411L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_코드_사업코드_이력 ( HD_CODE_DEPT_HIST )";

	/*******************************************************************************************************************************
	* Property set << histDate >> [[ */
	
	@XmlTransient
	private boolean isSet_histDate = false;
	
	protected boolean isSet_histDate()
	{
		return this.isSet_histDate;
	}
	
	protected void setIsSet_histDate(boolean value)
	{
		this.isSet_histDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이력일자 [SYS_C0012107(C),SYS_C0012915(P) SYS_C0012915(UNIQUE)]", formatType="", format="", align="left", length=7, decimal=0, arrayReference="", fill="")
	private java.lang.String histDate  = null;
	
	/**
	 * @Description 이력일자 [SYS_C0012107(C),SYS_C0012915(P) SYS_C0012915(UNIQUE)]
	 */
	public java.lang.String getHistDate(){
		return histDate;
	}
	
	/**
	 * @Description 이력일자 [SYS_C0012107(C),SYS_C0012915(P) SYS_C0012915(UNIQUE)]
	 */
	@JsonProperty("histDate")
	public void setHistDate( java.lang.String histDate ) {
		isSet_histDate = true;
		this.histDate = histDate;
	}
	
	/** Property set << histDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012108(C),SYS_C0012915(P) SYS_C0012915(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012108(C),SYS_C0012915(P) SYS_C0012915(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012108(C),SYS_C0012915(P) SYS_C0012915(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptName >> [[ */
	
	@XmlTransient
	private boolean isSet_deptName = false;
	
	protected boolean isSet_deptName()
	{
		return this.isSet_deptName;
	}
	
	protected void setIsSet_deptName(boolean value)
	{
		this.isSet_deptName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업명칭 [SYS_C0012109(C)]", formatType="", format="", align="left", length=150, decimal=0, arrayReference="", fill="")
	private java.lang.String deptName  = null;
	
	/**
	 * @Description 사업명칭 [SYS_C0012109(C)]
	 */
	public java.lang.String getDeptName(){
		return deptName;
	}
	
	/**
	 * @Description 사업명칭 [SYS_C0012109(C)]
	 */
	@JsonProperty("deptName")
	public void setDeptName( java.lang.String deptName ) {
		isSet_deptName = true;
		this.deptName = deptName;
	}
	
	/** Property set << deptName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << tel >> [[ */
	
	@XmlTransient
	private boolean isSet_tel = false;
	
	protected boolean isSet_tel()
	{
		return this.isSet_tel;
	}
	
	protected void setIsSet_tel(boolean value)
	{
		this.isSet_tel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전화번호", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String tel  = null;
	
	/**
	 * @Description 전화번호
	 */
	public java.lang.String getTel(){
		return tel;
	}
	
	/**
	 * @Description 전화번호
	 */
	@JsonProperty("tel")
	public void setTel( java.lang.String tel ) {
		isSet_tel = true;
		this.tel = tel;
	}
	
	/** Property set << tel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << zip >> [[ */
	
	@XmlTransient
	private boolean isSet_zip = false;
	
	protected boolean isSet_zip()
	{
		return this.isSet_zip;
	}
	
	protected void setIsSet_zip(boolean value)
	{
		this.isSet_zip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="우편번호", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String zip  = null;
	
	/**
	 * @Description 우편번호
	 */
	public java.lang.String getZip(){
		return zip;
	}
	
	/**
	 * @Description 우편번호
	 */
	@JsonProperty("zip")
	public void setZip( java.lang.String zip ) {
		isSet_zip = true;
		this.zip = zip;
	}
	
	/** Property set << zip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr1 = false;
	
	protected boolean isSet_addr1()
	{
		return this.isSet_addr1;
	}
	
	protected void setIsSet_addr1(boolean value)
	{
		this.isSet_addr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소1", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String addr1  = null;
	
	/**
	 * @Description 주소1
	 */
	public java.lang.String getAddr1(){
		return addr1;
	}
	
	/**
	 * @Description 주소1
	 */
	@JsonProperty("addr1")
	public void setAddr1( java.lang.String addr1 ) {
		isSet_addr1 = true;
		this.addr1 = addr1;
	}
	
	/** Property set << addr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2 = false;
	
	protected boolean isSet_addr2()
	{
		return this.isSet_addr2;
	}
	
	protected void setIsSet_addr2(boolean value)
	{
		this.isSet_addr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소2", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2  = null;
	
	/**
	 * @Description 주소2
	 */
	public java.lang.String getAddr2(){
		return addr2;
	}
	
	/**
	 * @Description 주소2
	 */
	@JsonProperty("addr2")
	public void setAddr2( java.lang.String addr2 ) {
		isSet_addr2 = true;
		this.addr2 = addr2;
	}
	
	/** Property set << addr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << listtag >> [[ */
	
	@XmlTransient
	private boolean isSet_listtag = false;
	
	protected boolean isSet_listtag()
	{
		return this.isSet_listtag;
	}
	
	protected void setIsSet_listtag(boolean value)
	{
		this.isSet_listtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="진행여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String listtag  = null;
	
	/**
	 * @Description 진행여부
	 */
	public java.lang.String getListtag(){
		return listtag;
	}
	
	/**
	 * @Description 진행여부
	 */
	@JsonProperty("listtag")
	public void setListtag( java.lang.String listtag ) {
		isSet_listtag = true;
		this.listtag = listtag;
	}
	
	/** Property set << listtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jobtag >> [[ */
	
	@XmlTransient
	private boolean isSet_jobtag = false;
	
	protected boolean isSet_jobtag()
	{
		return this.isSet_jobtag;
	}
	
	protected void setIsSet_jobtag(boolean value)
	{
		this.isSet_jobtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대현장구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String jobtag  = null;
	
	/**
	 * @Description 임대현장구분
	 */
	public java.lang.String getJobtag(){
		return jobtag;
	}
	
	/**
	 * @Description 임대현장구분
	 */
	@JsonProperty("jobtag")
	public void setJobtag( java.lang.String jobtag ) {
		isSet_jobtag = true;
		this.jobtag = jobtag;
	}
	
	/** Property set << jobtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << companyCode >> [[ */
	
	@XmlTransient
	private boolean isSet_companyCode = false;
	
	protected boolean isSet_companyCode()
	{
		return this.isSet_companyCode;
	}
	
	protected void setIsSet_companyCode(boolean value)
	{
		this.isSet_companyCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업장코드", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String companyCode  = null;
	
	/**
	 * @Description 사업장코드
	 */
	public java.lang.String getCompanyCode(){
		return companyCode;
	}
	
	/**
	 * @Description 사업장코드
	 */
	@JsonProperty("companyCode")
	public void setCompanyCode( java.lang.String companyCode ) {
		isSet_companyCode = true;
		this.companyCode = companyCode;
	}
	
	/** Property set << companyCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << amisDeptcode >> [[ */
	
	@XmlTransient
	private boolean isSet_amisDeptcode = false;
	
	protected boolean isSet_amisDeptcode()
	{
		return this.isSet_amisDeptcode;
	}
	
	protected void setIsSet_amisDeptcode(boolean value)
	{
		this.isSet_amisDeptcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부서코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String amisDeptcode  = null;
	
	/**
	 * @Description 부서코드
	 */
	public java.lang.String getAmisDeptcode(){
		return amisDeptcode;
	}
	
	/**
	 * @Description 부서코드
	 */
	@JsonProperty("amisDeptcode")
	public void setAmisDeptcode( java.lang.String amisDeptcode ) {
		isSet_amisDeptcode = true;
		this.amisDeptcode = amisDeptcode;
	}
	
	/** Property set << amisDeptcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << taxTag >> [[ */
	
	@XmlTransient
	private boolean isSet_taxTag = false;
	
	protected boolean isSet_taxTag()
	{
		return this.isSet_taxTag;
	}
	
	protected void setIsSet_taxTag(boolean value)
	{
		this.isSet_taxTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="세금계산기준", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String taxTag  = null;
	
	/**
	 * @Description 세금계산기준
	 */
	public java.lang.String getTaxTag(){
		return taxTag;
	}
	
	/**
	 * @Description 세금계산기준
	 */
	@JsonProperty("taxTag")
	public void setTaxTag( java.lang.String taxTag ) {
		isSet_taxTag = true;
		this.taxTag = taxTag;
	}
	
	/** Property set << taxTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangVendor >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangVendor = false;
	
	protected boolean isSet_sihangVendor()
	{
		return this.isSet_sihangVendor;
	}
	
	protected void setIsSet_sihangVendor(boolean value)
	{
		this.isSet_sihangVendor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사사업자코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangVendor  = null;
	
	/**
	 * @Description 시행사사업자코드
	 */
	public java.lang.String getSihangVendor(){
		return sihangVendor;
	}
	
	/**
	 * @Description 시행사사업자코드
	 */
	@JsonProperty("sihangVendor")
	public void setSihangVendor( java.lang.String sihangVendor ) {
		isSet_sihangVendor = true;
		this.sihangVendor = sihangVendor;
	}
	
	/** Property set << sihangVendor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangName >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangName = false;
	
	protected boolean isSet_sihangName()
	{
		return this.isSet_sihangName;
	}
	
	protected void setIsSet_sihangName(boolean value)
	{
		this.isSet_sihangName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사상호명", formatType="", format="", align="left", length=60, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangName  = null;
	
	/**
	 * @Description 시행사상호명
	 */
	public java.lang.String getSihangName(){
		return sihangName;
	}
	
	/**
	 * @Description 시행사상호명
	 */
	@JsonProperty("sihangName")
	public void setSihangName( java.lang.String sihangName ) {
		isSet_sihangName = true;
		this.sihangName = sihangName;
	}
	
	/** Property set << sihangName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangDepyo >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangDepyo = false;
	
	protected boolean isSet_sihangDepyo()
	{
		return this.isSet_sihangDepyo;
	}
	
	protected void setIsSet_sihangDepyo(boolean value)
	{
		this.isSet_sihangDepyo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사대표자명", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangDepyo  = null;
	
	/**
	 * @Description 시행사대표자명
	 */
	public java.lang.String getSihangDepyo(){
		return sihangDepyo;
	}
	
	/**
	 * @Description 시행사대표자명
	 */
	@JsonProperty("sihangDepyo")
	public void setSihangDepyo( java.lang.String sihangDepyo ) {
		isSet_sihangDepyo = true;
		this.sihangDepyo = sihangDepyo;
	}
	
	/** Property set << sihangDepyo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangUpte >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangUpte = false;
	
	protected boolean isSet_sihangUpte()
	{
		return this.isSet_sihangUpte;
	}
	
	protected void setIsSet_sihangUpte(boolean value)
	{
		this.isSet_sihangUpte = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사업태", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangUpte  = null;
	
	/**
	 * @Description 시행사업태
	 */
	public java.lang.String getSihangUpte(){
		return sihangUpte;
	}
	
	/**
	 * @Description 시행사업태
	 */
	@JsonProperty("sihangUpte")
	public void setSihangUpte( java.lang.String sihangUpte ) {
		isSet_sihangUpte = true;
		this.sihangUpte = sihangUpte;
	}
	
	/** Property set << sihangUpte >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangUpjong >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangUpjong = false;
	
	protected boolean isSet_sihangUpjong()
	{
		return this.isSet_sihangUpjong;
	}
	
	protected void setIsSet_sihangUpjong(boolean value)
	{
		this.isSet_sihangUpjong = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사업종", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangUpjong  = null;
	
	/**
	 * @Description 시행사업종
	 */
	public java.lang.String getSihangUpjong(){
		return sihangUpjong;
	}
	
	/**
	 * @Description 시행사업종
	 */
	@JsonProperty("sihangUpjong")
	public void setSihangUpjong( java.lang.String sihangUpjong ) {
		isSet_sihangUpjong = true;
		this.sihangUpjong = sihangUpjong;
	}
	
	/** Property set << sihangUpjong >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangZip >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangZip = false;
	
	protected boolean isSet_sihangZip()
	{
		return this.isSet_sihangZip;
	}
	
	protected void setIsSet_sihangZip(boolean value)
	{
		this.isSet_sihangZip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사우편번호", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangZip  = null;
	
	/**
	 * @Description 시행사우편번호
	 */
	public java.lang.String getSihangZip(){
		return sihangZip;
	}
	
	/**
	 * @Description 시행사우편번호
	 */
	@JsonProperty("sihangZip")
	public void setSihangZip( java.lang.String sihangZip ) {
		isSet_sihangZip = true;
		this.sihangZip = sihangZip;
	}
	
	/** Property set << sihangZip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr1 = false;
	
	protected boolean isSet_sihangAddr1()
	{
		return this.isSet_sihangAddr1;
	}
	
	protected void setIsSet_sihangAddr1(boolean value)
	{
		this.isSet_sihangAddr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소1", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr1  = null;
	
	/**
	 * @Description 시행사주소1
	 */
	public java.lang.String getSihangAddr1(){
		return sihangAddr1;
	}
	
	/**
	 * @Description 시행사주소1
	 */
	@JsonProperty("sihangAddr1")
	public void setSihangAddr1( java.lang.String sihangAddr1 ) {
		isSet_sihangAddr1 = true;
		this.sihangAddr1 = sihangAddr1;
	}
	
	/** Property set << sihangAddr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr2 = false;
	
	protected boolean isSet_sihangAddr2()
	{
		return this.isSet_sihangAddr2;
	}
	
	protected void setIsSet_sihangAddr2(boolean value)
	{
		this.isSet_sihangAddr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소2", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr2  = null;
	
	/**
	 * @Description 시행사주소2
	 */
	public java.lang.String getSihangAddr2(){
		return sihangAddr2;
	}
	
	/**
	 * @Description 시행사주소2
	 */
	@JsonProperty("sihangAddr2")
	public void setSihangAddr2( java.lang.String sihangAddr2 ) {
		isSet_sihangAddr2 = true;
		this.sihangAddr2 = sihangAddr2;
	}
	
	/** Property set << sihangAddr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sigongName >> [[ */
	
	@XmlTransient
	private boolean isSet_sigongName = false;
	
	protected boolean isSet_sigongName()
	{
		return this.isSet_sigongName;
	}
	
	protected void setIsSet_sigongName(boolean value)
	{
		this.isSet_sigongName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시공사상호명", formatType="", format="", align="left", length=60, decimal=0, arrayReference="", fill="")
	private java.lang.String sigongName  = null;
	
	/**
	 * @Description 시공사상호명
	 */
	public java.lang.String getSigongName(){
		return sigongName;
	}
	
	/**
	 * @Description 시공사상호명
	 */
	@JsonProperty("sigongName")
	public void setSigongName( java.lang.String sigongName ) {
		isSet_sigongName = true;
		this.sigongName = sigongName;
	}
	
	/** Property set << sigongName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sigongDepyo >> [[ */
	
	@XmlTransient
	private boolean isSet_sigongDepyo = false;
	
	protected boolean isSet_sigongDepyo()
	{
		return this.isSet_sigongDepyo;
	}
	
	protected void setIsSet_sigongDepyo(boolean value)
	{
		this.isSet_sigongDepyo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시공사대표자명", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sigongDepyo  = null;
	
	/**
	 * @Description 시공사대표자명
	 */
	public java.lang.String getSigongDepyo(){
		return sigongDepyo;
	}
	
	/**
	 * @Description 시공사대표자명
	 */
	@JsonProperty("sigongDepyo")
	public void setSigongDepyo( java.lang.String sigongDepyo ) {
		isSet_sigongDepyo = true;
		this.sigongDepyo = sigongDepyo;
	}
	
	/** Property set << sigongDepyo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sigongCharge >> [[ */
	
	@XmlTransient
	private boolean isSet_sigongCharge = false;
	
	protected boolean isSet_sigongCharge()
	{
		return this.isSet_sigongCharge;
	}
	
	protected void setIsSet_sigongCharge(boolean value)
	{
		this.isSet_sigongCharge = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시공사담당자", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String sigongCharge  = null;
	
	/**
	 * @Description 시공사담당자
	 */
	public java.lang.String getSigongCharge(){
		return sigongCharge;
	}
	
	/**
	 * @Description 시공사담당자
	 */
	@JsonProperty("sigongCharge")
	public void setSigongCharge( java.lang.String sigongCharge ) {
		isSet_sigongCharge = true;
		this.sigongCharge = sigongCharge;
	}
	
	/** Property set << sigongCharge >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sigongTel >> [[ */
	
	@XmlTransient
	private boolean isSet_sigongTel = false;
	
	protected boolean isSet_sigongTel()
	{
		return this.isSet_sigongTel;
	}
	
	protected void setIsSet_sigongTel(boolean value)
	{
		this.isSet_sigongTel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시공사전화번호", formatType="", format="", align="left", length=18, decimal=0, arrayReference="", fill="")
	private java.lang.String sigongTel  = null;
	
	/**
	 * @Description 시공사전화번호
	 */
	public java.lang.String getSigongTel(){
		return sigongTel;
	}
	
	/**
	 * @Description 시공사전화번호
	 */
	@JsonProperty("sigongTel")
	public void setSigongTel( java.lang.String sigongTel ) {
		isSet_sigongTel = true;
		this.sigongTel = sigongTel;
	}
	
	/** Property set << sigongTel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelZip >> [[ */
	
	@XmlTransient
	private boolean isSet_modelZip = false;
	
	protected boolean isSet_modelZip()
	{
		return this.isSet_modelZip;
	}
	
	protected void setIsSet_modelZip(boolean value)
	{
		this.isSet_modelZip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스우편번호", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String modelZip  = null;
	
	/**
	 * @Description 모델하우스우편번호
	 */
	public java.lang.String getModelZip(){
		return modelZip;
	}
	
	/**
	 * @Description 모델하우스우편번호
	 */
	@JsonProperty("modelZip")
	public void setModelZip( java.lang.String modelZip ) {
		isSet_modelZip = true;
		this.modelZip = modelZip;
	}
	
	/** Property set << modelZip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelAddr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_modelAddr1 = false;
	
	protected boolean isSet_modelAddr1()
	{
		return this.isSet_modelAddr1;
	}
	
	protected void setIsSet_modelAddr1(boolean value)
	{
		this.isSet_modelAddr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스주소1", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String modelAddr1  = null;
	
	/**
	 * @Description 모델하우스주소1
	 */
	public java.lang.String getModelAddr1(){
		return modelAddr1;
	}
	
	/**
	 * @Description 모델하우스주소1
	 */
	@JsonProperty("modelAddr1")
	public void setModelAddr1( java.lang.String modelAddr1 ) {
		isSet_modelAddr1 = true;
		this.modelAddr1 = modelAddr1;
	}
	
	/** Property set << modelAddr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelAddr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_modelAddr2 = false;
	
	protected boolean isSet_modelAddr2()
	{
		return this.isSet_modelAddr2;
	}
	
	protected void setIsSet_modelAddr2(boolean value)
	{
		this.isSet_modelAddr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스주소2", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String modelAddr2  = null;
	
	/**
	 * @Description 모델하우스주소2
	 */
	public java.lang.String getModelAddr2(){
		return modelAddr2;
	}
	
	/**
	 * @Description 모델하우스주소2
	 */
	@JsonProperty("modelAddr2")
	public void setModelAddr2( java.lang.String modelAddr2 ) {
		isSet_modelAddr2 = true;
		this.modelAddr2 = modelAddr2;
	}
	
	/** Property set << modelAddr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelTel >> [[ */
	
	@XmlTransient
	private boolean isSet_modelTel = false;
	
	protected boolean isSet_modelTel()
	{
		return this.isSet_modelTel;
	}
	
	protected void setIsSet_modelTel(boolean value)
	{
		this.isSet_modelTel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스전화번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String modelTel  = null;
	
	/**
	 * @Description 모델하우스전화번호
	 */
	public java.lang.String getModelTel(){
		return modelTel;
	}
	
	/**
	 * @Description 모델하우스전화번호
	 */
	@JsonProperty("modelTel")
	public void setModelTel( java.lang.String modelTel ) {
		isSet_modelTel = true;
		this.modelTel = modelTel;
	}
	
	/** Property set << modelTel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptTypeCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptTypeCode = false;
	
	protected boolean isSet_deptTypeCode()
	{
		return this.isSet_deptTypeCode;
	}
	
	protected void setIsSet_deptTypeCode(boolean value)
	{
		this.isSet_deptTypeCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="물건종류코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String deptTypeCode  = null;
	
	/**
	 * @Description 물건종류코드
	 */
	public java.lang.String getDeptTypeCode(){
		return deptTypeCode;
	}
	
	/**
	 * @Description 물건종류코드
	 */
	@JsonProperty("deptTypeCode")
	public void setDeptTypeCode( java.lang.String deptTypeCode ) {
		isSet_deptTypeCode = true;
		this.deptTypeCode = deptTypeCode;
	}
	
	/** Property set << deptTypeCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << smsName >> [[ */
	
	@XmlTransient
	private boolean isSet_smsName = false;
	
	protected boolean isSet_smsName()
	{
		return this.isSet_smsName;
	}
	
	protected void setIsSet_smsName(boolean value)
	{
		this.isSet_smsName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업약칭", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String smsName  = null;
	
	/**
	 * @Description 사업약칭
	 */
	public java.lang.String getSmsName(){
		return smsName;
	}
	
	/**
	 * @Description 사업약칭
	 */
	@JsonProperty("smsName")
	public void setSmsName( java.lang.String smsName ) {
		isSet_smsName = true;
		this.smsName = smsName;
	}
	
	/** Property set << smsName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << smsTel >> [[ */
	
	@XmlTransient
	private boolean isSet_smsTel = false;
	
	protected boolean isSet_smsTel()
	{
		return this.isSet_smsTel;
	}
	
	protected void setIsSet_smsTel(boolean value)
	{
		this.isSet_smsTel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="SMS회신전화번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String smsTel  = null;
	
	/**
	 * @Description SMS회신전화번호
	 */
	public java.lang.String getSmsTel(){
		return smsTel;
	}
	
	/**
	 * @Description SMS회신전화번호
	 */
	@JsonProperty("smsTel")
	public void setSmsTel( java.lang.String smsTel ) {
		isSet_smsTel = true;
		this.smsTel = smsTel;
	}
	
	/** Property set << smsTel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << oldDeptcode >> [[ */
	
	@XmlTransient
	private boolean isSet_oldDeptcode = false;
	
	protected boolean isSet_oldDeptcode()
	{
		return this.isSet_oldDeptcode;
	}
	
	protected void setIsSet_oldDeptcode(boolean value)
	{
		this.isSet_oldDeptcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="구현장코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String oldDeptcode  = null;
	
	/**
	 * @Description 구현장코드
	 */
	public java.lang.String getOldDeptcode(){
		return oldDeptcode;
	}
	
	/**
	 * @Description 구현장코드
	 */
	@JsonProperty("oldDeptcode")
	public void setOldDeptcode( java.lang.String oldDeptcode ) {
		isSet_oldDeptcode = true;
		this.oldDeptcode = oldDeptcode;
	}
	
	/** Property set << oldDeptcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << triTag >> [[ */
	
	@XmlTransient
	private boolean isSet_triTag = false;
	
	protected boolean isSet_triTag()
	{
		return this.isSet_triTag;
	}
	
	protected void setIsSet_triTag(boolean value)
	{
		this.isSet_triTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="트리거구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String triTag  = null;
	
	/**
	 * @Description 트리거구분
	 */
	public java.lang.String getTriTag(){
		return triTag;
	}
	
	/**
	 * @Description 트리거구분
	 */
	@JsonProperty("triTag")
	public void setTriTag( java.lang.String triTag ) {
		isSet_triTag = true;
		this.triTag = triTag;
	}
	
	/** Property set << triTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modtag >> [[ */
	
	@XmlTransient
	private boolean isSet_modtag = false;
	
	protected boolean isSet_modtag()
	{
		return this.isSet_modtag;
	}
	
	protected void setIsSet_modtag(boolean value)
	{
		this.isSet_modtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="자료수정여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String modtag  = null;
	
	/**
	 * @Description 자료수정여부
	 */
	public java.lang.String getModtag(){
		return modtag;
	}
	
	/**
	 * @Description 자료수정여부
	 */
	@JsonProperty("modtag")
	public void setModtag( java.lang.String modtag ) {
		isSet_modtag = true;
		this.modtag = modtag;
	}
	
	/** Property set << modtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << zipOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_zipOrg = false;
	
	protected boolean isSet_zipOrg()
	{
		return this.isSet_zipOrg;
	}
	
	protected void setIsSet_zipOrg(boolean value)
	{
		this.isSet_zipOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="우편번호_지번", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String zipOrg  = null;
	
	/**
	 * @Description 우편번호_지번
	 */
	public java.lang.String getZipOrg(){
		return zipOrg;
	}
	
	/**
	 * @Description 우편번호_지번
	 */
	@JsonProperty("zipOrg")
	public void setZipOrg( java.lang.String zipOrg ) {
		isSet_zipOrg = true;
		this.zipOrg = zipOrg;
	}
	
	/** Property set << zipOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_addr1Org = false;
	
	protected boolean isSet_addr1Org()
	{
		return this.isSet_addr1Org;
	}
	
	protected void setIsSet_addr1Org(boolean value)
	{
		this.isSet_addr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소1_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String addr1Org  = null;
	
	/**
	 * @Description 주소1_지번
	 */
	public java.lang.String getAddr1Org(){
		return addr1Org;
	}
	
	/**
	 * @Description 주소1_지번
	 */
	@JsonProperty("addr1Org")
	public void setAddr1Org( java.lang.String addr1Org ) {
		isSet_addr1Org = true;
		this.addr1Org = addr1Org;
	}
	
	/** Property set << addr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2Org = false;
	
	protected boolean isSet_addr2Org()
	{
		return this.isSet_addr2Org;
	}
	
	protected void setIsSet_addr2Org(boolean value)
	{
		this.isSet_addr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소2_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2Org  = null;
	
	/**
	 * @Description 주소2_지번
	 */
	public java.lang.String getAddr2Org(){
		return addr2Org;
	}
	
	/**
	 * @Description 주소2_지번
	 */
	@JsonProperty("addr2Org")
	public void setAddr2Org( java.lang.String addr2Org ) {
		isSet_addr2Org = true;
		this.addr2Org = addr2Org;
	}
	
	/** Property set << addr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_addrTag = false;
	
	protected boolean isSet_addrTag()
	{
		return this.isSet_addrTag;
	}
	
	protected void setIsSet_addrTag(boolean value)
	{
		this.isSet_addrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소_구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String addrTag  = null;
	
	/**
	 * @Description 주소_구분
	 */
	public java.lang.String getAddrTag(){
		return addrTag;
	}
	
	/**
	 * @Description 주소_구분
	 */
	@JsonProperty("addrTag")
	public void setAddrTag( java.lang.String addrTag ) {
		isSet_addrTag = true;
		this.addrTag = addrTag;
	}
	
	/** Property set << addrTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangZipOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangZipOrg = false;
	
	protected boolean isSet_sihangZipOrg()
	{
		return this.isSet_sihangZipOrg;
	}
	
	protected void setIsSet_sihangZipOrg(boolean value)
	{
		this.isSet_sihangZipOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사우편번호_지번", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangZipOrg  = null;
	
	/**
	 * @Description 시행사우편번호_지번
	 */
	public java.lang.String getSihangZipOrg(){
		return sihangZipOrg;
	}
	
	/**
	 * @Description 시행사우편번호_지번
	 */
	@JsonProperty("sihangZipOrg")
	public void setSihangZipOrg( java.lang.String sihangZipOrg ) {
		isSet_sihangZipOrg = true;
		this.sihangZipOrg = sihangZipOrg;
	}
	
	/** Property set << sihangZipOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr1Org = false;
	
	protected boolean isSet_sihangAddr1Org()
	{
		return this.isSet_sihangAddr1Org;
	}
	
	protected void setIsSet_sihangAddr1Org(boolean value)
	{
		this.isSet_sihangAddr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소1_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr1Org  = null;
	
	/**
	 * @Description 시행사주소1_지번
	 */
	public java.lang.String getSihangAddr1Org(){
		return sihangAddr1Org;
	}
	
	/**
	 * @Description 시행사주소1_지번
	 */
	@JsonProperty("sihangAddr1Org")
	public void setSihangAddr1Org( java.lang.String sihangAddr1Org ) {
		isSet_sihangAddr1Org = true;
		this.sihangAddr1Org = sihangAddr1Org;
	}
	
	/** Property set << sihangAddr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr2Org = false;
	
	protected boolean isSet_sihangAddr2Org()
	{
		return this.isSet_sihangAddr2Org;
	}
	
	protected void setIsSet_sihangAddr2Org(boolean value)
	{
		this.isSet_sihangAddr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소2_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr2Org  = null;
	
	/**
	 * @Description 시행사주소2_지번
	 */
	public java.lang.String getSihangAddr2Org(){
		return sihangAddr2Org;
	}
	
	/**
	 * @Description 시행사주소2_지번
	 */
	@JsonProperty("sihangAddr2Org")
	public void setSihangAddr2Org( java.lang.String sihangAddr2Org ) {
		isSet_sihangAddr2Org = true;
		this.sihangAddr2Org = sihangAddr2Org;
	}
	
	/** Property set << sihangAddr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddrTag = false;
	
	protected boolean isSet_sihangAddrTag()
	{
		return this.isSet_sihangAddrTag;
	}
	
	protected void setIsSet_sihangAddrTag(boolean value)
	{
		this.isSet_sihangAddrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소_구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddrTag  = null;
	
	/**
	 * @Description 시행사주소_구분
	 */
	public java.lang.String getSihangAddrTag(){
		return sihangAddrTag;
	}
	
	/**
	 * @Description 시행사주소_구분
	 */
	@JsonProperty("sihangAddrTag")
	public void setSihangAddrTag( java.lang.String sihangAddrTag ) {
		isSet_sihangAddrTag = true;
		this.sihangAddrTag = sihangAddrTag;
	}
	
	/** Property set << sihangAddrTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelZipOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_modelZipOrg = false;
	
	protected boolean isSet_modelZipOrg()
	{
		return this.isSet_modelZipOrg;
	}
	
	protected void setIsSet_modelZipOrg(boolean value)
	{
		this.isSet_modelZipOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스우편번호_지번", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String modelZipOrg  = null;
	
	/**
	 * @Description 모델하우스우편번호_지번
	 */
	public java.lang.String getModelZipOrg(){
		return modelZipOrg;
	}
	
	/**
	 * @Description 모델하우스우편번호_지번
	 */
	@JsonProperty("modelZipOrg")
	public void setModelZipOrg( java.lang.String modelZipOrg ) {
		isSet_modelZipOrg = true;
		this.modelZipOrg = modelZipOrg;
	}
	
	/** Property set << modelZipOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelAddr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_modelAddr1Org = false;
	
	protected boolean isSet_modelAddr1Org()
	{
		return this.isSet_modelAddr1Org;
	}
	
	protected void setIsSet_modelAddr1Org(boolean value)
	{
		this.isSet_modelAddr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스주소1_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String modelAddr1Org  = null;
	
	/**
	 * @Description 모델하우스주소1_지번
	 */
	public java.lang.String getModelAddr1Org(){
		return modelAddr1Org;
	}
	
	/**
	 * @Description 모델하우스주소1_지번
	 */
	@JsonProperty("modelAddr1Org")
	public void setModelAddr1Org( java.lang.String modelAddr1Org ) {
		isSet_modelAddr1Org = true;
		this.modelAddr1Org = modelAddr1Org;
	}
	
	/** Property set << modelAddr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelAddr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_modelAddr2Org = false;
	
	protected boolean isSet_modelAddr2Org()
	{
		return this.isSet_modelAddr2Org;
	}
	
	protected void setIsSet_modelAddr2Org(boolean value)
	{
		this.isSet_modelAddr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스주소2_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String modelAddr2Org  = null;
	
	/**
	 * @Description 모델하우스주소2_지번
	 */
	public java.lang.String getModelAddr2Org(){
		return modelAddr2Org;
	}
	
	/**
	 * @Description 모델하우스주소2_지번
	 */
	@JsonProperty("modelAddr2Org")
	public void setModelAddr2Org( java.lang.String modelAddr2Org ) {
		isSet_modelAddr2Org = true;
		this.modelAddr2Org = modelAddr2Org;
	}
	
	/** Property set << modelAddr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modelAddrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_modelAddrTag = false;
	
	protected boolean isSet_modelAddrTag()
	{
		return this.isSet_modelAddrTag;
	}
	
	protected void setIsSet_modelAddrTag(boolean value)
	{
		this.isSet_modelAddrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="모델하우스주소_구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String modelAddrTag  = null;
	
	/**
	 * @Description 모델하우스주소_구분
	 */
	public java.lang.String getModelAddrTag(){
		return modelAddrTag;
	}
	
	/**
	 * @Description 모델하우스주소_구분
	 */
	@JsonProperty("modelAddrTag")
	public void setModelAddrTag( java.lang.String modelAddrTag ) {
		isSet_modelAddrTag = true;
		this.modelAddrTag = modelAddrTag;
	}
	
	/** Property set << modelAddrTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeDeptHist01IO clone(){
		try{
			DHDCodeDeptHist01IO object= (DHDCodeDeptHist01IO)super.clone();
			if ( this.histDate== null ) object.histDate = null;
			else{
				object.histDate = this.histDate;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.deptName== null ) object.deptName = null;
			else{
				object.deptName = this.deptName;
			}
			if ( this.tel== null ) object.tel = null;
			else{
				object.tel = this.tel;
			}
			if ( this.zip== null ) object.zip = null;
			else{
				object.zip = this.zip;
			}
			if ( this.addr1== null ) object.addr1 = null;
			else{
				object.addr1 = this.addr1;
			}
			if ( this.addr2== null ) object.addr2 = null;
			else{
				object.addr2 = this.addr2;
			}
			if ( this.listtag== null ) object.listtag = null;
			else{
				object.listtag = this.listtag;
			}
			if ( this.jobtag== null ) object.jobtag = null;
			else{
				object.jobtag = this.jobtag;
			}
			if ( this.companyCode== null ) object.companyCode = null;
			else{
				object.companyCode = this.companyCode;
			}
			if ( this.amisDeptcode== null ) object.amisDeptcode = null;
			else{
				object.amisDeptcode = this.amisDeptcode;
			}
			if ( this.taxTag== null ) object.taxTag = null;
			else{
				object.taxTag = this.taxTag;
			}
			if ( this.sihangVendor== null ) object.sihangVendor = null;
			else{
				object.sihangVendor = this.sihangVendor;
			}
			if ( this.sihangName== null ) object.sihangName = null;
			else{
				object.sihangName = this.sihangName;
			}
			if ( this.sihangDepyo== null ) object.sihangDepyo = null;
			else{
				object.sihangDepyo = this.sihangDepyo;
			}
			if ( this.sihangUpte== null ) object.sihangUpte = null;
			else{
				object.sihangUpte = this.sihangUpte;
			}
			if ( this.sihangUpjong== null ) object.sihangUpjong = null;
			else{
				object.sihangUpjong = this.sihangUpjong;
			}
			if ( this.sihangZip== null ) object.sihangZip = null;
			else{
				object.sihangZip = this.sihangZip;
			}
			if ( this.sihangAddr1== null ) object.sihangAddr1 = null;
			else{
				object.sihangAddr1 = this.sihangAddr1;
			}
			if ( this.sihangAddr2== null ) object.sihangAddr2 = null;
			else{
				object.sihangAddr2 = this.sihangAddr2;
			}
			if ( this.sigongName== null ) object.sigongName = null;
			else{
				object.sigongName = this.sigongName;
			}
			if ( this.sigongDepyo== null ) object.sigongDepyo = null;
			else{
				object.sigongDepyo = this.sigongDepyo;
			}
			if ( this.sigongCharge== null ) object.sigongCharge = null;
			else{
				object.sigongCharge = this.sigongCharge;
			}
			if ( this.sigongTel== null ) object.sigongTel = null;
			else{
				object.sigongTel = this.sigongTel;
			}
			if ( this.modelZip== null ) object.modelZip = null;
			else{
				object.modelZip = this.modelZip;
			}
			if ( this.modelAddr1== null ) object.modelAddr1 = null;
			else{
				object.modelAddr1 = this.modelAddr1;
			}
			if ( this.modelAddr2== null ) object.modelAddr2 = null;
			else{
				object.modelAddr2 = this.modelAddr2;
			}
			if ( this.modelTel== null ) object.modelTel = null;
			else{
				object.modelTel = this.modelTel;
			}
			if ( this.deptTypeCode== null ) object.deptTypeCode = null;
			else{
				object.deptTypeCode = this.deptTypeCode;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.smsName== null ) object.smsName = null;
			else{
				object.smsName = this.smsName;
			}
			if ( this.smsTel== null ) object.smsTel = null;
			else{
				object.smsTel = this.smsTel;
			}
			if ( this.oldDeptcode== null ) object.oldDeptcode = null;
			else{
				object.oldDeptcode = this.oldDeptcode;
			}
			if ( this.triTag== null ) object.triTag = null;
			else{
				object.triTag = this.triTag;
			}
			if ( this.modtag== null ) object.modtag = null;
			else{
				object.modtag = this.modtag;
			}
			if ( this.zipOrg== null ) object.zipOrg = null;
			else{
				object.zipOrg = this.zipOrg;
			}
			if ( this.addr1Org== null ) object.addr1Org = null;
			else{
				object.addr1Org = this.addr1Org;
			}
			if ( this.addr2Org== null ) object.addr2Org = null;
			else{
				object.addr2Org = this.addr2Org;
			}
			if ( this.addrTag== null ) object.addrTag = null;
			else{
				object.addrTag = this.addrTag;
			}
			if ( this.sihangZipOrg== null ) object.sihangZipOrg = null;
			else{
				object.sihangZipOrg = this.sihangZipOrg;
			}
			if ( this.sihangAddr1Org== null ) object.sihangAddr1Org = null;
			else{
				object.sihangAddr1Org = this.sihangAddr1Org;
			}
			if ( this.sihangAddr2Org== null ) object.sihangAddr2Org = null;
			else{
				object.sihangAddr2Org = this.sihangAddr2Org;
			}
			if ( this.sihangAddrTag== null ) object.sihangAddrTag = null;
			else{
				object.sihangAddrTag = this.sihangAddrTag;
			}
			if ( this.modelZipOrg== null ) object.modelZipOrg = null;
			else{
				object.modelZipOrg = this.modelZipOrg;
			}
			if ( this.modelAddr1Org== null ) object.modelAddr1Org = null;
			else{
				object.modelAddr1Org = this.modelAddr1Org;
			}
			if ( this.modelAddr2Org== null ) object.modelAddr2Org = null;
			else{
				object.modelAddr2Org = this.modelAddr2Org;
			}
			if ( this.modelAddrTag== null ) object.modelAddrTag = null;
			else{
				object.modelAddrTag = this.modelAddrTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((histDate==null)?0:histDate.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((deptName==null)?0:deptName.hashCode());
		result = prime * result + ((tel==null)?0:tel.hashCode());
		result = prime * result + ((zip==null)?0:zip.hashCode());
		result = prime * result + ((addr1==null)?0:addr1.hashCode());
		result = prime * result + ((addr2==null)?0:addr2.hashCode());
		result = prime * result + ((listtag==null)?0:listtag.hashCode());
		result = prime * result + ((jobtag==null)?0:jobtag.hashCode());
		result = prime * result + ((companyCode==null)?0:companyCode.hashCode());
		result = prime * result + ((amisDeptcode==null)?0:amisDeptcode.hashCode());
		result = prime * result + ((taxTag==null)?0:taxTag.hashCode());
		result = prime * result + ((sihangVendor==null)?0:sihangVendor.hashCode());
		result = prime * result + ((sihangName==null)?0:sihangName.hashCode());
		result = prime * result + ((sihangDepyo==null)?0:sihangDepyo.hashCode());
		result = prime * result + ((sihangUpte==null)?0:sihangUpte.hashCode());
		result = prime * result + ((sihangUpjong==null)?0:sihangUpjong.hashCode());
		result = prime * result + ((sihangZip==null)?0:sihangZip.hashCode());
		result = prime * result + ((sihangAddr1==null)?0:sihangAddr1.hashCode());
		result = prime * result + ((sihangAddr2==null)?0:sihangAddr2.hashCode());
		result = prime * result + ((sigongName==null)?0:sigongName.hashCode());
		result = prime * result + ((sigongDepyo==null)?0:sigongDepyo.hashCode());
		result = prime * result + ((sigongCharge==null)?0:sigongCharge.hashCode());
		result = prime * result + ((sigongTel==null)?0:sigongTel.hashCode());
		result = prime * result + ((modelZip==null)?0:modelZip.hashCode());
		result = prime * result + ((modelAddr1==null)?0:modelAddr1.hashCode());
		result = prime * result + ((modelAddr2==null)?0:modelAddr2.hashCode());
		result = prime * result + ((modelTel==null)?0:modelTel.hashCode());
		result = prime * result + ((deptTypeCode==null)?0:deptTypeCode.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((smsName==null)?0:smsName.hashCode());
		result = prime * result + ((smsTel==null)?0:smsTel.hashCode());
		result = prime * result + ((oldDeptcode==null)?0:oldDeptcode.hashCode());
		result = prime * result + ((triTag==null)?0:triTag.hashCode());
		result = prime * result + ((modtag==null)?0:modtag.hashCode());
		result = prime * result + ((zipOrg==null)?0:zipOrg.hashCode());
		result = prime * result + ((addr1Org==null)?0:addr1Org.hashCode());
		result = prime * result + ((addr2Org==null)?0:addr2Org.hashCode());
		result = prime * result + ((addrTag==null)?0:addrTag.hashCode());
		result = prime * result + ((sihangZipOrg==null)?0:sihangZipOrg.hashCode());
		result = prime * result + ((sihangAddr1Org==null)?0:sihangAddr1Org.hashCode());
		result = prime * result + ((sihangAddr2Org==null)?0:sihangAddr2Org.hashCode());
		result = prime * result + ((sihangAddrTag==null)?0:sihangAddrTag.hashCode());
		result = prime * result + ((modelZipOrg==null)?0:modelZipOrg.hashCode());
		result = prime * result + ((modelAddr1Org==null)?0:modelAddr1Org.hashCode());
		result = prime * result + ((modelAddr2Org==null)?0:modelAddr2Org.hashCode());
		result = prime * result + ((modelAddrTag==null)?0:modelAddrTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO other = (kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO)obj;
		if ( histDate == null ){
			if ( other.histDate != null ) return false;
		}
		else if ( !histDate.equals(other.histDate) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( deptName == null ){
			if ( other.deptName != null ) return false;
		}
		else if ( !deptName.equals(other.deptName) )
			return false;
		if ( tel == null ){
			if ( other.tel != null ) return false;
		}
		else if ( !tel.equals(other.tel) )
			return false;
		if ( zip == null ){
			if ( other.zip != null ) return false;
		}
		else if ( !zip.equals(other.zip) )
			return false;
		if ( addr1 == null ){
			if ( other.addr1 != null ) return false;
		}
		else if ( !addr1.equals(other.addr1) )
			return false;
		if ( addr2 == null ){
			if ( other.addr2 != null ) return false;
		}
		else if ( !addr2.equals(other.addr2) )
			return false;
		if ( listtag == null ){
			if ( other.listtag != null ) return false;
		}
		else if ( !listtag.equals(other.listtag) )
			return false;
		if ( jobtag == null ){
			if ( other.jobtag != null ) return false;
		}
		else if ( !jobtag.equals(other.jobtag) )
			return false;
		if ( companyCode == null ){
			if ( other.companyCode != null ) return false;
		}
		else if ( !companyCode.equals(other.companyCode) )
			return false;
		if ( amisDeptcode == null ){
			if ( other.amisDeptcode != null ) return false;
		}
		else if ( !amisDeptcode.equals(other.amisDeptcode) )
			return false;
		if ( taxTag == null ){
			if ( other.taxTag != null ) return false;
		}
		else if ( !taxTag.equals(other.taxTag) )
			return false;
		if ( sihangVendor == null ){
			if ( other.sihangVendor != null ) return false;
		}
		else if ( !sihangVendor.equals(other.sihangVendor) )
			return false;
		if ( sihangName == null ){
			if ( other.sihangName != null ) return false;
		}
		else if ( !sihangName.equals(other.sihangName) )
			return false;
		if ( sihangDepyo == null ){
			if ( other.sihangDepyo != null ) return false;
		}
		else if ( !sihangDepyo.equals(other.sihangDepyo) )
			return false;
		if ( sihangUpte == null ){
			if ( other.sihangUpte != null ) return false;
		}
		else if ( !sihangUpte.equals(other.sihangUpte) )
			return false;
		if ( sihangUpjong == null ){
			if ( other.sihangUpjong != null ) return false;
		}
		else if ( !sihangUpjong.equals(other.sihangUpjong) )
			return false;
		if ( sihangZip == null ){
			if ( other.sihangZip != null ) return false;
		}
		else if ( !sihangZip.equals(other.sihangZip) )
			return false;
		if ( sihangAddr1 == null ){
			if ( other.sihangAddr1 != null ) return false;
		}
		else if ( !sihangAddr1.equals(other.sihangAddr1) )
			return false;
		if ( sihangAddr2 == null ){
			if ( other.sihangAddr2 != null ) return false;
		}
		else if ( !sihangAddr2.equals(other.sihangAddr2) )
			return false;
		if ( sigongName == null ){
			if ( other.sigongName != null ) return false;
		}
		else if ( !sigongName.equals(other.sigongName) )
			return false;
		if ( sigongDepyo == null ){
			if ( other.sigongDepyo != null ) return false;
		}
		else if ( !sigongDepyo.equals(other.sigongDepyo) )
			return false;
		if ( sigongCharge == null ){
			if ( other.sigongCharge != null ) return false;
		}
		else if ( !sigongCharge.equals(other.sigongCharge) )
			return false;
		if ( sigongTel == null ){
			if ( other.sigongTel != null ) return false;
		}
		else if ( !sigongTel.equals(other.sigongTel) )
			return false;
		if ( modelZip == null ){
			if ( other.modelZip != null ) return false;
		}
		else if ( !modelZip.equals(other.modelZip) )
			return false;
		if ( modelAddr1 == null ){
			if ( other.modelAddr1 != null ) return false;
		}
		else if ( !modelAddr1.equals(other.modelAddr1) )
			return false;
		if ( modelAddr2 == null ){
			if ( other.modelAddr2 != null ) return false;
		}
		else if ( !modelAddr2.equals(other.modelAddr2) )
			return false;
		if ( modelTel == null ){
			if ( other.modelTel != null ) return false;
		}
		else if ( !modelTel.equals(other.modelTel) )
			return false;
		if ( deptTypeCode == null ){
			if ( other.deptTypeCode != null ) return false;
		}
		else if ( !deptTypeCode.equals(other.deptTypeCode) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( smsName == null ){
			if ( other.smsName != null ) return false;
		}
		else if ( !smsName.equals(other.smsName) )
			return false;
		if ( smsTel == null ){
			if ( other.smsTel != null ) return false;
		}
		else if ( !smsTel.equals(other.smsTel) )
			return false;
		if ( oldDeptcode == null ){
			if ( other.oldDeptcode != null ) return false;
		}
		else if ( !oldDeptcode.equals(other.oldDeptcode) )
			return false;
		if ( triTag == null ){
			if ( other.triTag != null ) return false;
		}
		else if ( !triTag.equals(other.triTag) )
			return false;
		if ( modtag == null ){
			if ( other.modtag != null ) return false;
		}
		else if ( !modtag.equals(other.modtag) )
			return false;
		if ( zipOrg == null ){
			if ( other.zipOrg != null ) return false;
		}
		else if ( !zipOrg.equals(other.zipOrg) )
			return false;
		if ( addr1Org == null ){
			if ( other.addr1Org != null ) return false;
		}
		else if ( !addr1Org.equals(other.addr1Org) )
			return false;
		if ( addr2Org == null ){
			if ( other.addr2Org != null ) return false;
		}
		else if ( !addr2Org.equals(other.addr2Org) )
			return false;
		if ( addrTag == null ){
			if ( other.addrTag != null ) return false;
		}
		else if ( !addrTag.equals(other.addrTag) )
			return false;
		if ( sihangZipOrg == null ){
			if ( other.sihangZipOrg != null ) return false;
		}
		else if ( !sihangZipOrg.equals(other.sihangZipOrg) )
			return false;
		if ( sihangAddr1Org == null ){
			if ( other.sihangAddr1Org != null ) return false;
		}
		else if ( !sihangAddr1Org.equals(other.sihangAddr1Org) )
			return false;
		if ( sihangAddr2Org == null ){
			if ( other.sihangAddr2Org != null ) return false;
		}
		else if ( !sihangAddr2Org.equals(other.sihangAddr2Org) )
			return false;
		if ( sihangAddrTag == null ){
			if ( other.sihangAddrTag != null ) return false;
		}
		else if ( !sihangAddrTag.equals(other.sihangAddrTag) )
			return false;
		if ( modelZipOrg == null ){
			if ( other.modelZipOrg != null ) return false;
		}
		else if ( !modelZipOrg.equals(other.modelZipOrg) )
			return false;
		if ( modelAddr1Org == null ){
			if ( other.modelAddr1Org != null ) return false;
		}
		else if ( !modelAddr1Org.equals(other.modelAddr1Org) )
			return false;
		if ( modelAddr2Org == null ){
			if ( other.modelAddr2Org != null ) return false;
		}
		else if ( !modelAddr2Org.equals(other.modelAddr2Org) )
			return false;
		if ( modelAddrTag == null ){
			if ( other.modelAddrTag != null ) return false;
		}
		else if ( !modelAddrTag.equals(other.modelAddrTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO:\n");
		sb.append("\thistDate: ");
		sb.append(histDate==null?"null":getHistDate());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\tdeptName: ");
		sb.append(deptName==null?"null":getDeptName());
		sb.append("\n");
		sb.append("\ttel: ");
		sb.append(tel==null?"null":getTel());
		sb.append("\n");
		sb.append("\tzip: ");
		sb.append(zip==null?"null":getZip());
		sb.append("\n");
		sb.append("\taddr1: ");
		sb.append(addr1==null?"null":getAddr1());
		sb.append("\n");
		sb.append("\taddr2: ");
		sb.append(addr2==null?"null":getAddr2());
		sb.append("\n");
		sb.append("\tlisttag: ");
		sb.append(listtag==null?"null":getListtag());
		sb.append("\n");
		sb.append("\tjobtag: ");
		sb.append(jobtag==null?"null":getJobtag());
		sb.append("\n");
		sb.append("\tcompanyCode: ");
		sb.append(companyCode==null?"null":getCompanyCode());
		sb.append("\n");
		sb.append("\tamisDeptcode: ");
		sb.append(amisDeptcode==null?"null":getAmisDeptcode());
		sb.append("\n");
		sb.append("\ttaxTag: ");
		sb.append(taxTag==null?"null":getTaxTag());
		sb.append("\n");
		sb.append("\tsihangVendor: ");
		sb.append(sihangVendor==null?"null":getSihangVendor());
		sb.append("\n");
		sb.append("\tsihangName: ");
		sb.append(sihangName==null?"null":getSihangName());
		sb.append("\n");
		sb.append("\tsihangDepyo: ");
		sb.append(sihangDepyo==null?"null":getSihangDepyo());
		sb.append("\n");
		sb.append("\tsihangUpte: ");
		sb.append(sihangUpte==null?"null":getSihangUpte());
		sb.append("\n");
		sb.append("\tsihangUpjong: ");
		sb.append(sihangUpjong==null?"null":getSihangUpjong());
		sb.append("\n");
		sb.append("\tsihangZip: ");
		sb.append(sihangZip==null?"null":getSihangZip());
		sb.append("\n");
		sb.append("\tsihangAddr1: ");
		sb.append(sihangAddr1==null?"null":getSihangAddr1());
		sb.append("\n");
		sb.append("\tsihangAddr2: ");
		sb.append(sihangAddr2==null?"null":getSihangAddr2());
		sb.append("\n");
		sb.append("\tsigongName: ");
		sb.append(sigongName==null?"null":getSigongName());
		sb.append("\n");
		sb.append("\tsigongDepyo: ");
		sb.append(sigongDepyo==null?"null":getSigongDepyo());
		sb.append("\n");
		sb.append("\tsigongCharge: ");
		sb.append(sigongCharge==null?"null":getSigongCharge());
		sb.append("\n");
		sb.append("\tsigongTel: ");
		sb.append(sigongTel==null?"null":getSigongTel());
		sb.append("\n");
		sb.append("\tmodelZip: ");
		sb.append(modelZip==null?"null":getModelZip());
		sb.append("\n");
		sb.append("\tmodelAddr1: ");
		sb.append(modelAddr1==null?"null":getModelAddr1());
		sb.append("\n");
		sb.append("\tmodelAddr2: ");
		sb.append(modelAddr2==null?"null":getModelAddr2());
		sb.append("\n");
		sb.append("\tmodelTel: ");
		sb.append(modelTel==null?"null":getModelTel());
		sb.append("\n");
		sb.append("\tdeptTypeCode: ");
		sb.append(deptTypeCode==null?"null":getDeptTypeCode());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tsmsName: ");
		sb.append(smsName==null?"null":getSmsName());
		sb.append("\n");
		sb.append("\tsmsTel: ");
		sb.append(smsTel==null?"null":getSmsTel());
		sb.append("\n");
		sb.append("\toldDeptcode: ");
		sb.append(oldDeptcode==null?"null":getOldDeptcode());
		sb.append("\n");
		sb.append("\ttriTag: ");
		sb.append(triTag==null?"null":getTriTag());
		sb.append("\n");
		sb.append("\tmodtag: ");
		sb.append(modtag==null?"null":getModtag());
		sb.append("\n");
		sb.append("\tzipOrg: ");
		sb.append(zipOrg==null?"null":getZipOrg());
		sb.append("\n");
		sb.append("\taddr1Org: ");
		sb.append(addr1Org==null?"null":getAddr1Org());
		sb.append("\n");
		sb.append("\taddr2Org: ");
		sb.append(addr2Org==null?"null":getAddr2Org());
		sb.append("\n");
		sb.append("\taddrTag: ");
		sb.append(addrTag==null?"null":getAddrTag());
		sb.append("\n");
		sb.append("\tsihangZipOrg: ");
		sb.append(sihangZipOrg==null?"null":getSihangZipOrg());
		sb.append("\n");
		sb.append("\tsihangAddr1Org: ");
		sb.append(sihangAddr1Org==null?"null":getSihangAddr1Org());
		sb.append("\n");
		sb.append("\tsihangAddr2Org: ");
		sb.append(sihangAddr2Org==null?"null":getSihangAddr2Org());
		sb.append("\n");
		sb.append("\tsihangAddrTag: ");
		sb.append(sihangAddrTag==null?"null":getSihangAddrTag());
		sb.append("\n");
		sb.append("\tmodelZipOrg: ");
		sb.append(modelZipOrg==null?"null":getModelZipOrg());
		sb.append("\n");
		sb.append("\tmodelAddr1Org: ");
		sb.append(modelAddr1Org==null?"null":getModelAddr1Org());
		sb.append("\n");
		sb.append("\tmodelAddr2Org: ");
		sb.append(modelAddr2Org==null?"null":getModelAddr2Org());
		sb.append("\n");
		sb.append("\tmodelAddrTag: ");
		sb.append(modelAddrTag==null?"null":getModelAddrTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 7; /* histDate */
		messageLen+= 12; /* deptCode */
		messageLen+= 150; /* deptName */
		messageLen+= 12; /* tel */
		messageLen+= 6; /* zip */
		messageLen+= 100; /* addr1 */
		messageLen+= 100; /* addr2 */
		messageLen+= 1; /* listtag */
		messageLen+= 1; /* jobtag */
		messageLen+= 6; /* companyCode */
		messageLen+= 12; /* amisDeptcode */
		messageLen+= 1; /* taxTag */
		messageLen+= 20; /* sihangVendor */
		messageLen+= 60; /* sihangName */
		messageLen+= 40; /* sihangDepyo */
		messageLen+= 40; /* sihangUpte */
		messageLen+= 40; /* sihangUpjong */
		messageLen+= 6; /* sihangZip */
		messageLen+= 100; /* sihangAddr1 */
		messageLen+= 100; /* sihangAddr2 */
		messageLen+= 60; /* sigongName */
		messageLen+= 40; /* sigongDepyo */
		messageLen+= 20; /* sigongCharge */
		messageLen+= 18; /* sigongTel */
		messageLen+= 6; /* modelZip */
		messageLen+= 100; /* modelAddr1 */
		messageLen+= 100; /* modelAddr2 */
		messageLen+= 20; /* modelTel */
		messageLen+= 2; /* deptTypeCode */
		messageLen+= 50; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 20; /* smsName */
		messageLen+= 20; /* smsTel */
		messageLen+= 20; /* oldDeptcode */
		messageLen+= 1; /* triTag */
		messageLen+= 1; /* modtag */
		messageLen+= 6; /* zipOrg */
		messageLen+= 100; /* addr1Org */
		messageLen+= 100; /* addr2Org */
		messageLen+= 1; /* addrTag */
		messageLen+= 6; /* sihangZipOrg */
		messageLen+= 100; /* sihangAddr1Org */
		messageLen+= 100; /* sihangAddr2Org */
		messageLen+= 1; /* sihangAddrTag */
		messageLen+= 6; /* modelZipOrg */
		messageLen+= 100; /* modelAddr1Org */
		messageLen+= 100; /* modelAddr2Org */
		messageLen+= 1; /* modelAddrTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("histDate");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("deptName");
	
		fieldNames.add("tel");
	
		fieldNames.add("zip");
	
		fieldNames.add("addr1");
	
		fieldNames.add("addr2");
	
		fieldNames.add("listtag");
	
		fieldNames.add("jobtag");
	
		fieldNames.add("companyCode");
	
		fieldNames.add("amisDeptcode");
	
		fieldNames.add("taxTag");
	
		fieldNames.add("sihangVendor");
	
		fieldNames.add("sihangName");
	
		fieldNames.add("sihangDepyo");
	
		fieldNames.add("sihangUpte");
	
		fieldNames.add("sihangUpjong");
	
		fieldNames.add("sihangZip");
	
		fieldNames.add("sihangAddr1");
	
		fieldNames.add("sihangAddr2");
	
		fieldNames.add("sigongName");
	
		fieldNames.add("sigongDepyo");
	
		fieldNames.add("sigongCharge");
	
		fieldNames.add("sigongTel");
	
		fieldNames.add("modelZip");
	
		fieldNames.add("modelAddr1");
	
		fieldNames.add("modelAddr2");
	
		fieldNames.add("modelTel");
	
		fieldNames.add("deptTypeCode");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("smsName");
	
		fieldNames.add("smsTel");
	
		fieldNames.add("oldDeptcode");
	
		fieldNames.add("triTag");
	
		fieldNames.add("modtag");
	
		fieldNames.add("zipOrg");
	
		fieldNames.add("addr1Org");
	
		fieldNames.add("addr2Org");
	
		fieldNames.add("addrTag");
	
		fieldNames.add("sihangZipOrg");
	
		fieldNames.add("sihangAddr1Org");
	
		fieldNames.add("sihangAddr2Org");
	
		fieldNames.add("sihangAddrTag");
	
		fieldNames.add("modelZipOrg");
	
		fieldNames.add("modelAddr1Org");
	
		fieldNames.add("modelAddr2Org");
	
		fieldNames.add("modelAddrTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("histDate", get("histDate"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("deptName", get("deptName"));
	
		fieldValueMap.put("tel", get("tel"));
	
		fieldValueMap.put("zip", get("zip"));
	
		fieldValueMap.put("addr1", get("addr1"));
	
		fieldValueMap.put("addr2", get("addr2"));
	
		fieldValueMap.put("listtag", get("listtag"));
	
		fieldValueMap.put("jobtag", get("jobtag"));
	
		fieldValueMap.put("companyCode", get("companyCode"));
	
		fieldValueMap.put("amisDeptcode", get("amisDeptcode"));
	
		fieldValueMap.put("taxTag", get("taxTag"));
	
		fieldValueMap.put("sihangVendor", get("sihangVendor"));
	
		fieldValueMap.put("sihangName", get("sihangName"));
	
		fieldValueMap.put("sihangDepyo", get("sihangDepyo"));
	
		fieldValueMap.put("sihangUpte", get("sihangUpte"));
	
		fieldValueMap.put("sihangUpjong", get("sihangUpjong"));
	
		fieldValueMap.put("sihangZip", get("sihangZip"));
	
		fieldValueMap.put("sihangAddr1", get("sihangAddr1"));
	
		fieldValueMap.put("sihangAddr2", get("sihangAddr2"));
	
		fieldValueMap.put("sigongName", get("sigongName"));
	
		fieldValueMap.put("sigongDepyo", get("sigongDepyo"));
	
		fieldValueMap.put("sigongCharge", get("sigongCharge"));
	
		fieldValueMap.put("sigongTel", get("sigongTel"));
	
		fieldValueMap.put("modelZip", get("modelZip"));
	
		fieldValueMap.put("modelAddr1", get("modelAddr1"));
	
		fieldValueMap.put("modelAddr2", get("modelAddr2"));
	
		fieldValueMap.put("modelTel", get("modelTel"));
	
		fieldValueMap.put("deptTypeCode", get("deptTypeCode"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("smsName", get("smsName"));
	
		fieldValueMap.put("smsTel", get("smsTel"));
	
		fieldValueMap.put("oldDeptcode", get("oldDeptcode"));
	
		fieldValueMap.put("triTag", get("triTag"));
	
		fieldValueMap.put("modtag", get("modtag"));
	
		fieldValueMap.put("zipOrg", get("zipOrg"));
	
		fieldValueMap.put("addr1Org", get("addr1Org"));
	
		fieldValueMap.put("addr2Org", get("addr2Org"));
	
		fieldValueMap.put("addrTag", get("addrTag"));
	
		fieldValueMap.put("sihangZipOrg", get("sihangZipOrg"));
	
		fieldValueMap.put("sihangAddr1Org", get("sihangAddr1Org"));
	
		fieldValueMap.put("sihangAddr2Org", get("sihangAddr2Org"));
	
		fieldValueMap.put("sihangAddrTag", get("sihangAddrTag"));
	
		fieldValueMap.put("modelZipOrg", get("modelZipOrg"));
	
		fieldValueMap.put("modelAddr1Org", get("modelAddr1Org"));
	
		fieldValueMap.put("modelAddr2Org", get("modelAddr2Org"));
	
		fieldValueMap.put("modelAddrTag", get("modelAddrTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			return getHistDate();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case 946946672 : /* deptName */
			return getDeptName();
		case 114715 : /* tel */
			return getTel();
		case 120609 : /* zip */
			return getZip();
		case 92660320 : /* addr1 */
			return getAddr1();
		case 92660321 : /* addr2 */
			return getAddr2();
		case 181985852 : /* listtag */
			return getListtag();
		case -1154732355 : /* jobtag */
			return getJobtag();
		case -508897270 : /* companyCode */
			return getCompanyCode();
		case 1491234344 : /* amisDeptcode */
			return getAmisDeptcode();
		case -880745489 : /* taxTag */
			return getTaxTag();
		case 1984253744 : /* sihangVendor */
			return getSihangVendor();
		case -1924432269 : /* sihangName */
			return getSihangName();
		case 463029373 : /* sihangDepyo */
			return getSihangDepyo();
		case -1924209100 : /* sihangUpte */
			return getSihangUpte();
		case 1965674689 : /* sihangUpjong */
			return getSihangUpjong();
		case 1600501305 : /* sihangZip */
			return getSihangZip();
		case 460217208 : /* sihangAddr1 */
			return getSihangAddr1();
		case 460217209 : /* sihangAddr2 */
			return getSihangAddr2();
		case 167874338 : /* sigongName */
			return getSigongName();
		case 900024750 : /* sigongDepyo */
			return getSigongDepyo();
		case 2104651147 : /* sigongCharge */
			return getSigongCharge();
		case 1113799844 : /* sigongTel */
			return getSigongTel();
		case -619043016 : /* modelZip */
			return getModelZip();
		case 2076870839 : /* modelAddr1 */
			return getModelAddr1();
		case 2076870840 : /* modelAddr2 */
			return getModelAddr2();
		case -619048910 : /* modelTel */
			return getModelTel();
		case -1438264916 : /* deptTypeCode */
			return getDeptTypeCode();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -2082056316 : /* smsName */
			return getSmsName();
		case -898441214 : /* smsTel */
			return getSmsTel();
		case -986317575 : /* oldDeptcode */
			return getOldDeptcode();
		case -865492497 : /* triTag */
			return getTriTag();
		case -1068785320 : /* modtag */
			return getModtag();
		case -701825021 : /* zipOrg */
			return getZipOrg();
		case -1220298652 : /* addr1Org */
			return getAddr1Org();
		case -1220268861 : /* addr2Org */
			return getAddr2Org();
		case -1147708951 : /* addrTag */
			return getAddrTag();
		case 2102503915 : /* sihangZipOrg */
			return getSihangZipOrg();
		case 795314252 : /* sihangAddr1Org */
			return getSihangAddr1Org();
		case 795344043 : /* sihangAddr2Org */
			return getSihangAddr2Org();
		case -112857855 : /* sihangAddrTag */
			return getSihangAddrTag();
		case 679158924 : /* modelZipOrg */
			return getModelZipOrg();
		case -1239621971 : /* modelAddr1Org */
			return getModelAddr1Org();
		case -1239592180 : /* modelAddr2Org */
			return getModelAddr2Org();
		case -1286879616 : /* modelAddrTag */
			return getModelAddrTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			setHistDate((java.lang.String) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case 946946672 : /* deptName */
			setDeptName((java.lang.String) value);
			return;
		case 114715 : /* tel */
			setTel((java.lang.String) value);
			return;
		case 120609 : /* zip */
			setZip((java.lang.String) value);
			return;
		case 92660320 : /* addr1 */
			setAddr1((java.lang.String) value);
			return;
		case 92660321 : /* addr2 */
			setAddr2((java.lang.String) value);
			return;
		case 181985852 : /* listtag */
			setListtag((java.lang.String) value);
			return;
		case -1154732355 : /* jobtag */
			setJobtag((java.lang.String) value);
			return;
		case -508897270 : /* companyCode */
			setCompanyCode((java.lang.String) value);
			return;
		case 1491234344 : /* amisDeptcode */
			setAmisDeptcode((java.lang.String) value);
			return;
		case -880745489 : /* taxTag */
			setTaxTag((java.lang.String) value);
			return;
		case 1984253744 : /* sihangVendor */
			setSihangVendor((java.lang.String) value);
			return;
		case -1924432269 : /* sihangName */
			setSihangName((java.lang.String) value);
			return;
		case 463029373 : /* sihangDepyo */
			setSihangDepyo((java.lang.String) value);
			return;
		case -1924209100 : /* sihangUpte */
			setSihangUpte((java.lang.String) value);
			return;
		case 1965674689 : /* sihangUpjong */
			setSihangUpjong((java.lang.String) value);
			return;
		case 1600501305 : /* sihangZip */
			setSihangZip((java.lang.String) value);
			return;
		case 460217208 : /* sihangAddr1 */
			setSihangAddr1((java.lang.String) value);
			return;
		case 460217209 : /* sihangAddr2 */
			setSihangAddr2((java.lang.String) value);
			return;
		case 167874338 : /* sigongName */
			setSigongName((java.lang.String) value);
			return;
		case 900024750 : /* sigongDepyo */
			setSigongDepyo((java.lang.String) value);
			return;
		case 2104651147 : /* sigongCharge */
			setSigongCharge((java.lang.String) value);
			return;
		case 1113799844 : /* sigongTel */
			setSigongTel((java.lang.String) value);
			return;
		case -619043016 : /* modelZip */
			setModelZip((java.lang.String) value);
			return;
		case 2076870839 : /* modelAddr1 */
			setModelAddr1((java.lang.String) value);
			return;
		case 2076870840 : /* modelAddr2 */
			setModelAddr2((java.lang.String) value);
			return;
		case -619048910 : /* modelTel */
			setModelTel((java.lang.String) value);
			return;
		case -1438264916 : /* deptTypeCode */
			setDeptTypeCode((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -2082056316 : /* smsName */
			setSmsName((java.lang.String) value);
			return;
		case -898441214 : /* smsTel */
			setSmsTel((java.lang.String) value);
			return;
		case -986317575 : /* oldDeptcode */
			setOldDeptcode((java.lang.String) value);
			return;
		case -865492497 : /* triTag */
			setTriTag((java.lang.String) value);
			return;
		case -1068785320 : /* modtag */
			setModtag((java.lang.String) value);
			return;
		case -701825021 : /* zipOrg */
			setZipOrg((java.lang.String) value);
			return;
		case -1220298652 : /* addr1Org */
			setAddr1Org((java.lang.String) value);
			return;
		case -1220268861 : /* addr2Org */
			setAddr2Org((java.lang.String) value);
			return;
		case -1147708951 : /* addrTag */
			setAddrTag((java.lang.String) value);
			return;
		case 2102503915 : /* sihangZipOrg */
			setSihangZipOrg((java.lang.String) value);
			return;
		case 795314252 : /* sihangAddr1Org */
			setSihangAddr1Org((java.lang.String) value);
			return;
		case 795344043 : /* sihangAddr2Org */
			setSihangAddr2Org((java.lang.String) value);
			return;
		case -112857855 : /* sihangAddrTag */
			setSihangAddrTag((java.lang.String) value);
			return;
		case 679158924 : /* modelZipOrg */
			setModelZipOrg((java.lang.String) value);
			return;
		case -1239621971 : /* modelAddr1Org */
			setModelAddr1Org((java.lang.String) value);
			return;
		case -1239592180 : /* modelAddr2Org */
			setModelAddr2Org((java.lang.String) value);
			return;
		case -1286879616 : /* modelAddrTag */
			setModelAddrTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
