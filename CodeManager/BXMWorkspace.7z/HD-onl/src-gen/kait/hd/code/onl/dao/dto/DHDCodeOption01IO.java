/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_CODE_OPTION
 */
@XmlType(propOrder={"deptCode", "housetag", "optseq", "square", "type", "optionName", "optionSup", "optionVat", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "prtseq"}, name="DHDCodeOption01IO")
@XmlRootElement(name="DHDCodeOption01IO")
@SuppressWarnings("all")
public class DHDCodeOption01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -598636063L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_CODE_OPTION";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012118(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description  [SYS_C0012118(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description  [SYS_C0012118(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012119(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description  [SYS_C0012119(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description  [SYS_C0012119(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optseq >> [[ */
	
	@XmlTransient
	private boolean isSet_optseq = false;
	
	protected boolean isSet_optseq()
	{
		return this.isSet_optseq;
	}
	
	protected void setIsSet_optseq(boolean value)
	{
		this.isSet_optseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description  [SYS_C0012120(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	public void setOptseq(java.lang.String value) {
		isSet_optseq = true;
		this.optseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description  [SYS_C0012120(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	public void setOptseq(double value) {
		isSet_optseq = true;
		this.optseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description  [SYS_C0012120(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	public void setOptseq(long value) {
		isSet_optseq = true;
		this.optseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012120(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal optseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description  [SYS_C0012120(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	public java.math.BigDecimal getOptseq(){
		return optseq;
	}
	
	/**
	 * @Description  [SYS_C0012120(C),SYS_C0012919(P) SYS_C0012919(UNIQUE)]
	 */
	@JsonProperty("optseq")
	public void setOptseq( java.math.BigDecimal optseq ) {
		isSet_optseq = true;
		this.optseq = optseq;
	}
	
	/** Property set << optseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << type >> [[ */
	
	@XmlTransient
	private boolean isSet_type = false;
	
	protected boolean isSet_type()
	{
		return this.isSet_type;
	}
	
	protected void setIsSet_type(boolean value)
	{
		this.isSet_type = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String type  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getType(){
		return type;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("type")
	public void setType( java.lang.String type ) {
		isSet_type = true;
		this.type = type;
	}
	
	/** Property set << type >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optionName >> [[ */
	
	@XmlTransient
	private boolean isSet_optionName = false;
	
	protected boolean isSet_optionName()
	{
		return this.isSet_optionName;
	}
	
	protected void setIsSet_optionName(boolean value)
	{
		this.isSet_optionName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String optionName  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getOptionName(){
		return optionName;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("optionName")
	public void setOptionName( java.lang.String optionName ) {
		isSet_optionName = true;
		this.optionName = optionName;
	}
	
	/** Property set << optionName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optionSup >> [[ */
	
	@XmlTransient
	private boolean isSet_optionSup = false;
	
	protected boolean isSet_optionSup()
	{
		return this.isSet_optionSup;
	}
	
	protected void setIsSet_optionSup(boolean value)
	{
		this.isSet_optionSup = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 
	 */
	public void setOptionSup(java.lang.String value) {
		isSet_optionSup = true;
		this.optionSup = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 
	 */
	public void setOptionSup(double value) {
		isSet_optionSup = true;
		this.optionSup = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 
	 */
	public void setOptionSup(long value) {
		isSet_optionSup = true;
		this.optionSup = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal optionSup  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 
	 */
	public java.math.BigDecimal getOptionSup(){
		return optionSup;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("optionSup")
	public void setOptionSup( java.math.BigDecimal optionSup ) {
		isSet_optionSup = true;
		this.optionSup = optionSup;
	}
	
	/** Property set << optionSup >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optionVat >> [[ */
	
	@XmlTransient
	private boolean isSet_optionVat = false;
	
	protected boolean isSet_optionVat()
	{
		return this.isSet_optionVat;
	}
	
	protected void setIsSet_optionVat(boolean value)
	{
		this.isSet_optionVat = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 
	 */
	public void setOptionVat(java.lang.String value) {
		isSet_optionVat = true;
		this.optionVat = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 
	 */
	public void setOptionVat(double value) {
		isSet_optionVat = true;
		this.optionVat = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 
	 */
	public void setOptionVat(long value) {
		isSet_optionVat = true;
		this.optionVat = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal optionVat  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 
	 */
	public java.math.BigDecimal getOptionVat(){
		return optionVat;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("optionVat")
	public void setOptionVat( java.math.BigDecimal optionVat ) {
		isSet_optionVat = true;
		this.optionVat = optionVat;
	}
	
	/** Property set << optionVat >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=500, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << prtseq >> [[ */
	
	@XmlTransient
	private boolean isSet_prtseq = false;
	
	protected boolean isSet_prtseq()
	{
		return this.isSet_prtseq;
	}
	
	protected void setIsSet_prtseq(boolean value)
	{
		this.isSet_prtseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 
	 */
	public void setPrtseq(java.lang.String value) {
		isSet_prtseq = true;
		this.prtseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 
	 */
	public void setPrtseq(double value) {
		isSet_prtseq = true;
		this.prtseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 
	 */
	public void setPrtseq(long value) {
		isSet_prtseq = true;
		this.prtseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal prtseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 
	 */
	public java.math.BigDecimal getPrtseq(){
		return prtseq;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("prtseq")
	public void setPrtseq( java.math.BigDecimal prtseq ) {
		isSet_prtseq = true;
		this.prtseq = prtseq;
	}
	
	/** Property set << prtseq >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeOption01IO clone(){
		try{
			DHDCodeOption01IO object= (DHDCodeOption01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.optseq== null ) object.optseq = null;
			else{
				object.optseq = new java.math.BigDecimal(optseq.toString());
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.type== null ) object.type = null;
			else{
				object.type = this.type;
			}
			if ( this.optionName== null ) object.optionName = null;
			else{
				object.optionName = this.optionName;
			}
			if ( this.optionSup== null ) object.optionSup = null;
			else{
				object.optionSup = new java.math.BigDecimal(optionSup.toString());
			}
			if ( this.optionVat== null ) object.optionVat = null;
			else{
				object.optionVat = new java.math.BigDecimal(optionVat.toString());
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.prtseq== null ) object.prtseq = null;
			else{
				object.prtseq = new java.math.BigDecimal(prtseq.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((optseq==null)?0:optseq.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((type==null)?0:type.hashCode());
		result = prime * result + ((optionName==null)?0:optionName.hashCode());
		result = prime * result + ((optionSup==null)?0:optionSup.hashCode());
		result = prime * result + ((optionVat==null)?0:optionVat.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((prtseq==null)?0:prtseq.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeOption01IO other = (kait.hd.code.onl.dao.dto.DHDCodeOption01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( optseq == null ){
			if ( other.optseq != null ) return false;
		}
		else if ( !optseq.equals(other.optseq) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( type == null ){
			if ( other.type != null ) return false;
		}
		else if ( !type.equals(other.type) )
			return false;
		if ( optionName == null ){
			if ( other.optionName != null ) return false;
		}
		else if ( !optionName.equals(other.optionName) )
			return false;
		if ( optionSup == null ){
			if ( other.optionSup != null ) return false;
		}
		else if ( !optionSup.equals(other.optionSup) )
			return false;
		if ( optionVat == null ){
			if ( other.optionVat != null ) return false;
		}
		else if ( !optionVat.equals(other.optionVat) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( prtseq == null ){
			if ( other.prtseq != null ) return false;
		}
		else if ( !prtseq.equals(other.prtseq) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeOption01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\toptseq: ");
		sb.append(optseq==null?"null":getOptseq());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttype: ");
		sb.append(type==null?"null":getType());
		sb.append("\n");
		sb.append("\toptionName: ");
		sb.append(optionName==null?"null":getOptionName());
		sb.append("\n");
		sb.append("\toptionSup: ");
		sb.append(optionSup==null?"null":getOptionSup());
		sb.append("\n");
		sb.append("\toptionVat: ");
		sb.append(optionVat==null?"null":getOptionVat());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tprtseq: ");
		sb.append(prtseq==null?"null":getPrtseq());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* optseq */
		messageLen+= 22; /* square */
		messageLen+= 4; /* type */
		messageLen+= 100; /* optionName */
		messageLen+= 22; /* optionSup */
		messageLen+= 22; /* optionVat */
		messageLen+= 500; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* prtseq */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("optseq");
	
		fieldNames.add("square");
	
		fieldNames.add("type");
	
		fieldNames.add("optionName");
	
		fieldNames.add("optionSup");
	
		fieldNames.add("optionVat");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("prtseq");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("optseq", get("optseq"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("type", get("type"));
	
		fieldValueMap.put("optionName", get("optionName"));
	
		fieldValueMap.put("optionSup", get("optionSup"));
	
		fieldValueMap.put("optionVat", get("optionVat"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("prtseq", get("prtseq"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -1010127668 : /* optseq */
			return getOptseq();
		case -894674659 : /* square */
			return getSquare();
		case 3575610 : /* type */
			return getType();
		case 1373385888 : /* optionName */
			return getOptionName();
		case 1845423513 : /* optionSup */
			return getOptionSup();
		case 1845425780 : /* optionVat */
			return getOptionVat();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -979651475 : /* prtseq */
			return getPrtseq();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -1010127668 : /* optseq */
			setOptseq((java.math.BigDecimal) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case 3575610 : /* type */
			setType((java.lang.String) value);
			return;
		case 1373385888 : /* optionName */
			setOptionName((java.lang.String) value);
			return;
		case 1845423513 : /* optionSup */
			setOptionSup((java.math.BigDecimal) value);
			return;
		case 1845425780 : /* optionVat */
			setOptionVat((java.math.BigDecimal) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -979651475 : /* prtseq */
			setPrtseq((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
