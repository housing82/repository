/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.sc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 조회 In
 */
@XmlType(propOrder={"inSHDCODE00102Sub01"}, name="SHDCODE00102In")
@XmlRootElement(name="SHDCODE00102In")
@SuppressWarnings("all")
public class SHDCODE00102In  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1934479796L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 조회 In";

	/*******************************************************************************************************************************
	* Property set << inSHDCODE00102Sub01 >> [[ */
	
	@XmlTransient
	private boolean isSet_inSHDCODE00102Sub01 = false;
	
	protected boolean isSet_inSHDCODE00102Sub01()
	{
		return this.isSet_inSHDCODE00102Sub01;
	}
	
	protected void setIsSet_inSHDCODE00102Sub01(boolean value)
	{
		this.isSet_inSHDCODE00102Sub01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.SHDCODE00102Sub01 inSHDCODE00102Sub01  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.sc.dto.SHDCODE00102Sub01 getInSHDCODE00102Sub01(){
		return inSHDCODE00102Sub01;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inSHDCODE00102Sub01")
	public void setInSHDCODE00102Sub01( kait.hd.code.onl.sc.dto.SHDCODE00102Sub01 inSHDCODE00102Sub01 ) {
		isSet_inSHDCODE00102Sub01 = true;
		this.inSHDCODE00102Sub01 = inSHDCODE00102Sub01;
	}
	
	/** Property set << inSHDCODE00102Sub01 >> ]]
	*******************************************************************************************************************************/

	@Override
	public SHDCODE00102In clone(){
		try{
			SHDCODE00102In object= (SHDCODE00102In)super.clone();
			if ( this.inSHDCODE00102Sub01== null ) object.inSHDCODE00102Sub01 = null;
			else{
				object.inSHDCODE00102Sub01 = (kait.hd.code.onl.sc.dto.SHDCODE00102Sub01)this.inSHDCODE00102Sub01.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((inSHDCODE00102Sub01==null)?0:inSHDCODE00102Sub01.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.sc.dto.SHDCODE00102In other = (kait.hd.code.onl.sc.dto.SHDCODE00102In)obj;
		if ( inSHDCODE00102Sub01 == null ){
			if ( other.inSHDCODE00102Sub01 != null ) return false;
		}
		else if ( !inSHDCODE00102Sub01.equals(other.inSHDCODE00102Sub01) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.sc.dto.SHDCODE00102In:\n");
		sb.append("\tinSHDCODE00102Sub01: ");
		sb.append(inSHDCODE00102Sub01==null?"null":getInSHDCODE00102Sub01());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		if ( inSHDCODE00102Sub01 != null && !(inSHDCODE00102Sub01 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.SHDCODE00102Sub01 temp= inSHDCODE00102Sub01;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.SHDCODE00102Sub01();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inSHDCODE00102Sub01 */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("inSHDCODE00102Sub01");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("inSHDCODE00102Sub01", get("inSHDCODE00102Sub01"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -298120827 : /* inSHDCODE00102Sub01 */
			return getInSHDCODE00102Sub01();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -298120827 : /* inSHDCODE00102Sub01 */
			setInSHDCODE00102Sub01((kait.hd.code.onl.sc.dto.SHDCODE00102Sub01) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
