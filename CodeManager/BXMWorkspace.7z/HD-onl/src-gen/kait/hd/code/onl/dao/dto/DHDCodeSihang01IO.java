/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_코드_시행사 ( HD_CODE_SIHANG )
 */
@XmlType(propOrder={"deptCode", "seq", "sihangVendor", "sihangDepyo", "sihangUpte", "sihangUpjong", "sihangZip", "sihangAddr1", "sihangAddr2", "inputDutyId", "inputDate", "chgDutyId", "sihangName", "chgDate", "sihangZipOrg", "sihangAddr1Org", "sihangAddr2Org", "sihangAddrTag"}, name="DHDCodeSihang01IO")
@XmlRootElement(name="DHDCodeSihang01IO")
@SuppressWarnings("all")
public class DHDCodeSihang01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 398513076L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_코드_시행사 ( HD_CODE_SIHANG )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012121(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012121(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012121(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012122(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012122(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012122(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012122(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012122(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012122(C),SYS_C0012920(P) SYS_C0012920(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangVendor >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangVendor = false;
	
	protected boolean isSet_sihangVendor()
	{
		return this.isSet_sihangVendor;
	}
	
	protected void setIsSet_sihangVendor(boolean value)
	{
		this.isSet_sihangVendor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사사업자코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangVendor  = null;
	
	/**
	 * @Description 시행사사업자코드
	 */
	public java.lang.String getSihangVendor(){
		return sihangVendor;
	}
	
	/**
	 * @Description 시행사사업자코드
	 */
	@JsonProperty("sihangVendor")
	public void setSihangVendor( java.lang.String sihangVendor ) {
		isSet_sihangVendor = true;
		this.sihangVendor = sihangVendor;
	}
	
	/** Property set << sihangVendor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangDepyo >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangDepyo = false;
	
	protected boolean isSet_sihangDepyo()
	{
		return this.isSet_sihangDepyo;
	}
	
	protected void setIsSet_sihangDepyo(boolean value)
	{
		this.isSet_sihangDepyo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사대표자명", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangDepyo  = null;
	
	/**
	 * @Description 시행사대표자명
	 */
	public java.lang.String getSihangDepyo(){
		return sihangDepyo;
	}
	
	/**
	 * @Description 시행사대표자명
	 */
	@JsonProperty("sihangDepyo")
	public void setSihangDepyo( java.lang.String sihangDepyo ) {
		isSet_sihangDepyo = true;
		this.sihangDepyo = sihangDepyo;
	}
	
	/** Property set << sihangDepyo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangUpte >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangUpte = false;
	
	protected boolean isSet_sihangUpte()
	{
		return this.isSet_sihangUpte;
	}
	
	protected void setIsSet_sihangUpte(boolean value)
	{
		this.isSet_sihangUpte = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사업태", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangUpte  = null;
	
	/**
	 * @Description 시행사업태
	 */
	public java.lang.String getSihangUpte(){
		return sihangUpte;
	}
	
	/**
	 * @Description 시행사업태
	 */
	@JsonProperty("sihangUpte")
	public void setSihangUpte( java.lang.String sihangUpte ) {
		isSet_sihangUpte = true;
		this.sihangUpte = sihangUpte;
	}
	
	/** Property set << sihangUpte >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangUpjong >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangUpjong = false;
	
	protected boolean isSet_sihangUpjong()
	{
		return this.isSet_sihangUpjong;
	}
	
	protected void setIsSet_sihangUpjong(boolean value)
	{
		this.isSet_sihangUpjong = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사업종", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangUpjong  = null;
	
	/**
	 * @Description 시행사업종
	 */
	public java.lang.String getSihangUpjong(){
		return sihangUpjong;
	}
	
	/**
	 * @Description 시행사업종
	 */
	@JsonProperty("sihangUpjong")
	public void setSihangUpjong( java.lang.String sihangUpjong ) {
		isSet_sihangUpjong = true;
		this.sihangUpjong = sihangUpjong;
	}
	
	/** Property set << sihangUpjong >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangZip >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangZip = false;
	
	protected boolean isSet_sihangZip()
	{
		return this.isSet_sihangZip;
	}
	
	protected void setIsSet_sihangZip(boolean value)
	{
		this.isSet_sihangZip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사우편번호", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangZip  = null;
	
	/**
	 * @Description 시행사우편번호
	 */
	public java.lang.String getSihangZip(){
		return sihangZip;
	}
	
	/**
	 * @Description 시행사우편번호
	 */
	@JsonProperty("sihangZip")
	public void setSihangZip( java.lang.String sihangZip ) {
		isSet_sihangZip = true;
		this.sihangZip = sihangZip;
	}
	
	/** Property set << sihangZip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr1 = false;
	
	protected boolean isSet_sihangAddr1()
	{
		return this.isSet_sihangAddr1;
	}
	
	protected void setIsSet_sihangAddr1(boolean value)
	{
		this.isSet_sihangAddr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소1", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr1  = null;
	
	/**
	 * @Description 시행사주소1
	 */
	public java.lang.String getSihangAddr1(){
		return sihangAddr1;
	}
	
	/**
	 * @Description 시행사주소1
	 */
	@JsonProperty("sihangAddr1")
	public void setSihangAddr1( java.lang.String sihangAddr1 ) {
		isSet_sihangAddr1 = true;
		this.sihangAddr1 = sihangAddr1;
	}
	
	/** Property set << sihangAddr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr2 = false;
	
	protected boolean isSet_sihangAddr2()
	{
		return this.isSet_sihangAddr2;
	}
	
	protected void setIsSet_sihangAddr2(boolean value)
	{
		this.isSet_sihangAddr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소2", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr2  = null;
	
	/**
	 * @Description 시행사주소2
	 */
	public java.lang.String getSihangAddr2(){
		return sihangAddr2;
	}
	
	/**
	 * @Description 시행사주소2
	 */
	@JsonProperty("sihangAddr2")
	public void setSihangAddr2( java.lang.String sihangAddr2 ) {
		isSet_sihangAddr2 = true;
		this.sihangAddr2 = sihangAddr2;
	}
	
	/** Property set << sihangAddr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangName >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangName = false;
	
	protected boolean isSet_sihangName()
	{
		return this.isSet_sihangName;
	}
	
	protected void setIsSet_sihangName(boolean value)
	{
		this.isSet_sihangName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사상호명", formatType="", format="", align="left", length=60, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangName  = null;
	
	/**
	 * @Description 시행사상호명
	 */
	public java.lang.String getSihangName(){
		return sihangName;
	}
	
	/**
	 * @Description 시행사상호명
	 */
	@JsonProperty("sihangName")
	public void setSihangName( java.lang.String sihangName ) {
		isSet_sihangName = true;
		this.sihangName = sihangName;
	}
	
	/** Property set << sihangName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangZipOrg >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangZipOrg = false;
	
	protected boolean isSet_sihangZipOrg()
	{
		return this.isSet_sihangZipOrg;
	}
	
	protected void setIsSet_sihangZipOrg(boolean value)
	{
		this.isSet_sihangZipOrg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사우편번호_지번", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangZipOrg  = null;
	
	/**
	 * @Description 시행사우편번호_지번
	 */
	public java.lang.String getSihangZipOrg(){
		return sihangZipOrg;
	}
	
	/**
	 * @Description 시행사우편번호_지번
	 */
	@JsonProperty("sihangZipOrg")
	public void setSihangZipOrg( java.lang.String sihangZipOrg ) {
		isSet_sihangZipOrg = true;
		this.sihangZipOrg = sihangZipOrg;
	}
	
	/** Property set << sihangZipOrg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr1Org >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr1Org = false;
	
	protected boolean isSet_sihangAddr1Org()
	{
		return this.isSet_sihangAddr1Org;
	}
	
	protected void setIsSet_sihangAddr1Org(boolean value)
	{
		this.isSet_sihangAddr1Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소1_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr1Org  = null;
	
	/**
	 * @Description 시행사주소1_지번
	 */
	public java.lang.String getSihangAddr1Org(){
		return sihangAddr1Org;
	}
	
	/**
	 * @Description 시행사주소1_지번
	 */
	@JsonProperty("sihangAddr1Org")
	public void setSihangAddr1Org( java.lang.String sihangAddr1Org ) {
		isSet_sihangAddr1Org = true;
		this.sihangAddr1Org = sihangAddr1Org;
	}
	
	/** Property set << sihangAddr1Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddr2Org >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddr2Org = false;
	
	protected boolean isSet_sihangAddr2Org()
	{
		return this.isSet_sihangAddr2Org;
	}
	
	protected void setIsSet_sihangAddr2Org(boolean value)
	{
		this.isSet_sihangAddr2Org = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소2_지번", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddr2Org  = null;
	
	/**
	 * @Description 시행사주소2_지번
	 */
	public java.lang.String getSihangAddr2Org(){
		return sihangAddr2Org;
	}
	
	/**
	 * @Description 시행사주소2_지번
	 */
	@JsonProperty("sihangAddr2Org")
	public void setSihangAddr2Org( java.lang.String sihangAddr2Org ) {
		isSet_sihangAddr2Org = true;
		this.sihangAddr2Org = sihangAddr2Org;
	}
	
	/** Property set << sihangAddr2Org >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sihangAddrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_sihangAddrTag = false;
	
	protected boolean isSet_sihangAddrTag()
	{
		return this.isSet_sihangAddrTag;
	}
	
	protected void setIsSet_sihangAddrTag(boolean value)
	{
		this.isSet_sihangAddrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시행사주소_구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String sihangAddrTag  = null;
	
	/**
	 * @Description 시행사주소_구분
	 */
	public java.lang.String getSihangAddrTag(){
		return sihangAddrTag;
	}
	
	/**
	 * @Description 시행사주소_구분
	 */
	@JsonProperty("sihangAddrTag")
	public void setSihangAddrTag( java.lang.String sihangAddrTag ) {
		isSet_sihangAddrTag = true;
		this.sihangAddrTag = sihangAddrTag;
	}
	
	/** Property set << sihangAddrTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeSihang01IO clone(){
		try{
			DHDCodeSihang01IO object= (DHDCodeSihang01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.sihangVendor== null ) object.sihangVendor = null;
			else{
				object.sihangVendor = this.sihangVendor;
			}
			if ( this.sihangDepyo== null ) object.sihangDepyo = null;
			else{
				object.sihangDepyo = this.sihangDepyo;
			}
			if ( this.sihangUpte== null ) object.sihangUpte = null;
			else{
				object.sihangUpte = this.sihangUpte;
			}
			if ( this.sihangUpjong== null ) object.sihangUpjong = null;
			else{
				object.sihangUpjong = this.sihangUpjong;
			}
			if ( this.sihangZip== null ) object.sihangZip = null;
			else{
				object.sihangZip = this.sihangZip;
			}
			if ( this.sihangAddr1== null ) object.sihangAddr1 = null;
			else{
				object.sihangAddr1 = this.sihangAddr1;
			}
			if ( this.sihangAddr2== null ) object.sihangAddr2 = null;
			else{
				object.sihangAddr2 = this.sihangAddr2;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.sihangName== null ) object.sihangName = null;
			else{
				object.sihangName = this.sihangName;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.sihangZipOrg== null ) object.sihangZipOrg = null;
			else{
				object.sihangZipOrg = this.sihangZipOrg;
			}
			if ( this.sihangAddr1Org== null ) object.sihangAddr1Org = null;
			else{
				object.sihangAddr1Org = this.sihangAddr1Org;
			}
			if ( this.sihangAddr2Org== null ) object.sihangAddr2Org = null;
			else{
				object.sihangAddr2Org = this.sihangAddr2Org;
			}
			if ( this.sihangAddrTag== null ) object.sihangAddrTag = null;
			else{
				object.sihangAddrTag = this.sihangAddrTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((sihangVendor==null)?0:sihangVendor.hashCode());
		result = prime * result + ((sihangDepyo==null)?0:sihangDepyo.hashCode());
		result = prime * result + ((sihangUpte==null)?0:sihangUpte.hashCode());
		result = prime * result + ((sihangUpjong==null)?0:sihangUpjong.hashCode());
		result = prime * result + ((sihangZip==null)?0:sihangZip.hashCode());
		result = prime * result + ((sihangAddr1==null)?0:sihangAddr1.hashCode());
		result = prime * result + ((sihangAddr2==null)?0:sihangAddr2.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((sihangName==null)?0:sihangName.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((sihangZipOrg==null)?0:sihangZipOrg.hashCode());
		result = prime * result + ((sihangAddr1Org==null)?0:sihangAddr1Org.hashCode());
		result = prime * result + ((sihangAddr2Org==null)?0:sihangAddr2Org.hashCode());
		result = prime * result + ((sihangAddrTag==null)?0:sihangAddrTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeSihang01IO other = (kait.hd.code.onl.dao.dto.DHDCodeSihang01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( sihangVendor == null ){
			if ( other.sihangVendor != null ) return false;
		}
		else if ( !sihangVendor.equals(other.sihangVendor) )
			return false;
		if ( sihangDepyo == null ){
			if ( other.sihangDepyo != null ) return false;
		}
		else if ( !sihangDepyo.equals(other.sihangDepyo) )
			return false;
		if ( sihangUpte == null ){
			if ( other.sihangUpte != null ) return false;
		}
		else if ( !sihangUpte.equals(other.sihangUpte) )
			return false;
		if ( sihangUpjong == null ){
			if ( other.sihangUpjong != null ) return false;
		}
		else if ( !sihangUpjong.equals(other.sihangUpjong) )
			return false;
		if ( sihangZip == null ){
			if ( other.sihangZip != null ) return false;
		}
		else if ( !sihangZip.equals(other.sihangZip) )
			return false;
		if ( sihangAddr1 == null ){
			if ( other.sihangAddr1 != null ) return false;
		}
		else if ( !sihangAddr1.equals(other.sihangAddr1) )
			return false;
		if ( sihangAddr2 == null ){
			if ( other.sihangAddr2 != null ) return false;
		}
		else if ( !sihangAddr2.equals(other.sihangAddr2) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( sihangName == null ){
			if ( other.sihangName != null ) return false;
		}
		else if ( !sihangName.equals(other.sihangName) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( sihangZipOrg == null ){
			if ( other.sihangZipOrg != null ) return false;
		}
		else if ( !sihangZipOrg.equals(other.sihangZipOrg) )
			return false;
		if ( sihangAddr1Org == null ){
			if ( other.sihangAddr1Org != null ) return false;
		}
		else if ( !sihangAddr1Org.equals(other.sihangAddr1Org) )
			return false;
		if ( sihangAddr2Org == null ){
			if ( other.sihangAddr2Org != null ) return false;
		}
		else if ( !sihangAddr2Org.equals(other.sihangAddr2Org) )
			return false;
		if ( sihangAddrTag == null ){
			if ( other.sihangAddrTag != null ) return false;
		}
		else if ( !sihangAddrTag.equals(other.sihangAddrTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeSihang01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tsihangVendor: ");
		sb.append(sihangVendor==null?"null":getSihangVendor());
		sb.append("\n");
		sb.append("\tsihangDepyo: ");
		sb.append(sihangDepyo==null?"null":getSihangDepyo());
		sb.append("\n");
		sb.append("\tsihangUpte: ");
		sb.append(sihangUpte==null?"null":getSihangUpte());
		sb.append("\n");
		sb.append("\tsihangUpjong: ");
		sb.append(sihangUpjong==null?"null":getSihangUpjong());
		sb.append("\n");
		sb.append("\tsihangZip: ");
		sb.append(sihangZip==null?"null":getSihangZip());
		sb.append("\n");
		sb.append("\tsihangAddr1: ");
		sb.append(sihangAddr1==null?"null":getSihangAddr1());
		sb.append("\n");
		sb.append("\tsihangAddr2: ");
		sb.append(sihangAddr2==null?"null":getSihangAddr2());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tsihangName: ");
		sb.append(sihangName==null?"null":getSihangName());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tsihangZipOrg: ");
		sb.append(sihangZipOrg==null?"null":getSihangZipOrg());
		sb.append("\n");
		sb.append("\tsihangAddr1Org: ");
		sb.append(sihangAddr1Org==null?"null":getSihangAddr1Org());
		sb.append("\n");
		sb.append("\tsihangAddr2Org: ");
		sb.append(sihangAddr2Org==null?"null":getSihangAddr2Org());
		sb.append("\n");
		sb.append("\tsihangAddrTag: ");
		sb.append(sihangAddrTag==null?"null":getSihangAddrTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 22; /* seq */
		messageLen+= 20; /* sihangVendor */
		messageLen+= 40; /* sihangDepyo */
		messageLen+= 40; /* sihangUpte */
		messageLen+= 40; /* sihangUpjong */
		messageLen+= 6; /* sihangZip */
		messageLen+= 100; /* sihangAddr1 */
		messageLen+= 100; /* sihangAddr2 */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 60; /* sihangName */
		messageLen+= 14; /* chgDate */
		messageLen+= 6; /* sihangZipOrg */
		messageLen+= 100; /* sihangAddr1Org */
		messageLen+= 100; /* sihangAddr2Org */
		messageLen+= 1; /* sihangAddrTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("sihangVendor");
	
		fieldNames.add("sihangDepyo");
	
		fieldNames.add("sihangUpte");
	
		fieldNames.add("sihangUpjong");
	
		fieldNames.add("sihangZip");
	
		fieldNames.add("sihangAddr1");
	
		fieldNames.add("sihangAddr2");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("sihangName");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("sihangZipOrg");
	
		fieldNames.add("sihangAddr1Org");
	
		fieldNames.add("sihangAddr2Org");
	
		fieldNames.add("sihangAddrTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("sihangVendor", get("sihangVendor"));
	
		fieldValueMap.put("sihangDepyo", get("sihangDepyo"));
	
		fieldValueMap.put("sihangUpte", get("sihangUpte"));
	
		fieldValueMap.put("sihangUpjong", get("sihangUpjong"));
	
		fieldValueMap.put("sihangZip", get("sihangZip"));
	
		fieldValueMap.put("sihangAddr1", get("sihangAddr1"));
	
		fieldValueMap.put("sihangAddr2", get("sihangAddr2"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("sihangName", get("sihangName"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("sihangZipOrg", get("sihangZipOrg"));
	
		fieldValueMap.put("sihangAddr1Org", get("sihangAddr1Org"));
	
		fieldValueMap.put("sihangAddr2Org", get("sihangAddr2Org"));
	
		fieldValueMap.put("sihangAddrTag", get("sihangAddrTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case 113759 : /* seq */
			return getSeq();
		case 1984253744 : /* sihangVendor */
			return getSihangVendor();
		case 463029373 : /* sihangDepyo */
			return getSihangDepyo();
		case -1924209100 : /* sihangUpte */
			return getSihangUpte();
		case 1965674689 : /* sihangUpjong */
			return getSihangUpjong();
		case 1600501305 : /* sihangZip */
			return getSihangZip();
		case 460217208 : /* sihangAddr1 */
			return getSihangAddr1();
		case 460217209 : /* sihangAddr2 */
			return getSihangAddr2();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case -1924432269 : /* sihangName */
			return getSihangName();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 2102503915 : /* sihangZipOrg */
			return getSihangZipOrg();
		case 795314252 : /* sihangAddr1Org */
			return getSihangAddr1Org();
		case 795344043 : /* sihangAddr2Org */
			return getSihangAddr2Org();
		case -112857855 : /* sihangAddrTag */
			return getSihangAddrTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1984253744 : /* sihangVendor */
			setSihangVendor((java.lang.String) value);
			return;
		case 463029373 : /* sihangDepyo */
			setSihangDepyo((java.lang.String) value);
			return;
		case -1924209100 : /* sihangUpte */
			setSihangUpte((java.lang.String) value);
			return;
		case 1965674689 : /* sihangUpjong */
			setSihangUpjong((java.lang.String) value);
			return;
		case 1600501305 : /* sihangZip */
			setSihangZip((java.lang.String) value);
			return;
		case 460217208 : /* sihangAddr1 */
			setSihangAddr1((java.lang.String) value);
			return;
		case 460217209 : /* sihangAddr2 */
			setSihangAddr2((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case -1924432269 : /* sihangName */
			setSihangName((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 2102503915 : /* sihangZipOrg */
			setSihangZipOrg((java.lang.String) value);
			return;
		case 795314252 : /* sihangAddr1Org */
			setSihangAddr1Org((java.lang.String) value);
			return;
		case 795344043 : /* sihangAddr2Org */
			setSihangAddr2Org((java.lang.String) value);
			return;
		case -112857855 : /* sihangAddrTag */
			setSihangAddrTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
