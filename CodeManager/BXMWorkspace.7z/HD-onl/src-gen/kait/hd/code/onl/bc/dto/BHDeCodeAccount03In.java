/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 저장 In
 */
@XmlType(propOrder={"inDeleteDHDCodeAgency01IOCnt", "inDeleteDHDCodeAgency01IOList", "inUpdateDHDCodeAgency01IOCnt", "inUpdateDHDCodeAgency01IOList", "insertDHDCodeAcnt01IOCnt", "insertDHDCodeAcnt01IOList", "inDHDCodeAcnt01IO", "inDHDCodeAgency01IO"}, name="BHDeCodeAccount03In")
@XmlRootElement(name="BHDeCodeAccount03In")
@SuppressWarnings("all")
public class BHDeCodeAccount03In  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -163220414L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 저장 In";

	/*******************************************************************************************************************************
	* Property set << inDeleteDHDCodeAgency01IOCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_inDeleteDHDCodeAgency01IOCnt = false;
	
	protected boolean isSet_inDeleteDHDCodeAgency01IOCnt()
	{
		return this.isSet_inDeleteDHDCodeAgency01IOCnt;
	}
	
	protected void setIsSet_inDeleteDHDCodeAgency01IOCnt(boolean value)
	{
		this.isSet_inDeleteDHDCodeAgency01IOCnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY ) 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer inDeleteDHDCodeAgency01IOCnt  = 0;
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY ) 건수
	 */
	public java.lang.Integer getInDeleteDHDCodeAgency01IOCnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_inDeleteDHDCodeAgency01IOCnt )	return inDeleteDHDCodeAgency01IOCnt;
		else
		{
			if ( inDeleteDHDCodeAgency01IOList == null || inDeleteDHDCodeAgency01IOList.size() == 0 ) return 0;
			else return inDeleteDHDCodeAgency01IOList.size();
		}
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY ) 건수
	 */
	@JsonProperty("inDeleteDHDCodeAgency01IOCnt")
	public void setInDeleteDHDCodeAgency01IOCnt( java.lang.Integer inDeleteDHDCodeAgency01IOCnt ) {
		isSet_inDeleteDHDCodeAgency01IOCnt = true;
		this.inDeleteDHDCodeAgency01IOCnt = inDeleteDHDCodeAgency01IOCnt;
	}
	
	/** Property set << inDeleteDHDCodeAgency01IOCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDeleteDHDCodeAgency01IOList >> [[ */
	
	@XmlTransient
	private boolean isSet_inDeleteDHDCodeAgency01IOList = false;
	
	protected boolean isSet_inDeleteDHDCodeAgency01IOList()
	{
		return this.isSet_inDeleteDHDCodeAgency01IOList;
	}
	
	protected void setIsSet_inDeleteDHDCodeAgency01IOList(boolean value)
	{
		this.isSet_inDeleteDHDCodeAgency01IOList = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="inDeleteDHDCodeAgency01IOCnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> inDeleteDHDCodeAgency01IOList  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>();
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>  getInDeleteDHDCodeAgency01IOList(){
		return inDeleteDHDCodeAgency01IOList;
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	@JsonProperty("inDeleteDHDCodeAgency01IOList")
	public void setInDeleteDHDCodeAgency01IOList( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> inDeleteDHDCodeAgency01IOList ) {
		isSet_inDeleteDHDCodeAgency01IOList = true;
		this.inDeleteDHDCodeAgency01IOList = inDeleteDHDCodeAgency01IOList;
	}
	
	/** Property set << inDeleteDHDCodeAgency01IOList >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inUpdateDHDCodeAgency01IOCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_inUpdateDHDCodeAgency01IOCnt = false;
	
	protected boolean isSet_inUpdateDHDCodeAgency01IOCnt()
	{
		return this.isSet_inUpdateDHDCodeAgency01IOCnt;
	}
	
	protected void setIsSet_inUpdateDHDCodeAgency01IOCnt(boolean value)
	{
		this.isSet_inUpdateDHDCodeAgency01IOCnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY ) 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer inUpdateDHDCodeAgency01IOCnt  = 0;
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY ) 건수
	 */
	public java.lang.Integer getInUpdateDHDCodeAgency01IOCnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_inUpdateDHDCodeAgency01IOCnt )	return inUpdateDHDCodeAgency01IOCnt;
		else
		{
			if ( inUpdateDHDCodeAgency01IOList == null || inUpdateDHDCodeAgency01IOList.size() == 0 ) return 0;
			else return inUpdateDHDCodeAgency01IOList.size();
		}
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY ) 건수
	 */
	@JsonProperty("inUpdateDHDCodeAgency01IOCnt")
	public void setInUpdateDHDCodeAgency01IOCnt( java.lang.Integer inUpdateDHDCodeAgency01IOCnt ) {
		isSet_inUpdateDHDCodeAgency01IOCnt = true;
		this.inUpdateDHDCodeAgency01IOCnt = inUpdateDHDCodeAgency01IOCnt;
	}
	
	/** Property set << inUpdateDHDCodeAgency01IOCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inUpdateDHDCodeAgency01IOList >> [[ */
	
	@XmlTransient
	private boolean isSet_inUpdateDHDCodeAgency01IOList = false;
	
	protected boolean isSet_inUpdateDHDCodeAgency01IOList()
	{
		return this.isSet_inUpdateDHDCodeAgency01IOList;
	}
	
	protected void setIsSet_inUpdateDHDCodeAgency01IOList(boolean value)
	{
		this.isSet_inUpdateDHDCodeAgency01IOList = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="inUpdateDHDCodeAgency01IOCnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> inUpdateDHDCodeAgency01IOList  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>();
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>  getInUpdateDHDCodeAgency01IOList(){
		return inUpdateDHDCodeAgency01IOList;
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	@JsonProperty("inUpdateDHDCodeAgency01IOList")
	public void setInUpdateDHDCodeAgency01IOList( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> inUpdateDHDCodeAgency01IOList ) {
		isSet_inUpdateDHDCodeAgency01IOList = true;
		this.inUpdateDHDCodeAgency01IOList = inUpdateDHDCodeAgency01IOList;
	}
	
	/** Property set << inUpdateDHDCodeAgency01IOList >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << insertDHDCodeAcnt01IOCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_insertDHDCodeAcnt01IOCnt = false;
	
	protected boolean isSet_insertDHDCodeAcnt01IOCnt()
	{
		return this.isSet_insertDHDCodeAcnt01IOCnt;
	}
	
	protected void setIsSet_insertDHDCodeAcnt01IOCnt(boolean value)
	{
		this.isSet_insertDHDCodeAcnt01IOCnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT ) 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer insertDHDCodeAcnt01IOCnt  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT ) 건수
	 */
	public java.lang.Integer getInsertDHDCodeAcnt01IOCnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_insertDHDCodeAcnt01IOCnt )	return insertDHDCodeAcnt01IOCnt;
		else
		{
			if ( insertDHDCodeAcnt01IOList == null || insertDHDCodeAcnt01IOList.size() == 0 ) return 0;
			else return insertDHDCodeAcnt01IOList.size();
		}
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT ) 건수
	 */
	@JsonProperty("insertDHDCodeAcnt01IOCnt")
	public void setInsertDHDCodeAcnt01IOCnt( java.lang.Integer insertDHDCodeAcnt01IOCnt ) {
		isSet_insertDHDCodeAcnt01IOCnt = true;
		this.insertDHDCodeAcnt01IOCnt = insertDHDCodeAcnt01IOCnt;
	}
	
	/** Property set << insertDHDCodeAcnt01IOCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << insertDHDCodeAcnt01IOList >> [[ */
	
	@XmlTransient
	private boolean isSet_insertDHDCodeAcnt01IOList = false;
	
	protected boolean isSet_insertDHDCodeAcnt01IOList()
	{
		return this.isSet_insertDHDCodeAcnt01IOList;
	}
	
	protected void setIsSet_insertDHDCodeAcnt01IOList(boolean value)
	{
		this.isSet_insertDHDCodeAcnt01IOList = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="insertDHDCodeAcnt01IOCnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> insertDHDCodeAcnt01IOList  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>();
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>  getInsertDHDCodeAcnt01IOList(){
		return insertDHDCodeAcnt01IOList;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("insertDHDCodeAcnt01IOList")
	public void setInsertDHDCodeAcnt01IOList( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> insertDHDCodeAcnt01IOList ) {
		isSet_insertDHDCodeAcnt01IOList = true;
		this.insertDHDCodeAcnt01IOList = insertDHDCodeAcnt01IOList;
	}
	
	/** Property set << insertDHDCodeAcnt01IOList >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDHDCodeAcnt01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDCodeAcnt01IO = false;
	
	protected boolean isSet_inDHDCodeAcnt01IO()
	{
		return this.isSet_inDHDCodeAcnt01IO;
	}
	
	protected void setIsSet_inDHDCodeAcnt01IO(boolean value)
	{
		this.isSet_inDHDCodeAcnt01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getInDHDCodeAcnt01IO(){
		return inDHDCodeAcnt01IO;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inDHDCodeAcnt01IO")
	public void setInDHDCodeAcnt01IO( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO ) {
		isSet_inDHDCodeAcnt01IO = true;
		this.inDHDCodeAcnt01IO = inDHDCodeAcnt01IO;
	}
	
	/** Property set << inDHDCodeAcnt01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDHDCodeAgency01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDCodeAgency01IO = false;
	
	protected boolean isSet_inDHDCodeAgency01IO()
	{
		return this.isSet_inDHDCodeAgency01IO;
	}
	
	protected void setIsSet_inDHDCodeAgency01IO(boolean value)
	{
		this.isSet_inDHDCodeAgency01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAgency01IO inDHDCodeAgency01IO  = null;
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAgency01IO getInDHDCodeAgency01IO(){
		return inDHDCodeAgency01IO;
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	@JsonProperty("inDHDCodeAgency01IO")
	public void setInDHDCodeAgency01IO( kait.hd.code.onl.dao.dto.DHDCodeAgency01IO inDHDCodeAgency01IO ) {
		isSet_inDHDCodeAgency01IO = true;
		this.inDHDCodeAgency01IO = inDHDCodeAgency01IO;
	}
	
	/** Property set << inDHDCodeAgency01IO >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeAccount03In clone(){
		try{
			BHDeCodeAccount03In object= (BHDeCodeAccount03In)super.clone();
			if ( this.inDeleteDHDCodeAgency01IOCnt== null ) object.inDeleteDHDCodeAgency01IOCnt = null;
			else{
				object.inDeleteDHDCodeAgency01IOCnt = this.inDeleteDHDCodeAgency01IOCnt;
			}
			if ( this.inDeleteDHDCodeAgency01IOList== null ) object.inDeleteDHDCodeAgency01IOList = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>(inDeleteDHDCodeAgency01IOList.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAgency01IO item : inDeleteDHDCodeAgency01IOList ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAgency01IO)item.clone());
				}
				object.inDeleteDHDCodeAgency01IOList = clonedList;
			}
			if ( this.inUpdateDHDCodeAgency01IOCnt== null ) object.inUpdateDHDCodeAgency01IOCnt = null;
			else{
				object.inUpdateDHDCodeAgency01IOCnt = this.inUpdateDHDCodeAgency01IOCnt;
			}
			if ( this.inUpdateDHDCodeAgency01IOList== null ) object.inUpdateDHDCodeAgency01IOList = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>(inUpdateDHDCodeAgency01IOList.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAgency01IO item : inUpdateDHDCodeAgency01IOList ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAgency01IO)item.clone());
				}
				object.inUpdateDHDCodeAgency01IOList = clonedList;
			}
			if ( this.insertDHDCodeAcnt01IOCnt== null ) object.insertDHDCodeAcnt01IOCnt = null;
			else{
				object.insertDHDCodeAcnt01IOCnt = this.insertDHDCodeAcnt01IOCnt;
			}
			if ( this.insertDHDCodeAcnt01IOList== null ) object.insertDHDCodeAcnt01IOList = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>(insertDHDCodeAcnt01IOList.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO item : insertDHDCodeAcnt01IOList ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)item.clone());
				}
				object.insertDHDCodeAcnt01IOList = clonedList;
			}
			if ( this.inDHDCodeAcnt01IO== null ) object.inDHDCodeAcnt01IO = null;
			else{
				object.inDHDCodeAcnt01IO = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.inDHDCodeAcnt01IO.clone();
			}
			if ( this.inDHDCodeAgency01IO== null ) object.inDHDCodeAgency01IO = null;
			else{
				object.inDHDCodeAgency01IO = (kait.hd.code.onl.dao.dto.DHDCodeAgency01IO)this.inDHDCodeAgency01IO.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((inDeleteDHDCodeAgency01IOCnt==null)?0:inDeleteDHDCodeAgency01IOCnt.hashCode());
		result = prime * result + ((inDeleteDHDCodeAgency01IOList==null)?0:inDeleteDHDCodeAgency01IOList.hashCode());
		result = prime * result + ((inUpdateDHDCodeAgency01IOCnt==null)?0:inUpdateDHDCodeAgency01IOCnt.hashCode());
		result = prime * result + ((inUpdateDHDCodeAgency01IOList==null)?0:inUpdateDHDCodeAgency01IOList.hashCode());
		result = prime * result + ((insertDHDCodeAcnt01IOCnt==null)?0:insertDHDCodeAcnt01IOCnt.hashCode());
		result = prime * result + ((insertDHDCodeAcnt01IOList==null)?0:insertDHDCodeAcnt01IOList.hashCode());
		result = prime * result + ((inDHDCodeAcnt01IO==null)?0:inDHDCodeAcnt01IO.hashCode());
		result = prime * result + ((inDHDCodeAgency01IO==null)?0:inDHDCodeAgency01IO.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeAccount03In other = (kait.hd.code.onl.bc.dto.BHDeCodeAccount03In)obj;
		if ( inDeleteDHDCodeAgency01IOCnt == null ){
			if ( other.inDeleteDHDCodeAgency01IOCnt != null ) return false;
		}
		else if ( !inDeleteDHDCodeAgency01IOCnt.equals(other.inDeleteDHDCodeAgency01IOCnt) )
			return false;
		if ( inDeleteDHDCodeAgency01IOList == null ){
			if ( other.inDeleteDHDCodeAgency01IOList != null ) return false;
		}
		else if ( !inDeleteDHDCodeAgency01IOList.equals(other.inDeleteDHDCodeAgency01IOList) )
			return false;
		if ( inUpdateDHDCodeAgency01IOCnt == null ){
			if ( other.inUpdateDHDCodeAgency01IOCnt != null ) return false;
		}
		else if ( !inUpdateDHDCodeAgency01IOCnt.equals(other.inUpdateDHDCodeAgency01IOCnt) )
			return false;
		if ( inUpdateDHDCodeAgency01IOList == null ){
			if ( other.inUpdateDHDCodeAgency01IOList != null ) return false;
		}
		else if ( !inUpdateDHDCodeAgency01IOList.equals(other.inUpdateDHDCodeAgency01IOList) )
			return false;
		if ( insertDHDCodeAcnt01IOCnt == null ){
			if ( other.insertDHDCodeAcnt01IOCnt != null ) return false;
		}
		else if ( !insertDHDCodeAcnt01IOCnt.equals(other.insertDHDCodeAcnt01IOCnt) )
			return false;
		if ( insertDHDCodeAcnt01IOList == null ){
			if ( other.insertDHDCodeAcnt01IOList != null ) return false;
		}
		else if ( !insertDHDCodeAcnt01IOList.equals(other.insertDHDCodeAcnt01IOList) )
			return false;
		if ( inDHDCodeAcnt01IO == null ){
			if ( other.inDHDCodeAcnt01IO != null ) return false;
		}
		else if ( !inDHDCodeAcnt01IO.equals(other.inDHDCodeAcnt01IO) )
			return false;
		if ( inDHDCodeAgency01IO == null ){
			if ( other.inDHDCodeAgency01IO != null ) return false;
		}
		else if ( !inDHDCodeAgency01IO.equals(other.inDHDCodeAgency01IO) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeAccount03In:\n");
		sb.append("\tinDeleteDHDCodeAgency01IOCnt: ");
		sb.append(inDeleteDHDCodeAgency01IOCnt==null?"null":getInDeleteDHDCodeAgency01IOCnt());
		sb.append("\n");
		sb.append("\tinDeleteDHDCodeAgency01IOList: ");
		if ( inDeleteDHDCodeAgency01IOList == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(inDeleteDHDCodeAgency01IOList.size());
			sb.append("(items)\n");
	
			int max= (10<inDeleteDHDCodeAgency01IOList.size())?10:inDeleteDHDCodeAgency01IOList.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\tinDeleteDHDCodeAgency01IOList[");
				sb.append(i);
				sb.append("] : ");
				sb.append(inDeleteDHDCodeAgency01IOList.get(i));
				sb.append("\n");
			}
	
			if ( max < inDeleteDHDCodeAgency01IOList.size() ){
				sb.append("\tinDeleteDHDCodeAgency01IOList[.] : ").append("more ").append((inDeleteDHDCodeAgency01IOList.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("\tinUpdateDHDCodeAgency01IOCnt: ");
		sb.append(inUpdateDHDCodeAgency01IOCnt==null?"null":getInUpdateDHDCodeAgency01IOCnt());
		sb.append("\n");
		sb.append("\tinUpdateDHDCodeAgency01IOList: ");
		if ( inUpdateDHDCodeAgency01IOList == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(inUpdateDHDCodeAgency01IOList.size());
			sb.append("(items)\n");
	
			int max= (10<inUpdateDHDCodeAgency01IOList.size())?10:inUpdateDHDCodeAgency01IOList.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\tinUpdateDHDCodeAgency01IOList[");
				sb.append(i);
				sb.append("] : ");
				sb.append(inUpdateDHDCodeAgency01IOList.get(i));
				sb.append("\n");
			}
	
			if ( max < inUpdateDHDCodeAgency01IOList.size() ){
				sb.append("\tinUpdateDHDCodeAgency01IOList[.] : ").append("more ").append((inUpdateDHDCodeAgency01IOList.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("\tinsertDHDCodeAcnt01IOCnt: ");
		sb.append(insertDHDCodeAcnt01IOCnt==null?"null":getInsertDHDCodeAcnt01IOCnt());
		sb.append("\n");
		sb.append("\tinsertDHDCodeAcnt01IOList: ");
		if ( insertDHDCodeAcnt01IOList == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(insertDHDCodeAcnt01IOList.size());
			sb.append("(items)\n");
	
			int max= (10<insertDHDCodeAcnt01IOList.size())?10:insertDHDCodeAcnt01IOList.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\tinsertDHDCodeAcnt01IOList[");
				sb.append(i);
				sb.append("] : ");
				sb.append(insertDHDCodeAcnt01IOList.get(i));
				sb.append("\n");
			}
	
			if ( max < insertDHDCodeAcnt01IOList.size() ){
				sb.append("\tinsertDHDCodeAcnt01IOList[.] : ").append("more ").append((insertDHDCodeAcnt01IOList.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("\tinDHDCodeAcnt01IO: ");
		sb.append(inDHDCodeAcnt01IO==null?"null":getInDHDCodeAcnt01IO());
		sb.append("\n");
		sb.append("\tinDHDCodeAgency01IO: ");
		sb.append(inDHDCodeAgency01IO==null?"null":getInDHDCodeAgency01IO());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 9; /* inDeleteDHDCodeAgency01IOCnt */
		{/*inDeleteDHDCodeAgency01IOList*/
			int size=getInDeleteDHDCodeAgency01IOCnt();
			int count= inDeleteDHDCodeAgency01IOList.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAgency01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAgency01IO element= inDeleteDHDCodeAgency01IOList.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAgency01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
		messageLen+= 9; /* inUpdateDHDCodeAgency01IOCnt */
		{/*inUpdateDHDCodeAgency01IOList*/
			int size=getInUpdateDHDCodeAgency01IOCnt();
			int count= inUpdateDHDCodeAgency01IOList.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAgency01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAgency01IO element= inUpdateDHDCodeAgency01IOList.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAgency01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
		messageLen+= 9; /* insertDHDCodeAcnt01IOCnt */
		{/*insertDHDCodeAcnt01IOList*/
			int size=getInsertDHDCodeAcnt01IOCnt();
			int count= insertDHDCodeAcnt01IOList.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO element= insertDHDCodeAcnt01IOList.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
		if ( inDHDCodeAcnt01IO != null && !(inDHDCodeAcnt01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= inDHDCodeAcnt01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDCodeAcnt01IO */
		}
		if ( inDHDCodeAgency01IO != null && !(inDHDCodeAgency01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAgency01IO temp= inDHDCodeAgency01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAgency01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDCodeAgency01IO */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("inDeleteDHDCodeAgency01IOCnt");
	
		fieldNames.add("inDeleteDHDCodeAgency01IOList");
	
		fieldNames.add("inUpdateDHDCodeAgency01IOCnt");
	
		fieldNames.add("inUpdateDHDCodeAgency01IOList");
	
		fieldNames.add("insertDHDCodeAcnt01IOCnt");
	
		fieldNames.add("insertDHDCodeAcnt01IOList");
	
		fieldNames.add("inDHDCodeAcnt01IO");
	
		fieldNames.add("inDHDCodeAgency01IO");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("inDeleteDHDCodeAgency01IOCnt", get("inDeleteDHDCodeAgency01IOCnt"));
	
		fieldValueMap.put("inDeleteDHDCodeAgency01IOList", get("inDeleteDHDCodeAgency01IOList"));
	
		fieldValueMap.put("inUpdateDHDCodeAgency01IOCnt", get("inUpdateDHDCodeAgency01IOCnt"));
	
		fieldValueMap.put("inUpdateDHDCodeAgency01IOList", get("inUpdateDHDCodeAgency01IOList"));
	
		fieldValueMap.put("insertDHDCodeAcnt01IOCnt", get("insertDHDCodeAcnt01IOCnt"));
	
		fieldValueMap.put("insertDHDCodeAcnt01IOList", get("insertDHDCodeAcnt01IOList"));
	
		fieldValueMap.put("inDHDCodeAcnt01IO", get("inDHDCodeAcnt01IO"));
	
		fieldValueMap.put("inDHDCodeAgency01IO", get("inDHDCodeAgency01IO"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 1433820992 : /* inDeleteDHDCodeAgency01IOCnt */
			return getInDeleteDHDCodeAgency01IOCnt();
		case 1499041191 : /* inDeleteDHDCodeAgency01IOList */
			return getInDeleteDHDCodeAgency01IOList();
		case 438654814 : /* inUpdateDHDCodeAgency01IOCnt */
			return getInUpdateDHDCodeAgency01IOCnt();
		case 713660745 : /* inUpdateDHDCodeAgency01IOList */
			return getInUpdateDHDCodeAgency01IOList();
		case -979321722 : /* insertDHDCodeAcnt01IOCnt */
			return getInsertDHDCodeAcnt01IOCnt();
		case -293938911 : /* insertDHDCodeAcnt01IOList */
			return getInsertDHDCodeAcnt01IOList();
		case -678728201 : /* inDHDCodeAcnt01IO */
			return getInDHDCodeAcnt01IO();
		case -367292396 : /* inDHDCodeAgency01IO */
			return getInDHDCodeAgency01IO();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 1433820992 : /* inDeleteDHDCodeAgency01IOCnt */
			setInDeleteDHDCodeAgency01IOCnt((java.lang.Integer) value);
			return;
		case 1499041191 : /* inDeleteDHDCodeAgency01IOList */
			setInDeleteDHDCodeAgency01IOList((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>) value);
			return;
		case 438654814 : /* inUpdateDHDCodeAgency01IOCnt */
			setInUpdateDHDCodeAgency01IOCnt((java.lang.Integer) value);
			return;
		case 713660745 : /* inUpdateDHDCodeAgency01IOList */
			setInUpdateDHDCodeAgency01IOList((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO>) value);
			return;
		case -979321722 : /* insertDHDCodeAcnt01IOCnt */
			setInsertDHDCodeAcnt01IOCnt((java.lang.Integer) value);
			return;
		case -293938911 : /* insertDHDCodeAcnt01IOList */
			setInsertDHDCodeAcnt01IOList((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>) value);
			return;
		case -678728201 : /* inDHDCodeAcnt01IO */
			setInDHDCodeAcnt01IO((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		case -367292396 : /* inDHDCodeAgency01IO */
			setInDHDCodeAgency01IO((kait.hd.code.onl.dao.dto.DHDCodeAgency01IO) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
