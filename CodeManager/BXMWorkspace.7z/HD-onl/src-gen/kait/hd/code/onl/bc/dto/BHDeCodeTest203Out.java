/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 삭제 Out
 */
@XmlType(propOrder={"outDeleteHdCodeAgency01"}, name="BHDeCodeTest203Out")
@XmlRootElement(name="BHDeCodeTest203Out")
@SuppressWarnings("all")
public class BHDeCodeTest203Out  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -423262018L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 삭제 Out";

	/*******************************************************************************************************************************
	* Property set << outDeleteHdCodeAgency01 >> [[ */
	
	@XmlTransient
	private boolean isSet_outDeleteHdCodeAgency01 = false;
	
	protected boolean isSet_outDeleteHdCodeAgency01()
	{
		return this.isSet_outDeleteHdCodeAgency01;
	}
	
	protected void setIsSet_outDeleteHdCodeAgency01(boolean value)
	{
		this.isSet_outDeleteHdCodeAgency01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 삭제 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outDeleteHdCodeAgency01  = 0;
	
	/**
	 * @Description HD_코드-대행사 삭제 결과
	 */
	public java.lang.Integer getOutDeleteHdCodeAgency01(){
		return outDeleteHdCodeAgency01;
	}
	
	/**
	 * @Description HD_코드-대행사 삭제 결과
	 */
	@JsonProperty("outDeleteHdCodeAgency01")
	public void setOutDeleteHdCodeAgency01( java.lang.Integer outDeleteHdCodeAgency01 ) {
		isSet_outDeleteHdCodeAgency01 = true;
		this.outDeleteHdCodeAgency01 = outDeleteHdCodeAgency01;
	}
	
	/** Property set << outDeleteHdCodeAgency01 >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeTest203Out clone(){
		try{
			BHDeCodeTest203Out object= (BHDeCodeTest203Out)super.clone();
			if ( this.outDeleteHdCodeAgency01== null ) object.outDeleteHdCodeAgency01 = null;
			else{
				object.outDeleteHdCodeAgency01 = this.outDeleteHdCodeAgency01;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((outDeleteHdCodeAgency01==null)?0:outDeleteHdCodeAgency01.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeTest203Out other = (kait.hd.code.onl.bc.dto.BHDeCodeTest203Out)obj;
		if ( outDeleteHdCodeAgency01 == null ){
			if ( other.outDeleteHdCodeAgency01 != null ) return false;
		}
		else if ( !outDeleteHdCodeAgency01.equals(other.outDeleteHdCodeAgency01) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeTest203Out:\n");
		sb.append("\toutDeleteHdCodeAgency01: ");
		sb.append(outDeleteHdCodeAgency01==null?"null":getOutDeleteHdCodeAgency01());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 9; /* outDeleteHdCodeAgency01 */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("outDeleteHdCodeAgency01");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("outDeleteHdCodeAgency01", get("outDeleteHdCodeAgency01"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -55997464 : /* outDeleteHdCodeAgency01 */
			return getOutDeleteHdCodeAgency01();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -55997464 : /* outDeleteHdCodeAgency01 */
			setOutDeleteHdCodeAgency01((java.lang.Integer) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
