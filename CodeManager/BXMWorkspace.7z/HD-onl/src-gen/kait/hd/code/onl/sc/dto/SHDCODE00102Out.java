/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.sc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 조회 Out
 */
@XmlType(propOrder={"bHDeCodeAccount01Out"}, name="SHDCODE00102Out")
@XmlRootElement(name="SHDCODE00102Out")
@SuppressWarnings("all")
public class SHDCODE00102Out  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 160674567L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 조회 Out";

	/*******************************************************************************************************************************
	* Property set << bHDeCodeAccount01Out >> [[ */
	
	@XmlTransient
	private boolean isSet_bHDeCodeAccount01Out = false;
	
	protected boolean isSet_bHDeCodeAccount01Out()
	{
		return this.isSet_bHDeCodeAccount01Out;
	}
	
	protected void setIsSet_bHDeCodeAccount01Out(boolean value)
	{
		this.isSet_bHDeCodeAccount01Out = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양계정 조회 Out", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out bHDeCodeAccount01Out  = null;
	
	/**
	 * @Description 분양계정 조회 Out
	 */
	public kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out getbHDeCodeAccount01Out(){
		return bHDeCodeAccount01Out;
	}
	
	/**
	 * @Description 분양계정 조회 Out
	 */
	@JsonProperty("bHDeCodeAccount01Out")
	public void setbHDeCodeAccount01Out( kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out bHDeCodeAccount01Out ) {
		isSet_bHDeCodeAccount01Out = true;
		this.bHDeCodeAccount01Out = bHDeCodeAccount01Out;
	}
	
	/** Property set << bHDeCodeAccount01Out >> ]]
	*******************************************************************************************************************************/

	@Override
	public SHDCODE00102Out clone(){
		try{
			SHDCODE00102Out object= (SHDCODE00102Out)super.clone();
			if ( this.bHDeCodeAccount01Out== null ) object.bHDeCodeAccount01Out = null;
			else{
				object.bHDeCodeAccount01Out = (kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out)this.bHDeCodeAccount01Out.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((bHDeCodeAccount01Out==null)?0:bHDeCodeAccount01Out.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.sc.dto.SHDCODE00102Out other = (kait.hd.code.onl.sc.dto.SHDCODE00102Out)obj;
		if ( bHDeCodeAccount01Out == null ){
			if ( other.bHDeCodeAccount01Out != null ) return false;
		}
		else if ( !bHDeCodeAccount01Out.equals(other.bHDeCodeAccount01Out) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.sc.dto.SHDCODE00102Out:\n");
		sb.append("\tbHDeCodeAccount01Out: ");
		sb.append(bHDeCodeAccount01Out==null?"null":getbHDeCodeAccount01Out());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		if ( bHDeCodeAccount01Out != null && !(bHDeCodeAccount01Out instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out temp= bHDeCodeAccount01Out;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* bHDeCodeAccount01Out */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("bHDeCodeAccount01Out");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("bHDeCodeAccount01Out", get("bHDeCodeAccount01Out"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 694988660 : /* bHDeCodeAccount01Out */
			return getbHDeCodeAccount01Out();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 694988660 : /* bHDeCodeAccount01Out */
			setbHDeCodeAccount01Out((kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
