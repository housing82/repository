/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_CODE_COMM_HIST
 */
@XmlType(propOrder={"histDate", "gubun", "code", "nm", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "triTag"}, name="DHDCodeCommHist01IO")
@XmlRootElement(name="DHDCodeCommHist01IO")
@SuppressWarnings("all")
public class DHDCodeCommHist01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1511644154L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_CODE_COMM_HIST";

	/*******************************************************************************************************************************
	* Property set << histDate >> [[ */
	
	@XmlTransient
	private boolean isSet_histDate = false;
	
	protected boolean isSet_histDate()
	{
		return this.isSet_histDate;
	}
	
	protected void setIsSet_histDate(boolean value)
	{
		this.isSet_histDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012082(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]", formatType="", format="", align="left", length=7, decimal=0, arrayReference="", fill="")
	private java.lang.String histDate  = null;
	
	/**
	 * @Description  [SYS_C0012082(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]
	 */
	public java.lang.String getHistDate(){
		return histDate;
	}
	
	/**
	 * @Description  [SYS_C0012082(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]
	 */
	@JsonProperty("histDate")
	public void setHistDate( java.lang.String histDate ) {
		isSet_histDate = true;
		this.histDate = histDate;
	}
	
	/** Property set << histDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << gubun >> [[ */
	
	@XmlTransient
	private boolean isSet_gubun = false;
	
	protected boolean isSet_gubun()
	{
		return this.isSet_gubun;
	}
	
	protected void setIsSet_gubun(boolean value)
	{
		this.isSet_gubun = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012083(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String gubun  = null;
	
	/**
	 * @Description  [SYS_C0012083(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]
	 */
	public java.lang.String getGubun(){
		return gubun;
	}
	
	/**
	 * @Description  [SYS_C0012083(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]
	 */
	@JsonProperty("gubun")
	public void setGubun( java.lang.String gubun ) {
		isSet_gubun = true;
		this.gubun = gubun;
	}
	
	/** Property set << gubun >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << code >> [[ */
	
	@XmlTransient
	private boolean isSet_code = false;
	
	protected boolean isSet_code()
	{
		return this.isSet_code;
	}
	
	protected void setIsSet_code(boolean value)
	{
		this.isSet_code = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012084(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String code  = null;
	
	/**
	 * @Description  [SYS_C0012084(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]
	 */
	public java.lang.String getCode(){
		return code;
	}
	
	/**
	 * @Description  [SYS_C0012084(C),SYS_C0012908(P) SYS_C0012908(UNIQUE)]
	 */
	@JsonProperty("code")
	public void setCode( java.lang.String code ) {
		isSet_code = true;
		this.code = code;
	}
	
	/** Property set << code >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << nm >> [[ */
	
	@XmlTransient
	private boolean isSet_nm = false;
	
	protected boolean isSet_nm()
	{
		return this.isSet_nm;
	}
	
	protected void setIsSet_nm(boolean value)
	{
		this.isSet_nm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String nm  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getNm(){
		return nm;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("nm")
	public void setNm( java.lang.String nm ) {
		isSet_nm = true;
		this.nm = nm;
	}
	
	/** Property set << nm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << triTag >> [[ */
	
	@XmlTransient
	private boolean isSet_triTag = false;
	
	protected boolean isSet_triTag()
	{
		return this.isSet_triTag;
	}
	
	protected void setIsSet_triTag(boolean value)
	{
		this.isSet_triTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String triTag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getTriTag(){
		return triTag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("triTag")
	public void setTriTag( java.lang.String triTag ) {
		isSet_triTag = true;
		this.triTag = triTag;
	}
	
	/** Property set << triTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeCommHist01IO clone(){
		try{
			DHDCodeCommHist01IO object= (DHDCodeCommHist01IO)super.clone();
			if ( this.histDate== null ) object.histDate = null;
			else{
				object.histDate = this.histDate;
			}
			if ( this.gubun== null ) object.gubun = null;
			else{
				object.gubun = this.gubun;
			}
			if ( this.code== null ) object.code = null;
			else{
				object.code = this.code;
			}
			if ( this.nm== null ) object.nm = null;
			else{
				object.nm = this.nm;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.triTag== null ) object.triTag = null;
			else{
				object.triTag = this.triTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((histDate==null)?0:histDate.hashCode());
		result = prime * result + ((gubun==null)?0:gubun.hashCode());
		result = prime * result + ((code==null)?0:code.hashCode());
		result = prime * result + ((nm==null)?0:nm.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((triTag==null)?0:triTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO other = (kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO)obj;
		if ( histDate == null ){
			if ( other.histDate != null ) return false;
		}
		else if ( !histDate.equals(other.histDate) )
			return false;
		if ( gubun == null ){
			if ( other.gubun != null ) return false;
		}
		else if ( !gubun.equals(other.gubun) )
			return false;
		if ( code == null ){
			if ( other.code != null ) return false;
		}
		else if ( !code.equals(other.code) )
			return false;
		if ( nm == null ){
			if ( other.nm != null ) return false;
		}
		else if ( !nm.equals(other.nm) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( triTag == null ){
			if ( other.triTag != null ) return false;
		}
		else if ( !triTag.equals(other.triTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO:\n");
		sb.append("\thistDate: ");
		sb.append(histDate==null?"null":getHistDate());
		sb.append("\n");
		sb.append("\tgubun: ");
		sb.append(gubun==null?"null":getGubun());
		sb.append("\n");
		sb.append("\tcode: ");
		sb.append(code==null?"null":getCode());
		sb.append("\n");
		sb.append("\tnm: ");
		sb.append(nm==null?"null":getNm());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\ttriTag: ");
		sb.append(triTag==null?"null":getTriTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 7; /* histDate */
		messageLen+= 2; /* gubun */
		messageLen+= 2; /* code */
		messageLen+= 20; /* nm */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 1; /* triTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("histDate");
	
		fieldNames.add("gubun");
	
		fieldNames.add("code");
	
		fieldNames.add("nm");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("triTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("histDate", get("histDate"));
	
		fieldValueMap.put("gubun", get("gubun"));
	
		fieldValueMap.put("code", get("code"));
	
		fieldValueMap.put("nm", get("nm"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("triTag", get("triTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			return getHistDate();
		case 98706125 : /* gubun */
			return getGubun();
		case 3059181 : /* code */
			return getCode();
		case 3519 : /* nm */
			return getNm();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -865492497 : /* triTag */
			return getTriTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			setHistDate((java.lang.String) value);
			return;
		case 98706125 : /* gubun */
			setGubun((java.lang.String) value);
			return;
		case 3059181 : /* code */
			setCode((java.lang.String) value);
			return;
		case 3519 : /* nm */
			setNm((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -865492497 : /* triTag */
			setTriTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
