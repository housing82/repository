/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 저장 Out
 */
@XmlType(propOrder={"delCnt", "updCnt", "insCnt", "outSelectListHdCodeAcnt01Cnt", "outSelectListHdCodeAcnt01List", "outInsertHdCodeAgency01"}, name="BHDeCodeAccount03Out")
@XmlRootElement(name="BHDeCodeAccount03Out")
@SuppressWarnings("all")
public class BHDeCodeAccount03Out  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -764859439L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 저장 Out";

	/*******************************************************************************************************************************
	* Property set << delCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_delCnt = false;
	
	protected boolean isSet_delCnt()
	{
		return this.isSet_delCnt;
	}
	
	protected void setIsSet_delCnt(boolean value)
	{
		this.isSet_delCnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 삭제 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer delCnt  = 0;
	
	/**
	 * @Description HD_코드-대행사 삭제 결과
	 */
	public java.lang.Integer getDelCnt(){
		return delCnt;
	}
	
	/**
	 * @Description HD_코드-대행사 삭제 결과
	 */
	@JsonProperty("delCnt")
	public void setDelCnt( java.lang.Integer delCnt ) {
		isSet_delCnt = true;
		this.delCnt = delCnt;
	}
	
	/** Property set << delCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << updCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_updCnt = false;
	
	protected boolean isSet_updCnt()
	{
		return this.isSet_updCnt;
	}
	
	protected void setIsSet_updCnt(boolean value)
	{
		this.isSet_updCnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 수정 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer updCnt  = 0;
	
	/**
	 * @Description HD_코드-대행사 수정 결과
	 */
	public java.lang.Integer getUpdCnt(){
		return updCnt;
	}
	
	/**
	 * @Description HD_코드-대행사 수정 결과
	 */
	@JsonProperty("updCnt")
	public void setUpdCnt( java.lang.Integer updCnt ) {
		isSet_updCnt = true;
		this.updCnt = updCnt;
	}
	
	/** Property set << updCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << insCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_insCnt = false;
	
	protected boolean isSet_insCnt()
	{
		return this.isSet_insCnt;
	}
	
	protected void setIsSet_insCnt(boolean value)
	{
		this.isSet_insCnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 등록 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer insCnt  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 등록 결과
	 */
	public java.lang.Integer getInsCnt(){
		return insCnt;
	}
	
	/**
	 * @Description HD_분양_전표_계정 등록 결과
	 */
	@JsonProperty("insCnt")
	public void setInsCnt( java.lang.Integer insCnt ) {
		isSet_insCnt = true;
		this.insCnt = insCnt;
	}
	
	/** Property set << insCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01Cnt >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01Cnt = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01Cnt()
	{
		return this.isSet_outSelectListHdCodeAcnt01Cnt;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01Cnt(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01Cnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outSelectListHdCodeAcnt01Cnt  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	public java.lang.Integer getOutSelectListHdCodeAcnt01Cnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_outSelectListHdCodeAcnt01Cnt )	return outSelectListHdCodeAcnt01Cnt;
		else
		{
			if ( outSelectListHdCodeAcnt01List == null || outSelectListHdCodeAcnt01List.size() == 0 ) return 0;
			else return outSelectListHdCodeAcnt01List.size();
		}
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	@JsonProperty("outSelectListHdCodeAcnt01Cnt")
	public void setOutSelectListHdCodeAcnt01Cnt( java.lang.Integer outSelectListHdCodeAcnt01Cnt ) {
		isSet_outSelectListHdCodeAcnt01Cnt = true;
		this.outSelectListHdCodeAcnt01Cnt = outSelectListHdCodeAcnt01Cnt;
	}
	
	/** Property set << outSelectListHdCodeAcnt01Cnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01List >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01List = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01List()
	{
		return this.isSet_outSelectListHdCodeAcnt01List;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01List(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01List = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과", formatType="", format="", align="left", length=0, decimal=0, arrayReference="outSelectListHdCodeAcnt01Cnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>();
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>  getOutSelectListHdCodeAcnt01List(){
		return outSelectListHdCodeAcnt01List;
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	@JsonProperty("outSelectListHdCodeAcnt01List")
	public void setOutSelectListHdCodeAcnt01List( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List ) {
		isSet_outSelectListHdCodeAcnt01List = true;
		this.outSelectListHdCodeAcnt01List = outSelectListHdCodeAcnt01List;
	}
	
	/** Property set << outSelectListHdCodeAcnt01List >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outInsertHdCodeAgency01 >> [[ */
	
	@XmlTransient
	private boolean isSet_outInsertHdCodeAgency01 = false;
	
	protected boolean isSet_outInsertHdCodeAgency01()
	{
		return this.isSet_outInsertHdCodeAgency01;
	}
	
	protected void setIsSet_outInsertHdCodeAgency01(boolean value)
	{
		this.isSet_outInsertHdCodeAgency01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 등록 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outInsertHdCodeAgency01  = 0;
	
	/**
	 * @Description HD_코드-대행사 등록 결과
	 */
	public java.lang.Integer getOutInsertHdCodeAgency01(){
		return outInsertHdCodeAgency01;
	}
	
	/**
	 * @Description HD_코드-대행사 등록 결과
	 */
	@JsonProperty("outInsertHdCodeAgency01")
	public void setOutInsertHdCodeAgency01( java.lang.Integer outInsertHdCodeAgency01 ) {
		isSet_outInsertHdCodeAgency01 = true;
		this.outInsertHdCodeAgency01 = outInsertHdCodeAgency01;
	}
	
	/** Property set << outInsertHdCodeAgency01 >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeAccount03Out clone(){
		try{
			BHDeCodeAccount03Out object= (BHDeCodeAccount03Out)super.clone();
			if ( this.delCnt== null ) object.delCnt = null;
			else{
				object.delCnt = this.delCnt;
			}
			if ( this.updCnt== null ) object.updCnt = null;
			else{
				object.updCnt = this.updCnt;
			}
			if ( this.insCnt== null ) object.insCnt = null;
			else{
				object.insCnt = this.insCnt;
			}
			if ( this.outSelectListHdCodeAcnt01Cnt== null ) object.outSelectListHdCodeAcnt01Cnt = null;
			else{
				object.outSelectListHdCodeAcnt01Cnt = this.outSelectListHdCodeAcnt01Cnt;
			}
			if ( this.outSelectListHdCodeAcnt01List== null ) object.outSelectListHdCodeAcnt01List = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>(outSelectListHdCodeAcnt01List.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO item : outSelectListHdCodeAcnt01List ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)item.clone());
				}
				object.outSelectListHdCodeAcnt01List = clonedList;
			}
			if ( this.outInsertHdCodeAgency01== null ) object.outInsertHdCodeAgency01 = null;
			else{
				object.outInsertHdCodeAgency01 = this.outInsertHdCodeAgency01;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((delCnt==null)?0:delCnt.hashCode());
		result = prime * result + ((updCnt==null)?0:updCnt.hashCode());
		result = prime * result + ((insCnt==null)?0:insCnt.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01Cnt==null)?0:outSelectListHdCodeAcnt01Cnt.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01List==null)?0:outSelectListHdCodeAcnt01List.hashCode());
		result = prime * result + ((outInsertHdCodeAgency01==null)?0:outInsertHdCodeAgency01.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeAccount03Out other = (kait.hd.code.onl.bc.dto.BHDeCodeAccount03Out)obj;
		if ( delCnt == null ){
			if ( other.delCnt != null ) return false;
		}
		else if ( !delCnt.equals(other.delCnt) )
			return false;
		if ( updCnt == null ){
			if ( other.updCnt != null ) return false;
		}
		else if ( !updCnt.equals(other.updCnt) )
			return false;
		if ( insCnt == null ){
			if ( other.insCnt != null ) return false;
		}
		else if ( !insCnt.equals(other.insCnt) )
			return false;
		if ( outSelectListHdCodeAcnt01Cnt == null ){
			if ( other.outSelectListHdCodeAcnt01Cnt != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01Cnt.equals(other.outSelectListHdCodeAcnt01Cnt) )
			return false;
		if ( outSelectListHdCodeAcnt01List == null ){
			if ( other.outSelectListHdCodeAcnt01List != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01List.equals(other.outSelectListHdCodeAcnt01List) )
			return false;
		if ( outInsertHdCodeAgency01 == null ){
			if ( other.outInsertHdCodeAgency01 != null ) return false;
		}
		else if ( !outInsertHdCodeAgency01.equals(other.outInsertHdCodeAgency01) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeAccount03Out:\n");
		sb.append("\tdelCnt: ");
		sb.append(delCnt==null?"null":getDelCnt());
		sb.append("\n");
		sb.append("\tupdCnt: ");
		sb.append(updCnt==null?"null":getUpdCnt());
		sb.append("\n");
		sb.append("\tinsCnt: ");
		sb.append(insCnt==null?"null":getInsCnt());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01Cnt: ");
		sb.append(outSelectListHdCodeAcnt01Cnt==null?"null":getOutSelectListHdCodeAcnt01Cnt());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01List: ");
		if ( outSelectListHdCodeAcnt01List == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(outSelectListHdCodeAcnt01List.size());
			sb.append("(items)\n");
	
			int max= (10<outSelectListHdCodeAcnt01List.size())?10:outSelectListHdCodeAcnt01List.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\toutSelectListHdCodeAcnt01List[");
				sb.append(i);
				sb.append("] : ");
				sb.append(outSelectListHdCodeAcnt01List.get(i));
				sb.append("\n");
			}
	
			if ( max < outSelectListHdCodeAcnt01List.size() ){
				sb.append("\toutSelectListHdCodeAcnt01List[.] : ").append("more ").append((outSelectListHdCodeAcnt01List.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("\toutInsertHdCodeAgency01: ");
		sb.append(outInsertHdCodeAgency01==null?"null":getOutInsertHdCodeAgency01());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 9; /* delCnt */
		messageLen+= 9; /* updCnt */
		messageLen+= 9; /* insCnt */
		messageLen+= 9; /* outSelectListHdCodeAcnt01Cnt */
		{/*outSelectListHdCodeAcnt01List*/
			int size=getOutSelectListHdCodeAcnt01Cnt();
			int count= outSelectListHdCodeAcnt01List.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO element= outSelectListHdCodeAcnt01List.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
		messageLen+= 9; /* outInsertHdCodeAgency01 */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("delCnt");
	
		fieldNames.add("updCnt");
	
		fieldNames.add("insCnt");
	
		fieldNames.add("outSelectListHdCodeAcnt01Cnt");
	
		fieldNames.add("outSelectListHdCodeAcnt01List");
	
		fieldNames.add("outInsertHdCodeAgency01");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("delCnt", get("delCnt"));
	
		fieldValueMap.put("updCnt", get("updCnt"));
	
		fieldValueMap.put("insCnt", get("insCnt"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01Cnt", get("outSelectListHdCodeAcnt01Cnt"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01List", get("outSelectListHdCodeAcnt01List"));
	
		fieldValueMap.put("outInsertHdCodeAgency01", get("outInsertHdCodeAgency01"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1335491234 : /* delCnt */
			return getDelCnt();
		case -838875264 : /* updCnt */
			return getUpdCnt();
		case -1183825253 : /* insCnt */
			return getInsCnt();
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			return getOutSelectListHdCodeAcnt01Cnt();
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			return getOutSelectListHdCodeAcnt01List();
		case -1635461002 : /* outInsertHdCodeAgency01 */
			return getOutInsertHdCodeAgency01();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1335491234 : /* delCnt */
			setDelCnt((java.lang.Integer) value);
			return;
		case -838875264 : /* updCnt */
			setUpdCnt((java.lang.Integer) value);
			return;
		case -1183825253 : /* insCnt */
			setInsCnt((java.lang.Integer) value);
			return;
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			setOutSelectListHdCodeAcnt01Cnt((java.lang.Integer) value);
			return;
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			setOutSelectListHdCodeAcnt01List((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>) value);
			return;
		case -1635461002 : /* outInsertHdCodeAgency01 */
			setOutInsertHdCodeAgency01((java.lang.Integer) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
