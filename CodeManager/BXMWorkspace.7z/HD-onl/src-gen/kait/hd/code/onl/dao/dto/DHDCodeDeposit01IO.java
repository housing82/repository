/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_코드-계좌번호 ( HD_CODE_DEPOSIT )
 */
@XmlType(propOrder={"deptCode", "housetag", "depositNo", "receipttag", "bankCode", "bankName", "listorder", "outdepositno", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "virTag"}, name="DHDCodeDeposit01IO")
@XmlRootElement(name="DHDCodeDeposit01IO")
@SuppressWarnings("all")
public class DHDCodeDeposit01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1243112928L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_코드-계좌번호 ( HD_CODE_DEPOSIT )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012096(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012096(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012096(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012097(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012097(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012097(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호 [SYS_C0012098(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호 [SYS_C0012098(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호 [SYS_C0012098(C),SYS_C0012912(P) SYS_C0012912(UNIQUE)]
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receipttag >> [[ */
	
	@XmlTransient
	private boolean isSet_receipttag = false;
	
	protected boolean isSet_receipttag()
	{
		return this.isSet_receipttag;
	}
	
	protected void setIsSet_receipttag(boolean value)
	{
		this.isSet_receipttag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌용도구분 [SYS_C0012099(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String receipttag  = null;
	
	/**
	 * @Description 계좌용도구분 [SYS_C0012099(C)]
	 */
	public java.lang.String getReceipttag(){
		return receipttag;
	}
	
	/**
	 * @Description 계좌용도구분 [SYS_C0012099(C)]
	 */
	@JsonProperty("receipttag")
	public void setReceipttag( java.lang.String receipttag ) {
		isSet_receipttag = true;
		this.receipttag = receipttag;
	}
	
	/** Property set << receipttag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankCode = false;
	
	protected boolean isSet_bankCode()
	{
		return this.isSet_bankCode;
	}
	
	protected void setIsSet_bankCode(boolean value)
	{
		this.isSet_bankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행코드 [SYS_C0012100(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String bankCode  = null;
	
	/**
	 * @Description 은행코드 [SYS_C0012100(C)]
	 */
	public java.lang.String getBankCode(){
		return bankCode;
	}
	
	/**
	 * @Description 은행코드 [SYS_C0012100(C)]
	 */
	@JsonProperty("bankCode")
	public void setBankCode( java.lang.String bankCode ) {
		isSet_bankCode = true;
		this.bankCode = bankCode;
	}
	
	/** Property set << bankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankName >> [[ */
	
	@XmlTransient
	private boolean isSet_bankName = false;
	
	protected boolean isSet_bankName()
	{
		return this.isSet_bankName;
	}
	
	protected void setIsSet_bankName(boolean value)
	{
		this.isSet_bankName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행명칭 [SYS_C0012101(C)]", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String bankName  = null;
	
	/**
	 * @Description 은행명칭 [SYS_C0012101(C)]
	 */
	public java.lang.String getBankName(){
		return bankName;
	}
	
	/**
	 * @Description 은행명칭 [SYS_C0012101(C)]
	 */
	@JsonProperty("bankName")
	public void setBankName( java.lang.String bankName ) {
		isSet_bankName = true;
		this.bankName = bankName;
	}
	
	/** Property set << bankName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << listorder >> [[ */
	
	@XmlTransient
	private boolean isSet_listorder = false;
	
	protected boolean isSet_listorder()
	{
		return this.isSet_listorder;
	}
	
	protected void setIsSet_listorder(boolean value)
	{
		this.isSet_listorder = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력순위 [SYS_C0012102(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float listorder  = .0F;
	
	/**
	 * @Description 출력순위 [SYS_C0012102(C)]
	 */
	public java.lang.Float getListorder(){
		return listorder;
	}
	
	/**
	 * @Description 출력순위 [SYS_C0012102(C)]
	 */
	@JsonProperty("listorder")
	public void setListorder( java.lang.Float listorder ) {
		isSet_listorder = true;
		this.listorder = listorder;
	}
	
	/** Property set << listorder >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outdepositno >> [[ */
	
	@XmlTransient
	private boolean isSet_outdepositno = false;
	
	protected boolean isSet_outdepositno()
	{
		return this.isSet_outdepositno;
	}
	
	protected void setIsSet_outdepositno(boolean value)
	{
		this.isSet_outdepositno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력용계좌번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String outdepositno  = null;
	
	/**
	 * @Description 출력용계좌번호
	 */
	public java.lang.String getOutdepositno(){
		return outdepositno;
	}
	
	/**
	 * @Description 출력용계좌번호
	 */
	@JsonProperty("outdepositno")
	public void setOutdepositno( java.lang.String outdepositno ) {
		isSet_outdepositno = true;
		this.outdepositno = outdepositno;
	}
	
	/** Property set << outdepositno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virTag >> [[ */
	
	@XmlTransient
	private boolean isSet_virTag = false;
	
	protected boolean isSet_virTag()
	{
		return this.isSet_virTag;
	}
	
	protected void setIsSet_virTag(boolean value)
	{
		this.isSet_virTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String virTag  = null;
	
	/**
	 * @Description 가상계좌구분
	 */
	public java.lang.String getVirTag(){
		return virTag;
	}
	
	/**
	 * @Description 가상계좌구분
	 */
	@JsonProperty("virTag")
	public void setVirTag( java.lang.String virTag ) {
		isSet_virTag = true;
		this.virTag = virTag;
	}
	
	/** Property set << virTag >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeDeposit01IO clone(){
		try{
			DHDCodeDeposit01IO object= (DHDCodeDeposit01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.receipttag== null ) object.receipttag = null;
			else{
				object.receipttag = this.receipttag;
			}
			if ( this.bankCode== null ) object.bankCode = null;
			else{
				object.bankCode = this.bankCode;
			}
			if ( this.bankName== null ) object.bankName = null;
			else{
				object.bankName = this.bankName;
			}
			if ( this.listorder== null ) object.listorder = null;
			else{
				object.listorder = this.listorder;
			}
			if ( this.outdepositno== null ) object.outdepositno = null;
			else{
				object.outdepositno = this.outdepositno;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.virTag== null ) object.virTag = null;
			else{
				object.virTag = this.virTag;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((receipttag==null)?0:receipttag.hashCode());
		result = prime * result + ((bankCode==null)?0:bankCode.hashCode());
		result = prime * result + ((bankName==null)?0:bankName.hashCode());
		result = prime * result + ((listorder==null)?0:listorder.hashCode());
		result = prime * result + ((outdepositno==null)?0:outdepositno.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((virTag==null)?0:virTag.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO other = (kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( receipttag == null ){
			if ( other.receipttag != null ) return false;
		}
		else if ( !receipttag.equals(other.receipttag) )
			return false;
		if ( bankCode == null ){
			if ( other.bankCode != null ) return false;
		}
		else if ( !bankCode.equals(other.bankCode) )
			return false;
		if ( bankName == null ){
			if ( other.bankName != null ) return false;
		}
		else if ( !bankName.equals(other.bankName) )
			return false;
		if ( listorder == null ){
			if ( other.listorder != null ) return false;
		}
		else if ( !listorder.equals(other.listorder) )
			return false;
		if ( outdepositno == null ){
			if ( other.outdepositno != null ) return false;
		}
		else if ( !outdepositno.equals(other.outdepositno) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( virTag == null ){
			if ( other.virTag != null ) return false;
		}
		else if ( !virTag.equals(other.virTag) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\treceipttag: ");
		sb.append(receipttag==null?"null":getReceipttag());
		sb.append("\n");
		sb.append("\tbankCode: ");
		sb.append(bankCode==null?"null":getBankCode());
		sb.append("\n");
		sb.append("\tbankName: ");
		sb.append(bankName==null?"null":getBankName());
		sb.append("\n");
		sb.append("\tlistorder: ");
		sb.append(listorder==null?"null":getListorder());
		sb.append("\n");
		sb.append("\toutdepositno: ");
		sb.append(outdepositno==null?"null":getOutdepositno());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tvirTag: ");
		sb.append(virTag==null?"null":getVirTag());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 20; /* depositNo */
		messageLen+= 1; /* receipttag */
		messageLen+= 8; /* bankCode */
		messageLen+= 30; /* bankName */
		messageLen+= 22; /* listorder */
		messageLen+= 20; /* outdepositno */
		messageLen+= 50; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 1; /* virTag */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("receipttag");
	
		fieldNames.add("bankCode");
	
		fieldNames.add("bankName");
	
		fieldNames.add("listorder");
	
		fieldNames.add("outdepositno");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("virTag");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("receipttag", get("receipttag"));
	
		fieldValueMap.put("bankCode", get("bankCode"));
	
		fieldValueMap.put("bankName", get("bankName"));
	
		fieldValueMap.put("listorder", get("listorder"));
	
		fieldValueMap.put("outdepositno", get("outdepositno"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("virTag", get("virTag"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 204178018 : /* receipttag */
			return getReceipttag();
		case -1859605943 : /* bankCode */
			return getBankCode();
		case -1859291417 : /* bankName */
			return getBankName();
		case -1209366160 : /* listorder */
			return getListorder();
		case -485515951 : /* outdepositno */
			return getOutdepositno();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -816277765 : /* virTag */
			return getVirTag();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 204178018 : /* receipttag */
			setReceipttag((java.lang.String) value);
			return;
		case -1859605943 : /* bankCode */
			setBankCode((java.lang.String) value);
			return;
		case -1859291417 : /* bankName */
			setBankName((java.lang.String) value);
			return;
		case -1209366160 : /* listorder */
			setListorder((java.lang.Float) value);
			return;
		case -485515951 : /* outdepositno */
			setOutdepositno((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -816277765 : /* virTag */
			setVirTag((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
