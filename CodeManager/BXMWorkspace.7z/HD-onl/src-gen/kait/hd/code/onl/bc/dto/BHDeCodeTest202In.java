/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 조회 In
 */
@XmlType(propOrder={"inDHDCodeAcnt01IO"}, name="BHDeCodeTest202In")
@XmlRootElement(name="BHDeCodeTest202In")
@SuppressWarnings("all")
public class BHDeCodeTest202In  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -844938764L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 조회 In";

	/*******************************************************************************************************************************
	* Property set << inDHDCodeAcnt01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDCodeAcnt01IO = false;
	
	protected boolean isSet_inDHDCodeAcnt01IO()
	{
		return this.isSet_inDHDCodeAcnt01IO;
	}
	
	protected void setIsSet_inDHDCodeAcnt01IO(boolean value)
	{
		this.isSet_inDHDCodeAcnt01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getInDHDCodeAcnt01IO(){
		return inDHDCodeAcnt01IO;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inDHDCodeAcnt01IO")
	public void setInDHDCodeAcnt01IO( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO ) {
		isSet_inDHDCodeAcnt01IO = true;
		this.inDHDCodeAcnt01IO = inDHDCodeAcnt01IO;
	}
	
	/** Property set << inDHDCodeAcnt01IO >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeTest202In clone(){
		try{
			BHDeCodeTest202In object= (BHDeCodeTest202In)super.clone();
			if ( this.inDHDCodeAcnt01IO== null ) object.inDHDCodeAcnt01IO = null;
			else{
				object.inDHDCodeAcnt01IO = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.inDHDCodeAcnt01IO.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((inDHDCodeAcnt01IO==null)?0:inDHDCodeAcnt01IO.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeTest202In other = (kait.hd.code.onl.bc.dto.BHDeCodeTest202In)obj;
		if ( inDHDCodeAcnt01IO == null ){
			if ( other.inDHDCodeAcnt01IO != null ) return false;
		}
		else if ( !inDHDCodeAcnt01IO.equals(other.inDHDCodeAcnt01IO) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeTest202In:\n");
		sb.append("\tinDHDCodeAcnt01IO: ");
		sb.append(inDHDCodeAcnt01IO==null?"null":getInDHDCodeAcnt01IO());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		if ( inDHDCodeAcnt01IO != null && !(inDHDCodeAcnt01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= inDHDCodeAcnt01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDCodeAcnt01IO */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("inDHDCodeAcnt01IO");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("inDHDCodeAcnt01IO", get("inDHDCodeAcnt01IO"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -678728201 : /* inDHDCodeAcnt01IO */
			return getInDHDCodeAcnt01IO();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -678728201 : /* inDHDCodeAcnt01IO */
			setInDHDCodeAcnt01IO((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
