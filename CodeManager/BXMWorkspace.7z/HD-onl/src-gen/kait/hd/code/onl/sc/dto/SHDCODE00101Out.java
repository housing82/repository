/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.sc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 현장 다건조회 Out
 */
@XmlType(propOrder={"outDHDCodeAcnt01IO", "outSelectListHdCodeAcnt01Cnt", "outSelectListHdCodeAcnt01List", "bHDeCodeTest01Out", "outDHDCodeAcnt01IO", "outSelectListHdCodeAcnt01Cnt", "outSelectListHdCodeAcnt01List", "bHDeCodeTest02Out"}, name="SHDCODE00101Out")
@XmlRootElement(name="SHDCODE00101Out")
@SuppressWarnings("all")
public class SHDCODE00101Out  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 160644776L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "현장 다건조회 Out";

	/*******************************************************************************************************************************
	* Property set << outDHDCodeAcnt01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_outDHDCodeAcnt01IO = false;
	
	protected boolean isSet_outDHDCodeAcnt01IO()
	{
		return this.isSet_outDHDCodeAcnt01IO;
	}
	
	protected void setIsSet_outDHDCodeAcnt01IO(boolean value)
	{
		this.isSet_outDHDCodeAcnt01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO outDHDCodeAcnt01IO  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getOutDHDCodeAcnt01IO(){
		return outDHDCodeAcnt01IO;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("outDHDCodeAcnt01IO")
	public void setOutDHDCodeAcnt01IO( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO outDHDCodeAcnt01IO ) {
		isSet_outDHDCodeAcnt01IO = true;
		this.outDHDCodeAcnt01IO = outDHDCodeAcnt01IO;
	}
	
	/** Property set << outDHDCodeAcnt01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01Cnt >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01Cnt = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01Cnt()
	{
		return this.isSet_outSelectListHdCodeAcnt01Cnt;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01Cnt(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01Cnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outSelectListHdCodeAcnt01Cnt  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	public java.lang.Integer getOutSelectListHdCodeAcnt01Cnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_outSelectListHdCodeAcnt01Cnt )	return outSelectListHdCodeAcnt01Cnt;
		else
		{
			if ( outSelectListHdCodeAcnt01List == null || outSelectListHdCodeAcnt01List.size() == 0 ) return 0;
			else return outSelectListHdCodeAcnt01List.size();
		}
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	@JsonProperty("outSelectListHdCodeAcnt01Cnt")
	public void setOutSelectListHdCodeAcnt01Cnt( java.lang.Integer outSelectListHdCodeAcnt01Cnt ) {
		isSet_outSelectListHdCodeAcnt01Cnt = true;
		this.outSelectListHdCodeAcnt01Cnt = outSelectListHdCodeAcnt01Cnt;
	}
	
	/** Property set << outSelectListHdCodeAcnt01Cnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01List >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01List = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01List()
	{
		return this.isSet_outSelectListHdCodeAcnt01List;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01List(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01List = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과", formatType="", format="", align="left", length=0, decimal=0, arrayReference="outSelectListHdCodeAcnt01Cnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>();
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>  getOutSelectListHdCodeAcnt01List(){
		return outSelectListHdCodeAcnt01List;
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	@JsonProperty("outSelectListHdCodeAcnt01List")
	public void setOutSelectListHdCodeAcnt01List( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List ) {
		isSet_outSelectListHdCodeAcnt01List = true;
		this.outSelectListHdCodeAcnt01List = outSelectListHdCodeAcnt01List;
	}
	
	/** Property set << outSelectListHdCodeAcnt01List >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bHDeCodeTest01Out >> [[ */
	
	@XmlTransient
	private boolean isSet_bHDeCodeTest01Out = false;
	
	protected boolean isSet_bHDeCodeTest01Out()
	{
		return this.isSet_bHDeCodeTest01Out;
	}
	
	protected void setIsSet_bHDeCodeTest01Out(boolean value)
	{
		this.isSet_bHDeCodeTest01Out = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장 다건조회 Out", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.BHDeCodeTest01Out bHDeCodeTest01Out  = null;
	
	/**
	 * @Description 현장 다건조회 Out
	 */
	public kait.hd.code.onl.sc.dto.BHDeCodeTest01Out getbHDeCodeTest01Out(){
		return bHDeCodeTest01Out;
	}
	
	/**
	 * @Description 현장 다건조회 Out
	 */
	@JsonProperty("bHDeCodeTest01Out")
	public void setbHDeCodeTest01Out( kait.hd.code.onl.sc.dto.BHDeCodeTest01Out bHDeCodeTest01Out ) {
		isSet_bHDeCodeTest01Out = true;
		this.bHDeCodeTest01Out = bHDeCodeTest01Out;
	}
	
	/** Property set << bHDeCodeTest01Out >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outDHDCodeAcnt01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_outDHDCodeAcnt01IO = false;
	
	protected boolean isSet_outDHDCodeAcnt01IO()
	{
		return this.isSet_outDHDCodeAcnt01IO;
	}
	
	protected void setIsSet_outDHDCodeAcnt01IO(boolean value)
	{
		this.isSet_outDHDCodeAcnt01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO outDHDCodeAcnt01IO  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getOutDHDCodeAcnt01IO(){
		return outDHDCodeAcnt01IO;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("outDHDCodeAcnt01IO")
	public void setOutDHDCodeAcnt01IO( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO outDHDCodeAcnt01IO ) {
		isSet_outDHDCodeAcnt01IO = true;
		this.outDHDCodeAcnt01IO = outDHDCodeAcnt01IO;
	}
	
	/** Property set << outDHDCodeAcnt01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01Cnt >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01Cnt = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01Cnt()
	{
		return this.isSet_outSelectListHdCodeAcnt01Cnt;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01Cnt(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01Cnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outSelectListHdCodeAcnt01Cnt  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	public java.lang.Integer getOutSelectListHdCodeAcnt01Cnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_outSelectListHdCodeAcnt01Cnt )	return outSelectListHdCodeAcnt01Cnt;
		else
		{
			if ( outSelectListHdCodeAcnt01List == null || outSelectListHdCodeAcnt01List.size() == 0 ) return 0;
			else return outSelectListHdCodeAcnt01List.size();
		}
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	@JsonProperty("outSelectListHdCodeAcnt01Cnt")
	public void setOutSelectListHdCodeAcnt01Cnt( java.lang.Integer outSelectListHdCodeAcnt01Cnt ) {
		isSet_outSelectListHdCodeAcnt01Cnt = true;
		this.outSelectListHdCodeAcnt01Cnt = outSelectListHdCodeAcnt01Cnt;
	}
	
	/** Property set << outSelectListHdCodeAcnt01Cnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01List >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01List = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01List()
	{
		return this.isSet_outSelectListHdCodeAcnt01List;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01List(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01List = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과", formatType="", format="", align="left", length=0, decimal=0, arrayReference="outSelectListHdCodeAcnt01Cnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>();
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>  getOutSelectListHdCodeAcnt01List(){
		return outSelectListHdCodeAcnt01List;
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	@JsonProperty("outSelectListHdCodeAcnt01List")
	public void setOutSelectListHdCodeAcnt01List( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List ) {
		isSet_outSelectListHdCodeAcnt01List = true;
		this.outSelectListHdCodeAcnt01List = outSelectListHdCodeAcnt01List;
	}
	
	/** Property set << outSelectListHdCodeAcnt01List >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bHDeCodeTest02Out >> [[ */
	
	@XmlTransient
	private boolean isSet_bHDeCodeTest02Out = false;
	
	protected boolean isSet_bHDeCodeTest02Out()
	{
		return this.isSet_bHDeCodeTest02Out;
	}
	
	protected void setIsSet_bHDeCodeTest02Out(boolean value)
	{
		this.isSet_bHDeCodeTest02Out = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장 다건조회 Out", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.sc.dto.BHDeCodeTest02Out bHDeCodeTest02Out  = null;
	
	/**
	 * @Description 현장 다건조회 Out
	 */
	public kait.hd.code.onl.sc.dto.BHDeCodeTest02Out getbHDeCodeTest02Out(){
		return bHDeCodeTest02Out;
	}
	
	/**
	 * @Description 현장 다건조회 Out
	 */
	@JsonProperty("bHDeCodeTest02Out")
	public void setbHDeCodeTest02Out( kait.hd.code.onl.sc.dto.BHDeCodeTest02Out bHDeCodeTest02Out ) {
		isSet_bHDeCodeTest02Out = true;
		this.bHDeCodeTest02Out = bHDeCodeTest02Out;
	}
	
	/** Property set << bHDeCodeTest02Out >> ]]
	*******************************************************************************************************************************/

	@Override
	public SHDCODE00101Out clone(){
		try{
			SHDCODE00101Out object= (SHDCODE00101Out)super.clone();
			if ( this.outDHDCodeAcnt01IO== null ) object.outDHDCodeAcnt01IO = null;
			else{
				object.outDHDCodeAcnt01IO = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.outDHDCodeAcnt01IO.clone();
			}
			if ( this.outSelectListHdCodeAcnt01Cnt== null ) object.outSelectListHdCodeAcnt01Cnt = null;
			else{
				object.outSelectListHdCodeAcnt01Cnt = this.outSelectListHdCodeAcnt01Cnt;
			}
			if ( this.outSelectListHdCodeAcnt01List== null ) object.outSelectListHdCodeAcnt01List = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>(outSelectListHdCodeAcnt01List.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO item : outSelectListHdCodeAcnt01List ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)item.clone());
				}
				object.outSelectListHdCodeAcnt01List = clonedList;
			}
			if ( this.bHDeCodeTest01Out== null ) object.bHDeCodeTest01Out = null;
			else{
				object.bHDeCodeTest01Out = (kait.hd.code.onl.sc.dto.BHDeCodeTest01Out)this.bHDeCodeTest01Out.clone();
			}
			if ( this.outDHDCodeAcnt01IO== null ) object.outDHDCodeAcnt01IO = null;
			else{
				object.outDHDCodeAcnt01IO = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.outDHDCodeAcnt01IO.clone();
			}
			if ( this.outSelectListHdCodeAcnt01Cnt== null ) object.outSelectListHdCodeAcnt01Cnt = null;
			else{
				object.outSelectListHdCodeAcnt01Cnt = this.outSelectListHdCodeAcnt01Cnt;
			}
			if ( this.outSelectListHdCodeAcnt01List== null ) object.outSelectListHdCodeAcnt01List = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>(outSelectListHdCodeAcnt01List.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO item : outSelectListHdCodeAcnt01List ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)item.clone());
				}
				object.outSelectListHdCodeAcnt01List = clonedList;
			}
			if ( this.bHDeCodeTest02Out== null ) object.bHDeCodeTest02Out = null;
			else{
				object.bHDeCodeTest02Out = (kait.hd.code.onl.sc.dto.BHDeCodeTest02Out)this.bHDeCodeTest02Out.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((outDHDCodeAcnt01IO==null)?0:outDHDCodeAcnt01IO.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01Cnt==null)?0:outSelectListHdCodeAcnt01Cnt.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01List==null)?0:outSelectListHdCodeAcnt01List.hashCode());
		result = prime * result + ((bHDeCodeTest01Out==null)?0:bHDeCodeTest01Out.hashCode());
		result = prime * result + ((outDHDCodeAcnt01IO==null)?0:outDHDCodeAcnt01IO.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01Cnt==null)?0:outSelectListHdCodeAcnt01Cnt.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01List==null)?0:outSelectListHdCodeAcnt01List.hashCode());
		result = prime * result + ((bHDeCodeTest02Out==null)?0:bHDeCodeTest02Out.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.sc.dto.SHDCODE00101Out other = (kait.hd.code.onl.sc.dto.SHDCODE00101Out)obj;
		if ( outDHDCodeAcnt01IO == null ){
			if ( other.outDHDCodeAcnt01IO != null ) return false;
		}
		else if ( !outDHDCodeAcnt01IO.equals(other.outDHDCodeAcnt01IO) )
			return false;
		if ( outSelectListHdCodeAcnt01Cnt == null ){
			if ( other.outSelectListHdCodeAcnt01Cnt != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01Cnt.equals(other.outSelectListHdCodeAcnt01Cnt) )
			return false;
		if ( outSelectListHdCodeAcnt01List == null ){
			if ( other.outSelectListHdCodeAcnt01List != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01List.equals(other.outSelectListHdCodeAcnt01List) )
			return false;
		if ( bHDeCodeTest01Out == null ){
			if ( other.bHDeCodeTest01Out != null ) return false;
		}
		else if ( !bHDeCodeTest01Out.equals(other.bHDeCodeTest01Out) )
			return false;
		if ( outDHDCodeAcnt01IO == null ){
			if ( other.outDHDCodeAcnt01IO != null ) return false;
		}
		else if ( !outDHDCodeAcnt01IO.equals(other.outDHDCodeAcnt01IO) )
			return false;
		if ( outSelectListHdCodeAcnt01Cnt == null ){
			if ( other.outSelectListHdCodeAcnt01Cnt != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01Cnt.equals(other.outSelectListHdCodeAcnt01Cnt) )
			return false;
		if ( outSelectListHdCodeAcnt01List == null ){
			if ( other.outSelectListHdCodeAcnt01List != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01List.equals(other.outSelectListHdCodeAcnt01List) )
			return false;
		if ( bHDeCodeTest02Out == null ){
			if ( other.bHDeCodeTest02Out != null ) return false;
		}
		else if ( !bHDeCodeTest02Out.equals(other.bHDeCodeTest02Out) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.sc.dto.SHDCODE00101Out:\n");
		sb.append("\toutDHDCodeAcnt01IO: ");
		sb.append(outDHDCodeAcnt01IO==null?"null":getOutDHDCodeAcnt01IO());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01Cnt: ");
		sb.append(outSelectListHdCodeAcnt01Cnt==null?"null":getOutSelectListHdCodeAcnt01Cnt());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01List: ");
		if ( outSelectListHdCodeAcnt01List == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(outSelectListHdCodeAcnt01List.size());
			sb.append("(items)\n");
	
			int max= (10<outSelectListHdCodeAcnt01List.size())?10:outSelectListHdCodeAcnt01List.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\toutSelectListHdCodeAcnt01List[");
				sb.append(i);
				sb.append("] : ");
				sb.append(outSelectListHdCodeAcnt01List.get(i));
				sb.append("\n");
			}
	
			if ( max < outSelectListHdCodeAcnt01List.size() ){
				sb.append("\toutSelectListHdCodeAcnt01List[.] : ").append("more ").append((outSelectListHdCodeAcnt01List.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("\tbHDeCodeTest01Out: ");
		sb.append(bHDeCodeTest01Out==null?"null":getbHDeCodeTest01Out());
		sb.append("\n");
		sb.append("\toutDHDCodeAcnt01IO: ");
		sb.append(outDHDCodeAcnt01IO==null?"null":getOutDHDCodeAcnt01IO());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01Cnt: ");
		sb.append(outSelectListHdCodeAcnt01Cnt==null?"null":getOutSelectListHdCodeAcnt01Cnt());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01List: ");
		if ( outSelectListHdCodeAcnt01List == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(outSelectListHdCodeAcnt01List.size());
			sb.append("(items)\n");
	
			int max= (10<outSelectListHdCodeAcnt01List.size())?10:outSelectListHdCodeAcnt01List.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\toutSelectListHdCodeAcnt01List[");
				sb.append(i);
				sb.append("] : ");
				sb.append(outSelectListHdCodeAcnt01List.get(i));
				sb.append("\n");
			}
	
			if ( max < outSelectListHdCodeAcnt01List.size() ){
				sb.append("\toutSelectListHdCodeAcnt01List[.] : ").append("more ").append((outSelectListHdCodeAcnt01List.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("\tbHDeCodeTest02Out: ");
		sb.append(bHDeCodeTest02Out==null?"null":getbHDeCodeTest02Out());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		if ( outDHDCodeAcnt01IO != null && !(outDHDCodeAcnt01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= outDHDCodeAcnt01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* outDHDCodeAcnt01IO */
		}
		messageLen+= 9; /* outSelectListHdCodeAcnt01Cnt */
		{/*outSelectListHdCodeAcnt01List*/
			int size=getOutSelectListHdCodeAcnt01Cnt();
			int count= outSelectListHdCodeAcnt01List.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO element= outSelectListHdCodeAcnt01List.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
		if ( bHDeCodeTest01Out != null && !(bHDeCodeTest01Out instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.BHDeCodeTest01Out temp= bHDeCodeTest01Out;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.BHDeCodeTest01Out();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* bHDeCodeTest01Out */
		}
		if ( outDHDCodeAcnt01IO != null && !(outDHDCodeAcnt01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= outDHDCodeAcnt01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* outDHDCodeAcnt01IO */
		}
		messageLen+= 9; /* outSelectListHdCodeAcnt01Cnt */
		{/*outSelectListHdCodeAcnt01List*/
			int size=getOutSelectListHdCodeAcnt01Cnt();
			int count= outSelectListHdCodeAcnt01List.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO element= outSelectListHdCodeAcnt01List.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
		if ( bHDeCodeTest02Out != null && !(bHDeCodeTest02Out instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.sc.dto.BHDeCodeTest02Out temp= bHDeCodeTest02Out;
			if ( temp== null ) temp= new kait.hd.code.onl.sc.dto.BHDeCodeTest02Out();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* bHDeCodeTest02Out */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("outDHDCodeAcnt01IO");
	
		fieldNames.add("outSelectListHdCodeAcnt01Cnt");
	
		fieldNames.add("outSelectListHdCodeAcnt01List");
	
		fieldNames.add("bHDeCodeTest01Out");
	
		fieldNames.add("outDHDCodeAcnt01IO");
	
		fieldNames.add("outSelectListHdCodeAcnt01Cnt");
	
		fieldNames.add("outSelectListHdCodeAcnt01List");
	
		fieldNames.add("bHDeCodeTest02Out");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("outDHDCodeAcnt01IO", get("outDHDCodeAcnt01IO"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01Cnt", get("outSelectListHdCodeAcnt01Cnt"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01List", get("outSelectListHdCodeAcnt01List"));
	
		fieldValueMap.put("bHDeCodeTest01Out", get("bHDeCodeTest01Out"));
	
		fieldValueMap.put("outDHDCodeAcnt01IO", get("outDHDCodeAcnt01IO"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01Cnt", get("outSelectListHdCodeAcnt01Cnt"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01List", get("outSelectListHdCodeAcnt01List"));
	
		fieldValueMap.put("bHDeCodeTest02Out", get("bHDeCodeTest02Out"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 606999726 : /* outDHDCodeAcnt01IO */
			return getOutDHDCodeAcnt01IO();
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			return getOutSelectListHdCodeAcnt01Cnt();
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			return getOutSelectListHdCodeAcnt01List();
		case -941829945 : /* bHDeCodeTest01Out */
			return getbHDeCodeTest01Out();
		case 606999726 : /* outDHDCodeAcnt01IO */
			return getOutDHDCodeAcnt01IO();
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			return getOutSelectListHdCodeAcnt01Cnt();
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			return getOutSelectListHdCodeAcnt01List();
		case -941800154 : /* bHDeCodeTest02Out */
			return getbHDeCodeTest02Out();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 606999726 : /* outDHDCodeAcnt01IO */
			setOutDHDCodeAcnt01IO((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			setOutSelectListHdCodeAcnt01Cnt((java.lang.Integer) value);
			return;
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			setOutSelectListHdCodeAcnt01List((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>) value);
			return;
		case -941829945 : /* bHDeCodeTest01Out */
			setbHDeCodeTest01Out((kait.hd.code.onl.sc.dto.BHDeCodeTest01Out) value);
			return;
		case 606999726 : /* outDHDCodeAcnt01IO */
			setOutDHDCodeAcnt01IO((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			setOutSelectListHdCodeAcnt01Cnt((java.lang.Integer) value);
			return;
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			setOutSelectListHdCodeAcnt01List((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>) value);
			return;
		case -941800154 : /* bHDeCodeTest02Out */
			setbHDeCodeTest02Out((kait.hd.code.onl.sc.dto.BHDeCodeTest02Out) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
