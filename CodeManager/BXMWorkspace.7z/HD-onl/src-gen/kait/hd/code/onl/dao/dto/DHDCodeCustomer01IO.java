/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_코드_고객_컨버젼용 ( HD_CODE_CUSTOMER )
 */
@XmlType(propOrder={"custCode", "custName", "custcodeTag", "handphone", "tel", "compTel", "zip", "addr1", "addr2", "owner", "condition", "category", "email", "residentZip", "residentAddr1", "residentAddr2", "useyn", "compRecvYn", "deptCode", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDCodeCustomer01IO")
@XmlRootElement(name="DHDCodeCustomer01IO")
@SuppressWarnings("all")
public class DHDCodeCustomer01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 770996106L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_코드_고객_컨버젼용 ( HD_CODE_CUSTOMER )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객코드 [SYS_C0012088(C),SYS_C0012910(P) SYS_C0012910(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 고객코드 [SYS_C0012088(C),SYS_C0012910(P) SYS_C0012910(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 고객코드 [SYS_C0012088(C),SYS_C0012910(P) SYS_C0012910(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custName >> [[ */
	
	@XmlTransient
	private boolean isSet_custName = false;
	
	protected boolean isSet_custName()
	{
		return this.isSet_custName;
	}
	
	protected void setIsSet_custName(boolean value)
	{
		this.isSet_custName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객명칭 [SYS_C0012089(C) XIE1HD_CODE_CUSTOMER(NONUNIQUE)]", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String custName  = null;
	
	/**
	 * @Description 고객명칭 [SYS_C0012089(C) XIE1HD_CODE_CUSTOMER(NONUNIQUE)]
	 */
	public java.lang.String getCustName(){
		return custName;
	}
	
	/**
	 * @Description 고객명칭 [SYS_C0012089(C) XIE1HD_CODE_CUSTOMER(NONUNIQUE)]
	 */
	@JsonProperty("custName")
	public void setCustName( java.lang.String custName ) {
		isSet_custName = true;
		this.custName = custName;
	}
	
	/** Property set << custName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custcodeTag >> [[ */
	
	@XmlTransient
	private boolean isSet_custcodeTag = false;
	
	protected boolean isSet_custcodeTag()
	{
		return this.isSet_custcodeTag;
	}
	
	protected void setIsSet_custcodeTag(boolean value)
	{
		this.isSet_custcodeTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객구분", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String custcodeTag  = null;
	
	/**
	 * @Description 고객구분
	 */
	public java.lang.String getCustcodeTag(){
		return custcodeTag;
	}
	
	/**
	 * @Description 고객구분
	 */
	@JsonProperty("custcodeTag")
	public void setCustcodeTag( java.lang.String custcodeTag ) {
		isSet_custcodeTag = true;
		this.custcodeTag = custcodeTag;
	}
	
	/** Property set << custcodeTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << handphone >> [[ */
	
	@XmlTransient
	private boolean isSet_handphone = false;
	
	protected boolean isSet_handphone()
	{
		return this.isSet_handphone;
	}
	
	protected void setIsSet_handphone(boolean value)
	{
		this.isSet_handphone = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="핸드폰번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String handphone  = null;
	
	/**
	 * @Description 핸드폰번호
	 */
	public java.lang.String getHandphone(){
		return handphone;
	}
	
	/**
	 * @Description 핸드폰번호
	 */
	@JsonProperty("handphone")
	public void setHandphone( java.lang.String handphone ) {
		isSet_handphone = true;
		this.handphone = handphone;
	}
	
	/** Property set << handphone >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << tel >> [[ */
	
	@XmlTransient
	private boolean isSet_tel = false;
	
	protected boolean isSet_tel()
	{
		return this.isSet_tel;
	}
	
	protected void setIsSet_tel(boolean value)
	{
		this.isSet_tel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전화번호_자택", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String tel  = null;
	
	/**
	 * @Description 전화번호_자택
	 */
	public java.lang.String getTel(){
		return tel;
	}
	
	/**
	 * @Description 전화번호_자택
	 */
	@JsonProperty("tel")
	public void setTel( java.lang.String tel ) {
		isSet_tel = true;
		this.tel = tel;
	}
	
	/** Property set << tel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << compTel >> [[ */
	
	@XmlTransient
	private boolean isSet_compTel = false;
	
	protected boolean isSet_compTel()
	{
		return this.isSet_compTel;
	}
	
	protected void setIsSet_compTel(boolean value)
	{
		this.isSet_compTel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전화번호_회사", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String compTel  = null;
	
	/**
	 * @Description 전화번호_회사
	 */
	public java.lang.String getCompTel(){
		return compTel;
	}
	
	/**
	 * @Description 전화번호_회사
	 */
	@JsonProperty("compTel")
	public void setCompTel( java.lang.String compTel ) {
		isSet_compTel = true;
		this.compTel = compTel;
	}
	
	/** Property set << compTel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << zip >> [[ */
	
	@XmlTransient
	private boolean isSet_zip = false;
	
	protected boolean isSet_zip()
	{
		return this.isSet_zip;
	}
	
	protected void setIsSet_zip(boolean value)
	{
		this.isSet_zip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거주지우편번호 [SYS_C0012090(C)]", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String zip  = null;
	
	/**
	 * @Description 거주지우편번호 [SYS_C0012090(C)]
	 */
	public java.lang.String getZip(){
		return zip;
	}
	
	/**
	 * @Description 거주지우편번호 [SYS_C0012090(C)]
	 */
	@JsonProperty("zip")
	public void setZip( java.lang.String zip ) {
		isSet_zip = true;
		this.zip = zip;
	}
	
	/** Property set << zip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr1 = false;
	
	protected boolean isSet_addr1()
	{
		return this.isSet_addr1;
	}
	
	protected void setIsSet_addr1(boolean value)
	{
		this.isSet_addr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거주지주소1 [SYS_C0012091(C)]", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr1  = null;
	
	/**
	 * @Description 거주지주소1 [SYS_C0012091(C)]
	 */
	public java.lang.String getAddr1(){
		return addr1;
	}
	
	/**
	 * @Description 거주지주소1 [SYS_C0012091(C)]
	 */
	@JsonProperty("addr1")
	public void setAddr1( java.lang.String addr1 ) {
		isSet_addr1 = true;
		this.addr1 = addr1;
	}
	
	/** Property set << addr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2 = false;
	
	protected boolean isSet_addr2()
	{
		return this.isSet_addr2;
	}
	
	protected void setIsSet_addr2(boolean value)
	{
		this.isSet_addr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거주지주소2 [SYS_C0012092(C)]", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2  = null;
	
	/**
	 * @Description 거주지주소2 [SYS_C0012092(C)]
	 */
	public java.lang.String getAddr2(){
		return addr2;
	}
	
	/**
	 * @Description 거주지주소2 [SYS_C0012092(C)]
	 */
	@JsonProperty("addr2")
	public void setAddr2( java.lang.String addr2 ) {
		isSet_addr2 = true;
		this.addr2 = addr2;
	}
	
	/** Property set << addr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << owner >> [[ */
	
	@XmlTransient
	private boolean isSet_owner = false;
	
	protected boolean isSet_owner()
	{
		return this.isSet_owner;
	}
	
	protected void setIsSet_owner(boolean value)
	{
		this.isSet_owner = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대표자", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String owner  = null;
	
	/**
	 * @Description 대표자
	 */
	public java.lang.String getOwner(){
		return owner;
	}
	
	/**
	 * @Description 대표자
	 */
	@JsonProperty("owner")
	public void setOwner( java.lang.String owner ) {
		isSet_owner = true;
		this.owner = owner;
	}
	
	/** Property set << owner >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << condition >> [[ */
	
	@XmlTransient
	private boolean isSet_condition = false;
	
	protected boolean isSet_condition()
	{
		return this.isSet_condition;
	}
	
	protected void setIsSet_condition(boolean value)
	{
		this.isSet_condition = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="업태", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String condition  = null;
	
	/**
	 * @Description 업태
	 */
	public java.lang.String getCondition(){
		return condition;
	}
	
	/**
	 * @Description 업태
	 */
	@JsonProperty("condition")
	public void setCondition( java.lang.String condition ) {
		isSet_condition = true;
		this.condition = condition;
	}
	
	/** Property set << condition >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << category >> [[ */
	
	@XmlTransient
	private boolean isSet_category = false;
	
	protected boolean isSet_category()
	{
		return this.isSet_category;
	}
	
	protected void setIsSet_category(boolean value)
	{
		this.isSet_category = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="업종", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String category  = null;
	
	/**
	 * @Description 업종
	 */
	public java.lang.String getCategory(){
		return category;
	}
	
	/**
	 * @Description 업종
	 */
	@JsonProperty("category")
	public void setCategory( java.lang.String category ) {
		isSet_category = true;
		this.category = category;
	}
	
	/** Property set << category >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << email >> [[ */
	
	@XmlTransient
	private boolean isSet_email = false;
	
	protected boolean isSet_email()
	{
		return this.isSet_email;
	}
	
	protected void setIsSet_email(boolean value)
	{
		this.isSet_email = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이메일", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String email  = null;
	
	/**
	 * @Description 이메일
	 */
	public java.lang.String getEmail(){
		return email;
	}
	
	/**
	 * @Description 이메일
	 */
	@JsonProperty("email")
	public void setEmail( java.lang.String email ) {
		isSet_email = true;
		this.email = email;
	}
	
	/** Property set << email >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << residentZip >> [[ */
	
	@XmlTransient
	private boolean isSet_residentZip = false;
	
	protected boolean isSet_residentZip()
	{
		return this.isSet_residentZip;
	}
	
	protected void setIsSet_residentZip(boolean value)
	{
		this.isSet_residentZip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주민등록상우편번호", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String residentZip  = null;
	
	/**
	 * @Description 주민등록상우편번호
	 */
	public java.lang.String getResidentZip(){
		return residentZip;
	}
	
	/**
	 * @Description 주민등록상우편번호
	 */
	@JsonProperty("residentZip")
	public void setResidentZip( java.lang.String residentZip ) {
		isSet_residentZip = true;
		this.residentZip = residentZip;
	}
	
	/** Property set << residentZip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << residentAddr1 >> [[ */
	
	@XmlTransient
	private boolean isSet_residentAddr1 = false;
	
	protected boolean isSet_residentAddr1()
	{
		return this.isSet_residentAddr1;
	}
	
	protected void setIsSet_residentAddr1(boolean value)
	{
		this.isSet_residentAddr1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주민등록상주소1", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String residentAddr1  = null;
	
	/**
	 * @Description 주민등록상주소1
	 */
	public java.lang.String getResidentAddr1(){
		return residentAddr1;
	}
	
	/**
	 * @Description 주민등록상주소1
	 */
	@JsonProperty("residentAddr1")
	public void setResidentAddr1( java.lang.String residentAddr1 ) {
		isSet_residentAddr1 = true;
		this.residentAddr1 = residentAddr1;
	}
	
	/** Property set << residentAddr1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << residentAddr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_residentAddr2 = false;
	
	protected boolean isSet_residentAddr2()
	{
		return this.isSet_residentAddr2;
	}
	
	protected void setIsSet_residentAddr2(boolean value)
	{
		this.isSet_residentAddr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주민등록상주소2", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String residentAddr2  = null;
	
	/**
	 * @Description 주민등록상주소2
	 */
	public java.lang.String getResidentAddr2(){
		return residentAddr2;
	}
	
	/**
	 * @Description 주민등록상주소2
	 */
	@JsonProperty("residentAddr2")
	public void setResidentAddr2( java.lang.String residentAddr2 ) {
		isSet_residentAddr2 = true;
		this.residentAddr2 = residentAddr2;
	}
	
	/** Property set << residentAddr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << useyn >> [[ */
	
	@XmlTransient
	private boolean isSet_useyn = false;
	
	protected boolean isSet_useyn()
	{
		return this.isSet_useyn;
	}
	
	protected void setIsSet_useyn(boolean value)
	{
		this.isSet_useyn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사용여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String useyn  = null;
	
	/**
	 * @Description 사용여부
	 */
	public java.lang.String getUseyn(){
		return useyn;
	}
	
	/**
	 * @Description 사용여부
	 */
	@JsonProperty("useyn")
	public void setUseyn( java.lang.String useyn ) {
		isSet_useyn = true;
		this.useyn = useyn;
	}
	
	/** Property set << useyn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << compRecvYn >> [[ */
	
	@XmlTransient
	private boolean isSet_compRecvYn = false;
	
	protected boolean isSet_compRecvYn()
	{
		return this.isSet_compRecvYn;
	}
	
	protected void setIsSet_compRecvYn(boolean value)
	{
		this.isSet_compRecvYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="회사정보수신", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String compRecvYn  = null;
	
	/**
	 * @Description 회사정보수신
	 */
	public java.lang.String getCompRecvYn(){
		return compRecvYn;
	}
	
	/**
	 * @Description 회사정보수신
	 */
	@JsonProperty("compRecvYn")
	public void setCompRecvYn( java.lang.String compRecvYn ) {
		isSet_compRecvYn = true;
		this.compRecvYn = compRecvYn;
	}
	
	/** Property set << compRecvYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeCustomer01IO clone(){
		try{
			DHDCodeCustomer01IO object= (DHDCodeCustomer01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.custName== null ) object.custName = null;
			else{
				object.custName = this.custName;
			}
			if ( this.custcodeTag== null ) object.custcodeTag = null;
			else{
				object.custcodeTag = this.custcodeTag;
			}
			if ( this.handphone== null ) object.handphone = null;
			else{
				object.handphone = this.handphone;
			}
			if ( this.tel== null ) object.tel = null;
			else{
				object.tel = this.tel;
			}
			if ( this.compTel== null ) object.compTel = null;
			else{
				object.compTel = this.compTel;
			}
			if ( this.zip== null ) object.zip = null;
			else{
				object.zip = this.zip;
			}
			if ( this.addr1== null ) object.addr1 = null;
			else{
				object.addr1 = this.addr1;
			}
			if ( this.addr2== null ) object.addr2 = null;
			else{
				object.addr2 = this.addr2;
			}
			if ( this.owner== null ) object.owner = null;
			else{
				object.owner = this.owner;
			}
			if ( this.condition== null ) object.condition = null;
			else{
				object.condition = this.condition;
			}
			if ( this.category== null ) object.category = null;
			else{
				object.category = this.category;
			}
			if ( this.email== null ) object.email = null;
			else{
				object.email = this.email;
			}
			if ( this.residentZip== null ) object.residentZip = null;
			else{
				object.residentZip = this.residentZip;
			}
			if ( this.residentAddr1== null ) object.residentAddr1 = null;
			else{
				object.residentAddr1 = this.residentAddr1;
			}
			if ( this.residentAddr2== null ) object.residentAddr2 = null;
			else{
				object.residentAddr2 = this.residentAddr2;
			}
			if ( this.useyn== null ) object.useyn = null;
			else{
				object.useyn = this.useyn;
			}
			if ( this.compRecvYn== null ) object.compRecvYn = null;
			else{
				object.compRecvYn = this.compRecvYn;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((custName==null)?0:custName.hashCode());
		result = prime * result + ((custcodeTag==null)?0:custcodeTag.hashCode());
		result = prime * result + ((handphone==null)?0:handphone.hashCode());
		result = prime * result + ((tel==null)?0:tel.hashCode());
		result = prime * result + ((compTel==null)?0:compTel.hashCode());
		result = prime * result + ((zip==null)?0:zip.hashCode());
		result = prime * result + ((addr1==null)?0:addr1.hashCode());
		result = prime * result + ((addr2==null)?0:addr2.hashCode());
		result = prime * result + ((owner==null)?0:owner.hashCode());
		result = prime * result + ((condition==null)?0:condition.hashCode());
		result = prime * result + ((category==null)?0:category.hashCode());
		result = prime * result + ((email==null)?0:email.hashCode());
		result = prime * result + ((residentZip==null)?0:residentZip.hashCode());
		result = prime * result + ((residentAddr1==null)?0:residentAddr1.hashCode());
		result = prime * result + ((residentAddr2==null)?0:residentAddr2.hashCode());
		result = prime * result + ((useyn==null)?0:useyn.hashCode());
		result = prime * result + ((compRecvYn==null)?0:compRecvYn.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO other = (kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( custName == null ){
			if ( other.custName != null ) return false;
		}
		else if ( !custName.equals(other.custName) )
			return false;
		if ( custcodeTag == null ){
			if ( other.custcodeTag != null ) return false;
		}
		else if ( !custcodeTag.equals(other.custcodeTag) )
			return false;
		if ( handphone == null ){
			if ( other.handphone != null ) return false;
		}
		else if ( !handphone.equals(other.handphone) )
			return false;
		if ( tel == null ){
			if ( other.tel != null ) return false;
		}
		else if ( !tel.equals(other.tel) )
			return false;
		if ( compTel == null ){
			if ( other.compTel != null ) return false;
		}
		else if ( !compTel.equals(other.compTel) )
			return false;
		if ( zip == null ){
			if ( other.zip != null ) return false;
		}
		else if ( !zip.equals(other.zip) )
			return false;
		if ( addr1 == null ){
			if ( other.addr1 != null ) return false;
		}
		else if ( !addr1.equals(other.addr1) )
			return false;
		if ( addr2 == null ){
			if ( other.addr2 != null ) return false;
		}
		else if ( !addr2.equals(other.addr2) )
			return false;
		if ( owner == null ){
			if ( other.owner != null ) return false;
		}
		else if ( !owner.equals(other.owner) )
			return false;
		if ( condition == null ){
			if ( other.condition != null ) return false;
		}
		else if ( !condition.equals(other.condition) )
			return false;
		if ( category == null ){
			if ( other.category != null ) return false;
		}
		else if ( !category.equals(other.category) )
			return false;
		if ( email == null ){
			if ( other.email != null ) return false;
		}
		else if ( !email.equals(other.email) )
			return false;
		if ( residentZip == null ){
			if ( other.residentZip != null ) return false;
		}
		else if ( !residentZip.equals(other.residentZip) )
			return false;
		if ( residentAddr1 == null ){
			if ( other.residentAddr1 != null ) return false;
		}
		else if ( !residentAddr1.equals(other.residentAddr1) )
			return false;
		if ( residentAddr2 == null ){
			if ( other.residentAddr2 != null ) return false;
		}
		else if ( !residentAddr2.equals(other.residentAddr2) )
			return false;
		if ( useyn == null ){
			if ( other.useyn != null ) return false;
		}
		else if ( !useyn.equals(other.useyn) )
			return false;
		if ( compRecvYn == null ){
			if ( other.compRecvYn != null ) return false;
		}
		else if ( !compRecvYn.equals(other.compRecvYn) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tcustName: ");
		sb.append(custName==null?"null":getCustName());
		sb.append("\n");
		sb.append("\tcustcodeTag: ");
		sb.append(custcodeTag==null?"null":getCustcodeTag());
		sb.append("\n");
		sb.append("\thandphone: ");
		sb.append(handphone==null?"null":getHandphone());
		sb.append("\n");
		sb.append("\ttel: ");
		sb.append(tel==null?"null":getTel());
		sb.append("\n");
		sb.append("\tcompTel: ");
		sb.append(compTel==null?"null":getCompTel());
		sb.append("\n");
		sb.append("\tzip: ");
		sb.append(zip==null?"null":getZip());
		sb.append("\n");
		sb.append("\taddr1: ");
		sb.append(addr1==null?"null":getAddr1());
		sb.append("\n");
		sb.append("\taddr2: ");
		sb.append(addr2==null?"null":getAddr2());
		sb.append("\n");
		sb.append("\towner: ");
		sb.append(owner==null?"null":getOwner());
		sb.append("\n");
		sb.append("\tcondition: ");
		sb.append(condition==null?"null":getCondition());
		sb.append("\n");
		sb.append("\tcategory: ");
		sb.append(category==null?"null":getCategory());
		sb.append("\n");
		sb.append("\temail: ");
		sb.append(email==null?"null":getEmail());
		sb.append("\n");
		sb.append("\tresidentZip: ");
		sb.append(residentZip==null?"null":getResidentZip());
		sb.append("\n");
		sb.append("\tresidentAddr1: ");
		sb.append(residentAddr1==null?"null":getResidentAddr1());
		sb.append("\n");
		sb.append("\tresidentAddr2: ");
		sb.append(residentAddr2==null?"null":getResidentAddr2());
		sb.append("\n");
		sb.append("\tuseyn: ");
		sb.append(useyn==null?"null":getUseyn());
		sb.append("\n");
		sb.append("\tcompRecvYn: ");
		sb.append(compRecvYn==null?"null":getCompRecvYn());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 50; /* custName */
		messageLen+= 3; /* custcodeTag */
		messageLen+= 20; /* handphone */
		messageLen+= 20; /* tel */
		messageLen+= 20; /* compTel */
		messageLen+= 6; /* zip */
		messageLen+= 300; /* addr1 */
		messageLen+= 300; /* addr2 */
		messageLen+= 30; /* owner */
		messageLen+= 30; /* condition */
		messageLen+= 12; /* category */
		messageLen+= 50; /* email */
		messageLen+= 6; /* residentZip */
		messageLen+= 100; /* residentAddr1 */
		messageLen+= 100; /* residentAddr2 */
		messageLen+= 1; /* useyn */
		messageLen+= 1; /* compRecvYn */
		messageLen+= 12; /* deptCode */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("custName");
	
		fieldNames.add("custcodeTag");
	
		fieldNames.add("handphone");
	
		fieldNames.add("tel");
	
		fieldNames.add("compTel");
	
		fieldNames.add("zip");
	
		fieldNames.add("addr1");
	
		fieldNames.add("addr2");
	
		fieldNames.add("owner");
	
		fieldNames.add("condition");
	
		fieldNames.add("category");
	
		fieldNames.add("email");
	
		fieldNames.add("residentZip");
	
		fieldNames.add("residentAddr1");
	
		fieldNames.add("residentAddr2");
	
		fieldNames.add("useyn");
	
		fieldNames.add("compRecvYn");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("custName", get("custName"));
	
		fieldValueMap.put("custcodeTag", get("custcodeTag"));
	
		fieldValueMap.put("handphone", get("handphone"));
	
		fieldValueMap.put("tel", get("tel"));
	
		fieldValueMap.put("compTel", get("compTel"));
	
		fieldValueMap.put("zip", get("zip"));
	
		fieldValueMap.put("addr1", get("addr1"));
	
		fieldValueMap.put("addr2", get("addr2"));
	
		fieldValueMap.put("owner", get("owner"));
	
		fieldValueMap.put("condition", get("condition"));
	
		fieldValueMap.put("category", get("category"));
	
		fieldValueMap.put("email", get("email"));
	
		fieldValueMap.put("residentZip", get("residentZip"));
	
		fieldValueMap.put("residentAddr1", get("residentAddr1"));
	
		fieldValueMap.put("residentAddr2", get("residentAddr2"));
	
		fieldValueMap.put("useyn", get("useyn"));
	
		fieldValueMap.put("compRecvYn", get("compRecvYn"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 605180798 : /* custName */
			return getCustName();
		case 518732986 : /* custcodeTag */
			return getCustcodeTag();
		case 67922527 : /* handphone */
			return getHandphone();
		case 114715 : /* tel */
			return getTel();
		case 950471308 : /* compTel */
			return getCompTel();
		case 120609 : /* zip */
			return getZip();
		case 92660320 : /* addr1 */
			return getAddr1();
		case 92660321 : /* addr2 */
			return getAddr2();
		case 106164915 : /* owner */
			return getOwner();
		case -861311717 : /* condition */
			return getCondition();
		case 50511102 : /* category */
			return getCategory();
		case 96619420 : /* email */
			return getEmail();
		case 1098338225 : /* residentZip */
			return getResidentZip();
		case -1082165520 : /* residentAddr1 */
			return getResidentAddr1();
		case -1082165519 : /* residentAddr2 */
			return getResidentAddr2();
		case 111578844 : /* useyn */
			return getUseyn();
		case -1286056054 : /* compRecvYn */
			return getCompRecvYn();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 605180798 : /* custName */
			setCustName((java.lang.String) value);
			return;
		case 518732986 : /* custcodeTag */
			setCustcodeTag((java.lang.String) value);
			return;
		case 67922527 : /* handphone */
			setHandphone((java.lang.String) value);
			return;
		case 114715 : /* tel */
			setTel((java.lang.String) value);
			return;
		case 950471308 : /* compTel */
			setCompTel((java.lang.String) value);
			return;
		case 120609 : /* zip */
			setZip((java.lang.String) value);
			return;
		case 92660320 : /* addr1 */
			setAddr1((java.lang.String) value);
			return;
		case 92660321 : /* addr2 */
			setAddr2((java.lang.String) value);
			return;
		case 106164915 : /* owner */
			setOwner((java.lang.String) value);
			return;
		case -861311717 : /* condition */
			setCondition((java.lang.String) value);
			return;
		case 50511102 : /* category */
			setCategory((java.lang.String) value);
			return;
		case 96619420 : /* email */
			setEmail((java.lang.String) value);
			return;
		case 1098338225 : /* residentZip */
			setResidentZip((java.lang.String) value);
			return;
		case -1082165520 : /* residentAddr1 */
			setResidentAddr1((java.lang.String) value);
			return;
		case -1082165519 : /* residentAddr2 */
			setResidentAddr2((java.lang.String) value);
			return;
		case 111578844 : /* useyn */
			setUseyn((java.lang.String) value);
			return;
		case -1286056054 : /* compRecvYn */
			setCompRecvYn((java.lang.String) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
