/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_코드_분양구분_이력 ( HD_CODE_HOUSE_HIST )
 */
@XmlType(propOrder={"histDate", "deptCode", "housetag", "housedate", "completiondate", "houseCnt", "moveinstartdate", "moveinenddate", "penaltyrate", "hicTag", "tirmRate", "sodukRate", "juminRate", "damdang", "damdangTel", "printCnt", "resellTag", "virdepositYn", "virbankCode", "deptAddrUseYn", "contPblName", "contDwName", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "contPblName2", "contDwName2", "contPblName3", "contDwName3", "slipgroup", "triTag", "applyCheckYn", "anne1aPbl", "anne1aDw", "anne1bPbl", "anne1bDw", "anne2aPbl", "anne2aDw", "anne2bPbl", "anne2bDw", "anne3Pbl", "anne3Dw", "anne4Pbl", "anne4Dw", "delayday", "delayrate", "agreeTag", "indeminityTag", "indeminityFrdt", "indeminityTodt", "sealtype", "jiroTag", "jiroSn", "hdDaymonthTag", "rtDaymonthTag", "rtFixrateTag", "predisTag", "proxyTag", "trustTag", "printYn", "rtFixrateDay", "rtFixrate", "virdeposit2Yn", "virbank2Code", "rtFixrate2", "rtExtrate", "rtGurtyn", "rtRentyn", "oncesalerate", "delayBlock"}, name="DHDCodeHouseHist01IO")
@XmlRootElement(name="DHDCodeHouseHist01IO")
@SuppressWarnings("all")
public class DHDCodeHouseHist01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1263735076L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_코드_분양구분_이력 ( HD_CODE_HOUSE_HIST )";

	/*******************************************************************************************************************************
	* Property set << histDate >> [[ */
	
	@XmlTransient
	private boolean isSet_histDate = false;
	
	protected boolean isSet_histDate()
	{
		return this.isSet_histDate;
	}
	
	protected void setIsSet_histDate(boolean value)
	{
		this.isSet_histDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이력일자 [SYS_C0012115(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]", formatType="", format="", align="left", length=7, decimal=0, arrayReference="", fill="")
	private java.lang.String histDate  = null;
	
	/**
	 * @Description 이력일자 [SYS_C0012115(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]
	 */
	public java.lang.String getHistDate(){
		return histDate;
	}
	
	/**
	 * @Description 이력일자 [SYS_C0012115(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]
	 */
	@JsonProperty("histDate")
	public void setHistDate( java.lang.String histDate ) {
		isSet_histDate = true;
		this.histDate = histDate;
	}
	
	/** Property set << histDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012116(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012116(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012116(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012117(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012117(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012117(C),SYS_C0012918(P) SYS_C0012918(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housedate >> [[ */
	
	@XmlTransient
	private boolean isSet_housedate = false;
	
	protected boolean isSet_housedate()
	{
		return this.isSet_housedate;
	}
	
	protected void setIsSet_housedate(boolean value)
	{
		this.isSet_housedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String housedate  = null;
	
	/**
	 * @Description 분양일자
	 */
	public java.lang.String getHousedate(){
		return housedate;
	}
	
	/**
	 * @Description 분양일자
	 */
	@JsonProperty("housedate")
	public void setHousedate( java.lang.String housedate ) {
		isSet_housedate = true;
		this.housedate = housedate;
	}
	
	/** Property set << housedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << completiondate >> [[ */
	
	@XmlTransient
	private boolean isSet_completiondate = false;
	
	protected boolean isSet_completiondate()
	{
		return this.isSet_completiondate;
	}
	
	protected void setIsSet_completiondate(boolean value)
	{
		this.isSet_completiondate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="준공일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String completiondate  = null;
	
	/**
	 * @Description 준공일자
	 */
	public java.lang.String getCompletiondate(){
		return completiondate;
	}
	
	/**
	 * @Description 준공일자
	 */
	@JsonProperty("completiondate")
	public void setCompletiondate( java.lang.String completiondate ) {
		isSet_completiondate = true;
		this.completiondate = completiondate;
	}
	
	/** Property set << completiondate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_houseCnt = false;
	
	protected boolean isSet_houseCnt()
	{
		return this.isSet_houseCnt;
	}
	
	protected void setIsSet_houseCnt(boolean value)
	{
		this.isSet_houseCnt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 총세대
	 */
	public void setHouseCnt(java.lang.String value) {
		isSet_houseCnt = true;
		this.houseCnt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 총세대
	 */
	public void setHouseCnt(double value) {
		isSet_houseCnt = true;
		this.houseCnt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 총세대
	 */
	public void setHouseCnt(long value) {
		isSet_houseCnt = true;
		this.houseCnt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="총세대", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal houseCnt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 총세대
	 */
	public java.math.BigDecimal getHouseCnt(){
		return houseCnt;
	}
	
	/**
	 * @Description 총세대
	 */
	@JsonProperty("houseCnt")
	public void setHouseCnt( java.math.BigDecimal houseCnt ) {
		isSet_houseCnt = true;
		this.houseCnt = houseCnt;
	}
	
	/** Property set << houseCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << moveinstartdate >> [[ */
	
	@XmlTransient
	private boolean isSet_moveinstartdate = false;
	
	protected boolean isSet_moveinstartdate()
	{
		return this.isSet_moveinstartdate;
	}
	
	protected void setIsSet_moveinstartdate(boolean value)
	{
		this.isSet_moveinstartdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주시작일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String moveinstartdate  = null;
	
	/**
	 * @Description 입주시작일자
	 */
	public java.lang.String getMoveinstartdate(){
		return moveinstartdate;
	}
	
	/**
	 * @Description 입주시작일자
	 */
	@JsonProperty("moveinstartdate")
	public void setMoveinstartdate( java.lang.String moveinstartdate ) {
		isSet_moveinstartdate = true;
		this.moveinstartdate = moveinstartdate;
	}
	
	/** Property set << moveinstartdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << moveinenddate >> [[ */
	
	@XmlTransient
	private boolean isSet_moveinenddate = false;
	
	protected boolean isSet_moveinenddate()
	{
		return this.isSet_moveinenddate;
	}
	
	protected void setIsSet_moveinenddate(boolean value)
	{
		this.isSet_moveinenddate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주종료일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String moveinenddate  = null;
	
	/**
	 * @Description 입주종료일자
	 */
	public java.lang.String getMoveinenddate(){
		return moveinenddate;
	}
	
	/**
	 * @Description 입주종료일자
	 */
	@JsonProperty("moveinenddate")
	public void setMoveinenddate( java.lang.String moveinenddate ) {
		isSet_moveinenddate = true;
		this.moveinenddate = moveinenddate;
	}
	
	/** Property set << moveinenddate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << penaltyrate >> [[ */
	
	@XmlTransient
	private boolean isSet_penaltyrate = false;
	
	protected boolean isSet_penaltyrate()
	{
		return this.isSet_penaltyrate;
	}
	
	protected void setIsSet_penaltyrate(boolean value)
	{
		this.isSet_penaltyrate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 해약_위약금율
	 */
	public void setPenaltyrate(java.lang.String value) {
		isSet_penaltyrate = true;
		this.penaltyrate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 해약_위약금율
	 */
	public void setPenaltyrate(double value) {
		isSet_penaltyrate = true;
		this.penaltyrate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 해약_위약금율
	 */
	public void setPenaltyrate(long value) {
		isSet_penaltyrate = true;
		this.penaltyrate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="해약_위약금율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal penaltyrate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 해약_위약금율
	 */
	public java.math.BigDecimal getPenaltyrate(){
		return penaltyrate;
	}
	
	/**
	 * @Description 해약_위약금율
	 */
	@JsonProperty("penaltyrate")
	public void setPenaltyrate( java.math.BigDecimal penaltyrate ) {
		isSet_penaltyrate = true;
		this.penaltyrate = penaltyrate;
	}
	
	/** Property set << penaltyrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << hicTag >> [[ */
	
	@XmlTransient
	private boolean isSet_hicTag = false;
	
	protected boolean isSet_hicTag()
	{
		return this.isSet_hicTag;
	}
	
	protected void setIsSet_hicTag(boolean value)
	{
		this.isSet_hicTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약_기간이자계산여부", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String hicTag  = null;
	
	/**
	 * @Description 해약_기간이자계산여부
	 */
	public java.lang.String getHicTag(){
		return hicTag;
	}
	
	/**
	 * @Description 해약_기간이자계산여부
	 */
	@JsonProperty("hicTag")
	public void setHicTag( java.lang.String hicTag ) {
		isSet_hicTag = true;
		this.hicTag = hicTag;
	}
	
	/** Property set << hicTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << tirmRate >> [[ */
	
	@XmlTransient
	private boolean isSet_tirmRate = false;
	
	protected boolean isSet_tirmRate()
	{
		return this.isSet_tirmRate;
	}
	
	protected void setIsSet_tirmRate(boolean value)
	{
		this.isSet_tirmRate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 해약_기간이자율
	 */
	public void setTirmRate(java.lang.String value) {
		isSet_tirmRate = true;
		this.tirmRate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 해약_기간이자율
	 */
	public void setTirmRate(double value) {
		isSet_tirmRate = true;
		this.tirmRate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 해약_기간이자율
	 */
	public void setTirmRate(long value) {
		isSet_tirmRate = true;
		this.tirmRate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="해약_기간이자율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal tirmRate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 해약_기간이자율
	 */
	public java.math.BigDecimal getTirmRate(){
		return tirmRate;
	}
	
	/**
	 * @Description 해약_기간이자율
	 */
	@JsonProperty("tirmRate")
	public void setTirmRate( java.math.BigDecimal tirmRate ) {
		isSet_tirmRate = true;
		this.tirmRate = tirmRate;
	}
	
	/** Property set << tirmRate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sodukRate >> [[ */
	
	@XmlTransient
	private boolean isSet_sodukRate = false;
	
	protected boolean isSet_sodukRate()
	{
		return this.isSet_sodukRate;
	}
	
	protected void setIsSet_sodukRate(boolean value)
	{
		this.isSet_sodukRate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 헤약_소득세율
	 */
	public void setSodukRate(java.lang.String value) {
		isSet_sodukRate = true;
		this.sodukRate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 헤약_소득세율
	 */
	public void setSodukRate(double value) {
		isSet_sodukRate = true;
		this.sodukRate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 헤약_소득세율
	 */
	public void setSodukRate(long value) {
		isSet_sodukRate = true;
		this.sodukRate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="헤약_소득세율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sodukRate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 헤약_소득세율
	 */
	public java.math.BigDecimal getSodukRate(){
		return sodukRate;
	}
	
	/**
	 * @Description 헤약_소득세율
	 */
	@JsonProperty("sodukRate")
	public void setSodukRate( java.math.BigDecimal sodukRate ) {
		isSet_sodukRate = true;
		this.sodukRate = sodukRate;
	}
	
	/** Property set << sodukRate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << juminRate >> [[ */
	
	@XmlTransient
	private boolean isSet_juminRate = false;
	
	protected boolean isSet_juminRate()
	{
		return this.isSet_juminRate;
	}
	
	protected void setIsSet_juminRate(boolean value)
	{
		this.isSet_juminRate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 해약_주민세율
	 */
	public void setJuminRate(java.lang.String value) {
		isSet_juminRate = true;
		this.juminRate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 해약_주민세율
	 */
	public void setJuminRate(double value) {
		isSet_juminRate = true;
		this.juminRate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 해약_주민세율
	 */
	public void setJuminRate(long value) {
		isSet_juminRate = true;
		this.juminRate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="해약_주민세율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal juminRate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 해약_주민세율
	 */
	public java.math.BigDecimal getJuminRate(){
		return juminRate;
	}
	
	/**
	 * @Description 해약_주민세율
	 */
	@JsonProperty("juminRate")
	public void setJuminRate( java.math.BigDecimal juminRate ) {
		isSet_juminRate = true;
		this.juminRate = juminRate;
	}
	
	/** Property set << juminRate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << damdang >> [[ */
	
	@XmlTransient
	private boolean isSet_damdang = false;
	
	protected boolean isSet_damdang()
	{
		return this.isSet_damdang;
	}
	
	protected void setIsSet_damdang(boolean value)
	{
		this.isSet_damdang = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="담당자", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String damdang  = null;
	
	/**
	 * @Description 담당자
	 */
	public java.lang.String getDamdang(){
		return damdang;
	}
	
	/**
	 * @Description 담당자
	 */
	@JsonProperty("damdang")
	public void setDamdang( java.lang.String damdang ) {
		isSet_damdang = true;
		this.damdang = damdang;
	}
	
	/** Property set << damdang >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << damdangTel >> [[ */
	
	@XmlTransient
	private boolean isSet_damdangTel = false;
	
	protected boolean isSet_damdangTel()
	{
		return this.isSet_damdangTel;
	}
	
	protected void setIsSet_damdangTel(boolean value)
	{
		this.isSet_damdangTel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="담당자전화번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String damdangTel  = null;
	
	/**
	 * @Description 담당자전화번호
	 */
	public java.lang.String getDamdangTel(){
		return damdangTel;
	}
	
	/**
	 * @Description 담당자전화번호
	 */
	@JsonProperty("damdangTel")
	public void setDamdangTel( java.lang.String damdangTel ) {
		isSet_damdangTel = true;
		this.damdangTel = damdangTel;
	}
	
	/** Property set << damdangTel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_printCnt = false;
	
	protected boolean isSet_printCnt()
	{
		return this.isSet_printCnt;
	}
	
	protected void setIsSet_printCnt(boolean value)
	{
		this.isSet_printCnt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약서출력매수
	 */
	public void setPrintCnt(java.lang.String value) {
		isSet_printCnt = true;
		this.printCnt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약서출력매수
	 */
	public void setPrintCnt(double value) {
		isSet_printCnt = true;
		this.printCnt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약서출력매수
	 */
	public void setPrintCnt(long value) {
		isSet_printCnt = true;
		this.printCnt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약서출력매수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal printCnt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약서출력매수
	 */
	public java.math.BigDecimal getPrintCnt(){
		return printCnt;
	}
	
	/**
	 * @Description 계약서출력매수
	 */
	@JsonProperty("printCnt")
	public void setPrintCnt( java.math.BigDecimal printCnt ) {
		isSet_printCnt = true;
		this.printCnt = printCnt;
	}
	
	/** Property set << printCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << resellTag >> [[ */
	
	@XmlTransient
	private boolean isSet_resellTag = false;
	
	protected boolean isSet_resellTag()
	{
		return this.isSet_resellTag;
	}
	
	protected void setIsSet_resellTag(boolean value)
	{
		this.isSet_resellTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전매여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String resellTag  = null;
	
	/**
	 * @Description 전매여부
	 */
	public java.lang.String getResellTag(){
		return resellTag;
	}
	
	/**
	 * @Description 전매여부
	 */
	@JsonProperty("resellTag")
	public void setResellTag( java.lang.String resellTag ) {
		isSet_resellTag = true;
		this.resellTag = resellTag;
	}
	
	/** Property set << resellTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virdepositYn >> [[ */
	
	@XmlTransient
	private boolean isSet_virdepositYn = false;
	
	protected boolean isSet_virdepositYn()
	{
		return this.isSet_virdepositYn;
	}
	
	protected void setIsSet_virdepositYn(boolean value)
	{
		this.isSet_virdepositYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌사용여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String virdepositYn  = null;
	
	/**
	 * @Description 가상계좌사용여부
	 */
	public java.lang.String getVirdepositYn(){
		return virdepositYn;
	}
	
	/**
	 * @Description 가상계좌사용여부
	 */
	@JsonProperty("virdepositYn")
	public void setVirdepositYn( java.lang.String virdepositYn ) {
		isSet_virdepositYn = true;
		this.virdepositYn = virdepositYn;
	}
	
	/** Property set << virdepositYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virbankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_virbankCode = false;
	
	protected boolean isSet_virbankCode()
	{
		return this.isSet_virbankCode;
	}
	
	protected void setIsSet_virbankCode(boolean value)
	{
		this.isSet_virbankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌은행", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String virbankCode  = null;
	
	/**
	 * @Description 가상계좌은행
	 */
	public java.lang.String getVirbankCode(){
		return virbankCode;
	}
	
	/**
	 * @Description 가상계좌은행
	 */
	@JsonProperty("virbankCode")
	public void setVirbankCode( java.lang.String virbankCode ) {
		isSet_virbankCode = true;
		this.virbankCode = virbankCode;
	}
	
	/** Property set << virbankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptAddrUseYn >> [[ */
	
	@XmlTransient
	private boolean isSet_deptAddrUseYn = false;
	
	protected boolean isSet_deptAddrUseYn()
	{
		return this.isSet_deptAddrUseYn;
	}
	
	protected void setIsSet_deptAddrUseYn(boolean value)
	{
		this.isSet_deptAddrUseYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장주소반영여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String deptAddrUseYn  = null;
	
	/**
	 * @Description 현장주소반영여부
	 */
	public java.lang.String getDeptAddrUseYn(){
		return deptAddrUseYn;
	}
	
	/**
	 * @Description 현장주소반영여부
	 */
	@JsonProperty("deptAddrUseYn")
	public void setDeptAddrUseYn( java.lang.String deptAddrUseYn ) {
		isSet_deptAddrUseYn = true;
		this.deptAddrUseYn = deptAddrUseYn;
	}
	
	/** Property set << deptAddrUseYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contPblName >> [[ */
	
	@XmlTransient
	private boolean isSet_contPblName = false;
	
	protected boolean isSet_contPblName()
	{
		return this.isSet_contPblName;
	}
	
	protected void setIsSet_contPblName(boolean value)
	{
		this.isSet_contPblName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약서PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String contPblName  = null;
	
	/**
	 * @Description 계약서PBL명칭
	 */
	public java.lang.String getContPblName(){
		return contPblName;
	}
	
	/**
	 * @Description 계약서PBL명칭
	 */
	@JsonProperty("contPblName")
	public void setContPblName( java.lang.String contPblName ) {
		isSet_contPblName = true;
		this.contPblName = contPblName;
	}
	
	/** Property set << contPblName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contDwName >> [[ */
	
	@XmlTransient
	private boolean isSet_contDwName = false;
	
	protected boolean isSet_contDwName()
	{
		return this.isSet_contDwName;
	}
	
	protected void setIsSet_contDwName(boolean value)
	{
		this.isSet_contDwName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약서DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String contDwName  = null;
	
	/**
	 * @Description 계약서DW명칭
	 */
	public java.lang.String getContDwName(){
		return contDwName;
	}
	
	/**
	 * @Description 계약서DW명칭
	 */
	@JsonProperty("contDwName")
	public void setContDwName( java.lang.String contDwName ) {
		isSet_contDwName = true;
		this.contDwName = contDwName;
	}
	
	/** Property set << contDwName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=500, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contPblName2 >> [[ */
	
	@XmlTransient
	private boolean isSet_contPblName2 = false;
	
	protected boolean isSet_contPblName2()
	{
		return this.isSet_contPblName2;
	}
	
	protected void setIsSet_contPblName2(boolean value)
	{
		this.isSet_contPblName2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="설계변경동의서PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String contPblName2  = null;
	
	/**
	 * @Description 설계변경동의서PBL명칭
	 */
	public java.lang.String getContPblName2(){
		return contPblName2;
	}
	
	/**
	 * @Description 설계변경동의서PBL명칭
	 */
	@JsonProperty("contPblName2")
	public void setContPblName2( java.lang.String contPblName2 ) {
		isSet_contPblName2 = true;
		this.contPblName2 = contPblName2;
	}
	
	/** Property set << contPblName2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contDwName2 >> [[ */
	
	@XmlTransient
	private boolean isSet_contDwName2 = false;
	
	protected boolean isSet_contDwName2()
	{
		return this.isSet_contDwName2;
	}
	
	protected void setIsSet_contDwName2(boolean value)
	{
		this.isSet_contDwName2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="설계변경동의서DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String contDwName2  = null;
	
	/**
	 * @Description 설계변경동의서DW명칭
	 */
	public java.lang.String getContDwName2(){
		return contDwName2;
	}
	
	/**
	 * @Description 설계변경동의서DW명칭
	 */
	@JsonProperty("contDwName2")
	public void setContDwName2( java.lang.String contDwName2 ) {
		isSet_contDwName2 = true;
		this.contDwName2 = contDwName2;
	}
	
	/** Property set << contDwName2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contPblName3 >> [[ */
	
	@XmlTransient
	private boolean isSet_contPblName3 = false;
	
	protected boolean isSet_contPblName3()
	{
		return this.isSet_contPblName3;
	}
	
	protected void setIsSet_contPblName3(boolean value)
	{
		this.isSet_contPblName3 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채권양도증서PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String contPblName3  = null;
	
	/**
	 * @Description 채권양도증서PBL명칭
	 */
	public java.lang.String getContPblName3(){
		return contPblName3;
	}
	
	/**
	 * @Description 채권양도증서PBL명칭
	 */
	@JsonProperty("contPblName3")
	public void setContPblName3( java.lang.String contPblName3 ) {
		isSet_contPblName3 = true;
		this.contPblName3 = contPblName3;
	}
	
	/** Property set << contPblName3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contDwName3 >> [[ */
	
	@XmlTransient
	private boolean isSet_contDwName3 = false;
	
	protected boolean isSet_contDwName3()
	{
		return this.isSet_contDwName3;
	}
	
	protected void setIsSet_contDwName3(boolean value)
	{
		this.isSet_contDwName3 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채권양도증서DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String contDwName3  = null;
	
	/**
	 * @Description 채권양도증서DW명칭
	 */
	public java.lang.String getContDwName3(){
		return contDwName3;
	}
	
	/**
	 * @Description 채권양도증서DW명칭
	 */
	@JsonProperty("contDwName3")
	public void setContDwName3( java.lang.String contDwName3 ) {
		isSet_contDwName3 = true;
		this.contDwName3 = contDwName3;
	}
	
	/** Property set << contDwName3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipgroup >> [[ */
	
	@XmlTransient
	private boolean isSet_slipgroup = false;
	
	protected boolean isSet_slipgroup()
	{
		return this.isSet_slipgroup;
	}
	
	protected void setIsSet_slipgroup(boolean value)
	{
		this.isSet_slipgroup = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표그룹생성여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String slipgroup  = null;
	
	/**
	 * @Description 전표그룹생성여부
	 */
	public java.lang.String getSlipgroup(){
		return slipgroup;
	}
	
	/**
	 * @Description 전표그룹생성여부
	 */
	@JsonProperty("slipgroup")
	public void setSlipgroup( java.lang.String slipgroup ) {
		isSet_slipgroup = true;
		this.slipgroup = slipgroup;
	}
	
	/** Property set << slipgroup >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << triTag >> [[ */
	
	@XmlTransient
	private boolean isSet_triTag = false;
	
	protected boolean isSet_triTag()
	{
		return this.isSet_triTag;
	}
	
	protected void setIsSet_triTag(boolean value)
	{
		this.isSet_triTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="트리거구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String triTag  = null;
	
	/**
	 * @Description 트리거구분
	 */
	public java.lang.String getTriTag(){
		return triTag;
	}
	
	/**
	 * @Description 트리거구분
	 */
	@JsonProperty("triTag")
	public void setTriTag( java.lang.String triTag ) {
		isSet_triTag = true;
		this.triTag = triTag;
	}
	
	/** Property set << triTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << applyCheckYn >> [[ */
	
	@XmlTransient
	private boolean isSet_applyCheckYn = false;
	
	protected boolean isSet_applyCheckYn()
	{
		return this.isSet_applyCheckYn;
	}
	
	protected void setIsSet_applyCheckYn(boolean value)
	{
		this.isSet_applyCheckYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약서승인관리여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String applyCheckYn  = null;
	
	/**
	 * @Description 계약서승인관리여부
	 */
	public java.lang.String getApplyCheckYn(){
		return applyCheckYn;
	}
	
	/**
	 * @Description 계약서승인관리여부
	 */
	@JsonProperty("applyCheckYn")
	public void setApplyCheckYn( java.lang.String applyCheckYn ) {
		isSet_applyCheckYn = true;
		this.applyCheckYn = applyCheckYn;
	}
	
	/** Property set << applyCheckYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne1aPbl >> [[ */
	
	@XmlTransient
	private boolean isSet_anne1aPbl = false;
	
	protected boolean isSet_anne1aPbl()
	{
		return this.isSet_anne1aPbl;
	}
	
	protected void setIsSet_anne1aPbl(boolean value)
	{
		this.isSet_anne1aPbl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납부안내장-일반 PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne1aPbl  = null;
	
	/**
	 * @Description 납부안내장-일반 PBL명칭
	 */
	public java.lang.String getAnne1aPbl(){
		return anne1aPbl;
	}
	
	/**
	 * @Description 납부안내장-일반 PBL명칭
	 */
	@JsonProperty("anne1aPbl")
	public void setAnne1aPbl( java.lang.String anne1aPbl ) {
		isSet_anne1aPbl = true;
		this.anne1aPbl = anne1aPbl;
	}
	
	/** Property set << anne1aPbl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne1aDw >> [[ */
	
	@XmlTransient
	private boolean isSet_anne1aDw = false;
	
	protected boolean isSet_anne1aDw()
	{
		return this.isSet_anne1aDw;
	}
	
	protected void setIsSet_anne1aDw(boolean value)
	{
		this.isSet_anne1aDw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납부안내장-일반 DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne1aDw  = null;
	
	/**
	 * @Description 납부안내장-일반 DW명칭
	 */
	public java.lang.String getAnne1aDw(){
		return anne1aDw;
	}
	
	/**
	 * @Description 납부안내장-일반 DW명칭
	 */
	@JsonProperty("anne1aDw")
	public void setAnne1aDw( java.lang.String anne1aDw ) {
		isSet_anne1aDw = true;
		this.anne1aDw = anne1aDw;
	}
	
	/** Property set << anne1aDw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne1bPbl >> [[ */
	
	@XmlTransient
	private boolean isSet_anne1bPbl = false;
	
	protected boolean isSet_anne1bPbl()
	{
		return this.isSet_anne1bPbl;
	}
	
	protected void setIsSet_anne1bPbl(boolean value)
	{
		this.isSet_anne1bPbl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납부안내장-지체보상 PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne1bPbl  = null;
	
	/**
	 * @Description 납부안내장-지체보상 PBL명칭
	 */
	public java.lang.String getAnne1bPbl(){
		return anne1bPbl;
	}
	
	/**
	 * @Description 납부안내장-지체보상 PBL명칭
	 */
	@JsonProperty("anne1bPbl")
	public void setAnne1bPbl( java.lang.String anne1bPbl ) {
		isSet_anne1bPbl = true;
		this.anne1bPbl = anne1bPbl;
	}
	
	/** Property set << anne1bPbl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne1bDw >> [[ */
	
	@XmlTransient
	private boolean isSet_anne1bDw = false;
	
	protected boolean isSet_anne1bDw()
	{
		return this.isSet_anne1bDw;
	}
	
	protected void setIsSet_anne1bDw(boolean value)
	{
		this.isSet_anne1bDw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납부안내장-지체보상 DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne1bDw  = null;
	
	/**
	 * @Description 납부안내장-지체보상 DW명칭
	 */
	public java.lang.String getAnne1bDw(){
		return anne1bDw;
	}
	
	/**
	 * @Description 납부안내장-지체보상 DW명칭
	 */
	@JsonProperty("anne1bDw")
	public void setAnne1bDw( java.lang.String anne1bDw ) {
		isSet_anne1bDw = true;
		this.anne1bDw = anne1bDw;
	}
	
	/** Property set << anne1bDw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne2aPbl >> [[ */
	
	@XmlTransient
	private boolean isSet_anne2aPbl = false;
	
	protected boolean isSet_anne2aPbl()
	{
		return this.isSet_anne2aPbl;
	}
	
	protected void setIsSet_anne2aPbl(boolean value)
	{
		this.isSet_anne2aPbl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납안내장-일반 PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne2aPbl  = null;
	
	/**
	 * @Description 미납안내장-일반 PBL명칭
	 */
	public java.lang.String getAnne2aPbl(){
		return anne2aPbl;
	}
	
	/**
	 * @Description 미납안내장-일반 PBL명칭
	 */
	@JsonProperty("anne2aPbl")
	public void setAnne2aPbl( java.lang.String anne2aPbl ) {
		isSet_anne2aPbl = true;
		this.anne2aPbl = anne2aPbl;
	}
	
	/** Property set << anne2aPbl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne2aDw >> [[ */
	
	@XmlTransient
	private boolean isSet_anne2aDw = false;
	
	protected boolean isSet_anne2aDw()
	{
		return this.isSet_anne2aDw;
	}
	
	protected void setIsSet_anne2aDw(boolean value)
	{
		this.isSet_anne2aDw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납안내장-일반 DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne2aDw  = null;
	
	/**
	 * @Description 미납안내장-일반 DW명칭
	 */
	public java.lang.String getAnne2aDw(){
		return anne2aDw;
	}
	
	/**
	 * @Description 미납안내장-일반 DW명칭
	 */
	@JsonProperty("anne2aDw")
	public void setAnne2aDw( java.lang.String anne2aDw ) {
		isSet_anne2aDw = true;
		this.anne2aDw = anne2aDw;
	}
	
	/** Property set << anne2aDw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne2bPbl >> [[ */
	
	@XmlTransient
	private boolean isSet_anne2bPbl = false;
	
	protected boolean isSet_anne2bPbl()
	{
		return this.isSet_anne2bPbl;
	}
	
	protected void setIsSet_anne2bPbl(boolean value)
	{
		this.isSet_anne2bPbl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납안내장-지체보상 PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne2bPbl  = null;
	
	/**
	 * @Description 미납안내장-지체보상 PBL명칭
	 */
	public java.lang.String getAnne2bPbl(){
		return anne2bPbl;
	}
	
	/**
	 * @Description 미납안내장-지체보상 PBL명칭
	 */
	@JsonProperty("anne2bPbl")
	public void setAnne2bPbl( java.lang.String anne2bPbl ) {
		isSet_anne2bPbl = true;
		this.anne2bPbl = anne2bPbl;
	}
	
	/** Property set << anne2bPbl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne2bDw >> [[ */
	
	@XmlTransient
	private boolean isSet_anne2bDw = false;
	
	protected boolean isSet_anne2bDw()
	{
		return this.isSet_anne2bDw;
	}
	
	protected void setIsSet_anne2bDw(boolean value)
	{
		this.isSet_anne2bDw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="미납안내장-지체보상 DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne2bDw  = null;
	
	/**
	 * @Description 미납안내장-지체보상 DW명칭
	 */
	public java.lang.String getAnne2bDw(){
		return anne2bDw;
	}
	
	/**
	 * @Description 미납안내장-지체보상 DW명칭
	 */
	@JsonProperty("anne2bDw")
	public void setAnne2bDw( java.lang.String anne2bDw ) {
		isSet_anne2bDw = true;
		this.anne2bDw = anne2bDw;
	}
	
	/** Property set << anne2bDw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne3Pbl >> [[ */
	
	@XmlTransient
	private boolean isSet_anne3Pbl = false;
	
	protected boolean isSet_anne3Pbl()
	{
		return this.isSet_anne3Pbl;
	}
	
	protected void setIsSet_anne3Pbl(boolean value)
	{
		this.isSet_anne3Pbl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="독촉장 PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne3Pbl  = null;
	
	/**
	 * @Description 독촉장 PBL명칭
	 */
	public java.lang.String getAnne3Pbl(){
		return anne3Pbl;
	}
	
	/**
	 * @Description 독촉장 PBL명칭
	 */
	@JsonProperty("anne3Pbl")
	public void setAnne3Pbl( java.lang.String anne3Pbl ) {
		isSet_anne3Pbl = true;
		this.anne3Pbl = anne3Pbl;
	}
	
	/** Property set << anne3Pbl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne3Dw >> [[ */
	
	@XmlTransient
	private boolean isSet_anne3Dw = false;
	
	protected boolean isSet_anne3Dw()
	{
		return this.isSet_anne3Dw;
	}
	
	protected void setIsSet_anne3Dw(boolean value)
	{
		this.isSet_anne3Dw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="독촉장 DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne3Dw  = null;
	
	/**
	 * @Description 독촉장 DW명칭
	 */
	public java.lang.String getAnne3Dw(){
		return anne3Dw;
	}
	
	/**
	 * @Description 독촉장 DW명칭
	 */
	@JsonProperty("anne3Dw")
	public void setAnne3Dw( java.lang.String anne3Dw ) {
		isSet_anne3Dw = true;
		this.anne3Dw = anne3Dw;
	}
	
	/** Property set << anne3Dw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne4Pbl >> [[ */
	
	@XmlTransient
	private boolean isSet_anne4Pbl = false;
	
	protected boolean isSet_anne4Pbl()
	{
		return this.isSet_anne4Pbl;
	}
	
	protected void setIsSet_anne4Pbl(boolean value)
	{
		this.isSet_anne4Pbl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="최고장 PBL명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne4Pbl  = null;
	
	/**
	 * @Description 최고장 PBL명칭
	 */
	public java.lang.String getAnne4Pbl(){
		return anne4Pbl;
	}
	
	/**
	 * @Description 최고장 PBL명칭
	 */
	@JsonProperty("anne4Pbl")
	public void setAnne4Pbl( java.lang.String anne4Pbl ) {
		isSet_anne4Pbl = true;
		this.anne4Pbl = anne4Pbl;
	}
	
	/** Property set << anne4Pbl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << anne4Dw >> [[ */
	
	@XmlTransient
	private boolean isSet_anne4Dw = false;
	
	protected boolean isSet_anne4Dw()
	{
		return this.isSet_anne4Dw;
	}
	
	protected void setIsSet_anne4Dw(boolean value)
	{
		this.isSet_anne4Dw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="최고장 DW명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String anne4Dw  = null;
	
	/**
	 * @Description 최고장 DW명칭
	 */
	public java.lang.String getAnne4Dw(){
		return anne4Dw;
	}
	
	/**
	 * @Description 최고장 DW명칭
	 */
	@JsonProperty("anne4Dw")
	public void setAnne4Dw( java.lang.String anne4Dw ) {
		isSet_anne4Dw = true;
		this.anne4Dw = anne4Dw;
	}
	
	/** Property set << anne4Dw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayday >> [[ */
	
	@XmlTransient
	private boolean isSet_delayday = false;
	
	protected boolean isSet_delayday()
	{
		return this.isSet_delayday;
	}
	
	protected void setIsSet_delayday(boolean value)
	{
		this.isSet_delayday = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 지체보상일수
	 */
	public void setDelayday(java.lang.String value) {
		isSet_delayday = true;
		this.delayday = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 지체보상일수
	 */
	public void setDelayday(double value) {
		isSet_delayday = true;
		this.delayday = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 지체보상일수
	 */
	public void setDelayday(long value) {
		isSet_delayday = true;
		this.delayday = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="지체보상일수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayday  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 지체보상일수
	 */
	public java.math.BigDecimal getDelayday(){
		return delayday;
	}
	
	/**
	 * @Description 지체보상일수
	 */
	@JsonProperty("delayday")
	public void setDelayday( java.math.BigDecimal delayday ) {
		isSet_delayday = true;
		this.delayday = delayday;
	}
	
	/** Property set << delayday >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayrate >> [[ */
	
	@XmlTransient
	private boolean isSet_delayrate = false;
	
	protected boolean isSet_delayrate()
	{
		return this.isSet_delayrate;
	}
	
	protected void setIsSet_delayrate(boolean value)
	{
		this.isSet_delayrate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 지체보상연체율
	 */
	public void setDelayrate(java.lang.String value) {
		isSet_delayrate = true;
		this.delayrate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 지체보상연체율
	 */
	public void setDelayrate(double value) {
		isSet_delayrate = true;
		this.delayrate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 지체보상연체율
	 */
	public void setDelayrate(long value) {
		isSet_delayrate = true;
		this.delayrate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="지체보상연체율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayrate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 지체보상연체율
	 */
	public java.math.BigDecimal getDelayrate(){
		return delayrate;
	}
	
	/**
	 * @Description 지체보상연체율
	 */
	@JsonProperty("delayrate")
	public void setDelayrate( java.math.BigDecimal delayrate ) {
		isSet_delayrate = true;
		this.delayrate = delayrate;
	}
	
	/** Property set << delayrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeTag >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeTag = false;
	
	protected boolean isSet_agreeTag()
	{
		return this.isSet_agreeTag;
	}
	
	protected void setIsSet_agreeTag(boolean value)
	{
		this.isSet_agreeTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="중도금이자구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String agreeTag  = null;
	
	/**
	 * @Description 중도금이자구분
	 */
	public java.lang.String getAgreeTag(){
		return agreeTag;
	}
	
	/**
	 * @Description 중도금이자구분
	 */
	@JsonProperty("agreeTag")
	public void setAgreeTag( java.lang.String agreeTag ) {
		isSet_agreeTag = true;
		this.agreeTag = agreeTag;
	}
	
	/** Property set << agreeTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indeminityTag >> [[ */
	
	@XmlTransient
	private boolean isSet_indeminityTag = false;
	
	protected boolean isSet_indeminityTag()
	{
		return this.isSet_indeminityTag;
	}
	
	protected void setIsSet_indeminityTag(boolean value)
	{
		this.isSet_indeminityTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="지체보상실납입구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String indeminityTag  = null;
	
	/**
	 * @Description 지체보상실납입구분
	 */
	public java.lang.String getIndeminityTag(){
		return indeminityTag;
	}
	
	/**
	 * @Description 지체보상실납입구분
	 */
	@JsonProperty("indeminityTag")
	public void setIndeminityTag( java.lang.String indeminityTag ) {
		isSet_indeminityTag = true;
		this.indeminityTag = indeminityTag;
	}
	
	/** Property set << indeminityTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indeminityFrdt >> [[ */
	
	@XmlTransient
	private boolean isSet_indeminityFrdt = false;
	
	protected boolean isSet_indeminityFrdt()
	{
		return this.isSet_indeminityFrdt;
	}
	
	protected void setIsSet_indeminityFrdt(boolean value)
	{
		this.isSet_indeminityFrdt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="지체보상시작일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String indeminityFrdt  = null;
	
	/**
	 * @Description 지체보상시작일
	 */
	public java.lang.String getIndeminityFrdt(){
		return indeminityFrdt;
	}
	
	/**
	 * @Description 지체보상시작일
	 */
	@JsonProperty("indeminityFrdt")
	public void setIndeminityFrdt( java.lang.String indeminityFrdt ) {
		isSet_indeminityFrdt = true;
		this.indeminityFrdt = indeminityFrdt;
	}
	
	/** Property set << indeminityFrdt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indeminityTodt >> [[ */
	
	@XmlTransient
	private boolean isSet_indeminityTodt = false;
	
	protected boolean isSet_indeminityTodt()
	{
		return this.isSet_indeminityTodt;
	}
	
	protected void setIsSet_indeminityTodt(boolean value)
	{
		this.isSet_indeminityTodt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="지체보상종료일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String indeminityTodt  = null;
	
	/**
	 * @Description 지체보상종료일
	 */
	public java.lang.String getIndeminityTodt(){
		return indeminityTodt;
	}
	
	/**
	 * @Description 지체보상종료일
	 */
	@JsonProperty("indeminityTodt")
	public void setIndeminityTodt( java.lang.String indeminityTodt ) {
		isSet_indeminityTodt = true;
		this.indeminityTodt = indeminityTodt;
	}
	
	/** Property set << indeminityTodt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sealtype >> [[ */
	
	@XmlTransient
	private boolean isSet_sealtype = false;
	
	protected boolean isSet_sealtype()
	{
		return this.isSet_sealtype;
	}
	
	protected void setIsSet_sealtype(boolean value)
	{
		this.isSet_sealtype = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="인장구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String sealtype  = null;
	
	/**
	 * @Description 인장구분
	 */
	public java.lang.String getSealtype(){
		return sealtype;
	}
	
	/**
	 * @Description 인장구분
	 */
	@JsonProperty("sealtype")
	public void setSealtype( java.lang.String sealtype ) {
		isSet_sealtype = true;
		this.sealtype = sealtype;
	}
	
	/** Property set << sealtype >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jiroTag >> [[ */
	
	@XmlTransient
	private boolean isSet_jiroTag = false;
	
	protected boolean isSet_jiroTag()
	{
		return this.isSet_jiroTag;
	}
	
	protected void setIsSet_jiroTag(boolean value)
	{
		this.isSet_jiroTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대지로구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String jiroTag  = null;
	
	/**
	 * @Description 임대지로구분
	 */
	public java.lang.String getJiroTag(){
		return jiroTag;
	}
	
	/**
	 * @Description 임대지로구분
	 */
	@JsonProperty("jiroTag")
	public void setJiroTag( java.lang.String jiroTag ) {
		isSet_jiroTag = true;
		this.jiroTag = jiroTag;
	}
	
	/** Property set << jiroTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jiroSn >> [[ */
	
	@XmlTransient
	private boolean isSet_jiroSn = false;
	
	protected boolean isSet_jiroSn()
	{
		return this.isSet_jiroSn;
	}
	
	protected void setIsSet_jiroSn(boolean value)
	{
		this.isSet_jiroSn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대지로번호", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String jiroSn  = null;
	
	/**
	 * @Description 임대지로번호
	 */
	public java.lang.String getJiroSn(){
		return jiroSn;
	}
	
	/**
	 * @Description 임대지로번호
	 */
	@JsonProperty("jiroSn")
	public void setJiroSn( java.lang.String jiroSn ) {
		isSet_jiroSn = true;
		this.jiroSn = jiroSn;
	}
	
	/** Property set << jiroSn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << hdDaymonthTag >> [[ */
	
	@XmlTransient
	private boolean isSet_hdDaymonthTag = false;
	
	protected boolean isSet_hdDaymonthTag()
	{
		return this.isSet_hdDaymonthTag;
	}
	
	protected void setIsSet_hdDaymonthTag(boolean value)
	{
		this.isSet_hdDaymonthTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양_연체일/월계산구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String hdDaymonthTag  = null;
	
	/**
	 * @Description 분양_연체일/월계산구분
	 */
	public java.lang.String getHdDaymonthTag(){
		return hdDaymonthTag;
	}
	
	/**
	 * @Description 분양_연체일/월계산구분
	 */
	@JsonProperty("hdDaymonthTag")
	public void setHdDaymonthTag( java.lang.String hdDaymonthTag ) {
		isSet_hdDaymonthTag = true;
		this.hdDaymonthTag = hdDaymonthTag;
	}
	
	/** Property set << hdDaymonthTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtDaymonthTag >> [[ */
	
	@XmlTransient
	private boolean isSet_rtDaymonthTag = false;
	
	protected boolean isSet_rtDaymonthTag()
	{
		return this.isSet_rtDaymonthTag;
	}
	
	protected void setIsSet_rtDaymonthTag(boolean value)
	{
		this.isSet_rtDaymonthTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대_연체일/월계산구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String rtDaymonthTag  = null;
	
	/**
	 * @Description 임대_연체일/월계산구분
	 */
	public java.lang.String getRtDaymonthTag(){
		return rtDaymonthTag;
	}
	
	/**
	 * @Description 임대_연체일/월계산구분
	 */
	@JsonProperty("rtDaymonthTag")
	public void setRtDaymonthTag( java.lang.String rtDaymonthTag ) {
		isSet_rtDaymonthTag = true;
		this.rtDaymonthTag = rtDaymonthTag;
	}
	
	/** Property set << rtDaymonthTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtFixrateTag >> [[ */
	
	@XmlTransient
	private boolean isSet_rtFixrateTag = false;
	
	protected boolean isSet_rtFixrateTag()
	{
		return this.isSet_rtFixrateTag;
	}
	
	protected void setIsSet_rtFixrateTag(boolean value)
	{
		this.isSet_rtFixrateTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대_일계산,고정이율계산구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String rtFixrateTag  = null;
	
	/**
	 * @Description 임대_일계산,고정이율계산구분
	 */
	public java.lang.String getRtFixrateTag(){
		return rtFixrateTag;
	}
	
	/**
	 * @Description 임대_일계산,고정이율계산구분
	 */
	@JsonProperty("rtFixrateTag")
	public void setRtFixrateTag( java.lang.String rtFixrateTag ) {
		isSet_rtFixrateTag = true;
		this.rtFixrateTag = rtFixrateTag;
	}
	
	/** Property set << rtFixrateTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << predisTag >> [[ */
	
	@XmlTransient
	private boolean isSet_predisTag = false;
	
	protected boolean isSet_predisTag()
	{
		return this.isSet_predisTag;
	}
	
	protected void setIsSet_predisTag(boolean value)
	{
		this.isSet_predisTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선납할인구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String predisTag  = null;
	
	/**
	 * @Description 선납할인구분
	 */
	public java.lang.String getPredisTag(){
		return predisTag;
	}
	
	/**
	 * @Description 선납할인구분
	 */
	@JsonProperty("predisTag")
	public void setPredisTag( java.lang.String predisTag ) {
		isSet_predisTag = true;
		this.predisTag = predisTag;
	}
	
	/** Property set << predisTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << proxyTag >> [[ */
	
	@XmlTransient
	private boolean isSet_proxyTag = false;
	
	protected boolean isSet_proxyTag()
	{
		return this.isSet_proxyTag;
	}
	
	protected void setIsSet_proxyTag(boolean value)
	{
		this.isSet_proxyTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이자대납여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String proxyTag  = null;
	
	/**
	 * @Description 이자대납여부
	 */
	public java.lang.String getProxyTag(){
		return proxyTag;
	}
	
	/**
	 * @Description 이자대납여부
	 */
	@JsonProperty("proxyTag")
	public void setProxyTag( java.lang.String proxyTag ) {
		isSet_proxyTag = true;
		this.proxyTag = proxyTag;
	}
	
	/** Property set << proxyTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << trustTag >> [[ */
	
	@XmlTransient
	private boolean isSet_trustTag = false;
	
	protected boolean isSet_trustTag()
	{
		return this.isSet_trustTag;
	}
	
	protected void setIsSet_trustTag(boolean value)
	{
		this.isSet_trustTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대위탁여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String trustTag  = null;
	
	/**
	 * @Description 임대위탁여부
	 */
	public java.lang.String getTrustTag(){
		return trustTag;
	}
	
	/**
	 * @Description 임대위탁여부
	 */
	@JsonProperty("trustTag")
	public void setTrustTag( java.lang.String trustTag ) {
		isSet_trustTag = true;
		this.trustTag = trustTag;
	}
	
	/** Property set << trustTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printYn >> [[ */
	
	@XmlTransient
	private boolean isSet_printYn = false;
	
	protected boolean isSet_printYn()
	{
		return this.isSet_printYn;
	}
	
	protected void setIsSet_printYn(boolean value)
	{
		this.isSet_printYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약서출력여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String printYn  = null;
	
	/**
	 * @Description 계약서출력여부
	 */
	public java.lang.String getPrintYn(){
		return printYn;
	}
	
	/**
	 * @Description 계약서출력여부
	 */
	@JsonProperty("printYn")
	public void setPrintYn( java.lang.String printYn ) {
		isSet_printYn = true;
		this.printYn = printYn;
	}
	
	/** Property set << printYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtFixrateDay >> [[ */
	
	@XmlTransient
	private boolean isSet_rtFixrateDay = false;
	
	protected boolean isSet_rtFixrateDay()
	{
		return this.isSet_rtFixrateDay;
	}
	
	protected void setIsSet_rtFixrateDay(boolean value)
	{
		this.isSet_rtFixrateDay = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고정일자
	 */
	public void setRtFixrateDay(java.lang.String value) {
		isSet_rtFixrateDay = true;
		this.rtFixrateDay = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고정일자
	 */
	public void setRtFixrateDay(double value) {
		isSet_rtFixrateDay = true;
		this.rtFixrateDay = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고정일자
	 */
	public void setRtFixrateDay(long value) {
		isSet_rtFixrateDay = true;
		this.rtFixrateDay = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고정일자", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rtFixrateDay  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고정일자
	 */
	public java.math.BigDecimal getRtFixrateDay(){
		return rtFixrateDay;
	}
	
	/**
	 * @Description 고정일자
	 */
	@JsonProperty("rtFixrateDay")
	public void setRtFixrateDay( java.math.BigDecimal rtFixrateDay ) {
		isSet_rtFixrateDay = true;
		this.rtFixrateDay = rtFixrateDay;
	}
	
	/** Property set << rtFixrateDay >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtFixrate >> [[ */
	
	@XmlTransient
	private boolean isSet_rtFixrate = false;
	
	protected boolean isSet_rtFixrate()
	{
		return this.isSet_rtFixrate;
	}
	
	protected void setIsSet_rtFixrate(boolean value)
	{
		this.isSet_rtFixrate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이내이율(사용안함)", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float rtFixrate  = .0F;
	
	/**
	 * @Description 기간이내이율(사용안함)
	 */
	public java.lang.Float getRtFixrate(){
		return rtFixrate;
	}
	
	/**
	 * @Description 기간이내이율(사용안함)
	 */
	@JsonProperty("rtFixrate")
	public void setRtFixrate( java.lang.Float rtFixrate ) {
		isSet_rtFixrate = true;
		this.rtFixrate = rtFixrate;
	}
	
	/** Property set << rtFixrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virdeposit2Yn >> [[ */
	
	@XmlTransient
	private boolean isSet_virdeposit2Yn = false;
	
	protected boolean isSet_virdeposit2Yn()
	{
		return this.isSet_virdeposit2Yn;
	}
	
	protected void setIsSet_virdeposit2Yn(boolean value)
	{
		this.isSet_virdeposit2Yn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대가상계좌사용여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String virdeposit2Yn  = null;
	
	/**
	 * @Description 임대가상계좌사용여부
	 */
	public java.lang.String getVirdeposit2Yn(){
		return virdeposit2Yn;
	}
	
	/**
	 * @Description 임대가상계좌사용여부
	 */
	@JsonProperty("virdeposit2Yn")
	public void setVirdeposit2Yn( java.lang.String virdeposit2Yn ) {
		isSet_virdeposit2Yn = true;
		this.virdeposit2Yn = virdeposit2Yn;
	}
	
	/** Property set << virdeposit2Yn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virbank2Code >> [[ */
	
	@XmlTransient
	private boolean isSet_virbank2Code = false;
	
	protected boolean isSet_virbank2Code()
	{
		return this.isSet_virbank2Code;
	}
	
	protected void setIsSet_virbank2Code(boolean value)
	{
		this.isSet_virbank2Code = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대가상계좌은행", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String virbank2Code  = null;
	
	/**
	 * @Description 임대가상계좌은행
	 */
	public java.lang.String getVirbank2Code(){
		return virbank2Code;
	}
	
	/**
	 * @Description 임대가상계좌은행
	 */
	@JsonProperty("virbank2Code")
	public void setVirbank2Code( java.lang.String virbank2Code ) {
		isSet_virbank2Code = true;
		this.virbank2Code = virbank2Code;
	}
	
	/** Property set << virbank2Code >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtFixrate2 >> [[ */
	
	@XmlTransient
	private boolean isSet_rtFixrate2 = false;
	
	protected boolean isSet_rtFixrate2()
	{
		return this.isSet_rtFixrate2;
	}
	
	protected void setIsSet_rtFixrate2(boolean value)
	{
		this.isSet_rtFixrate2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이후이율(사용안함)", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float rtFixrate2  = .0F;
	
	/**
	 * @Description 기간이후이율(사용안함)
	 */
	public java.lang.Float getRtFixrate2(){
		return rtFixrate2;
	}
	
	/**
	 * @Description 기간이후이율(사용안함)
	 */
	@JsonProperty("rtFixrate2")
	public void setRtFixrate2( java.lang.Float rtFixrate2 ) {
		isSet_rtFixrate2 = true;
		this.rtFixrate2 = rtFixrate2;
	}
	
	/** Property set << rtFixrate2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtExtrate >> [[ */
	
	@XmlTransient
	private boolean isSet_rtExtrate = false;
	
	protected boolean isSet_rtExtrate()
	{
		return this.isSet_rtExtrate;
	}
	
	protected void setIsSet_rtExtrate(boolean value)
	{
		this.isSet_rtExtrate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대기간연장인상율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float rtExtrate  = .0F;
	
	/**
	 * @Description 임대기간연장인상율
	 */
	public java.lang.Float getRtExtrate(){
		return rtExtrate;
	}
	
	/**
	 * @Description 임대기간연장인상율
	 */
	@JsonProperty("rtExtrate")
	public void setRtExtrate( java.lang.Float rtExtrate ) {
		isSet_rtExtrate = true;
		this.rtExtrate = rtExtrate;
	}
	
	/** Property set << rtExtrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtGurtyn >> [[ */
	
	@XmlTransient
	private boolean isSet_rtGurtyn = false;
	
	protected boolean isSet_rtGurtyn()
	{
		return this.isSet_rtGurtyn;
	}
	
	protected void setIsSet_rtGurtyn(boolean value)
	{
		this.isSet_rtGurtyn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String rtGurtyn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRtGurtyn(){
		return rtGurtyn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("rtGurtyn")
	public void setRtGurtyn( java.lang.String rtGurtyn ) {
		isSet_rtGurtyn = true;
		this.rtGurtyn = rtGurtyn;
	}
	
	/** Property set << rtGurtyn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rtRentyn >> [[ */
	
	@XmlTransient
	private boolean isSet_rtRentyn = false;
	
	protected boolean isSet_rtRentyn()
	{
		return this.isSet_rtRentyn;
	}
	
	protected void setIsSet_rtRentyn(boolean value)
	{
		this.isSet_rtRentyn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String rtRentyn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRtRentyn(){
		return rtRentyn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("rtRentyn")
	public void setRtRentyn( java.lang.String rtRentyn ) {
		isSet_rtRentyn = true;
		this.rtRentyn = rtRentyn;
	}
	
	/** Property set << rtRentyn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << oncesalerate >> [[ */
	
	@XmlTransient
	private boolean isSet_oncesalerate = false;
	
	protected boolean isSet_oncesalerate()
	{
		return this.isSet_oncesalerate;
	}
	
	protected void setIsSet_oncesalerate(boolean value)
	{
		this.isSet_oncesalerate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="일시납할인율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float oncesalerate  = .0F;
	
	/**
	 * @Description 일시납할인율
	 */
	public java.lang.Float getOncesalerate(){
		return oncesalerate;
	}
	
	/**
	 * @Description 일시납할인율
	 */
	@JsonProperty("oncesalerate")
	public void setOncesalerate( java.lang.Float oncesalerate ) {
		isSet_oncesalerate = true;
		this.oncesalerate = oncesalerate;
	}
	
	/** Property set << oncesalerate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayBlock >> [[ */
	
	@XmlTransient
	private boolean isSet_delayBlock = false;
	
	protected boolean isSet_delayBlock()
	{
		return this.isSet_delayBlock;
	}
	
	protected void setIsSet_delayBlock(boolean value)
	{
		this.isSet_delayBlock = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String delayBlock  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getDelayBlock(){
		return delayBlock;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("delayBlock")
	public void setDelayBlock( java.lang.String delayBlock ) {
		isSet_delayBlock = true;
		this.delayBlock = delayBlock;
	}
	
	/** Property set << delayBlock >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeHouseHist01IO clone(){
		try{
			DHDCodeHouseHist01IO object= (DHDCodeHouseHist01IO)super.clone();
			if ( this.histDate== null ) object.histDate = null;
			else{
				object.histDate = this.histDate;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.housedate== null ) object.housedate = null;
			else{
				object.housedate = this.housedate;
			}
			if ( this.completiondate== null ) object.completiondate = null;
			else{
				object.completiondate = this.completiondate;
			}
			if ( this.houseCnt== null ) object.houseCnt = null;
			else{
				object.houseCnt = new java.math.BigDecimal(houseCnt.toString());
			}
			if ( this.moveinstartdate== null ) object.moveinstartdate = null;
			else{
				object.moveinstartdate = this.moveinstartdate;
			}
			if ( this.moveinenddate== null ) object.moveinenddate = null;
			else{
				object.moveinenddate = this.moveinenddate;
			}
			if ( this.penaltyrate== null ) object.penaltyrate = null;
			else{
				object.penaltyrate = new java.math.BigDecimal(penaltyrate.toString());
			}
			if ( this.hicTag== null ) object.hicTag = null;
			else{
				object.hicTag = this.hicTag;
			}
			if ( this.tirmRate== null ) object.tirmRate = null;
			else{
				object.tirmRate = new java.math.BigDecimal(tirmRate.toString());
			}
			if ( this.sodukRate== null ) object.sodukRate = null;
			else{
				object.sodukRate = new java.math.BigDecimal(sodukRate.toString());
			}
			if ( this.juminRate== null ) object.juminRate = null;
			else{
				object.juminRate = new java.math.BigDecimal(juminRate.toString());
			}
			if ( this.damdang== null ) object.damdang = null;
			else{
				object.damdang = this.damdang;
			}
			if ( this.damdangTel== null ) object.damdangTel = null;
			else{
				object.damdangTel = this.damdangTel;
			}
			if ( this.printCnt== null ) object.printCnt = null;
			else{
				object.printCnt = new java.math.BigDecimal(printCnt.toString());
			}
			if ( this.resellTag== null ) object.resellTag = null;
			else{
				object.resellTag = this.resellTag;
			}
			if ( this.virdepositYn== null ) object.virdepositYn = null;
			else{
				object.virdepositYn = this.virdepositYn;
			}
			if ( this.virbankCode== null ) object.virbankCode = null;
			else{
				object.virbankCode = this.virbankCode;
			}
			if ( this.deptAddrUseYn== null ) object.deptAddrUseYn = null;
			else{
				object.deptAddrUseYn = this.deptAddrUseYn;
			}
			if ( this.contPblName== null ) object.contPblName = null;
			else{
				object.contPblName = this.contPblName;
			}
			if ( this.contDwName== null ) object.contDwName = null;
			else{
				object.contDwName = this.contDwName;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.contPblName2== null ) object.contPblName2 = null;
			else{
				object.contPblName2 = this.contPblName2;
			}
			if ( this.contDwName2== null ) object.contDwName2 = null;
			else{
				object.contDwName2 = this.contDwName2;
			}
			if ( this.contPblName3== null ) object.contPblName3 = null;
			else{
				object.contPblName3 = this.contPblName3;
			}
			if ( this.contDwName3== null ) object.contDwName3 = null;
			else{
				object.contDwName3 = this.contDwName3;
			}
			if ( this.slipgroup== null ) object.slipgroup = null;
			else{
				object.slipgroup = this.slipgroup;
			}
			if ( this.triTag== null ) object.triTag = null;
			else{
				object.triTag = this.triTag;
			}
			if ( this.applyCheckYn== null ) object.applyCheckYn = null;
			else{
				object.applyCheckYn = this.applyCheckYn;
			}
			if ( this.anne1aPbl== null ) object.anne1aPbl = null;
			else{
				object.anne1aPbl = this.anne1aPbl;
			}
			if ( this.anne1aDw== null ) object.anne1aDw = null;
			else{
				object.anne1aDw = this.anne1aDw;
			}
			if ( this.anne1bPbl== null ) object.anne1bPbl = null;
			else{
				object.anne1bPbl = this.anne1bPbl;
			}
			if ( this.anne1bDw== null ) object.anne1bDw = null;
			else{
				object.anne1bDw = this.anne1bDw;
			}
			if ( this.anne2aPbl== null ) object.anne2aPbl = null;
			else{
				object.anne2aPbl = this.anne2aPbl;
			}
			if ( this.anne2aDw== null ) object.anne2aDw = null;
			else{
				object.anne2aDw = this.anne2aDw;
			}
			if ( this.anne2bPbl== null ) object.anne2bPbl = null;
			else{
				object.anne2bPbl = this.anne2bPbl;
			}
			if ( this.anne2bDw== null ) object.anne2bDw = null;
			else{
				object.anne2bDw = this.anne2bDw;
			}
			if ( this.anne3Pbl== null ) object.anne3Pbl = null;
			else{
				object.anne3Pbl = this.anne3Pbl;
			}
			if ( this.anne3Dw== null ) object.anne3Dw = null;
			else{
				object.anne3Dw = this.anne3Dw;
			}
			if ( this.anne4Pbl== null ) object.anne4Pbl = null;
			else{
				object.anne4Pbl = this.anne4Pbl;
			}
			if ( this.anne4Dw== null ) object.anne4Dw = null;
			else{
				object.anne4Dw = this.anne4Dw;
			}
			if ( this.delayday== null ) object.delayday = null;
			else{
				object.delayday = new java.math.BigDecimal(delayday.toString());
			}
			if ( this.delayrate== null ) object.delayrate = null;
			else{
				object.delayrate = new java.math.BigDecimal(delayrate.toString());
			}
			if ( this.agreeTag== null ) object.agreeTag = null;
			else{
				object.agreeTag = this.agreeTag;
			}
			if ( this.indeminityTag== null ) object.indeminityTag = null;
			else{
				object.indeminityTag = this.indeminityTag;
			}
			if ( this.indeminityFrdt== null ) object.indeminityFrdt = null;
			else{
				object.indeminityFrdt = this.indeminityFrdt;
			}
			if ( this.indeminityTodt== null ) object.indeminityTodt = null;
			else{
				object.indeminityTodt = this.indeminityTodt;
			}
			if ( this.sealtype== null ) object.sealtype = null;
			else{
				object.sealtype = this.sealtype;
			}
			if ( this.jiroTag== null ) object.jiroTag = null;
			else{
				object.jiroTag = this.jiroTag;
			}
			if ( this.jiroSn== null ) object.jiroSn = null;
			else{
				object.jiroSn = this.jiroSn;
			}
			if ( this.hdDaymonthTag== null ) object.hdDaymonthTag = null;
			else{
				object.hdDaymonthTag = this.hdDaymonthTag;
			}
			if ( this.rtDaymonthTag== null ) object.rtDaymonthTag = null;
			else{
				object.rtDaymonthTag = this.rtDaymonthTag;
			}
			if ( this.rtFixrateTag== null ) object.rtFixrateTag = null;
			else{
				object.rtFixrateTag = this.rtFixrateTag;
			}
			if ( this.predisTag== null ) object.predisTag = null;
			else{
				object.predisTag = this.predisTag;
			}
			if ( this.proxyTag== null ) object.proxyTag = null;
			else{
				object.proxyTag = this.proxyTag;
			}
			if ( this.trustTag== null ) object.trustTag = null;
			else{
				object.trustTag = this.trustTag;
			}
			if ( this.printYn== null ) object.printYn = null;
			else{
				object.printYn = this.printYn;
			}
			if ( this.rtFixrateDay== null ) object.rtFixrateDay = null;
			else{
				object.rtFixrateDay = new java.math.BigDecimal(rtFixrateDay.toString());
			}
			if ( this.rtFixrate== null ) object.rtFixrate = null;
			else{
				object.rtFixrate = this.rtFixrate;
			}
			if ( this.virdeposit2Yn== null ) object.virdeposit2Yn = null;
			else{
				object.virdeposit2Yn = this.virdeposit2Yn;
			}
			if ( this.virbank2Code== null ) object.virbank2Code = null;
			else{
				object.virbank2Code = this.virbank2Code;
			}
			if ( this.rtFixrate2== null ) object.rtFixrate2 = null;
			else{
				object.rtFixrate2 = this.rtFixrate2;
			}
			if ( this.rtExtrate== null ) object.rtExtrate = null;
			else{
				object.rtExtrate = this.rtExtrate;
			}
			if ( this.rtGurtyn== null ) object.rtGurtyn = null;
			else{
				object.rtGurtyn = this.rtGurtyn;
			}
			if ( this.rtRentyn== null ) object.rtRentyn = null;
			else{
				object.rtRentyn = this.rtRentyn;
			}
			if ( this.oncesalerate== null ) object.oncesalerate = null;
			else{
				object.oncesalerate = this.oncesalerate;
			}
			if ( this.delayBlock== null ) object.delayBlock = null;
			else{
				object.delayBlock = this.delayBlock;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((histDate==null)?0:histDate.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((housedate==null)?0:housedate.hashCode());
		result = prime * result + ((completiondate==null)?0:completiondate.hashCode());
		result = prime * result + ((houseCnt==null)?0:houseCnt.hashCode());
		result = prime * result + ((moveinstartdate==null)?0:moveinstartdate.hashCode());
		result = prime * result + ((moveinenddate==null)?0:moveinenddate.hashCode());
		result = prime * result + ((penaltyrate==null)?0:penaltyrate.hashCode());
		result = prime * result + ((hicTag==null)?0:hicTag.hashCode());
		result = prime * result + ((tirmRate==null)?0:tirmRate.hashCode());
		result = prime * result + ((sodukRate==null)?0:sodukRate.hashCode());
		result = prime * result + ((juminRate==null)?0:juminRate.hashCode());
		result = prime * result + ((damdang==null)?0:damdang.hashCode());
		result = prime * result + ((damdangTel==null)?0:damdangTel.hashCode());
		result = prime * result + ((printCnt==null)?0:printCnt.hashCode());
		result = prime * result + ((resellTag==null)?0:resellTag.hashCode());
		result = prime * result + ((virdepositYn==null)?0:virdepositYn.hashCode());
		result = prime * result + ((virbankCode==null)?0:virbankCode.hashCode());
		result = prime * result + ((deptAddrUseYn==null)?0:deptAddrUseYn.hashCode());
		result = prime * result + ((contPblName==null)?0:contPblName.hashCode());
		result = prime * result + ((contDwName==null)?0:contDwName.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((contPblName2==null)?0:contPblName2.hashCode());
		result = prime * result + ((contDwName2==null)?0:contDwName2.hashCode());
		result = prime * result + ((contPblName3==null)?0:contPblName3.hashCode());
		result = prime * result + ((contDwName3==null)?0:contDwName3.hashCode());
		result = prime * result + ((slipgroup==null)?0:slipgroup.hashCode());
		result = prime * result + ((triTag==null)?0:triTag.hashCode());
		result = prime * result + ((applyCheckYn==null)?0:applyCheckYn.hashCode());
		result = prime * result + ((anne1aPbl==null)?0:anne1aPbl.hashCode());
		result = prime * result + ((anne1aDw==null)?0:anne1aDw.hashCode());
		result = prime * result + ((anne1bPbl==null)?0:anne1bPbl.hashCode());
		result = prime * result + ((anne1bDw==null)?0:anne1bDw.hashCode());
		result = prime * result + ((anne2aPbl==null)?0:anne2aPbl.hashCode());
		result = prime * result + ((anne2aDw==null)?0:anne2aDw.hashCode());
		result = prime * result + ((anne2bPbl==null)?0:anne2bPbl.hashCode());
		result = prime * result + ((anne2bDw==null)?0:anne2bDw.hashCode());
		result = prime * result + ((anne3Pbl==null)?0:anne3Pbl.hashCode());
		result = prime * result + ((anne3Dw==null)?0:anne3Dw.hashCode());
		result = prime * result + ((anne4Pbl==null)?0:anne4Pbl.hashCode());
		result = prime * result + ((anne4Dw==null)?0:anne4Dw.hashCode());
		result = prime * result + ((delayday==null)?0:delayday.hashCode());
		result = prime * result + ((delayrate==null)?0:delayrate.hashCode());
		result = prime * result + ((agreeTag==null)?0:agreeTag.hashCode());
		result = prime * result + ((indeminityTag==null)?0:indeminityTag.hashCode());
		result = prime * result + ((indeminityFrdt==null)?0:indeminityFrdt.hashCode());
		result = prime * result + ((indeminityTodt==null)?0:indeminityTodt.hashCode());
		result = prime * result + ((sealtype==null)?0:sealtype.hashCode());
		result = prime * result + ((jiroTag==null)?0:jiroTag.hashCode());
		result = prime * result + ((jiroSn==null)?0:jiroSn.hashCode());
		result = prime * result + ((hdDaymonthTag==null)?0:hdDaymonthTag.hashCode());
		result = prime * result + ((rtDaymonthTag==null)?0:rtDaymonthTag.hashCode());
		result = prime * result + ((rtFixrateTag==null)?0:rtFixrateTag.hashCode());
		result = prime * result + ((predisTag==null)?0:predisTag.hashCode());
		result = prime * result + ((proxyTag==null)?0:proxyTag.hashCode());
		result = prime * result + ((trustTag==null)?0:trustTag.hashCode());
		result = prime * result + ((printYn==null)?0:printYn.hashCode());
		result = prime * result + ((rtFixrateDay==null)?0:rtFixrateDay.hashCode());
		result = prime * result + ((rtFixrate==null)?0:rtFixrate.hashCode());
		result = prime * result + ((virdeposit2Yn==null)?0:virdeposit2Yn.hashCode());
		result = prime * result + ((virbank2Code==null)?0:virbank2Code.hashCode());
		result = prime * result + ((rtFixrate2==null)?0:rtFixrate2.hashCode());
		result = prime * result + ((rtExtrate==null)?0:rtExtrate.hashCode());
		result = prime * result + ((rtGurtyn==null)?0:rtGurtyn.hashCode());
		result = prime * result + ((rtRentyn==null)?0:rtRentyn.hashCode());
		result = prime * result + ((oncesalerate==null)?0:oncesalerate.hashCode());
		result = prime * result + ((delayBlock==null)?0:delayBlock.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO other = (kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO)obj;
		if ( histDate == null ){
			if ( other.histDate != null ) return false;
		}
		else if ( !histDate.equals(other.histDate) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( housedate == null ){
			if ( other.housedate != null ) return false;
		}
		else if ( !housedate.equals(other.housedate) )
			return false;
		if ( completiondate == null ){
			if ( other.completiondate != null ) return false;
		}
		else if ( !completiondate.equals(other.completiondate) )
			return false;
		if ( houseCnt == null ){
			if ( other.houseCnt != null ) return false;
		}
		else if ( !houseCnt.equals(other.houseCnt) )
			return false;
		if ( moveinstartdate == null ){
			if ( other.moveinstartdate != null ) return false;
		}
		else if ( !moveinstartdate.equals(other.moveinstartdate) )
			return false;
		if ( moveinenddate == null ){
			if ( other.moveinenddate != null ) return false;
		}
		else if ( !moveinenddate.equals(other.moveinenddate) )
			return false;
		if ( penaltyrate == null ){
			if ( other.penaltyrate != null ) return false;
		}
		else if ( !penaltyrate.equals(other.penaltyrate) )
			return false;
		if ( hicTag == null ){
			if ( other.hicTag != null ) return false;
		}
		else if ( !hicTag.equals(other.hicTag) )
			return false;
		if ( tirmRate == null ){
			if ( other.tirmRate != null ) return false;
		}
		else if ( !tirmRate.equals(other.tirmRate) )
			return false;
		if ( sodukRate == null ){
			if ( other.sodukRate != null ) return false;
		}
		else if ( !sodukRate.equals(other.sodukRate) )
			return false;
		if ( juminRate == null ){
			if ( other.juminRate != null ) return false;
		}
		else if ( !juminRate.equals(other.juminRate) )
			return false;
		if ( damdang == null ){
			if ( other.damdang != null ) return false;
		}
		else if ( !damdang.equals(other.damdang) )
			return false;
		if ( damdangTel == null ){
			if ( other.damdangTel != null ) return false;
		}
		else if ( !damdangTel.equals(other.damdangTel) )
			return false;
		if ( printCnt == null ){
			if ( other.printCnt != null ) return false;
		}
		else if ( !printCnt.equals(other.printCnt) )
			return false;
		if ( resellTag == null ){
			if ( other.resellTag != null ) return false;
		}
		else if ( !resellTag.equals(other.resellTag) )
			return false;
		if ( virdepositYn == null ){
			if ( other.virdepositYn != null ) return false;
		}
		else if ( !virdepositYn.equals(other.virdepositYn) )
			return false;
		if ( virbankCode == null ){
			if ( other.virbankCode != null ) return false;
		}
		else if ( !virbankCode.equals(other.virbankCode) )
			return false;
		if ( deptAddrUseYn == null ){
			if ( other.deptAddrUseYn != null ) return false;
		}
		else if ( !deptAddrUseYn.equals(other.deptAddrUseYn) )
			return false;
		if ( contPblName == null ){
			if ( other.contPblName != null ) return false;
		}
		else if ( !contPblName.equals(other.contPblName) )
			return false;
		if ( contDwName == null ){
			if ( other.contDwName != null ) return false;
		}
		else if ( !contDwName.equals(other.contDwName) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( contPblName2 == null ){
			if ( other.contPblName2 != null ) return false;
		}
		else if ( !contPblName2.equals(other.contPblName2) )
			return false;
		if ( contDwName2 == null ){
			if ( other.contDwName2 != null ) return false;
		}
		else if ( !contDwName2.equals(other.contDwName2) )
			return false;
		if ( contPblName3 == null ){
			if ( other.contPblName3 != null ) return false;
		}
		else if ( !contPblName3.equals(other.contPblName3) )
			return false;
		if ( contDwName3 == null ){
			if ( other.contDwName3 != null ) return false;
		}
		else if ( !contDwName3.equals(other.contDwName3) )
			return false;
		if ( slipgroup == null ){
			if ( other.slipgroup != null ) return false;
		}
		else if ( !slipgroup.equals(other.slipgroup) )
			return false;
		if ( triTag == null ){
			if ( other.triTag != null ) return false;
		}
		else if ( !triTag.equals(other.triTag) )
			return false;
		if ( applyCheckYn == null ){
			if ( other.applyCheckYn != null ) return false;
		}
		else if ( !applyCheckYn.equals(other.applyCheckYn) )
			return false;
		if ( anne1aPbl == null ){
			if ( other.anne1aPbl != null ) return false;
		}
		else if ( !anne1aPbl.equals(other.anne1aPbl) )
			return false;
		if ( anne1aDw == null ){
			if ( other.anne1aDw != null ) return false;
		}
		else if ( !anne1aDw.equals(other.anne1aDw) )
			return false;
		if ( anne1bPbl == null ){
			if ( other.anne1bPbl != null ) return false;
		}
		else if ( !anne1bPbl.equals(other.anne1bPbl) )
			return false;
		if ( anne1bDw == null ){
			if ( other.anne1bDw != null ) return false;
		}
		else if ( !anne1bDw.equals(other.anne1bDw) )
			return false;
		if ( anne2aPbl == null ){
			if ( other.anne2aPbl != null ) return false;
		}
		else if ( !anne2aPbl.equals(other.anne2aPbl) )
			return false;
		if ( anne2aDw == null ){
			if ( other.anne2aDw != null ) return false;
		}
		else if ( !anne2aDw.equals(other.anne2aDw) )
			return false;
		if ( anne2bPbl == null ){
			if ( other.anne2bPbl != null ) return false;
		}
		else if ( !anne2bPbl.equals(other.anne2bPbl) )
			return false;
		if ( anne2bDw == null ){
			if ( other.anne2bDw != null ) return false;
		}
		else if ( !anne2bDw.equals(other.anne2bDw) )
			return false;
		if ( anne3Pbl == null ){
			if ( other.anne3Pbl != null ) return false;
		}
		else if ( !anne3Pbl.equals(other.anne3Pbl) )
			return false;
		if ( anne3Dw == null ){
			if ( other.anne3Dw != null ) return false;
		}
		else if ( !anne3Dw.equals(other.anne3Dw) )
			return false;
		if ( anne4Pbl == null ){
			if ( other.anne4Pbl != null ) return false;
		}
		else if ( !anne4Pbl.equals(other.anne4Pbl) )
			return false;
		if ( anne4Dw == null ){
			if ( other.anne4Dw != null ) return false;
		}
		else if ( !anne4Dw.equals(other.anne4Dw) )
			return false;
		if ( delayday == null ){
			if ( other.delayday != null ) return false;
		}
		else if ( !delayday.equals(other.delayday) )
			return false;
		if ( delayrate == null ){
			if ( other.delayrate != null ) return false;
		}
		else if ( !delayrate.equals(other.delayrate) )
			return false;
		if ( agreeTag == null ){
			if ( other.agreeTag != null ) return false;
		}
		else if ( !agreeTag.equals(other.agreeTag) )
			return false;
		if ( indeminityTag == null ){
			if ( other.indeminityTag != null ) return false;
		}
		else if ( !indeminityTag.equals(other.indeminityTag) )
			return false;
		if ( indeminityFrdt == null ){
			if ( other.indeminityFrdt != null ) return false;
		}
		else if ( !indeminityFrdt.equals(other.indeminityFrdt) )
			return false;
		if ( indeminityTodt == null ){
			if ( other.indeminityTodt != null ) return false;
		}
		else if ( !indeminityTodt.equals(other.indeminityTodt) )
			return false;
		if ( sealtype == null ){
			if ( other.sealtype != null ) return false;
		}
		else if ( !sealtype.equals(other.sealtype) )
			return false;
		if ( jiroTag == null ){
			if ( other.jiroTag != null ) return false;
		}
		else if ( !jiroTag.equals(other.jiroTag) )
			return false;
		if ( jiroSn == null ){
			if ( other.jiroSn != null ) return false;
		}
		else if ( !jiroSn.equals(other.jiroSn) )
			return false;
		if ( hdDaymonthTag == null ){
			if ( other.hdDaymonthTag != null ) return false;
		}
		else if ( !hdDaymonthTag.equals(other.hdDaymonthTag) )
			return false;
		if ( rtDaymonthTag == null ){
			if ( other.rtDaymonthTag != null ) return false;
		}
		else if ( !rtDaymonthTag.equals(other.rtDaymonthTag) )
			return false;
		if ( rtFixrateTag == null ){
			if ( other.rtFixrateTag != null ) return false;
		}
		else if ( !rtFixrateTag.equals(other.rtFixrateTag) )
			return false;
		if ( predisTag == null ){
			if ( other.predisTag != null ) return false;
		}
		else if ( !predisTag.equals(other.predisTag) )
			return false;
		if ( proxyTag == null ){
			if ( other.proxyTag != null ) return false;
		}
		else if ( !proxyTag.equals(other.proxyTag) )
			return false;
		if ( trustTag == null ){
			if ( other.trustTag != null ) return false;
		}
		else if ( !trustTag.equals(other.trustTag) )
			return false;
		if ( printYn == null ){
			if ( other.printYn != null ) return false;
		}
		else if ( !printYn.equals(other.printYn) )
			return false;
		if ( rtFixrateDay == null ){
			if ( other.rtFixrateDay != null ) return false;
		}
		else if ( !rtFixrateDay.equals(other.rtFixrateDay) )
			return false;
		if ( rtFixrate == null ){
			if ( other.rtFixrate != null ) return false;
		}
		else if ( !rtFixrate.equals(other.rtFixrate) )
			return false;
		if ( virdeposit2Yn == null ){
			if ( other.virdeposit2Yn != null ) return false;
		}
		else if ( !virdeposit2Yn.equals(other.virdeposit2Yn) )
			return false;
		if ( virbank2Code == null ){
			if ( other.virbank2Code != null ) return false;
		}
		else if ( !virbank2Code.equals(other.virbank2Code) )
			return false;
		if ( rtFixrate2 == null ){
			if ( other.rtFixrate2 != null ) return false;
		}
		else if ( !rtFixrate2.equals(other.rtFixrate2) )
			return false;
		if ( rtExtrate == null ){
			if ( other.rtExtrate != null ) return false;
		}
		else if ( !rtExtrate.equals(other.rtExtrate) )
			return false;
		if ( rtGurtyn == null ){
			if ( other.rtGurtyn != null ) return false;
		}
		else if ( !rtGurtyn.equals(other.rtGurtyn) )
			return false;
		if ( rtRentyn == null ){
			if ( other.rtRentyn != null ) return false;
		}
		else if ( !rtRentyn.equals(other.rtRentyn) )
			return false;
		if ( oncesalerate == null ){
			if ( other.oncesalerate != null ) return false;
		}
		else if ( !oncesalerate.equals(other.oncesalerate) )
			return false;
		if ( delayBlock == null ){
			if ( other.delayBlock != null ) return false;
		}
		else if ( !delayBlock.equals(other.delayBlock) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO:\n");
		sb.append("\thistDate: ");
		sb.append(histDate==null?"null":getHistDate());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\thousedate: ");
		sb.append(housedate==null?"null":getHousedate());
		sb.append("\n");
		sb.append("\tcompletiondate: ");
		sb.append(completiondate==null?"null":getCompletiondate());
		sb.append("\n");
		sb.append("\thouseCnt: ");
		sb.append(houseCnt==null?"null":getHouseCnt());
		sb.append("\n");
		sb.append("\tmoveinstartdate: ");
		sb.append(moveinstartdate==null?"null":getMoveinstartdate());
		sb.append("\n");
		sb.append("\tmoveinenddate: ");
		sb.append(moveinenddate==null?"null":getMoveinenddate());
		sb.append("\n");
		sb.append("\tpenaltyrate: ");
		sb.append(penaltyrate==null?"null":getPenaltyrate());
		sb.append("\n");
		sb.append("\thicTag: ");
		sb.append(hicTag==null?"null":getHicTag());
		sb.append("\n");
		sb.append("\ttirmRate: ");
		sb.append(tirmRate==null?"null":getTirmRate());
		sb.append("\n");
		sb.append("\tsodukRate: ");
		sb.append(sodukRate==null?"null":getSodukRate());
		sb.append("\n");
		sb.append("\tjuminRate: ");
		sb.append(juminRate==null?"null":getJuminRate());
		sb.append("\n");
		sb.append("\tdamdang: ");
		sb.append(damdang==null?"null":getDamdang());
		sb.append("\n");
		sb.append("\tdamdangTel: ");
		sb.append(damdangTel==null?"null":getDamdangTel());
		sb.append("\n");
		sb.append("\tprintCnt: ");
		sb.append(printCnt==null?"null":getPrintCnt());
		sb.append("\n");
		sb.append("\tresellTag: ");
		sb.append(resellTag==null?"null":getResellTag());
		sb.append("\n");
		sb.append("\tvirdepositYn: ");
		sb.append(virdepositYn==null?"null":getVirdepositYn());
		sb.append("\n");
		sb.append("\tvirbankCode: ");
		sb.append(virbankCode==null?"null":getVirbankCode());
		sb.append("\n");
		sb.append("\tdeptAddrUseYn: ");
		sb.append(deptAddrUseYn==null?"null":getDeptAddrUseYn());
		sb.append("\n");
		sb.append("\tcontPblName: ");
		sb.append(contPblName==null?"null":getContPblName());
		sb.append("\n");
		sb.append("\tcontDwName: ");
		sb.append(contDwName==null?"null":getContDwName());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tcontPblName2: ");
		sb.append(contPblName2==null?"null":getContPblName2());
		sb.append("\n");
		sb.append("\tcontDwName2: ");
		sb.append(contDwName2==null?"null":getContDwName2());
		sb.append("\n");
		sb.append("\tcontPblName3: ");
		sb.append(contPblName3==null?"null":getContPblName3());
		sb.append("\n");
		sb.append("\tcontDwName3: ");
		sb.append(contDwName3==null?"null":getContDwName3());
		sb.append("\n");
		sb.append("\tslipgroup: ");
		sb.append(slipgroup==null?"null":getSlipgroup());
		sb.append("\n");
		sb.append("\ttriTag: ");
		sb.append(triTag==null?"null":getTriTag());
		sb.append("\n");
		sb.append("\tapplyCheckYn: ");
		sb.append(applyCheckYn==null?"null":getApplyCheckYn());
		sb.append("\n");
		sb.append("\tanne1aPbl: ");
		sb.append(anne1aPbl==null?"null":getAnne1aPbl());
		sb.append("\n");
		sb.append("\tanne1aDw: ");
		sb.append(anne1aDw==null?"null":getAnne1aDw());
		sb.append("\n");
		sb.append("\tanne1bPbl: ");
		sb.append(anne1bPbl==null?"null":getAnne1bPbl());
		sb.append("\n");
		sb.append("\tanne1bDw: ");
		sb.append(anne1bDw==null?"null":getAnne1bDw());
		sb.append("\n");
		sb.append("\tanne2aPbl: ");
		sb.append(anne2aPbl==null?"null":getAnne2aPbl());
		sb.append("\n");
		sb.append("\tanne2aDw: ");
		sb.append(anne2aDw==null?"null":getAnne2aDw());
		sb.append("\n");
		sb.append("\tanne2bPbl: ");
		sb.append(anne2bPbl==null?"null":getAnne2bPbl());
		sb.append("\n");
		sb.append("\tanne2bDw: ");
		sb.append(anne2bDw==null?"null":getAnne2bDw());
		sb.append("\n");
		sb.append("\tanne3Pbl: ");
		sb.append(anne3Pbl==null?"null":getAnne3Pbl());
		sb.append("\n");
		sb.append("\tanne3Dw: ");
		sb.append(anne3Dw==null?"null":getAnne3Dw());
		sb.append("\n");
		sb.append("\tanne4Pbl: ");
		sb.append(anne4Pbl==null?"null":getAnne4Pbl());
		sb.append("\n");
		sb.append("\tanne4Dw: ");
		sb.append(anne4Dw==null?"null":getAnne4Dw());
		sb.append("\n");
		sb.append("\tdelayday: ");
		sb.append(delayday==null?"null":getDelayday());
		sb.append("\n");
		sb.append("\tdelayrate: ");
		sb.append(delayrate==null?"null":getDelayrate());
		sb.append("\n");
		sb.append("\tagreeTag: ");
		sb.append(agreeTag==null?"null":getAgreeTag());
		sb.append("\n");
		sb.append("\tindeminityTag: ");
		sb.append(indeminityTag==null?"null":getIndeminityTag());
		sb.append("\n");
		sb.append("\tindeminityFrdt: ");
		sb.append(indeminityFrdt==null?"null":getIndeminityFrdt());
		sb.append("\n");
		sb.append("\tindeminityTodt: ");
		sb.append(indeminityTodt==null?"null":getIndeminityTodt());
		sb.append("\n");
		sb.append("\tsealtype: ");
		sb.append(sealtype==null?"null":getSealtype());
		sb.append("\n");
		sb.append("\tjiroTag: ");
		sb.append(jiroTag==null?"null":getJiroTag());
		sb.append("\n");
		sb.append("\tjiroSn: ");
		sb.append(jiroSn==null?"null":getJiroSn());
		sb.append("\n");
		sb.append("\thdDaymonthTag: ");
		sb.append(hdDaymonthTag==null?"null":getHdDaymonthTag());
		sb.append("\n");
		sb.append("\trtDaymonthTag: ");
		sb.append(rtDaymonthTag==null?"null":getRtDaymonthTag());
		sb.append("\n");
		sb.append("\trtFixrateTag: ");
		sb.append(rtFixrateTag==null?"null":getRtFixrateTag());
		sb.append("\n");
		sb.append("\tpredisTag: ");
		sb.append(predisTag==null?"null":getPredisTag());
		sb.append("\n");
		sb.append("\tproxyTag: ");
		sb.append(proxyTag==null?"null":getProxyTag());
		sb.append("\n");
		sb.append("\ttrustTag: ");
		sb.append(trustTag==null?"null":getTrustTag());
		sb.append("\n");
		sb.append("\tprintYn: ");
		sb.append(printYn==null?"null":getPrintYn());
		sb.append("\n");
		sb.append("\trtFixrateDay: ");
		sb.append(rtFixrateDay==null?"null":getRtFixrateDay());
		sb.append("\n");
		sb.append("\trtFixrate: ");
		sb.append(rtFixrate==null?"null":getRtFixrate());
		sb.append("\n");
		sb.append("\tvirdeposit2Yn: ");
		sb.append(virdeposit2Yn==null?"null":getVirdeposit2Yn());
		sb.append("\n");
		sb.append("\tvirbank2Code: ");
		sb.append(virbank2Code==null?"null":getVirbank2Code());
		sb.append("\n");
		sb.append("\trtFixrate2: ");
		sb.append(rtFixrate2==null?"null":getRtFixrate2());
		sb.append("\n");
		sb.append("\trtExtrate: ");
		sb.append(rtExtrate==null?"null":getRtExtrate());
		sb.append("\n");
		sb.append("\trtGurtyn: ");
		sb.append(rtGurtyn==null?"null":getRtGurtyn());
		sb.append("\n");
		sb.append("\trtRentyn: ");
		sb.append(rtRentyn==null?"null":getRtRentyn());
		sb.append("\n");
		sb.append("\toncesalerate: ");
		sb.append(oncesalerate==null?"null":getOncesalerate());
		sb.append("\n");
		sb.append("\tdelayBlock: ");
		sb.append(delayBlock==null?"null":getDelayBlock());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 7; /* histDate */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 8; /* housedate */
		messageLen+= 8; /* completiondate */
		messageLen+= 22; /* houseCnt */
		messageLen+= 8; /* moveinstartdate */
		messageLen+= 8; /* moveinenddate */
		messageLen+= 22; /* penaltyrate */
		messageLen+= 2; /* hicTag */
		messageLen+= 22; /* tirmRate */
		messageLen+= 22; /* sodukRate */
		messageLen+= 22; /* juminRate */
		messageLen+= 20; /* damdang */
		messageLen+= 20; /* damdangTel */
		messageLen+= 22; /* printCnt */
		messageLen+= 1; /* resellTag */
		messageLen+= 1; /* virdepositYn */
		messageLen+= 8; /* virbankCode */
		messageLen+= 1; /* deptAddrUseYn */
		messageLen+= 30; /* contPblName */
		messageLen+= 30; /* contDwName */
		messageLen+= 500; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 30; /* contPblName2 */
		messageLen+= 30; /* contDwName2 */
		messageLen+= 30; /* contPblName3 */
		messageLen+= 30; /* contDwName3 */
		messageLen+= 1; /* slipgroup */
		messageLen+= 1; /* triTag */
		messageLen+= 1; /* applyCheckYn */
		messageLen+= 30; /* anne1aPbl */
		messageLen+= 30; /* anne1aDw */
		messageLen+= 30; /* anne1bPbl */
		messageLen+= 30; /* anne1bDw */
		messageLen+= 30; /* anne2aPbl */
		messageLen+= 30; /* anne2aDw */
		messageLen+= 30; /* anne2bPbl */
		messageLen+= 30; /* anne2bDw */
		messageLen+= 30; /* anne3Pbl */
		messageLen+= 30; /* anne3Dw */
		messageLen+= 30; /* anne4Pbl */
		messageLen+= 30; /* anne4Dw */
		messageLen+= 22; /* delayday */
		messageLen+= 22; /* delayrate */
		messageLen+= 1; /* agreeTag */
		messageLen+= 1; /* indeminityTag */
		messageLen+= 8; /* indeminityFrdt */
		messageLen+= 8; /* indeminityTodt */
		messageLen+= 1; /* sealtype */
		messageLen+= 1; /* jiroTag */
		messageLen+= 3; /* jiroSn */
		messageLen+= 1; /* hdDaymonthTag */
		messageLen+= 1; /* rtDaymonthTag */
		messageLen+= 1; /* rtFixrateTag */
		messageLen+= 1; /* predisTag */
		messageLen+= 1; /* proxyTag */
		messageLen+= 1; /* trustTag */
		messageLen+= 1; /* printYn */
		messageLen+= 22; /* rtFixrateDay */
		messageLen+= 22; /* rtFixrate */
		messageLen+= 1; /* virdeposit2Yn */
		messageLen+= 8; /* virbank2Code */
		messageLen+= 22; /* rtFixrate2 */
		messageLen+= 22; /* rtExtrate */
		messageLen+= 1; /* rtGurtyn */
		messageLen+= 1; /* rtRentyn */
		messageLen+= 22; /* oncesalerate */
		messageLen+= 1; /* delayBlock */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("histDate");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("housedate");
	
		fieldNames.add("completiondate");
	
		fieldNames.add("houseCnt");
	
		fieldNames.add("moveinstartdate");
	
		fieldNames.add("moveinenddate");
	
		fieldNames.add("penaltyrate");
	
		fieldNames.add("hicTag");
	
		fieldNames.add("tirmRate");
	
		fieldNames.add("sodukRate");
	
		fieldNames.add("juminRate");
	
		fieldNames.add("damdang");
	
		fieldNames.add("damdangTel");
	
		fieldNames.add("printCnt");
	
		fieldNames.add("resellTag");
	
		fieldNames.add("virdepositYn");
	
		fieldNames.add("virbankCode");
	
		fieldNames.add("deptAddrUseYn");
	
		fieldNames.add("contPblName");
	
		fieldNames.add("contDwName");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("contPblName2");
	
		fieldNames.add("contDwName2");
	
		fieldNames.add("contPblName3");
	
		fieldNames.add("contDwName3");
	
		fieldNames.add("slipgroup");
	
		fieldNames.add("triTag");
	
		fieldNames.add("applyCheckYn");
	
		fieldNames.add("anne1aPbl");
	
		fieldNames.add("anne1aDw");
	
		fieldNames.add("anne1bPbl");
	
		fieldNames.add("anne1bDw");
	
		fieldNames.add("anne2aPbl");
	
		fieldNames.add("anne2aDw");
	
		fieldNames.add("anne2bPbl");
	
		fieldNames.add("anne2bDw");
	
		fieldNames.add("anne3Pbl");
	
		fieldNames.add("anne3Dw");
	
		fieldNames.add("anne4Pbl");
	
		fieldNames.add("anne4Dw");
	
		fieldNames.add("delayday");
	
		fieldNames.add("delayrate");
	
		fieldNames.add("agreeTag");
	
		fieldNames.add("indeminityTag");
	
		fieldNames.add("indeminityFrdt");
	
		fieldNames.add("indeminityTodt");
	
		fieldNames.add("sealtype");
	
		fieldNames.add("jiroTag");
	
		fieldNames.add("jiroSn");
	
		fieldNames.add("hdDaymonthTag");
	
		fieldNames.add("rtDaymonthTag");
	
		fieldNames.add("rtFixrateTag");
	
		fieldNames.add("predisTag");
	
		fieldNames.add("proxyTag");
	
		fieldNames.add("trustTag");
	
		fieldNames.add("printYn");
	
		fieldNames.add("rtFixrateDay");
	
		fieldNames.add("rtFixrate");
	
		fieldNames.add("virdeposit2Yn");
	
		fieldNames.add("virbank2Code");
	
		fieldNames.add("rtFixrate2");
	
		fieldNames.add("rtExtrate");
	
		fieldNames.add("rtGurtyn");
	
		fieldNames.add("rtRentyn");
	
		fieldNames.add("oncesalerate");
	
		fieldNames.add("delayBlock");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("histDate", get("histDate"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("housedate", get("housedate"));
	
		fieldValueMap.put("completiondate", get("completiondate"));
	
		fieldValueMap.put("houseCnt", get("houseCnt"));
	
		fieldValueMap.put("moveinstartdate", get("moveinstartdate"));
	
		fieldValueMap.put("moveinenddate", get("moveinenddate"));
	
		fieldValueMap.put("penaltyrate", get("penaltyrate"));
	
		fieldValueMap.put("hicTag", get("hicTag"));
	
		fieldValueMap.put("tirmRate", get("tirmRate"));
	
		fieldValueMap.put("sodukRate", get("sodukRate"));
	
		fieldValueMap.put("juminRate", get("juminRate"));
	
		fieldValueMap.put("damdang", get("damdang"));
	
		fieldValueMap.put("damdangTel", get("damdangTel"));
	
		fieldValueMap.put("printCnt", get("printCnt"));
	
		fieldValueMap.put("resellTag", get("resellTag"));
	
		fieldValueMap.put("virdepositYn", get("virdepositYn"));
	
		fieldValueMap.put("virbankCode", get("virbankCode"));
	
		fieldValueMap.put("deptAddrUseYn", get("deptAddrUseYn"));
	
		fieldValueMap.put("contPblName", get("contPblName"));
	
		fieldValueMap.put("contDwName", get("contDwName"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("contPblName2", get("contPblName2"));
	
		fieldValueMap.put("contDwName2", get("contDwName2"));
	
		fieldValueMap.put("contPblName3", get("contPblName3"));
	
		fieldValueMap.put("contDwName3", get("contDwName3"));
	
		fieldValueMap.put("slipgroup", get("slipgroup"));
	
		fieldValueMap.put("triTag", get("triTag"));
	
		fieldValueMap.put("applyCheckYn", get("applyCheckYn"));
	
		fieldValueMap.put("anne1aPbl", get("anne1aPbl"));
	
		fieldValueMap.put("anne1aDw", get("anne1aDw"));
	
		fieldValueMap.put("anne1bPbl", get("anne1bPbl"));
	
		fieldValueMap.put("anne1bDw", get("anne1bDw"));
	
		fieldValueMap.put("anne2aPbl", get("anne2aPbl"));
	
		fieldValueMap.put("anne2aDw", get("anne2aDw"));
	
		fieldValueMap.put("anne2bPbl", get("anne2bPbl"));
	
		fieldValueMap.put("anne2bDw", get("anne2bDw"));
	
		fieldValueMap.put("anne3Pbl", get("anne3Pbl"));
	
		fieldValueMap.put("anne3Dw", get("anne3Dw"));
	
		fieldValueMap.put("anne4Pbl", get("anne4Pbl"));
	
		fieldValueMap.put("anne4Dw", get("anne4Dw"));
	
		fieldValueMap.put("delayday", get("delayday"));
	
		fieldValueMap.put("delayrate", get("delayrate"));
	
		fieldValueMap.put("agreeTag", get("agreeTag"));
	
		fieldValueMap.put("indeminityTag", get("indeminityTag"));
	
		fieldValueMap.put("indeminityFrdt", get("indeminityFrdt"));
	
		fieldValueMap.put("indeminityTodt", get("indeminityTodt"));
	
		fieldValueMap.put("sealtype", get("sealtype"));
	
		fieldValueMap.put("jiroTag", get("jiroTag"));
	
		fieldValueMap.put("jiroSn", get("jiroSn"));
	
		fieldValueMap.put("hdDaymonthTag", get("hdDaymonthTag"));
	
		fieldValueMap.put("rtDaymonthTag", get("rtDaymonthTag"));
	
		fieldValueMap.put("rtFixrateTag", get("rtFixrateTag"));
	
		fieldValueMap.put("predisTag", get("predisTag"));
	
		fieldValueMap.put("proxyTag", get("proxyTag"));
	
		fieldValueMap.put("trustTag", get("trustTag"));
	
		fieldValueMap.put("printYn", get("printYn"));
	
		fieldValueMap.put("rtFixrateDay", get("rtFixrateDay"));
	
		fieldValueMap.put("rtFixrate", get("rtFixrate"));
	
		fieldValueMap.put("virdeposit2Yn", get("virdeposit2Yn"));
	
		fieldValueMap.put("virbank2Code", get("virbank2Code"));
	
		fieldValueMap.put("rtFixrate2", get("rtFixrate2"));
	
		fieldValueMap.put("rtExtrate", get("rtExtrate"));
	
		fieldValueMap.put("rtGurtyn", get("rtGurtyn"));
	
		fieldValueMap.put("rtRentyn", get("rtRentyn"));
	
		fieldValueMap.put("oncesalerate", get("oncesalerate"));
	
		fieldValueMap.put("delayBlock", get("delayBlock"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			return getHistDate();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 1034168014 : /* housedate */
			return getHousedate();
		case 1147110794 : /* completiondate */
			return getCompletiondate();
		case -243765719 : /* houseCnt */
			return getHouseCnt();
		case -1249212646 : /* moveinstartdate */
			return getMoveinstartdate();
		case -113122925 : /* moveinenddate */
			return getMoveinenddate();
		case -1263331095 : /* penaltyrate */
			return getPenaltyrate();
		case -1217532744 : /* hicTag */
			return getHicTag();
		case -1926898576 : /* tirmRate */
			return getTirmRate();
		case 486607902 : /* sodukRate */
			return getSodukRate();
		case 497575591 : /* juminRate */
			return getJuminRate();
		case 1436822150 : /* damdang */
			return getDamdang();
		case 724682677 : /* damdangTel */
			return getDamdangTel();
		case -1166361732 : /* printCnt */
			return getPrintCnt();
		case 2017100117 : /* resellTag */
			return getResellTag();
		case 899669268 : /* virdepositYn */
			return getVirdepositYn();
		case 1798038376 : /* virbankCode */
			return getVirbankCode();
		case -1270141754 : /* deptAddrUseYn */
			return getDeptAddrUseYn();
		case 2096987859 : /* contPblName */
			return getContPblName();
		case -673028208 : /* contDwName */
			return getContDwName();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 582114239 : /* contPblName2 */
			return getContPblName2();
		case 610962082 : /* contDwName2 */
			return getContDwName2();
		case 582114240 : /* contPblName3 */
			return getContPblName3();
		case 610962083 : /* contDwName3 */
			return getContDwName3();
		case -450177729 : /* slipgroup */
			return getSlipgroup();
		case -865492497 : /* triTag */
			return getTriTag();
		case 608422639 : /* applyCheckYn */
			return getApplyCheckYn();
		case 987108390 : /* anne1aPbl */
			return getAnne1aPbl();
		case -660894809 : /* anne1aDw */
			return getAnne1aDw();
		case 987138181 : /* anne1bPbl */
			return getAnne1bPbl();
		case -660893848 : /* anne1bDw */
			return getAnne1bDw();
		case 988031911 : /* anne2aPbl */
			return getAnne2aPbl();
		case -660865018 : /* anne2aDw */
			return getAnne2aDw();
		case 988061702 : /* anne2bPbl */
			return getAnne2bPbl();
		case -660864057 : /* anne2bDw */
			return getAnne2bDw();
		case -660850645 : /* anne3Pbl */
			return getAnne3Pbl();
		case -852602110 : /* anne3Dw */
			return getAnne3Dw();
		case -660820854 : /* anne4Pbl */
			return getAnne4Pbl();
		case -852601149 : /* anne4Dw */
			return getAnne4Dw();
		case 816166713 : /* delayday */
			return getDelayday();
		case -468218653 : /* delayrate */
			return getDelayrate();
		case 1832568142 : /* agreeTag */
			return getAgreeTag();
		case -577366216 : /* indeminityTag */
			return getIndeminityTag();
		case -718884226 : /* indeminityFrdt */
			return getIndeminityFrdt();
		case -718470035 : /* indeminityTodt */
			return getIndeminityTodt();
		case 883627703 : /* sealtype */
			return getSealtype();
		case -1594124738 : /* jiroTag */
			return getJiroTag();
		case -1159802057 : /* jiroSn */
			return getJiroSn();
		case 75964922 : /* hdDaymonthTag */
			return getHdDaymonthTag();
		case -792741644 : /* rtDaymonthTag */
			return getRtDaymonthTag();
		case 1829662919 : /* rtFixrateTag */
			return getRtFixrateTag();
		case -1347568497 : /* predisTag */
			return getPredisTag();
		case -985186740 : /* proxyTag */
			return getProxyTag();
		case 1858095650 : /* trustTag */
			return getTrustTag();
		case -314718558 : /* printYn */
			return getPrintYn();
		case 1829647561 : /* rtFixrateDay */
			return getRtFixrateDay();
		case 1232282067 : /* rtFixrate */
			return getRtFixrate();
		case 2119905512 : /* virdeposit2Yn */
			return getVirdeposit2Yn();
		case -112385212 : /* virbank2Code */
			return getVirbank2Code();
		case -453961537 : /* rtFixrate2 */
			return getRtFixrate2();
		case 770521567 : /* rtExtrate */
			return getRtExtrate();
		case -1167639641 : /* rtGurtyn */
			return getRtGurtyn();
		case -867614480 : /* rtRentyn */
			return getRtRentyn();
		case -1155162328 : /* oncesalerate */
			return getOncesalerate();
		case -1673882422 : /* delayBlock */
			return getDelayBlock();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1331109392 : /* histDate */
			setHistDate((java.lang.String) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 1034168014 : /* housedate */
			setHousedate((java.lang.String) value);
			return;
		case 1147110794 : /* completiondate */
			setCompletiondate((java.lang.String) value);
			return;
		case -243765719 : /* houseCnt */
			setHouseCnt((java.math.BigDecimal) value);
			return;
		case -1249212646 : /* moveinstartdate */
			setMoveinstartdate((java.lang.String) value);
			return;
		case -113122925 : /* moveinenddate */
			setMoveinenddate((java.lang.String) value);
			return;
		case -1263331095 : /* penaltyrate */
			setPenaltyrate((java.math.BigDecimal) value);
			return;
		case -1217532744 : /* hicTag */
			setHicTag((java.lang.String) value);
			return;
		case -1926898576 : /* tirmRate */
			setTirmRate((java.math.BigDecimal) value);
			return;
		case 486607902 : /* sodukRate */
			setSodukRate((java.math.BigDecimal) value);
			return;
		case 497575591 : /* juminRate */
			setJuminRate((java.math.BigDecimal) value);
			return;
		case 1436822150 : /* damdang */
			setDamdang((java.lang.String) value);
			return;
		case 724682677 : /* damdangTel */
			setDamdangTel((java.lang.String) value);
			return;
		case -1166361732 : /* printCnt */
			setPrintCnt((java.math.BigDecimal) value);
			return;
		case 2017100117 : /* resellTag */
			setResellTag((java.lang.String) value);
			return;
		case 899669268 : /* virdepositYn */
			setVirdepositYn((java.lang.String) value);
			return;
		case 1798038376 : /* virbankCode */
			setVirbankCode((java.lang.String) value);
			return;
		case -1270141754 : /* deptAddrUseYn */
			setDeptAddrUseYn((java.lang.String) value);
			return;
		case 2096987859 : /* contPblName */
			setContPblName((java.lang.String) value);
			return;
		case -673028208 : /* contDwName */
			setContDwName((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 582114239 : /* contPblName2 */
			setContPblName2((java.lang.String) value);
			return;
		case 610962082 : /* contDwName2 */
			setContDwName2((java.lang.String) value);
			return;
		case 582114240 : /* contPblName3 */
			setContPblName3((java.lang.String) value);
			return;
		case 610962083 : /* contDwName3 */
			setContDwName3((java.lang.String) value);
			return;
		case -450177729 : /* slipgroup */
			setSlipgroup((java.lang.String) value);
			return;
		case -865492497 : /* triTag */
			setTriTag((java.lang.String) value);
			return;
		case 608422639 : /* applyCheckYn */
			setApplyCheckYn((java.lang.String) value);
			return;
		case 987108390 : /* anne1aPbl */
			setAnne1aPbl((java.lang.String) value);
			return;
		case -660894809 : /* anne1aDw */
			setAnne1aDw((java.lang.String) value);
			return;
		case 987138181 : /* anne1bPbl */
			setAnne1bPbl((java.lang.String) value);
			return;
		case -660893848 : /* anne1bDw */
			setAnne1bDw((java.lang.String) value);
			return;
		case 988031911 : /* anne2aPbl */
			setAnne2aPbl((java.lang.String) value);
			return;
		case -660865018 : /* anne2aDw */
			setAnne2aDw((java.lang.String) value);
			return;
		case 988061702 : /* anne2bPbl */
			setAnne2bPbl((java.lang.String) value);
			return;
		case -660864057 : /* anne2bDw */
			setAnne2bDw((java.lang.String) value);
			return;
		case -660850645 : /* anne3Pbl */
			setAnne3Pbl((java.lang.String) value);
			return;
		case -852602110 : /* anne3Dw */
			setAnne3Dw((java.lang.String) value);
			return;
		case -660820854 : /* anne4Pbl */
			setAnne4Pbl((java.lang.String) value);
			return;
		case -852601149 : /* anne4Dw */
			setAnne4Dw((java.lang.String) value);
			return;
		case 816166713 : /* delayday */
			setDelayday((java.math.BigDecimal) value);
			return;
		case -468218653 : /* delayrate */
			setDelayrate((java.math.BigDecimal) value);
			return;
		case 1832568142 : /* agreeTag */
			setAgreeTag((java.lang.String) value);
			return;
		case -577366216 : /* indeminityTag */
			setIndeminityTag((java.lang.String) value);
			return;
		case -718884226 : /* indeminityFrdt */
			setIndeminityFrdt((java.lang.String) value);
			return;
		case -718470035 : /* indeminityTodt */
			setIndeminityTodt((java.lang.String) value);
			return;
		case 883627703 : /* sealtype */
			setSealtype((java.lang.String) value);
			return;
		case -1594124738 : /* jiroTag */
			setJiroTag((java.lang.String) value);
			return;
		case -1159802057 : /* jiroSn */
			setJiroSn((java.lang.String) value);
			return;
		case 75964922 : /* hdDaymonthTag */
			setHdDaymonthTag((java.lang.String) value);
			return;
		case -792741644 : /* rtDaymonthTag */
			setRtDaymonthTag((java.lang.String) value);
			return;
		case 1829662919 : /* rtFixrateTag */
			setRtFixrateTag((java.lang.String) value);
			return;
		case -1347568497 : /* predisTag */
			setPredisTag((java.lang.String) value);
			return;
		case -985186740 : /* proxyTag */
			setProxyTag((java.lang.String) value);
			return;
		case 1858095650 : /* trustTag */
			setTrustTag((java.lang.String) value);
			return;
		case -314718558 : /* printYn */
			setPrintYn((java.lang.String) value);
			return;
		case 1829647561 : /* rtFixrateDay */
			setRtFixrateDay((java.math.BigDecimal) value);
			return;
		case 1232282067 : /* rtFixrate */
			setRtFixrate((java.lang.Float) value);
			return;
		case 2119905512 : /* virdeposit2Yn */
			setVirdeposit2Yn((java.lang.String) value);
			return;
		case -112385212 : /* virbank2Code */
			setVirbank2Code((java.lang.String) value);
			return;
		case -453961537 : /* rtFixrate2 */
			setRtFixrate2((java.lang.Float) value);
			return;
		case 770521567 : /* rtExtrate */
			setRtExtrate((java.lang.Float) value);
			return;
		case -1167639641 : /* rtGurtyn */
			setRtGurtyn((java.lang.String) value);
			return;
		case -867614480 : /* rtRentyn */
			setRtRentyn((java.lang.String) value);
			return;
		case -1155162328 : /* oncesalerate */
			setOncesalerate((java.lang.Float) value);
			return;
		case -1673882422 : /* delayBlock */
			setDelayBlock((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
