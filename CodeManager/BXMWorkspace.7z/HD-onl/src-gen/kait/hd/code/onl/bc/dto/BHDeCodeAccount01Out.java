/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 분양계정 조회 Out
 */
@XmlType(propOrder={"outInsertHdCodeAcnt01"}, name="BHDeCodeAccount01Out")
@XmlRootElement(name="BHDeCodeAccount01Out")
@SuppressWarnings("all")
public class BHDeCodeAccount01Out  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -764919021L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "분양계정 조회 Out";

	/*******************************************************************************************************************************
	* Property set << outInsertHdCodeAcnt01 >> [[ */
	
	@XmlTransient
	private boolean isSet_outInsertHdCodeAcnt01 = false;
	
	protected boolean isSet_outInsertHdCodeAcnt01()
	{
		return this.isSet_outInsertHdCodeAcnt01;
	}
	
	protected void setIsSet_outInsertHdCodeAcnt01(boolean value)
	{
		this.isSet_outInsertHdCodeAcnt01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 등록 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outInsertHdCodeAcnt01  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 등록 결과
	 */
	public java.lang.Integer getOutInsertHdCodeAcnt01(){
		return outInsertHdCodeAcnt01;
	}
	
	/**
	 * @Description HD_분양_전표_계정 등록 결과
	 */
	@JsonProperty("outInsertHdCodeAcnt01")
	public void setOutInsertHdCodeAcnt01( java.lang.Integer outInsertHdCodeAcnt01 ) {
		isSet_outInsertHdCodeAcnt01 = true;
		this.outInsertHdCodeAcnt01 = outInsertHdCodeAcnt01;
	}
	
	/** Property set << outInsertHdCodeAcnt01 >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeAccount01Out clone(){
		try{
			BHDeCodeAccount01Out object= (BHDeCodeAccount01Out)super.clone();
			if ( this.outInsertHdCodeAcnt01== null ) object.outInsertHdCodeAcnt01 = null;
			else{
				object.outInsertHdCodeAcnt01 = this.outInsertHdCodeAcnt01;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((outInsertHdCodeAcnt01==null)?0:outInsertHdCodeAcnt01.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeAccount01Out other = (kait.hd.code.onl.bc.dto.BHDeCodeAccount01Out)obj;
		if ( outInsertHdCodeAcnt01 == null ){
			if ( other.outInsertHdCodeAcnt01 != null ) return false;
		}
		else if ( !outInsertHdCodeAcnt01.equals(other.outInsertHdCodeAcnt01) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeAccount01Out:\n");
		sb.append("\toutInsertHdCodeAcnt01: ");
		sb.append(outInsertHdCodeAcnt01==null?"null":getOutInsertHdCodeAcnt01());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 9; /* outInsertHdCodeAcnt01 */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("outInsertHdCodeAcnt01");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("outInsertHdCodeAcnt01", get("outInsertHdCodeAcnt01"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 517780761 : /* outInsertHdCodeAcnt01 */
			return getOutInsertHdCodeAcnt01();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 517780761 : /* outInsertHdCodeAcnt01 */
			setOutInsertHdCodeAcnt01((java.lang.Integer) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
