/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_코드_고객_자료올리기 ( HD_CODE_CUSTOMER_TXTUP )
 */
@XmlType(propOrder={"custCode", "custcodeTag", "custName", "deptCode", "handphone", "tel", "zip", "addr", "email", "processTag", "errMsg", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "addr2", "addrTag", "representName"}, name="DHDCodeCustomerTxtup01IO")
@XmlRootElement(name="DHDCodeCustomerTxtup01IO")
@SuppressWarnings("all")
public class DHDCodeCustomerTxtup01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 965915535L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_코드_고객_자료올리기 ( HD_CODE_CUSTOMER_TXTUP )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객코드 [SYS_C0012093(C),SYS_C0012911(P) SYS_C0012911(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 고객코드 [SYS_C0012093(C),SYS_C0012911(P) SYS_C0012911(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 고객코드 [SYS_C0012093(C),SYS_C0012911(P) SYS_C0012911(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custcodeTag >> [[ */
	
	@XmlTransient
	private boolean isSet_custcodeTag = false;
	
	protected boolean isSet_custcodeTag()
	{
		return this.isSet_custcodeTag;
	}
	
	protected void setIsSet_custcodeTag(boolean value)
	{
		this.isSet_custcodeTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객구분", formatType="", format="", align="left", length=3, decimal=0, arrayReference="", fill="")
	private java.lang.String custcodeTag  = null;
	
	/**
	 * @Description 고객구분
	 */
	public java.lang.String getCustcodeTag(){
		return custcodeTag;
	}
	
	/**
	 * @Description 고객구분
	 */
	@JsonProperty("custcodeTag")
	public void setCustcodeTag( java.lang.String custcodeTag ) {
		isSet_custcodeTag = true;
		this.custcodeTag = custcodeTag;
	}
	
	/** Property set << custcodeTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custName >> [[ */
	
	@XmlTransient
	private boolean isSet_custName = false;
	
	protected boolean isSet_custName()
	{
		return this.isSet_custName;
	}
	
	protected void setIsSet_custName(boolean value)
	{
		this.isSet_custName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객명", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String custName  = null;
	
	/**
	 * @Description 고객명
	 */
	public java.lang.String getCustName(){
		return custName;
	}
	
	/**
	 * @Description 고객명
	 */
	@JsonProperty("custName")
	public void setCustName( java.lang.String custName ) {
		isSet_custName = true;
		this.custName = custName;
	}
	
	/** Property set << custName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << handphone >> [[ */
	
	@XmlTransient
	private boolean isSet_handphone = false;
	
	protected boolean isSet_handphone()
	{
		return this.isSet_handphone;
	}
	
	protected void setIsSet_handphone(boolean value)
	{
		this.isSet_handphone = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="핸드폰번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String handphone  = null;
	
	/**
	 * @Description 핸드폰번호
	 */
	public java.lang.String getHandphone(){
		return handphone;
	}
	
	/**
	 * @Description 핸드폰번호
	 */
	@JsonProperty("handphone")
	public void setHandphone( java.lang.String handphone ) {
		isSet_handphone = true;
		this.handphone = handphone;
	}
	
	/** Property set << handphone >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << tel >> [[ */
	
	@XmlTransient
	private boolean isSet_tel = false;
	
	protected boolean isSet_tel()
	{
		return this.isSet_tel;
	}
	
	protected void setIsSet_tel(boolean value)
	{
		this.isSet_tel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전화번호_자택", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String tel  = null;
	
	/**
	 * @Description 전화번호_자택
	 */
	public java.lang.String getTel(){
		return tel;
	}
	
	/**
	 * @Description 전화번호_자택
	 */
	@JsonProperty("tel")
	public void setTel( java.lang.String tel ) {
		isSet_tel = true;
		this.tel = tel;
	}
	
	/** Property set << tel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << zip >> [[ */
	
	@XmlTransient
	private boolean isSet_zip = false;
	
	protected boolean isSet_zip()
	{
		return this.isSet_zip;
	}
	
	protected void setIsSet_zip(boolean value)
	{
		this.isSet_zip = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거주지우편번호 [SYS_C0012094(C)]", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String zip  = null;
	
	/**
	 * @Description 거주지우편번호 [SYS_C0012094(C)]
	 */
	public java.lang.String getZip(){
		return zip;
	}
	
	/**
	 * @Description 거주지우편번호 [SYS_C0012094(C)]
	 */
	@JsonProperty("zip")
	public void setZip( java.lang.String zip ) {
		isSet_zip = true;
		this.zip = zip;
	}
	
	/** Property set << zip >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr >> [[ */
	
	@XmlTransient
	private boolean isSet_addr = false;
	
	protected boolean isSet_addr()
	{
		return this.isSet_addr;
	}
	
	protected void setIsSet_addr(boolean value)
	{
		this.isSet_addr = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거주지주소 [SYS_C0012095(C)]", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr  = null;
	
	/**
	 * @Description 거주지주소 [SYS_C0012095(C)]
	 */
	public java.lang.String getAddr(){
		return addr;
	}
	
	/**
	 * @Description 거주지주소 [SYS_C0012095(C)]
	 */
	@JsonProperty("addr")
	public void setAddr( java.lang.String addr ) {
		isSet_addr = true;
		this.addr = addr;
	}
	
	/** Property set << addr >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << email >> [[ */
	
	@XmlTransient
	private boolean isSet_email = false;
	
	protected boolean isSet_email()
	{
		return this.isSet_email;
	}
	
	protected void setIsSet_email(boolean value)
	{
		this.isSet_email = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이메일", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String email  = null;
	
	/**
	 * @Description 이메일
	 */
	public java.lang.String getEmail(){
		return email;
	}
	
	/**
	 * @Description 이메일
	 */
	@JsonProperty("email")
	public void setEmail( java.lang.String email ) {
		isSet_email = true;
		this.email = email;
	}
	
	/** Property set << email >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << processTag >> [[ */
	
	@XmlTransient
	private boolean isSet_processTag = false;
	
	protected boolean isSet_processTag()
	{
		return this.isSet_processTag;
	}
	
	protected void setIsSet_processTag(boolean value)
	{
		this.isSet_processTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="처리구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String processTag  = null;
	
	/**
	 * @Description 처리구분
	 */
	public java.lang.String getProcessTag(){
		return processTag;
	}
	
	/**
	 * @Description 처리구분
	 */
	@JsonProperty("processTag")
	public void setProcessTag( java.lang.String processTag ) {
		isSet_processTag = true;
		this.processTag = processTag;
	}
	
	/** Property set << processTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << errMsg >> [[ */
	
	@XmlTransient
	private boolean isSet_errMsg = false;
	
	protected boolean isSet_errMsg()
	{
		return this.isSet_errMsg;
	}
	
	protected void setIsSet_errMsg(boolean value)
	{
		this.isSet_errMsg = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="오류내용", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String errMsg  = null;
	
	/**
	 * @Description 오류내용
	 */
	public java.lang.String getErrMsg(){
		return errMsg;
	}
	
	/**
	 * @Description 오류내용
	 */
	@JsonProperty("errMsg")
	public void setErrMsg( java.lang.String errMsg ) {
		isSet_errMsg = true;
		this.errMsg = errMsg;
	}
	
	/** Property set << errMsg >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addr2 >> [[ */
	
	@XmlTransient
	private boolean isSet_addr2 = false;
	
	protected boolean isSet_addr2()
	{
		return this.isSet_addr2;
	}
	
	protected void setIsSet_addr2(boolean value)
	{
		this.isSet_addr2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상세주소", formatType="", format="", align="left", length=300, decimal=0, arrayReference="", fill="")
	private java.lang.String addr2  = null;
	
	/**
	 * @Description 상세주소
	 */
	public java.lang.String getAddr2(){
		return addr2;
	}
	
	/**
	 * @Description 상세주소
	 */
	@JsonProperty("addr2")
	public void setAddr2( java.lang.String addr2 ) {
		isSet_addr2 = true;
		this.addr2 = addr2;
	}
	
	/** Property set << addr2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << addrTag >> [[ */
	
	@XmlTransient
	private boolean isSet_addrTag = false;
	
	protected boolean isSet_addrTag()
	{
		return this.isSet_addrTag;
	}
	
	protected void setIsSet_addrTag(boolean value)
	{
		this.isSet_addrTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="주소_구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String addrTag  = null;
	
	/**
	 * @Description 주소_구분
	 */
	public java.lang.String getAddrTag(){
		return addrTag;
	}
	
	/**
	 * @Description 주소_구분
	 */
	@JsonProperty("addrTag")
	public void setAddrTag( java.lang.String addrTag ) {
		isSet_addrTag = true;
		this.addrTag = addrTag;
	}
	
	/** Property set << addrTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << representName >> [[ */
	
	@XmlTransient
	private boolean isSet_representName = false;
	
	protected boolean isSet_representName()
	{
		return this.isSet_representName;
	}
	
	protected void setIsSet_representName(boolean value)
	{
		this.isSet_representName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String representName  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRepresentName(){
		return representName;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("representName")
	public void setRepresentName( java.lang.String representName ) {
		isSet_representName = true;
		this.representName = representName;
	}
	
	/** Property set << representName >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDCodeCustomerTxtup01IO clone(){
		try{
			DHDCodeCustomerTxtup01IO object= (DHDCodeCustomerTxtup01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.custcodeTag== null ) object.custcodeTag = null;
			else{
				object.custcodeTag = this.custcodeTag;
			}
			if ( this.custName== null ) object.custName = null;
			else{
				object.custName = this.custName;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.handphone== null ) object.handphone = null;
			else{
				object.handphone = this.handphone;
			}
			if ( this.tel== null ) object.tel = null;
			else{
				object.tel = this.tel;
			}
			if ( this.zip== null ) object.zip = null;
			else{
				object.zip = this.zip;
			}
			if ( this.addr== null ) object.addr = null;
			else{
				object.addr = this.addr;
			}
			if ( this.email== null ) object.email = null;
			else{
				object.email = this.email;
			}
			if ( this.processTag== null ) object.processTag = null;
			else{
				object.processTag = this.processTag;
			}
			if ( this.errMsg== null ) object.errMsg = null;
			else{
				object.errMsg = this.errMsg;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.addr2== null ) object.addr2 = null;
			else{
				object.addr2 = this.addr2;
			}
			if ( this.addrTag== null ) object.addrTag = null;
			else{
				object.addrTag = this.addrTag;
			}
			if ( this.representName== null ) object.representName = null;
			else{
				object.representName = this.representName;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((custcodeTag==null)?0:custcodeTag.hashCode());
		result = prime * result + ((custName==null)?0:custName.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((handphone==null)?0:handphone.hashCode());
		result = prime * result + ((tel==null)?0:tel.hashCode());
		result = prime * result + ((zip==null)?0:zip.hashCode());
		result = prime * result + ((addr==null)?0:addr.hashCode());
		result = prime * result + ((email==null)?0:email.hashCode());
		result = prime * result + ((processTag==null)?0:processTag.hashCode());
		result = prime * result + ((errMsg==null)?0:errMsg.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((addr2==null)?0:addr2.hashCode());
		result = prime * result + ((addrTag==null)?0:addrTag.hashCode());
		result = prime * result + ((representName==null)?0:representName.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO other = (kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( custcodeTag == null ){
			if ( other.custcodeTag != null ) return false;
		}
		else if ( !custcodeTag.equals(other.custcodeTag) )
			return false;
		if ( custName == null ){
			if ( other.custName != null ) return false;
		}
		else if ( !custName.equals(other.custName) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( handphone == null ){
			if ( other.handphone != null ) return false;
		}
		else if ( !handphone.equals(other.handphone) )
			return false;
		if ( tel == null ){
			if ( other.tel != null ) return false;
		}
		else if ( !tel.equals(other.tel) )
			return false;
		if ( zip == null ){
			if ( other.zip != null ) return false;
		}
		else if ( !zip.equals(other.zip) )
			return false;
		if ( addr == null ){
			if ( other.addr != null ) return false;
		}
		else if ( !addr.equals(other.addr) )
			return false;
		if ( email == null ){
			if ( other.email != null ) return false;
		}
		else if ( !email.equals(other.email) )
			return false;
		if ( processTag == null ){
			if ( other.processTag != null ) return false;
		}
		else if ( !processTag.equals(other.processTag) )
			return false;
		if ( errMsg == null ){
			if ( other.errMsg != null ) return false;
		}
		else if ( !errMsg.equals(other.errMsg) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( addr2 == null ){
			if ( other.addr2 != null ) return false;
		}
		else if ( !addr2.equals(other.addr2) )
			return false;
		if ( addrTag == null ){
			if ( other.addrTag != null ) return false;
		}
		else if ( !addrTag.equals(other.addrTag) )
			return false;
		if ( representName == null ){
			if ( other.representName != null ) return false;
		}
		else if ( !representName.equals(other.representName) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tcustcodeTag: ");
		sb.append(custcodeTag==null?"null":getCustcodeTag());
		sb.append("\n");
		sb.append("\tcustName: ");
		sb.append(custName==null?"null":getCustName());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thandphone: ");
		sb.append(handphone==null?"null":getHandphone());
		sb.append("\n");
		sb.append("\ttel: ");
		sb.append(tel==null?"null":getTel());
		sb.append("\n");
		sb.append("\tzip: ");
		sb.append(zip==null?"null":getZip());
		sb.append("\n");
		sb.append("\taddr: ");
		sb.append(addr==null?"null":getAddr());
		sb.append("\n");
		sb.append("\temail: ");
		sb.append(email==null?"null":getEmail());
		sb.append("\n");
		sb.append("\tprocessTag: ");
		sb.append(processTag==null?"null":getProcessTag());
		sb.append("\n");
		sb.append("\terrMsg: ");
		sb.append(errMsg==null?"null":getErrMsg());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\taddr2: ");
		sb.append(addr2==null?"null":getAddr2());
		sb.append("\n");
		sb.append("\taddrTag: ");
		sb.append(addrTag==null?"null":getAddrTag());
		sb.append("\n");
		sb.append("\trepresentName: ");
		sb.append(representName==null?"null":getRepresentName());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 3; /* custcodeTag */
		messageLen+= 50; /* custName */
		messageLen+= 12; /* deptCode */
		messageLen+= 20; /* handphone */
		messageLen+= 20; /* tel */
		messageLen+= 6; /* zip */
		messageLen+= 300; /* addr */
		messageLen+= 50; /* email */
		messageLen+= 1; /* processTag */
		messageLen+= 100; /* errMsg */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 300; /* addr2 */
		messageLen+= 1; /* addrTag */
		messageLen+= 50; /* representName */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("custcodeTag");
	
		fieldNames.add("custName");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("handphone");
	
		fieldNames.add("tel");
	
		fieldNames.add("zip");
	
		fieldNames.add("addr");
	
		fieldNames.add("email");
	
		fieldNames.add("processTag");
	
		fieldNames.add("errMsg");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("addr2");
	
		fieldNames.add("addrTag");
	
		fieldNames.add("representName");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("custcodeTag", get("custcodeTag"));
	
		fieldValueMap.put("custName", get("custName"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("handphone", get("handphone"));
	
		fieldValueMap.put("tel", get("tel"));
	
		fieldValueMap.put("zip", get("zip"));
	
		fieldValueMap.put("addr", get("addr"));
	
		fieldValueMap.put("email", get("email"));
	
		fieldValueMap.put("processTag", get("processTag"));
	
		fieldValueMap.put("errMsg", get("errMsg"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("addr2", get("addr2"));
	
		fieldValueMap.put("addrTag", get("addrTag"));
	
		fieldValueMap.put("representName", get("representName"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 518732986 : /* custcodeTag */
			return getCustcodeTag();
		case 605180798 : /* custName */
			return getCustName();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case 67922527 : /* handphone */
			return getHandphone();
		case 114715 : /* tel */
			return getTel();
		case 120609 : /* zip */
			return getZip();
		case 2989041 : /* addr */
			return getAddr();
		case 96619420 : /* email */
			return getEmail();
		case 422174379 : /* processTag */
			return getProcessTag();
		case -1294667812 : /* errMsg */
			return getErrMsg();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case 92660321 : /* addr2 */
			return getAddr2();
		case -1147708951 : /* addrTag */
			return getAddrTag();
		case -160778797 : /* representName */
			return getRepresentName();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 518732986 : /* custcodeTag */
			setCustcodeTag((java.lang.String) value);
			return;
		case 605180798 : /* custName */
			setCustName((java.lang.String) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case 67922527 : /* handphone */
			setHandphone((java.lang.String) value);
			return;
		case 114715 : /* tel */
			setTel((java.lang.String) value);
			return;
		case 120609 : /* zip */
			setZip((java.lang.String) value);
			return;
		case 2989041 : /* addr */
			setAddr((java.lang.String) value);
			return;
		case 96619420 : /* email */
			setEmail((java.lang.String) value);
			return;
		case 422174379 : /* processTag */
			setProcessTag((java.lang.String) value);
			return;
		case -1294667812 : /* errMsg */
			setErrMsg((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case 92660321 : /* addr2 */
			setAddr2((java.lang.String) value);
			return;
		case -1147708951 : /* addrTag */
			setAddrTag((java.lang.String) value);
			return;
		case -160778797 : /* representName */
			setRepresentName((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
