/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 현장 다건조회 Out
 */
@XmlType(propOrder={"outInsertHdAcmastE01", "outDHDCodeAcnt01IO", "outSelectCountHdCodeAgency01", "outSelectListHdCodeAcnt01Cnt", "outSelectListHdCodeAcnt01List"}, name="BHDeCodeTest02Out")
@XmlRootElement(name="BHDeCodeTest02Out")
@SuppressWarnings("all")
public class BHDeCodeTest02Out  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -846696985L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "현장 다건조회 Out";

	/*******************************************************************************************************************************
	* Property set << outInsertHdAcmastE01 >> [[ */
	
	@XmlTransient
	private boolean isSet_outInsertHdAcmastE01 = false;
	
	protected boolean isSet_outInsertHdAcmastE01()
	{
		return this.isSet_outInsertHdAcmastE01;
	}
	
	protected void setIsSet_outInsertHdAcmastE01(boolean value)
	{
		this.isSet_outInsertHdAcmastE01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_ACMAST_E 등록 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outInsertHdAcmastE01  = 0;
	
	/**
	 * @Description HD_ACMAST_E 등록 결과
	 */
	public java.lang.Integer getOutInsertHdAcmastE01(){
		return outInsertHdAcmastE01;
	}
	
	/**
	 * @Description HD_ACMAST_E 등록 결과
	 */
	@JsonProperty("outInsertHdAcmastE01")
	public void setOutInsertHdAcmastE01( java.lang.Integer outInsertHdAcmastE01 ) {
		isSet_outInsertHdAcmastE01 = true;
		this.outInsertHdAcmastE01 = outInsertHdAcmastE01;
	}
	
	/** Property set << outInsertHdAcmastE01 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outDHDCodeAcnt01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_outDHDCodeAcnt01IO = false;
	
	protected boolean isSet_outDHDCodeAcnt01IO()
	{
		return this.isSet_outDHDCodeAcnt01IO;
	}
	
	protected void setIsSet_outDHDCodeAcnt01IO(boolean value)
	{
		this.isSet_outDHDCodeAcnt01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO outDHDCodeAcnt01IO  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getOutDHDCodeAcnt01IO(){
		return outDHDCodeAcnt01IO;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("outDHDCodeAcnt01IO")
	public void setOutDHDCodeAcnt01IO( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO outDHDCodeAcnt01IO ) {
		isSet_outDHDCodeAcnt01IO = true;
		this.outDHDCodeAcnt01IO = outDHDCodeAcnt01IO;
	}
	
	/** Property set << outDHDCodeAcnt01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectCountHdCodeAgency01 >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectCountHdCodeAgency01 = false;
	
	protected boolean isSet_outSelectCountHdCodeAgency01()
	{
		return this.isSet_outSelectCountHdCodeAgency01;
	}
	
	protected void setIsSet_outSelectCountHdCodeAgency01(boolean value)
	{
		this.isSet_outSelectCountHdCodeAgency01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 전채건수조회 결과", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outSelectCountHdCodeAgency01  = 0;
	
	/**
	 * @Description HD_코드-대행사 전채건수조회 결과
	 */
	public java.lang.Integer getOutSelectCountHdCodeAgency01(){
		return outSelectCountHdCodeAgency01;
	}
	
	/**
	 * @Description HD_코드-대행사 전채건수조회 결과
	 */
	@JsonProperty("outSelectCountHdCodeAgency01")
	public void setOutSelectCountHdCodeAgency01( java.lang.Integer outSelectCountHdCodeAgency01 ) {
		isSet_outSelectCountHdCodeAgency01 = true;
		this.outSelectCountHdCodeAgency01 = outSelectCountHdCodeAgency01;
	}
	
	/** Property set << outSelectCountHdCodeAgency01 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01Cnt >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01Cnt = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01Cnt()
	{
		return this.isSet_outSelectListHdCodeAcnt01Cnt;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01Cnt(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01Cnt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과 건수", formatType="", format="", align="right", length=9, decimal=0, arrayReference="", fill="")
	private java.lang.Integer outSelectListHdCodeAcnt01Cnt  = 0;
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	public java.lang.Integer getOutSelectListHdCodeAcnt01Cnt(){
		/*
		 * 이 변수는 배열 또는 BLOB, CLOB에 의해 참조 되는 변수 입니다.
		 */
		if ( isSet_outSelectListHdCodeAcnt01Cnt )	return outSelectListHdCodeAcnt01Cnt;
		else
		{
			if ( outSelectListHdCodeAcnt01List == null || outSelectListHdCodeAcnt01List.size() == 0 ) return 0;
			else return outSelectListHdCodeAcnt01List.size();
		}
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과 건수
	 */
	@JsonProperty("outSelectListHdCodeAcnt01Cnt")
	public void setOutSelectListHdCodeAcnt01Cnt( java.lang.Integer outSelectListHdCodeAcnt01Cnt ) {
		isSet_outSelectListHdCodeAcnt01Cnt = true;
		this.outSelectListHdCodeAcnt01Cnt = outSelectListHdCodeAcnt01Cnt;
	}
	
	/** Property set << outSelectListHdCodeAcnt01Cnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSelectListHdCodeAcnt01List >> [[ */
	
	@XmlTransient
	private boolean isSet_outSelectListHdCodeAcnt01List = false;
	
	protected boolean isSet_outSelectListHdCodeAcnt01List()
	{
		return this.isSet_outSelectListHdCodeAcnt01List;
	}
	
	protected void setIsSet_outSelectListHdCodeAcnt01List(boolean value)
	{
		this.isSet_outSelectListHdCodeAcnt01List = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 목록조회 결과", formatType="", format="", align="left", length=0, decimal=0, arrayReference="outSelectListHdCodeAcnt01Cnt", fill="")
	private java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List  = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>();
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	public java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>  getOutSelectListHdCodeAcnt01List(){
		return outSelectListHdCodeAcnt01List;
	}
	
	/**
	 * @Description HD_분양_전표_계정 목록조회 결과
	 */
	@JsonProperty("outSelectListHdCodeAcnt01List")
	public void setOutSelectListHdCodeAcnt01List( java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List ) {
		isSet_outSelectListHdCodeAcnt01List = true;
		this.outSelectListHdCodeAcnt01List = outSelectListHdCodeAcnt01List;
	}
	
	/** Property set << outSelectListHdCodeAcnt01List >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeTest02Out clone(){
		try{
			BHDeCodeTest02Out object= (BHDeCodeTest02Out)super.clone();
			if ( this.outInsertHdAcmastE01== null ) object.outInsertHdAcmastE01 = null;
			else{
				object.outInsertHdAcmastE01 = this.outInsertHdAcmastE01;
			}
			if ( this.outDHDCodeAcnt01IO== null ) object.outDHDCodeAcnt01IO = null;
			else{
				object.outDHDCodeAcnt01IO = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.outDHDCodeAcnt01IO.clone();
			}
			if ( this.outSelectCountHdCodeAgency01== null ) object.outSelectCountHdCodeAgency01 = null;
			else{
				object.outSelectCountHdCodeAgency01 = this.outSelectCountHdCodeAgency01;
			}
			if ( this.outSelectListHdCodeAcnt01Cnt== null ) object.outSelectListHdCodeAcnt01Cnt = null;
			else{
				object.outSelectListHdCodeAcnt01Cnt = this.outSelectListHdCodeAcnt01Cnt;
			}
			if ( this.outSelectListHdCodeAcnt01List== null ) object.outSelectListHdCodeAcnt01List = null;
			else{
				java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> clonedList = new java.util.ArrayList<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>(outSelectListHdCodeAcnt01List.size());
				for( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO item : outSelectListHdCodeAcnt01List ){
					clonedList.add( (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)item.clone());
				}
				object.outSelectListHdCodeAcnt01List = clonedList;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((outInsertHdAcmastE01==null)?0:outInsertHdAcmastE01.hashCode());
		result = prime * result + ((outDHDCodeAcnt01IO==null)?0:outDHDCodeAcnt01IO.hashCode());
		result = prime * result + ((outSelectCountHdCodeAgency01==null)?0:outSelectCountHdCodeAgency01.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01Cnt==null)?0:outSelectListHdCodeAcnt01Cnt.hashCode());
		result = prime * result + ((outSelectListHdCodeAcnt01List==null)?0:outSelectListHdCodeAcnt01List.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeTest02Out other = (kait.hd.code.onl.bc.dto.BHDeCodeTest02Out)obj;
		if ( outInsertHdAcmastE01 == null ){
			if ( other.outInsertHdAcmastE01 != null ) return false;
		}
		else if ( !outInsertHdAcmastE01.equals(other.outInsertHdAcmastE01) )
			return false;
		if ( outDHDCodeAcnt01IO == null ){
			if ( other.outDHDCodeAcnt01IO != null ) return false;
		}
		else if ( !outDHDCodeAcnt01IO.equals(other.outDHDCodeAcnt01IO) )
			return false;
		if ( outSelectCountHdCodeAgency01 == null ){
			if ( other.outSelectCountHdCodeAgency01 != null ) return false;
		}
		else if ( !outSelectCountHdCodeAgency01.equals(other.outSelectCountHdCodeAgency01) )
			return false;
		if ( outSelectListHdCodeAcnt01Cnt == null ){
			if ( other.outSelectListHdCodeAcnt01Cnt != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01Cnt.equals(other.outSelectListHdCodeAcnt01Cnt) )
			return false;
		if ( outSelectListHdCodeAcnt01List == null ){
			if ( other.outSelectListHdCodeAcnt01List != null ) return false;
		}
		else if ( !outSelectListHdCodeAcnt01List.equals(other.outSelectListHdCodeAcnt01List) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeTest02Out:\n");
		sb.append("\toutInsertHdAcmastE01: ");
		sb.append(outInsertHdAcmastE01==null?"null":getOutInsertHdAcmastE01());
		sb.append("\n");
		sb.append("\toutDHDCodeAcnt01IO: ");
		sb.append(outDHDCodeAcnt01IO==null?"null":getOutDHDCodeAcnt01IO());
		sb.append("\n");
		sb.append("\toutSelectCountHdCodeAgency01: ");
		sb.append(outSelectCountHdCodeAgency01==null?"null":getOutSelectCountHdCodeAgency01());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01Cnt: ");
		sb.append(outSelectListHdCodeAcnt01Cnt==null?"null":getOutSelectListHdCodeAcnt01Cnt());
		sb.append("\n");
		sb.append("\toutSelectListHdCodeAcnt01List: ");
		if ( outSelectListHdCodeAcnt01List == null ) sb.append("null");
		else{
			sb.append("array count : ");
			sb.append(outSelectListHdCodeAcnt01List.size());
			sb.append("(items)\n");
	
			int max= (10<outSelectListHdCodeAcnt01List.size())?10:outSelectListHdCodeAcnt01List.size();
	
			for ( int i = 0; i < max; ++i ){
				sb.append("\toutSelectListHdCodeAcnt01List[");
				sb.append(i);
				sb.append("] : ");
				sb.append(outSelectListHdCodeAcnt01List.get(i));
				sb.append("\n");
			}
	
			if ( max < outSelectListHdCodeAcnt01List.size() ){
				sb.append("\toutSelectListHdCodeAcnt01List[.] : ").append("more ").append((outSelectListHdCodeAcnt01List.size()-max)).append(" items").append("\n");
			}
		}
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 9; /* outInsertHdAcmastE01 */
		if ( outDHDCodeAcnt01IO != null && !(outDHDCodeAcnt01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= outDHDCodeAcnt01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* outDHDCodeAcnt01IO */
		}
		messageLen+= 9; /* outSelectCountHdCodeAgency01 */
		messageLen+= 9; /* outSelectListHdCodeAcnt01Cnt */
		{/*outSelectListHdCodeAcnt01List*/
			int size=getOutSelectListHdCodeAcnt01Cnt();
			int count= outSelectListHdCodeAcnt01List.size();
			int min= size > count?count:size;
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO emptyElement= null;
			for ( int i = 0; i < size ; ++i ){
				if ( i < min ){
					kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO element= outSelectListHdCodeAcnt01List.get(i);
					if ( element != null && !(element instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= element==null?0:( (Predictable)element).predictMessageLength();
				}else{
					if ( emptyElement== null ) emptyElement= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
					if ( !(emptyElement instanceof Predictable) )
						throw new IllegalStateException( "Can not predict message length.");
					messageLen+= ( (Predictable)emptyElement).predictMessageLength();
				}
			}
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("outInsertHdAcmastE01");
	
		fieldNames.add("outDHDCodeAcnt01IO");
	
		fieldNames.add("outSelectCountHdCodeAgency01");
	
		fieldNames.add("outSelectListHdCodeAcnt01Cnt");
	
		fieldNames.add("outSelectListHdCodeAcnt01List");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("outInsertHdAcmastE01", get("outInsertHdAcmastE01"));
	
		fieldValueMap.put("outDHDCodeAcnt01IO", get("outDHDCodeAcnt01IO"));
	
		fieldValueMap.put("outSelectCountHdCodeAgency01", get("outSelectCountHdCodeAgency01"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01Cnt", get("outSelectListHdCodeAcnt01Cnt"));
	
		fieldValueMap.put("outSelectListHdCodeAcnt01List", get("outSelectListHdCodeAcnt01List"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -356878388 : /* outInsertHdAcmastE01 */
			return getOutInsertHdAcmastE01();
		case 606999726 : /* outDHDCodeAcnt01IO */
			return getOutDHDCodeAcnt01IO();
		case 192570772 : /* outSelectCountHdCodeAgency01 */
			return getOutSelectCountHdCodeAgency01();
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			return getOutSelectListHdCodeAcnt01Cnt();
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			return getOutSelectListHdCodeAcnt01List();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -356878388 : /* outInsertHdAcmastE01 */
			setOutInsertHdAcmastE01((java.lang.Integer) value);
			return;
		case 606999726 : /* outDHDCodeAcnt01IO */
			setOutDHDCodeAcnt01IO((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		case 192570772 : /* outSelectCountHdCodeAgency01 */
			setOutSelectCountHdCodeAgency01((java.lang.Integer) value);
			return;
		case 846568815 : /* outSelectListHdCodeAcnt01Cnt */
			setOutSelectListHdCodeAcnt01Cnt((java.lang.Integer) value);
			return;
		case 474092888 : /* outSelectListHdCodeAcnt01List */
			setOutSelectListHdCodeAcnt01List((java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO>) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
