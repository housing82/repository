/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.code.onl.bc.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description 현장 다건조회 In
 */
@XmlType(propOrder={"inDHDAcmastE01IO", "inDHDCodeAcnt01IO", "inDHDCodeAgency01IO", "inDHDCodeAcnt01IO01"}, name="BHDeCodeTest01In")
@XmlRootElement(name="BHDeCodeTest01In")
@SuppressWarnings("all")
public class BHDeCodeTest01In  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1412787285L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "현장 다건조회 In";

	/*******************************************************************************************************************************
	* Property set << inDHDAcmastE01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDAcmastE01IO = false;
	
	protected boolean isSet_inDHDAcmastE01IO()
	{
		return this.isSet_inDHDAcmastE01IO;
	}
	
	protected void setIsSet_inDHDAcmastE01IO(boolean value)
	{
		this.isSet_inDHDAcmastE01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_ACMAST_E", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO inDHDAcmastE01IO  = null;
	
	/**
	 * @Description HD_ACMAST_E
	 */
	public kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO getInDHDAcmastE01IO(){
		return inDHDAcmastE01IO;
	}
	
	/**
	 * @Description HD_ACMAST_E
	 */
	@JsonProperty("inDHDAcmastE01IO")
	public void setInDHDAcmastE01IO( kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO inDHDAcmastE01IO ) {
		isSet_inDHDAcmastE01IO = true;
		this.inDHDAcmastE01IO = inDHDAcmastE01IO;
	}
	
	/** Property set << inDHDAcmastE01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDHDCodeAcnt01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDCodeAcnt01IO = false;
	
	protected boolean isSet_inDHDCodeAcnt01IO()
	{
		return this.isSet_inDHDCodeAcnt01IO;
	}
	
	protected void setIsSet_inDHDCodeAcnt01IO(boolean value)
	{
		this.isSet_inDHDCodeAcnt01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getInDHDCodeAcnt01IO(){
		return inDHDCodeAcnt01IO;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inDHDCodeAcnt01IO")
	public void setInDHDCodeAcnt01IO( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO ) {
		isSet_inDHDCodeAcnt01IO = true;
		this.inDHDCodeAcnt01IO = inDHDCodeAcnt01IO;
	}
	
	/** Property set << inDHDCodeAcnt01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDHDCodeAgency01IO >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDCodeAgency01IO = false;
	
	protected boolean isSet_inDHDCodeAgency01IO()
	{
		return this.isSet_inDHDCodeAgency01IO;
	}
	
	protected void setIsSet_inDHDCodeAgency01IO(boolean value)
	{
		this.isSet_inDHDCodeAgency01IO = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_코드-대행사 ( HD_CODE_AGENCY )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAgency01IO inDHDCodeAgency01IO  = null;
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAgency01IO getInDHDCodeAgency01IO(){
		return inDHDCodeAgency01IO;
	}
	
	/**
	 * @Description HD_코드-대행사 ( HD_CODE_AGENCY )
	 */
	@JsonProperty("inDHDCodeAgency01IO")
	public void setInDHDCodeAgency01IO( kait.hd.code.onl.dao.dto.DHDCodeAgency01IO inDHDCodeAgency01IO ) {
		isSet_inDHDCodeAgency01IO = true;
		this.inDHDCodeAgency01IO = inDHDCodeAgency01IO;
	}
	
	/** Property set << inDHDCodeAgency01IO >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inDHDCodeAcnt01IO01 >> [[ */
	
	@XmlTransient
	private boolean isSet_inDHDCodeAcnt01IO01 = false;
	
	protected boolean isSet_inDHDCodeAcnt01IO01()
	{
		return this.isSet_inDHDCodeAcnt01IO01;
	}
	
	protected void setIsSet_inDHDCodeAcnt01IO01(boolean value)
	{
		this.isSet_inDHDCodeAcnt01IO01 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="HD_분양_전표_계정 ( HD_CODE_ACNT )", formatType="", format="", align="left", length=0, decimal=0, arrayReference="", fill="")
	private kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO01  = null;
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	public kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO getInDHDCodeAcnt01IO01(){
		return inDHDCodeAcnt01IO01;
	}
	
	/**
	 * @Description HD_분양_전표_계정 ( HD_CODE_ACNT )
	 */
	@JsonProperty("inDHDCodeAcnt01IO01")
	public void setInDHDCodeAcnt01IO01( kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO inDHDCodeAcnt01IO01 ) {
		isSet_inDHDCodeAcnt01IO01 = true;
		this.inDHDCodeAcnt01IO01 = inDHDCodeAcnt01IO01;
	}
	
	/** Property set << inDHDCodeAcnt01IO01 >> ]]
	*******************************************************************************************************************************/

	@Override
	public BHDeCodeTest01In clone(){
		try{
			BHDeCodeTest01In object= (BHDeCodeTest01In)super.clone();
			if ( this.inDHDAcmastE01IO== null ) object.inDHDAcmastE01IO = null;
			else{
				object.inDHDAcmastE01IO = (kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO)this.inDHDAcmastE01IO.clone();
			}
			if ( this.inDHDCodeAcnt01IO== null ) object.inDHDCodeAcnt01IO = null;
			else{
				object.inDHDCodeAcnt01IO = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.inDHDCodeAcnt01IO.clone();
			}
			if ( this.inDHDCodeAgency01IO== null ) object.inDHDCodeAgency01IO = null;
			else{
				object.inDHDCodeAgency01IO = (kait.hd.code.onl.dao.dto.DHDCodeAgency01IO)this.inDHDCodeAgency01IO.clone();
			}
			if ( this.inDHDCodeAcnt01IO01== null ) object.inDHDCodeAcnt01IO01 = null;
			else{
				object.inDHDCodeAcnt01IO01 = (kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO)this.inDHDCodeAcnt01IO01.clone();
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((inDHDAcmastE01IO==null)?0:inDHDAcmastE01IO.hashCode());
		result = prime * result + ((inDHDCodeAcnt01IO==null)?0:inDHDCodeAcnt01IO.hashCode());
		result = prime * result + ((inDHDCodeAgency01IO==null)?0:inDHDCodeAgency01IO.hashCode());
		result = prime * result + ((inDHDCodeAcnt01IO01==null)?0:inDHDCodeAcnt01IO01.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.code.onl.bc.dto.BHDeCodeTest01In other = (kait.hd.code.onl.bc.dto.BHDeCodeTest01In)obj;
		if ( inDHDAcmastE01IO == null ){
			if ( other.inDHDAcmastE01IO != null ) return false;
		}
		else if ( !inDHDAcmastE01IO.equals(other.inDHDAcmastE01IO) )
			return false;
		if ( inDHDCodeAcnt01IO == null ){
			if ( other.inDHDCodeAcnt01IO != null ) return false;
		}
		else if ( !inDHDCodeAcnt01IO.equals(other.inDHDCodeAcnt01IO) )
			return false;
		if ( inDHDCodeAgency01IO == null ){
			if ( other.inDHDCodeAgency01IO != null ) return false;
		}
		else if ( !inDHDCodeAgency01IO.equals(other.inDHDCodeAgency01IO) )
			return false;
		if ( inDHDCodeAcnt01IO01 == null ){
			if ( other.inDHDCodeAcnt01IO01 != null ) return false;
		}
		else if ( !inDHDCodeAcnt01IO01.equals(other.inDHDCodeAcnt01IO01) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.code.onl.bc.dto.BHDeCodeTest01In:\n");
		sb.append("\tinDHDAcmastE01IO: ");
		sb.append(inDHDAcmastE01IO==null?"null":getInDHDAcmastE01IO());
		sb.append("\n");
		sb.append("\tinDHDCodeAcnt01IO: ");
		sb.append(inDHDCodeAcnt01IO==null?"null":getInDHDCodeAcnt01IO());
		sb.append("\n");
		sb.append("\tinDHDCodeAgency01IO: ");
		sb.append(inDHDCodeAgency01IO==null?"null":getInDHDCodeAgency01IO());
		sb.append("\n");
		sb.append("\tinDHDCodeAcnt01IO01: ");
		sb.append(inDHDCodeAcnt01IO01==null?"null":getInDHDCodeAcnt01IO01());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		if ( inDHDAcmastE01IO != null && !(inDHDAcmastE01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO temp= inDHDAcmastE01IO;
			if ( temp== null ) temp= new kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDAcmastE01IO */
		}
		if ( inDHDCodeAcnt01IO != null && !(inDHDCodeAcnt01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= inDHDCodeAcnt01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDCodeAcnt01IO */
		}
		if ( inDHDCodeAgency01IO != null && !(inDHDCodeAgency01IO instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAgency01IO temp= inDHDCodeAgency01IO;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAgency01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDCodeAgency01IO */
		}
		if ( inDHDCodeAcnt01IO01 != null && !(inDHDCodeAcnt01IO01 instanceof Predictable) )
			throw new IllegalStateException( "Can not predict message length.");
		{
			kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO temp= inDHDCodeAcnt01IO01;
			if ( temp== null ) temp= new kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO();
			messageLen+= ( (Predictable)temp).predictMessageLength(); /* inDHDCodeAcnt01IO01 */
		}
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("inDHDAcmastE01IO");
	
		fieldNames.add("inDHDCodeAcnt01IO");
	
		fieldNames.add("inDHDCodeAgency01IO");
	
		fieldNames.add("inDHDCodeAcnt01IO01");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("inDHDAcmastE01IO", get("inDHDAcmastE01IO"));
	
		fieldValueMap.put("inDHDCodeAcnt01IO", get("inDHDCodeAcnt01IO"));
	
		fieldValueMap.put("inDHDCodeAgency01IO", get("inDHDCodeAgency01IO"));
	
		fieldValueMap.put("inDHDCodeAcnt01IO01", get("inDHDCodeAcnt01IO01"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1858204422 : /* inDHDAcmastE01IO */
			return getInDHDAcmastE01IO();
		case -678728201 : /* inDHDCodeAcnt01IO */
			return getInDHDCodeAcnt01IO();
		case -367292396 : /* inDHDCodeAgency01IO */
			return getInDHDCodeAgency01IO();
		case 577229368 : /* inDHDCodeAcnt01IO01 */
			return getInDHDCodeAcnt01IO01();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1858204422 : /* inDHDAcmastE01IO */
			setInDHDAcmastE01IO((kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO) value);
			return;
		case -678728201 : /* inDHDCodeAcnt01IO */
			setInDHDCodeAcnt01IO((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		case -367292396 : /* inDHDCodeAgency01IO */
			setInDHDCodeAgency01IO((kait.hd.code.onl.dao.dto.DHDCodeAgency01IO) value);
			return;
		case 577229368 : /* inDHDCodeAcnt01IO01 */
			setInDHDCodeAcnt01IO01((kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
