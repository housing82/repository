/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.temp.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_TEMP_VIRTURE_DEPOSIT
 */
@XmlType(propOrder={"virDepositno", "makeSeq"}, name="DHDTempVirtureDeposit01IO")
@XmlRootElement(name="DHDTempVirtureDeposit01IO")
@SuppressWarnings("all")
public class DHDTempVirtureDeposit01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1418243653L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_TEMP_VIRTURE_DEPOSIT";

	/*******************************************************************************************************************************
	* Property set << virDepositno >> [[ */
	
	@XmlTransient
	private boolean isSet_virDepositno = false;
	
	protected boolean isSet_virDepositno()
	{
		return this.isSet_virDepositno;
	}
	
	protected void setIsSet_virDepositno(boolean value)
	{
		this.isSet_virDepositno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [PI_HD_TEMP_VIRTURE_DEPOSIT(P),SYS_C0012897(C) PI_HD_TEMP_VIRTURE_DEPOSIT(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String virDepositno  = null;
	
	/**
	 * @Description  [PI_HD_TEMP_VIRTURE_DEPOSIT(P),SYS_C0012897(C) PI_HD_TEMP_VIRTURE_DEPOSIT(UNIQUE)]
	 */
	public java.lang.String getVirDepositno(){
		return virDepositno;
	}
	
	/**
	 * @Description  [PI_HD_TEMP_VIRTURE_DEPOSIT(P),SYS_C0012897(C) PI_HD_TEMP_VIRTURE_DEPOSIT(UNIQUE)]
	 */
	@JsonProperty("virDepositno")
	public void setVirDepositno( java.lang.String virDepositno ) {
		isSet_virDepositno = true;
		this.virDepositno = virDepositno;
	}
	
	/** Property set << virDepositno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << makeSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_makeSeq = false;
	
	protected boolean isSet_makeSeq()
	{
		return this.isSet_makeSeq;
	}
	
	protected void setIsSet_makeSeq(boolean value)
	{
		this.isSet_makeSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012898(C)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String makeSeq  = null;
	
	/**
	 * @Description  [SYS_C0012898(C)]
	 */
	public java.lang.String getMakeSeq(){
		return makeSeq;
	}
	
	/**
	 * @Description  [SYS_C0012898(C)]
	 */
	@JsonProperty("makeSeq")
	public void setMakeSeq( java.lang.String makeSeq ) {
		isSet_makeSeq = true;
		this.makeSeq = makeSeq;
	}
	
	/** Property set << makeSeq >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDTempVirtureDeposit01IO clone(){
		try{
			DHDTempVirtureDeposit01IO object= (DHDTempVirtureDeposit01IO)super.clone();
			if ( this.virDepositno== null ) object.virDepositno = null;
			else{
				object.virDepositno = this.virDepositno;
			}
			if ( this.makeSeq== null ) object.makeSeq = null;
			else{
				object.makeSeq = this.makeSeq;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((virDepositno==null)?0:virDepositno.hashCode());
		result = prime * result + ((makeSeq==null)?0:makeSeq.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO other = (kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO)obj;
		if ( virDepositno == null ){
			if ( other.virDepositno != null ) return false;
		}
		else if ( !virDepositno.equals(other.virDepositno) )
			return false;
		if ( makeSeq == null ){
			if ( other.makeSeq != null ) return false;
		}
		else if ( !makeSeq.equals(other.makeSeq) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO:\n");
		sb.append("\tvirDepositno: ");
		sb.append(virDepositno==null?"null":getVirDepositno());
		sb.append("\n");
		sb.append("\tmakeSeq: ");
		sb.append(makeSeq==null?"null":getMakeSeq());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* virDepositno */
		messageLen+= 10; /* makeSeq */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("virDepositno");
	
		fieldNames.add("makeSeq");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("virDepositno", get("virDepositno"));
	
		fieldValueMap.put("makeSeq", get("makeSeq"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1391329408 : /* virDepositno */
			return getVirDepositno();
		case 832589713 : /* makeSeq */
			return getMakeSeq();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1391329408 : /* virDepositno */
			setVirDepositno((java.lang.String) value);
			return;
		case 832589713 : /* makeSeq */
			setMakeSeq((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
