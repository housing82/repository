/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.lease.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_채권가압류 ( HD_LEASE_BONDSEIZURE )
 */
@XmlType(propOrder={"custCode", "seq", "rentYn", "bondseq", "seizureNo", "seizor", "seizureamt", "remark", "seizureName", "court", "debt", "debt3", "requestBond", "requestContent", "decisionDate", "receiptDate", "cancelYn", "cancelDate", "seizureCode", "debtCode", "debt3Code", "debtRelation", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDLeaseBondseizure01IO")
@XmlRootElement(name="DHDLeaseBondseizure01IO")
@SuppressWarnings("all")
public class DHDLeaseBondseizure01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 2124680394L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_채권가압류 ( HD_LEASE_BONDSEIZURE )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012473(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012473(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012473(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012474(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012474(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012474(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012474(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012474(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012474(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentYn >> [[ */
	
	@XmlTransient
	private boolean isSet_rentYn = false;
	
	protected boolean isSet_rentYn()
	{
		return this.isSet_rentYn;
	}
	
	protected void setIsSet_rentYn(boolean value)
	{
		this.isSet_rentYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대구분 [SYS_C0012475(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String rentYn  = null;
	
	/**
	 * @Description 임대구분 [SYS_C0012475(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public java.lang.String getRentYn(){
		return rentYn;
	}
	
	/**
	 * @Description 임대구분 [SYS_C0012475(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	@JsonProperty("rentYn")
	public void setRentYn( java.lang.String rentYn ) {
		isSet_rentYn = true;
		this.rentYn = rentYn;
	}
	
	/** Property set << rentYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bondseq >> [[ */
	
	@XmlTransient
	private boolean isSet_bondseq = false;
	
	protected boolean isSet_bondseq()
	{
		return this.isSet_bondseq;
	}
	
	protected void setIsSet_bondseq(boolean value)
	{
		this.isSet_bondseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012476(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public void setBondseq(java.lang.String value) {
		isSet_bondseq = true;
		this.bondseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012476(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public void setBondseq(double value) {
		isSet_bondseq = true;
		this.bondseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012476(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public void setBondseq(long value) {
		isSet_bondseq = true;
		this.bondseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012476(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal bondseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012476(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	public java.math.BigDecimal getBondseq(){
		return bondseq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012476(C),SYS_C0012966(P) SYS_C0012966(UNIQUE)]
	 */
	@JsonProperty("bondseq")
	public void setBondseq( java.math.BigDecimal bondseq ) {
		isSet_bondseq = true;
		this.bondseq = bondseq;
	}
	
	/** Property set << bondseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seizureNo >> [[ */
	
	@XmlTransient
	private boolean isSet_seizureNo = false;
	
	protected boolean isSet_seizureNo()
	{
		return this.isSet_seizureNo;
	}
	
	protected void setIsSet_seizureNo(boolean value)
	{
		this.isSet_seizureNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사건번호", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String seizureNo  = null;
	
	/**
	 * @Description 사건번호
	 */
	public java.lang.String getSeizureNo(){
		return seizureNo;
	}
	
	/**
	 * @Description 사건번호
	 */
	@JsonProperty("seizureNo")
	public void setSeizureNo( java.lang.String seizureNo ) {
		isSet_seizureNo = true;
		this.seizureNo = seizureNo;
	}
	
	/** Property set << seizureNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seizor >> [[ */
	
	@XmlTransient
	private boolean isSet_seizor = false;
	
	protected boolean isSet_seizor()
	{
		return this.isSet_seizor;
	}
	
	protected void setIsSet_seizor(boolean value)
	{
		this.isSet_seizor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채권자", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String seizor  = null;
	
	/**
	 * @Description 채권자
	 */
	public java.lang.String getSeizor(){
		return seizor;
	}
	
	/**
	 * @Description 채권자
	 */
	@JsonProperty("seizor")
	public void setSeizor( java.lang.String seizor ) {
		isSet_seizor = true;
		this.seizor = seizor;
	}
	
	/** Property set << seizor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seizureamt >> [[ */
	
	@XmlTransient
	private boolean isSet_seizureamt = false;
	
	protected boolean isSet_seizureamt()
	{
		return this.isSet_seizureamt;
	}
	
	protected void setIsSet_seizureamt(boolean value)
	{
		this.isSet_seizureamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 청구금액
	 */
	public void setSeizureamt(java.lang.String value) {
		isSet_seizureamt = true;
		this.seizureamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 청구금액
	 */
	public void setSeizureamt(double value) {
		isSet_seizureamt = true;
		this.seizureamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 청구금액
	 */
	public void setSeizureamt(long value) {
		isSet_seizureamt = true;
		this.seizureamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="청구금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seizureamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 청구금액
	 */
	public java.math.BigDecimal getSeizureamt(){
		return seizureamt;
	}
	
	/**
	 * @Description 청구금액
	 */
	@JsonProperty("seizureamt")
	public void setSeizureamt( java.math.BigDecimal seizureamt ) {
		isSet_seizureamt = true;
		this.seizureamt = seizureamt;
	}
	
	/** Property set << seizureamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seizureName >> [[ */
	
	@XmlTransient
	private boolean isSet_seizureName = false;
	
	protected boolean isSet_seizureName()
	{
		return this.isSet_seizureName;
	}
	
	protected void setIsSet_seizureName(boolean value)
	{
		this.isSet_seizureName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사건명", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String seizureName  = null;
	
	/**
	 * @Description 사건명
	 */
	public java.lang.String getSeizureName(){
		return seizureName;
	}
	
	/**
	 * @Description 사건명
	 */
	@JsonProperty("seizureName")
	public void setSeizureName( java.lang.String seizureName ) {
		isSet_seizureName = true;
		this.seizureName = seizureName;
	}
	
	/** Property set << seizureName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << court >> [[ */
	
	@XmlTransient
	private boolean isSet_court = false;
	
	protected boolean isSet_court()
	{
		return this.isSet_court;
	}
	
	protected void setIsSet_court(boolean value)
	{
		this.isSet_court = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="관할법원", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String court  = null;
	
	/**
	 * @Description 관할법원
	 */
	public java.lang.String getCourt(){
		return court;
	}
	
	/**
	 * @Description 관할법원
	 */
	@JsonProperty("court")
	public void setCourt( java.lang.String court ) {
		isSet_court = true;
		this.court = court;
	}
	
	/** Property set << court >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << debt >> [[ */
	
	@XmlTransient
	private boolean isSet_debt = false;
	
	protected boolean isSet_debt()
	{
		return this.isSet_debt;
	}
	
	protected void setIsSet_debt(boolean value)
	{
		this.isSet_debt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채무자", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String debt  = null;
	
	/**
	 * @Description 채무자
	 */
	public java.lang.String getDebt(){
		return debt;
	}
	
	/**
	 * @Description 채무자
	 */
	@JsonProperty("debt")
	public void setDebt( java.lang.String debt ) {
		isSet_debt = true;
		this.debt = debt;
	}
	
	/** Property set << debt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << debt3 >> [[ */
	
	@XmlTransient
	private boolean isSet_debt3 = false;
	
	protected boolean isSet_debt3()
	{
		return this.isSet_debt3;
	}
	
	protected void setIsSet_debt3(boolean value)
	{
		this.isSet_debt3 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="제3채무자", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String debt3  = null;
	
	/**
	 * @Description 제3채무자
	 */
	public java.lang.String getDebt3(){
		return debt3;
	}
	
	/**
	 * @Description 제3채무자
	 */
	@JsonProperty("debt3")
	public void setDebt3( java.lang.String debt3 ) {
		isSet_debt3 = true;
		this.debt3 = debt3;
	}
	
	/** Property set << debt3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << requestBond >> [[ */
	
	@XmlTransient
	private boolean isSet_requestBond = false;
	
	protected boolean isSet_requestBond()
	{
		return this.isSet_requestBond;
	}
	
	protected void setIsSet_requestBond(boolean value)
	{
		this.isSet_requestBond = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="청구채권", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String requestBond  = null;
	
	/**
	 * @Description 청구채권
	 */
	public java.lang.String getRequestBond(){
		return requestBond;
	}
	
	/**
	 * @Description 청구채권
	 */
	@JsonProperty("requestBond")
	public void setRequestBond( java.lang.String requestBond ) {
		isSet_requestBond = true;
		this.requestBond = requestBond;
	}
	
	/** Property set << requestBond >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << requestContent >> [[ */
	
	@XmlTransient
	private boolean isSet_requestContent = false;
	
	protected boolean isSet_requestContent()
	{
		return this.isSet_requestContent;
	}
	
	protected void setIsSet_requestContent(boolean value)
	{
		this.isSet_requestContent = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="청구내용", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String requestContent  = null;
	
	/**
	 * @Description 청구내용
	 */
	public java.lang.String getRequestContent(){
		return requestContent;
	}
	
	/**
	 * @Description 청구내용
	 */
	@JsonProperty("requestContent")
	public void setRequestContent( java.lang.String requestContent ) {
		isSet_requestContent = true;
		this.requestContent = requestContent;
	}
	
	/** Property set << requestContent >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << decisionDate >> [[ */
	
	@XmlTransient
	private boolean isSet_decisionDate = false;
	
	protected boolean isSet_decisionDate()
	{
		return this.isSet_decisionDate;
	}
	
	protected void setIsSet_decisionDate(boolean value)
	{
		this.isSet_decisionDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="결정일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String decisionDate  = null;
	
	/**
	 * @Description 결정일
	 */
	public java.lang.String getDecisionDate(){
		return decisionDate;
	}
	
	/**
	 * @Description 결정일
	 */
	@JsonProperty("decisionDate")
	public void setDecisionDate( java.lang.String decisionDate ) {
		isSet_decisionDate = true;
		this.decisionDate = decisionDate;
	}
	
	/** Property set << decisionDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptDate >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptDate = false;
	
	protected boolean isSet_receiptDate()
	{
		return this.isSet_receiptDate;
	}
	
	protected void setIsSet_receiptDate(boolean value)
	{
		this.isSet_receiptDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="접수일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String receiptDate  = null;
	
	/**
	 * @Description 접수일
	 */
	public java.lang.String getReceiptDate(){
		return receiptDate;
	}
	
	/**
	 * @Description 접수일
	 */
	@JsonProperty("receiptDate")
	public void setReceiptDate( java.lang.String receiptDate ) {
		isSet_receiptDate = true;
		this.receiptDate = receiptDate;
	}
	
	/** Property set << receiptDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelYn >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelYn = false;
	
	protected boolean isSet_cancelYn()
	{
		return this.isSet_cancelYn;
	}
	
	protected void setIsSet_cancelYn(boolean value)
	{
		this.isSet_cancelYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해제구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelYn  = null;
	
	/**
	 * @Description 해제구분
	 */
	public java.lang.String getCancelYn(){
		return cancelYn;
	}
	
	/**
	 * @Description 해제구분
	 */
	@JsonProperty("cancelYn")
	public void setCancelYn( java.lang.String cancelYn ) {
		isSet_cancelYn = true;
		this.cancelYn = cancelYn;
	}
	
	/** Property set << cancelYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelDate >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelDate = false;
	
	protected boolean isSet_cancelDate()
	{
		return this.isSet_cancelDate;
	}
	
	protected void setIsSet_cancelDate(boolean value)
	{
		this.isSet_cancelDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해제일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelDate  = null;
	
	/**
	 * @Description 해제일자
	 */
	public java.lang.String getCancelDate(){
		return cancelDate;
	}
	
	/**
	 * @Description 해제일자
	 */
	@JsonProperty("cancelDate")
	public void setCancelDate( java.lang.String cancelDate ) {
		isSet_cancelDate = true;
		this.cancelDate = cancelDate;
	}
	
	/** Property set << cancelDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seizureCode >> [[ */
	
	@XmlTransient
	private boolean isSet_seizureCode = false;
	
	protected boolean isSet_seizureCode()
	{
		return this.isSet_seizureCode;
	}
	
	protected void setIsSet_seizureCode(boolean value)
	{
		this.isSet_seizureCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채권자코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String seizureCode  = null;
	
	/**
	 * @Description 채권자코드
	 */
	public java.lang.String getSeizureCode(){
		return seizureCode;
	}
	
	/**
	 * @Description 채권자코드
	 */
	@JsonProperty("seizureCode")
	public void setSeizureCode( java.lang.String seizureCode ) {
		isSet_seizureCode = true;
		this.seizureCode = seizureCode;
	}
	
	/** Property set << seizureCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << debtCode >> [[ */
	
	@XmlTransient
	private boolean isSet_debtCode = false;
	
	protected boolean isSet_debtCode()
	{
		return this.isSet_debtCode;
	}
	
	protected void setIsSet_debtCode(boolean value)
	{
		this.isSet_debtCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채무자코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String debtCode  = null;
	
	/**
	 * @Description 채무자코드
	 */
	public java.lang.String getDebtCode(){
		return debtCode;
	}
	
	/**
	 * @Description 채무자코드
	 */
	@JsonProperty("debtCode")
	public void setDebtCode( java.lang.String debtCode ) {
		isSet_debtCode = true;
		this.debtCode = debtCode;
	}
	
	/** Property set << debtCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << debt3Code >> [[ */
	
	@XmlTransient
	private boolean isSet_debt3Code = false;
	
	protected boolean isSet_debt3Code()
	{
		return this.isSet_debt3Code;
	}
	
	protected void setIsSet_debt3Code(boolean value)
	{
		this.isSet_debt3Code = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="제3채무자코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String debt3Code  = null;
	
	/**
	 * @Description 제3채무자코드
	 */
	public java.lang.String getDebt3Code(){
		return debt3Code;
	}
	
	/**
	 * @Description 제3채무자코드
	 */
	@JsonProperty("debt3Code")
	public void setDebt3Code( java.lang.String debt3Code ) {
		isSet_debt3Code = true;
		this.debt3Code = debt3Code;
	}
	
	/** Property set << debt3Code >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << debtRelation >> [[ */
	
	@XmlTransient
	private boolean isSet_debtRelation = false;
	
	protected boolean isSet_debtRelation()
	{
		return this.isSet_debtRelation;
	}
	
	protected void setIsSet_debtRelation(boolean value)
	{
		this.isSet_debtRelation = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채무자와의관계", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String debtRelation  = null;
	
	/**
	 * @Description 채무자와의관계
	 */
	public java.lang.String getDebtRelation(){
		return debtRelation;
	}
	
	/**
	 * @Description 채무자와의관계
	 */
	@JsonProperty("debtRelation")
	public void setDebtRelation( java.lang.String debtRelation ) {
		isSet_debtRelation = true;
		this.debtRelation = debtRelation;
	}
	
	/** Property set << debtRelation >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDLeaseBondseizure01IO clone(){
		try{
			DHDLeaseBondseizure01IO object= (DHDLeaseBondseizure01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.rentYn== null ) object.rentYn = null;
			else{
				object.rentYn = this.rentYn;
			}
			if ( this.bondseq== null ) object.bondseq = null;
			else{
				object.bondseq = new java.math.BigDecimal(bondseq.toString());
			}
			if ( this.seizureNo== null ) object.seizureNo = null;
			else{
				object.seizureNo = this.seizureNo;
			}
			if ( this.seizor== null ) object.seizor = null;
			else{
				object.seizor = this.seizor;
			}
			if ( this.seizureamt== null ) object.seizureamt = null;
			else{
				object.seizureamt = new java.math.BigDecimal(seizureamt.toString());
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.seizureName== null ) object.seizureName = null;
			else{
				object.seizureName = this.seizureName;
			}
			if ( this.court== null ) object.court = null;
			else{
				object.court = this.court;
			}
			if ( this.debt== null ) object.debt = null;
			else{
				object.debt = this.debt;
			}
			if ( this.debt3== null ) object.debt3 = null;
			else{
				object.debt3 = this.debt3;
			}
			if ( this.requestBond== null ) object.requestBond = null;
			else{
				object.requestBond = this.requestBond;
			}
			if ( this.requestContent== null ) object.requestContent = null;
			else{
				object.requestContent = this.requestContent;
			}
			if ( this.decisionDate== null ) object.decisionDate = null;
			else{
				object.decisionDate = this.decisionDate;
			}
			if ( this.receiptDate== null ) object.receiptDate = null;
			else{
				object.receiptDate = this.receiptDate;
			}
			if ( this.cancelYn== null ) object.cancelYn = null;
			else{
				object.cancelYn = this.cancelYn;
			}
			if ( this.cancelDate== null ) object.cancelDate = null;
			else{
				object.cancelDate = this.cancelDate;
			}
			if ( this.seizureCode== null ) object.seizureCode = null;
			else{
				object.seizureCode = this.seizureCode;
			}
			if ( this.debtCode== null ) object.debtCode = null;
			else{
				object.debtCode = this.debtCode;
			}
			if ( this.debt3Code== null ) object.debt3Code = null;
			else{
				object.debt3Code = this.debt3Code;
			}
			if ( this.debtRelation== null ) object.debtRelation = null;
			else{
				object.debtRelation = this.debtRelation;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((rentYn==null)?0:rentYn.hashCode());
		result = prime * result + ((bondseq==null)?0:bondseq.hashCode());
		result = prime * result + ((seizureNo==null)?0:seizureNo.hashCode());
		result = prime * result + ((seizor==null)?0:seizor.hashCode());
		result = prime * result + ((seizureamt==null)?0:seizureamt.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((seizureName==null)?0:seizureName.hashCode());
		result = prime * result + ((court==null)?0:court.hashCode());
		result = prime * result + ((debt==null)?0:debt.hashCode());
		result = prime * result + ((debt3==null)?0:debt3.hashCode());
		result = prime * result + ((requestBond==null)?0:requestBond.hashCode());
		result = prime * result + ((requestContent==null)?0:requestContent.hashCode());
		result = prime * result + ((decisionDate==null)?0:decisionDate.hashCode());
		result = prime * result + ((receiptDate==null)?0:receiptDate.hashCode());
		result = prime * result + ((cancelYn==null)?0:cancelYn.hashCode());
		result = prime * result + ((cancelDate==null)?0:cancelDate.hashCode());
		result = prime * result + ((seizureCode==null)?0:seizureCode.hashCode());
		result = prime * result + ((debtCode==null)?0:debtCode.hashCode());
		result = prime * result + ((debt3Code==null)?0:debt3Code.hashCode());
		result = prime * result + ((debtRelation==null)?0:debtRelation.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.lease.onl.dao.dto.DHDLeaseBondseizure01IO other = (kait.hd.lease.onl.dao.dto.DHDLeaseBondseizure01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( rentYn == null ){
			if ( other.rentYn != null ) return false;
		}
		else if ( !rentYn.equals(other.rentYn) )
			return false;
		if ( bondseq == null ){
			if ( other.bondseq != null ) return false;
		}
		else if ( !bondseq.equals(other.bondseq) )
			return false;
		if ( seizureNo == null ){
			if ( other.seizureNo != null ) return false;
		}
		else if ( !seizureNo.equals(other.seizureNo) )
			return false;
		if ( seizor == null ){
			if ( other.seizor != null ) return false;
		}
		else if ( !seizor.equals(other.seizor) )
			return false;
		if ( seizureamt == null ){
			if ( other.seizureamt != null ) return false;
		}
		else if ( !seizureamt.equals(other.seizureamt) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( seizureName == null ){
			if ( other.seizureName != null ) return false;
		}
		else if ( !seizureName.equals(other.seizureName) )
			return false;
		if ( court == null ){
			if ( other.court != null ) return false;
		}
		else if ( !court.equals(other.court) )
			return false;
		if ( debt == null ){
			if ( other.debt != null ) return false;
		}
		else if ( !debt.equals(other.debt) )
			return false;
		if ( debt3 == null ){
			if ( other.debt3 != null ) return false;
		}
		else if ( !debt3.equals(other.debt3) )
			return false;
		if ( requestBond == null ){
			if ( other.requestBond != null ) return false;
		}
		else if ( !requestBond.equals(other.requestBond) )
			return false;
		if ( requestContent == null ){
			if ( other.requestContent != null ) return false;
		}
		else if ( !requestContent.equals(other.requestContent) )
			return false;
		if ( decisionDate == null ){
			if ( other.decisionDate != null ) return false;
		}
		else if ( !decisionDate.equals(other.decisionDate) )
			return false;
		if ( receiptDate == null ){
			if ( other.receiptDate != null ) return false;
		}
		else if ( !receiptDate.equals(other.receiptDate) )
			return false;
		if ( cancelYn == null ){
			if ( other.cancelYn != null ) return false;
		}
		else if ( !cancelYn.equals(other.cancelYn) )
			return false;
		if ( cancelDate == null ){
			if ( other.cancelDate != null ) return false;
		}
		else if ( !cancelDate.equals(other.cancelDate) )
			return false;
		if ( seizureCode == null ){
			if ( other.seizureCode != null ) return false;
		}
		else if ( !seizureCode.equals(other.seizureCode) )
			return false;
		if ( debtCode == null ){
			if ( other.debtCode != null ) return false;
		}
		else if ( !debtCode.equals(other.debtCode) )
			return false;
		if ( debt3Code == null ){
			if ( other.debt3Code != null ) return false;
		}
		else if ( !debt3Code.equals(other.debt3Code) )
			return false;
		if ( debtRelation == null ){
			if ( other.debtRelation != null ) return false;
		}
		else if ( !debtRelation.equals(other.debtRelation) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.lease.onl.dao.dto.DHDLeaseBondseizure01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\trentYn: ");
		sb.append(rentYn==null?"null":getRentYn());
		sb.append("\n");
		sb.append("\tbondseq: ");
		sb.append(bondseq==null?"null":getBondseq());
		sb.append("\n");
		sb.append("\tseizureNo: ");
		sb.append(seizureNo==null?"null":getSeizureNo());
		sb.append("\n");
		sb.append("\tseizor: ");
		sb.append(seizor==null?"null":getSeizor());
		sb.append("\n");
		sb.append("\tseizureamt: ");
		sb.append(seizureamt==null?"null":getSeizureamt());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tseizureName: ");
		sb.append(seizureName==null?"null":getSeizureName());
		sb.append("\n");
		sb.append("\tcourt: ");
		sb.append(court==null?"null":getCourt());
		sb.append("\n");
		sb.append("\tdebt: ");
		sb.append(debt==null?"null":getDebt());
		sb.append("\n");
		sb.append("\tdebt3: ");
		sb.append(debt3==null?"null":getDebt3());
		sb.append("\n");
		sb.append("\trequestBond: ");
		sb.append(requestBond==null?"null":getRequestBond());
		sb.append("\n");
		sb.append("\trequestContent: ");
		sb.append(requestContent==null?"null":getRequestContent());
		sb.append("\n");
		sb.append("\tdecisionDate: ");
		sb.append(decisionDate==null?"null":getDecisionDate());
		sb.append("\n");
		sb.append("\treceiptDate: ");
		sb.append(receiptDate==null?"null":getReceiptDate());
		sb.append("\n");
		sb.append("\tcancelYn: ");
		sb.append(cancelYn==null?"null":getCancelYn());
		sb.append("\n");
		sb.append("\tcancelDate: ");
		sb.append(cancelDate==null?"null":getCancelDate());
		sb.append("\n");
		sb.append("\tseizureCode: ");
		sb.append(seizureCode==null?"null":getSeizureCode());
		sb.append("\n");
		sb.append("\tdebtCode: ");
		sb.append(debtCode==null?"null":getDebtCode());
		sb.append("\n");
		sb.append("\tdebt3Code: ");
		sb.append(debt3Code==null?"null":getDebt3Code());
		sb.append("\n");
		sb.append("\tdebtRelation: ");
		sb.append(debtRelation==null?"null":getDebtRelation());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 1; /* rentYn */
		messageLen+= 22; /* bondseq */
		messageLen+= 50; /* seizureNo */
		messageLen+= 50; /* seizor */
		messageLen+= 22; /* seizureamt */
		messageLen+= 200; /* remark */
		messageLen+= 100; /* seizureName */
		messageLen+= 50; /* court */
		messageLen+= 50; /* debt */
		messageLen+= 50; /* debt3 */
		messageLen+= 50; /* requestBond */
		messageLen+= 100; /* requestContent */
		messageLen+= 8; /* decisionDate */
		messageLen+= 8; /* receiptDate */
		messageLen+= 1; /* cancelYn */
		messageLen+= 8; /* cancelDate */
		messageLen+= 20; /* seizureCode */
		messageLen+= 20; /* debtCode */
		messageLen+= 20; /* debt3Code */
		messageLen+= 20; /* debtRelation */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("rentYn");
	
		fieldNames.add("bondseq");
	
		fieldNames.add("seizureNo");
	
		fieldNames.add("seizor");
	
		fieldNames.add("seizureamt");
	
		fieldNames.add("remark");
	
		fieldNames.add("seizureName");
	
		fieldNames.add("court");
	
		fieldNames.add("debt");
	
		fieldNames.add("debt3");
	
		fieldNames.add("requestBond");
	
		fieldNames.add("requestContent");
	
		fieldNames.add("decisionDate");
	
		fieldNames.add("receiptDate");
	
		fieldNames.add("cancelYn");
	
		fieldNames.add("cancelDate");
	
		fieldNames.add("seizureCode");
	
		fieldNames.add("debtCode");
	
		fieldNames.add("debt3Code");
	
		fieldNames.add("debtRelation");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("rentYn", get("rentYn"));
	
		fieldValueMap.put("bondseq", get("bondseq"));
	
		fieldValueMap.put("seizureNo", get("seizureNo"));
	
		fieldValueMap.put("seizor", get("seizor"));
	
		fieldValueMap.put("seizureamt", get("seizureamt"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("seizureName", get("seizureName"));
	
		fieldValueMap.put("court", get("court"));
	
		fieldValueMap.put("debt", get("debt"));
	
		fieldValueMap.put("debt3", get("debt3"));
	
		fieldValueMap.put("requestBond", get("requestBond"));
	
		fieldValueMap.put("requestContent", get("requestContent"));
	
		fieldValueMap.put("decisionDate", get("decisionDate"));
	
		fieldValueMap.put("receiptDate", get("receiptDate"));
	
		fieldValueMap.put("cancelYn", get("cancelYn"));
	
		fieldValueMap.put("cancelDate", get("cancelDate"));
	
		fieldValueMap.put("seizureCode", get("seizureCode"));
	
		fieldValueMap.put("debtCode", get("debtCode"));
	
		fieldValueMap.put("debt3Code", get("debt3Code"));
	
		fieldValueMap.put("debtRelation", get("debtRelation"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -934577106 : /* rentYn */
			return getRentYn();
		case 63563452 : /* bondseq */
			return getBondseq();
		case 534261798 : /* seizureNo */
			return getSeizureNo();
		case -906090458 : /* seizor */
			return getSeizor();
		case -617735133 : /* seizureamt */
			return getSeizureamt();
		case -934624384 : /* remark */
			return getRemark();
		case -1970497616 : /* seizureName */
			return getSeizureName();
		case 94851467 : /* court */
			return getCourt();
		case 3079315 : /* debt */
			return getDebt();
		case 95458816 : /* debt3 */
			return getDebt3();
		case 1149551090 : /* requestBond */
			return getRequestBond();
		case -904615190 : /* requestContent */
			return getRequestContent();
		case 675628458 : /* decisionDate */
			return getDecisionDate();
		case 2033121798 : /* receiptDate */
			return getReceiptDate();
		case -123174097 : /* cancelYn */
			return getCancelYn();
		case 1888142664 : /* cancelDate */
			return getCancelDate();
		case -1970812142 : /* seizureCode */
			return getSeizureCode();
		case 545824032 : /* debtCode */
			return getDebtCode();
		case -275400691 : /* debt3Code */
			return getDebt3Code();
		case 1435309999 : /* debtRelation */
			return getDebtRelation();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case -934577106 : /* rentYn */
			setRentYn((java.lang.String) value);
			return;
		case 63563452 : /* bondseq */
			setBondseq((java.math.BigDecimal) value);
			return;
		case 534261798 : /* seizureNo */
			setSeizureNo((java.lang.String) value);
			return;
		case -906090458 : /* seizor */
			setSeizor((java.lang.String) value);
			return;
		case -617735133 : /* seizureamt */
			setSeizureamt((java.math.BigDecimal) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -1970497616 : /* seizureName */
			setSeizureName((java.lang.String) value);
			return;
		case 94851467 : /* court */
			setCourt((java.lang.String) value);
			return;
		case 3079315 : /* debt */
			setDebt((java.lang.String) value);
			return;
		case 95458816 : /* debt3 */
			setDebt3((java.lang.String) value);
			return;
		case 1149551090 : /* requestBond */
			setRequestBond((java.lang.String) value);
			return;
		case -904615190 : /* requestContent */
			setRequestContent((java.lang.String) value);
			return;
		case 675628458 : /* decisionDate */
			setDecisionDate((java.lang.String) value);
			return;
		case 2033121798 : /* receiptDate */
			setReceiptDate((java.lang.String) value);
			return;
		case -123174097 : /* cancelYn */
			setCancelYn((java.lang.String) value);
			return;
		case 1888142664 : /* cancelDate */
			setCancelDate((java.lang.String) value);
			return;
		case -1970812142 : /* seizureCode */
			setSeizureCode((java.lang.String) value);
			return;
		case 545824032 : /* debtCode */
			setDebtCode((java.lang.String) value);
			return;
		case -275400691 : /* debt3Code */
			setDebt3Code((java.lang.String) value);
			return;
		case 1435309999 : /* debtRelation */
			setDebtRelation((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
