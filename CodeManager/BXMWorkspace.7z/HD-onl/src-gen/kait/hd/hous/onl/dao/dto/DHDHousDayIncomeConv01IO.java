/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_일자별입금내역_업로드 ( HD_HOUS_DAY_INCOME_CONV )
 */
@XmlType(propOrder={"deptCode", "housetag", "seq", "indt", "depositNo", "buildno", "houseno", "inamt", "ingun", "cdno", "cdBank", "cdEdate", "cdStype"}, name="DHDHousDayIncomeConv01IO")
@XmlRootElement(name="DHDHousDayIncomeConv01IO")
@SuppressWarnings("all")
public class DHDHousDayIncomeConv01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 982854923L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_일자별입금내역_업로드 ( HD_HOUS_DAY_INCOME_CONV )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012152(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012152(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012152(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012153(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012153(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012153(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012154(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012154(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012154(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012154(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012154(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012154(C),SYS_C0012928(P) SYS_C0012928(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indt >> [[ */
	
	@XmlTransient
	private boolean isSet_indt = false;
	
	protected boolean isSet_indt()
	{
		return this.isSet_indt;
	}
	
	protected void setIsSet_indt(boolean value)
	{
		this.isSet_indt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금일자 [SYS_C0012155(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String indt  = null;
	
	/**
	 * @Description 입금일자 [SYS_C0012155(C)]
	 */
	public java.lang.String getIndt(){
		return indt;
	}
	
	/**
	 * @Description 입금일자 [SYS_C0012155(C)]
	 */
	@JsonProperty("indt")
	public void setIndt( java.lang.String indt ) {
		isSet_indt = true;
		this.indt = indt;
	}
	
	/** Property set << indt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inamt >> [[ */
	
	@XmlTransient
	private boolean isSet_inamt = false;
	
	protected boolean isSet_inamt()
	{
		return this.isSet_inamt;
	}
	
	protected void setIsSet_inamt(boolean value)
	{
		this.isSet_inamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float inamt  = .0F;
	
	/**
	 * @Description 입금금액
	 */
	public java.lang.Float getInamt(){
		return inamt;
	}
	
	/**
	 * @Description 입금금액
	 */
	@JsonProperty("inamt")
	public void setInamt( java.lang.Float inamt ) {
		isSet_inamt = true;
		this.inamt = inamt;
	}
	
	/** Property set << inamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << ingun >> [[ */
	
	@XmlTransient
	private boolean isSet_ingun = false;
	
	protected boolean isSet_ingun()
	{
		return this.isSet_ingun;
	}
	
	protected void setIsSet_ingun(boolean value)
	{
		this.isSet_ingun = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String ingun  = null;
	
	/**
	 * @Description 입금구분
	 */
	public java.lang.String getIngun(){
		return ingun;
	}
	
	/**
	 * @Description 입금구분
	 */
	@JsonProperty("ingun")
	public void setIngun( java.lang.String ingun ) {
		isSet_ingun = true;
		this.ingun = ingun;
	}
	
	/** Property set << ingun >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cdno >> [[ */
	
	@XmlTransient
	private boolean isSet_cdno = false;
	
	protected boolean isSet_cdno()
	{
		return this.isSet_cdno;
	}
	
	protected void setIsSet_cdno(boolean value)
	{
		this.isSet_cdno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="카드번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String cdno  = null;
	
	/**
	 * @Description 카드번호
	 */
	public java.lang.String getCdno(){
		return cdno;
	}
	
	/**
	 * @Description 카드번호
	 */
	@JsonProperty("cdno")
	public void setCdno( java.lang.String cdno ) {
		isSet_cdno = true;
		this.cdno = cdno;
	}
	
	/** Property set << cdno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cdBank >> [[ */
	
	@XmlTransient
	private boolean isSet_cdBank = false;
	
	protected boolean isSet_cdBank()
	{
		return this.isSet_cdBank;
	}
	
	protected void setIsSet_cdBank(boolean value)
	{
		this.isSet_cdBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="카드_은행", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String cdBank  = null;
	
	/**
	 * @Description 카드_은행
	 */
	public java.lang.String getCdBank(){
		return cdBank;
	}
	
	/**
	 * @Description 카드_은행
	 */
	@JsonProperty("cdBank")
	public void setCdBank( java.lang.String cdBank ) {
		isSet_cdBank = true;
		this.cdBank = cdBank;
	}
	
	/** Property set << cdBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cdEdate >> [[ */
	
	@XmlTransient
	private boolean isSet_cdEdate = false;
	
	protected boolean isSet_cdEdate()
	{
		return this.isSet_cdEdate;
	}
	
	protected void setIsSet_cdEdate(boolean value)
	{
		this.isSet_cdEdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="카드_유효기간", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String cdEdate  = null;
	
	/**
	 * @Description 카드_유효기간
	 */
	public java.lang.String getCdEdate(){
		return cdEdate;
	}
	
	/**
	 * @Description 카드_유효기간
	 */
	@JsonProperty("cdEdate")
	public void setCdEdate( java.lang.String cdEdate ) {
		isSet_cdEdate = true;
		this.cdEdate = cdEdate;
	}
	
	/** Property set << cdEdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cdStype >> [[ */
	
	@XmlTransient
	private boolean isSet_cdStype = false;
	
	protected boolean isSet_cdStype()
	{
		return this.isSet_cdStype;
	}
	
	protected void setIsSet_cdStype(boolean value)
	{
		this.isSet_cdStype = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="카드_할부형태", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String cdStype  = null;
	
	/**
	 * @Description 카드_할부형태
	 */
	public java.lang.String getCdStype(){
		return cdStype;
	}
	
	/**
	 * @Description 카드_할부형태
	 */
	@JsonProperty("cdStype")
	public void setCdStype( java.lang.String cdStype ) {
		isSet_cdStype = true;
		this.cdStype = cdStype;
	}
	
	/** Property set << cdStype >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousDayIncomeConv01IO clone(){
		try{
			DHDHousDayIncomeConv01IO object= (DHDHousDayIncomeConv01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.indt== null ) object.indt = null;
			else{
				object.indt = this.indt;
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.inamt== null ) object.inamt = null;
			else{
				object.inamt = this.inamt;
			}
			if ( this.ingun== null ) object.ingun = null;
			else{
				object.ingun = this.ingun;
			}
			if ( this.cdno== null ) object.cdno = null;
			else{
				object.cdno = this.cdno;
			}
			if ( this.cdBank== null ) object.cdBank = null;
			else{
				object.cdBank = this.cdBank;
			}
			if ( this.cdEdate== null ) object.cdEdate = null;
			else{
				object.cdEdate = this.cdEdate;
			}
			if ( this.cdStype== null ) object.cdStype = null;
			else{
				object.cdStype = this.cdStype;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((indt==null)?0:indt.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((inamt==null)?0:inamt.hashCode());
		result = prime * result + ((ingun==null)?0:ingun.hashCode());
		result = prime * result + ((cdno==null)?0:cdno.hashCode());
		result = prime * result + ((cdBank==null)?0:cdBank.hashCode());
		result = prime * result + ((cdEdate==null)?0:cdEdate.hashCode());
		result = prime * result + ((cdStype==null)?0:cdStype.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO other = (kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( indt == null ){
			if ( other.indt != null ) return false;
		}
		else if ( !indt.equals(other.indt) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( inamt == null ){
			if ( other.inamt != null ) return false;
		}
		else if ( !inamt.equals(other.inamt) )
			return false;
		if ( ingun == null ){
			if ( other.ingun != null ) return false;
		}
		else if ( !ingun.equals(other.ingun) )
			return false;
		if ( cdno == null ){
			if ( other.cdno != null ) return false;
		}
		else if ( !cdno.equals(other.cdno) )
			return false;
		if ( cdBank == null ){
			if ( other.cdBank != null ) return false;
		}
		else if ( !cdBank.equals(other.cdBank) )
			return false;
		if ( cdEdate == null ){
			if ( other.cdEdate != null ) return false;
		}
		else if ( !cdEdate.equals(other.cdEdate) )
			return false;
		if ( cdStype == null ){
			if ( other.cdStype != null ) return false;
		}
		else if ( !cdStype.equals(other.cdStype) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tindt: ");
		sb.append(indt==null?"null":getIndt());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tinamt: ");
		sb.append(inamt==null?"null":getInamt());
		sb.append("\n");
		sb.append("\tingun: ");
		sb.append(ingun==null?"null":getIngun());
		sb.append("\n");
		sb.append("\tcdno: ");
		sb.append(cdno==null?"null":getCdno());
		sb.append("\n");
		sb.append("\tcdBank: ");
		sb.append(cdBank==null?"null":getCdBank());
		sb.append("\n");
		sb.append("\tcdEdate: ");
		sb.append(cdEdate==null?"null":getCdEdate());
		sb.append("\n");
		sb.append("\tcdStype: ");
		sb.append(cdStype==null?"null":getCdStype());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* seq */
		messageLen+= 8; /* indt */
		messageLen+= 30; /* depositNo */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 22; /* inamt */
		messageLen+= 2; /* ingun */
		messageLen+= 30; /* cdno */
		messageLen+= 8; /* cdBank */
		messageLen+= 6; /* cdEdate */
		messageLen+= 2; /* cdStype */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("seq");
	
		fieldNames.add("indt");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("inamt");
	
		fieldNames.add("ingun");
	
		fieldNames.add("cdno");
	
		fieldNames.add("cdBank");
	
		fieldNames.add("cdEdate");
	
		fieldNames.add("cdStype");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("indt", get("indt"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("inamt", get("inamt"));
	
		fieldValueMap.put("ingun", get("ingun"));
	
		fieldValueMap.put("cdno", get("cdno"));
	
		fieldValueMap.put("cdBank", get("cdBank"));
	
		fieldValueMap.put("cdEdate", get("cdEdate"));
	
		fieldValueMap.put("cdStype", get("cdStype"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 113759 : /* seq */
			return getSeq();
		case 3236981 : /* indt */
			return getIndt();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 100343427 : /* inamt */
			return getInamt();
		case 100349435 : /* ingun */
			return getIngun();
		case 3048930 : /* cdno */
			return getCdno();
		case -1366266307 : /* cdBank */
			return getCdBank();
		case 598265266 : /* cdEdate */
			return getCdEdate();
		case 611694156 : /* cdStype */
			return getCdStype();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 3236981 : /* indt */
			setIndt((java.lang.String) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 100343427 : /* inamt */
			setInamt((java.lang.Float) value);
			return;
		case 100349435 : /* ingun */
			setIngun((java.lang.String) value);
			return;
		case 3048930 : /* cdno */
			setCdno((java.lang.String) value);
			return;
		case -1366266307 : /* cdBank */
			setCdBank((java.lang.String) value);
			return;
		case 598265266 : /* cdEdate */
			setCdEdate((java.lang.String) value);
			return;
		case 611694156 : /* cdStype */
			setCdStype((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
