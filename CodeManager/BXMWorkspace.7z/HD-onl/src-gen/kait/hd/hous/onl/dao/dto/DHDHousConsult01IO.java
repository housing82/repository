/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_상담일지 ( HD_HOUS_CONSULT )
 */
@XmlType(propOrder={"deptCode", "housetag", "consDate", "consEmp", "seq", "sex", "custnm", "consTime", "square", "tel", "memo", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousConsult01IO")
@XmlRootElement(name="DHDHousConsult01IO")
@SuppressWarnings("all")
public class DHDHousConsult01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1705930366L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_상담일지 ( HD_HOUS_CONSULT )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012137(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012137(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012137(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012138(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012138(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012138(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << consDate >> [[ */
	
	@XmlTransient
	private boolean isSet_consDate = false;
	
	protected boolean isSet_consDate()
	{
		return this.isSet_consDate;
	}
	
	protected void setIsSet_consDate(boolean value)
	{
		this.isSet_consDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상담일자 [SYS_C0012139(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String consDate  = null;
	
	/**
	 * @Description 상담일자 [SYS_C0012139(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public java.lang.String getConsDate(){
		return consDate;
	}
	
	/**
	 * @Description 상담일자 [SYS_C0012139(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	@JsonProperty("consDate")
	public void setConsDate( java.lang.String consDate ) {
		isSet_consDate = true;
		this.consDate = consDate;
	}
	
	/** Property set << consDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << consEmp >> [[ */
	
	@XmlTransient
	private boolean isSet_consEmp = false;
	
	protected boolean isSet_consEmp()
	{
		return this.isSet_consEmp;
	}
	
	protected void setIsSet_consEmp(boolean value)
	{
		this.isSet_consEmp = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상담자 [SYS_C0012140(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String consEmp  = null;
	
	/**
	 * @Description 상담자 [SYS_C0012140(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public java.lang.String getConsEmp(){
		return consEmp;
	}
	
	/**
	 * @Description 상담자 [SYS_C0012140(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	@JsonProperty("consEmp")
	public void setConsEmp( java.lang.String consEmp ) {
		isSet_consEmp = true;
		this.consEmp = consEmp;
	}
	
	/** Property set << consEmp >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012141(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012141(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012141(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012141(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012141(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012141(C),SYS_C0012925(P) SYS_C0012925(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sex >> [[ */
	
	@XmlTransient
	private boolean isSet_sex = false;
	
	protected boolean isSet_sex()
	{
		return this.isSet_sex;
	}
	
	protected void setIsSet_sex(boolean value)
	{
		this.isSet_sex = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="성별", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String sex  = null;
	
	/**
	 * @Description 성별
	 */
	public java.lang.String getSex(){
		return sex;
	}
	
	/**
	 * @Description 성별
	 */
	@JsonProperty("sex")
	public void setSex( java.lang.String sex ) {
		isSet_sex = true;
		this.sex = sex;
	}
	
	/** Property set << sex >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custnm >> [[ */
	
	@XmlTransient
	private boolean isSet_custnm = false;
	
	protected boolean isSet_custnm()
	{
		return this.isSet_custnm;
	}
	
	protected void setIsSet_custnm(boolean value)
	{
		this.isSet_custnm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객명", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custnm  = null;
	
	/**
	 * @Description 고객명
	 */
	public java.lang.String getCustnm(){
		return custnm;
	}
	
	/**
	 * @Description 고객명
	 */
	@JsonProperty("custnm")
	public void setCustnm( java.lang.String custnm ) {
		isSet_custnm = true;
		this.custnm = custnm;
	}
	
	/** Property set << custnm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << consTime >> [[ */
	
	@XmlTransient
	private boolean isSet_consTime = false;
	
	protected boolean isSet_consTime()
	{
		return this.isSet_consTime;
	}
	
	protected void setIsSet_consTime(boolean value)
	{
		this.isSet_consTime = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상담시간", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String consTime  = null;
	
	/**
	 * @Description 상담시간
	 */
	public java.lang.String getConsTime(){
		return consTime;
	}
	
	/**
	 * @Description 상담시간
	 */
	@JsonProperty("consTime")
	public void setConsTime( java.lang.String consTime ) {
		isSet_consTime = true;
		this.consTime = consTime;
	}
	
	/** Property set << consTime >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String square  = null;
	
	/**
	 * @Description 평형
	 */
	public java.lang.String getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.lang.String square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << tel >> [[ */
	
	@XmlTransient
	private boolean isSet_tel = false;
	
	protected boolean isSet_tel()
	{
		return this.isSet_tel;
	}
	
	protected void setIsSet_tel(boolean value)
	{
		this.isSet_tel = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연락처", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String tel  = null;
	
	/**
	 * @Description 연락처
	 */
	public java.lang.String getTel(){
		return tel;
	}
	
	/**
	 * @Description 연락처
	 */
	@JsonProperty("tel")
	public void setTel( java.lang.String tel ) {
		isSet_tel = true;
		this.tel = tel;
	}
	
	/** Property set << tel >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << memo >> [[ */
	
	@XmlTransient
	private boolean isSet_memo = false;
	
	protected boolean isSet_memo()
	{
		return this.isSet_memo;
	}
	
	protected void setIsSet_memo(boolean value)
	{
		this.isSet_memo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="내용", formatType="", format="", align="left", length=4000, decimal=0, arrayReference="", fill="")
	private java.lang.String memo  = null;
	
	/**
	 * @Description 내용
	 */
	public java.lang.String getMemo(){
		return memo;
	}
	
	/**
	 * @Description 내용
	 */
	@JsonProperty("memo")
	public void setMemo( java.lang.String memo ) {
		isSet_memo = true;
		this.memo = memo;
	}
	
	/** Property set << memo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=4000, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousConsult01IO clone(){
		try{
			DHDHousConsult01IO object= (DHDHousConsult01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.consDate== null ) object.consDate = null;
			else{
				object.consDate = this.consDate;
			}
			if ( this.consEmp== null ) object.consEmp = null;
			else{
				object.consEmp = this.consEmp;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.sex== null ) object.sex = null;
			else{
				object.sex = this.sex;
			}
			if ( this.custnm== null ) object.custnm = null;
			else{
				object.custnm = this.custnm;
			}
			if ( this.consTime== null ) object.consTime = null;
			else{
				object.consTime = this.consTime;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = this.square;
			}
			if ( this.tel== null ) object.tel = null;
			else{
				object.tel = this.tel;
			}
			if ( this.memo== null ) object.memo = null;
			else{
				object.memo = this.memo;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((consDate==null)?0:consDate.hashCode());
		result = prime * result + ((consEmp==null)?0:consEmp.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((sex==null)?0:sex.hashCode());
		result = prime * result + ((custnm==null)?0:custnm.hashCode());
		result = prime * result + ((consTime==null)?0:consTime.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((tel==null)?0:tel.hashCode());
		result = prime * result + ((memo==null)?0:memo.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousConsult01IO other = (kait.hd.hous.onl.dao.dto.DHDHousConsult01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( consDate == null ){
			if ( other.consDate != null ) return false;
		}
		else if ( !consDate.equals(other.consDate) )
			return false;
		if ( consEmp == null ){
			if ( other.consEmp != null ) return false;
		}
		else if ( !consEmp.equals(other.consEmp) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( sex == null ){
			if ( other.sex != null ) return false;
		}
		else if ( !sex.equals(other.sex) )
			return false;
		if ( custnm == null ){
			if ( other.custnm != null ) return false;
		}
		else if ( !custnm.equals(other.custnm) )
			return false;
		if ( consTime == null ){
			if ( other.consTime != null ) return false;
		}
		else if ( !consTime.equals(other.consTime) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( tel == null ){
			if ( other.tel != null ) return false;
		}
		else if ( !tel.equals(other.tel) )
			return false;
		if ( memo == null ){
			if ( other.memo != null ) return false;
		}
		else if ( !memo.equals(other.memo) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousConsult01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tconsDate: ");
		sb.append(consDate==null?"null":getConsDate());
		sb.append("\n");
		sb.append("\tconsEmp: ");
		sb.append(consEmp==null?"null":getConsEmp());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tsex: ");
		sb.append(sex==null?"null":getSex());
		sb.append("\n");
		sb.append("\tcustnm: ");
		sb.append(custnm==null?"null":getCustnm());
		sb.append("\n");
		sb.append("\tconsTime: ");
		sb.append(consTime==null?"null":getConsTime());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttel: ");
		sb.append(tel==null?"null":getTel());
		sb.append("\n");
		sb.append("\tmemo: ");
		sb.append(memo==null?"null":getMemo());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 8; /* consDate */
		messageLen+= 20; /* consEmp */
		messageLen+= 22; /* seq */
		messageLen+= 1; /* sex */
		messageLen+= 20; /* custnm */
		messageLen+= 4; /* consTime */
		messageLen+= 4; /* square */
		messageLen+= 20; /* tel */
		messageLen+= 4000; /* memo */
		messageLen+= 4000; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("consDate");
	
		fieldNames.add("consEmp");
	
		fieldNames.add("seq");
	
		fieldNames.add("sex");
	
		fieldNames.add("custnm");
	
		fieldNames.add("consTime");
	
		fieldNames.add("square");
	
		fieldNames.add("tel");
	
		fieldNames.add("memo");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("consDate", get("consDate"));
	
		fieldValueMap.put("consEmp", get("consEmp"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("sex", get("sex"));
	
		fieldValueMap.put("custnm", get("custnm"));
	
		fieldValueMap.put("consTime", get("consTime"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("tel", get("tel"));
	
		fieldValueMap.put("memo", get("memo"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -569240961 : /* consDate */
			return getConsDate();
		case 951470039 : /* consEmp */
			return getConsEmp();
		case 113759 : /* seq */
			return getSeq();
		case 113766 : /* sex */
			return getSex();
		case -1349088430 : /* custnm */
			return getCustnm();
		case -568756834 : /* consTime */
			return getConsTime();
		case -894674659 : /* square */
			return getSquare();
		case 114715 : /* tel */
			return getTel();
		case 3347770 : /* memo */
			return getMemo();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -569240961 : /* consDate */
			setConsDate((java.lang.String) value);
			return;
		case 951470039 : /* consEmp */
			setConsEmp((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 113766 : /* sex */
			setSex((java.lang.String) value);
			return;
		case -1349088430 : /* custnm */
			setCustnm((java.lang.String) value);
			return;
		case -568756834 : /* consTime */
			setConsTime((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.lang.String) value);
			return;
		case 114715 : /* tel */
			setTel((java.lang.String) value);
			return;
		case 3347770 : /* memo */
			setMemo((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
