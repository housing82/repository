/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_지체보상금 ( HD_HOUS_INDEMINITY )
 */
@XmlType(propOrder={"custCode", "seq", "deptCode", "housetag", "receiptamt", "realincomamt", "indeminityTag", "delayIndeminity", "icheDate", "icheYn", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousIndeminity01IO")
@XmlRootElement(name="DHDHousIndeminity01IO")
@SuppressWarnings("all")
public class DHDHousIndeminity01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 517513566L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_지체보상금 ( HD_HOUS_INDEMINITY )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012251(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012251(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012251(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012252(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012252(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012252(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012252(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012252(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012252(C),SYS_C0012936(P) SYS_C0012936(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012253(C)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012253(C)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012253(C)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012254(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012254(C)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012254(C)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptamt = false;
	
	protected boolean isSet_receiptamt()
	{
		return this.isSet_receiptamt;
	}
	
	protected void setIsSet_receiptamt(boolean value)
	{
		this.isSet_receiptamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 납입금액
	 */
	public void setReceiptamt(java.lang.String value) {
		isSet_receiptamt = true;
		this.receiptamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 납입금액
	 */
	public void setReceiptamt(double value) {
		isSet_receiptamt = true;
		this.receiptamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 납입금액
	 */
	public void setReceiptamt(long value) {
		isSet_receiptamt = true;
		this.receiptamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="납입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 납입금액
	 */
	public java.math.BigDecimal getReceiptamt(){
		return receiptamt;
	}
	
	/**
	 * @Description 납입금액
	 */
	@JsonProperty("receiptamt")
	public void setReceiptamt( java.math.BigDecimal receiptamt ) {
		isSet_receiptamt = true;
		this.receiptamt = receiptamt;
	}
	
	/** Property set << receiptamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realincomamt >> [[ */
	
	@XmlTransient
	private boolean isSet_realincomamt = false;
	
	protected boolean isSet_realincomamt()
	{
		return this.isSet_realincomamt;
	}
	
	protected void setIsSet_realincomamt(boolean value)
	{
		this.isSet_realincomamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실납입금액
	 */
	public void setRealincomamt(java.lang.String value) {
		isSet_realincomamt = true;
		this.realincomamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실납입금액
	 */
	public void setRealincomamt(double value) {
		isSet_realincomamt = true;
		this.realincomamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실납입금액
	 */
	public void setRealincomamt(long value) {
		isSet_realincomamt = true;
		this.realincomamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실납입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal realincomamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실납입금액
	 */
	public java.math.BigDecimal getRealincomamt(){
		return realincomamt;
	}
	
	/**
	 * @Description 실납입금액
	 */
	@JsonProperty("realincomamt")
	public void setRealincomamt( java.math.BigDecimal realincomamt ) {
		isSet_realincomamt = true;
		this.realincomamt = realincomamt;
	}
	
	/** Property set << realincomamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indeminityTag >> [[ */
	
	@XmlTransient
	private boolean isSet_indeminityTag = false;
	
	protected boolean isSet_indeminityTag()
	{
		return this.isSet_indeminityTag;
	}
	
	protected void setIsSet_indeminityTag(boolean value)
	{
		this.isSet_indeminityTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String indeminityTag  = null;
	
	/**
	 * @Description 납입구분
	 */
	public java.lang.String getIndeminityTag(){
		return indeminityTag;
	}
	
	/**
	 * @Description 납입구분
	 */
	@JsonProperty("indeminityTag")
	public void setIndeminityTag( java.lang.String indeminityTag ) {
		isSet_indeminityTag = true;
		this.indeminityTag = indeminityTag;
	}
	
	/** Property set << indeminityTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayIndeminity >> [[ */
	
	@XmlTransient
	private boolean isSet_delayIndeminity = false;
	
	protected boolean isSet_delayIndeminity()
	{
		return this.isSet_delayIndeminity;
	}
	
	protected void setIsSet_delayIndeminity(boolean value)
	{
		this.isSet_delayIndeminity = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 지체상금
	 */
	public void setDelayIndeminity(java.lang.String value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 지체상금
	 */
	public void setDelayIndeminity(double value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 지체상금
	 */
	public void setDelayIndeminity(long value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="지체상금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayIndeminity  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 지체상금
	 */
	public java.math.BigDecimal getDelayIndeminity(){
		return delayIndeminity;
	}
	
	/**
	 * @Description 지체상금
	 */
	@JsonProperty("delayIndeminity")
	public void setDelayIndeminity( java.math.BigDecimal delayIndeminity ) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = delayIndeminity;
	}
	
	/** Property set << delayIndeminity >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << icheDate >> [[ */
	
	@XmlTransient
	private boolean isSet_icheDate = false;
	
	protected boolean isSet_icheDate()
	{
		return this.isSet_icheDate;
	}
	
	protected void setIsSet_icheDate(boolean value)
	{
		this.isSet_icheDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이체일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String icheDate  = null;
	
	/**
	 * @Description 이체일자
	 */
	public java.lang.String getIcheDate(){
		return icheDate;
	}
	
	/**
	 * @Description 이체일자
	 */
	@JsonProperty("icheDate")
	public void setIcheDate( java.lang.String icheDate ) {
		isSet_icheDate = true;
		this.icheDate = icheDate;
	}
	
	/** Property set << icheDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << icheYn >> [[ */
	
	@XmlTransient
	private boolean isSet_icheYn = false;
	
	protected boolean isSet_icheYn()
	{
		return this.isSet_icheYn;
	}
	
	protected void setIsSet_icheYn(boolean value)
	{
		this.isSet_icheYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이체여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String icheYn  = null;
	
	/**
	 * @Description 이체여부
	 */
	public java.lang.String getIcheYn(){
		return icheYn;
	}
	
	/**
	 * @Description 이체여부
	 */
	@JsonProperty("icheYn")
	public void setIcheYn( java.lang.String icheYn ) {
		isSet_icheYn = true;
		this.icheYn = icheYn;
	}
	
	/** Property set << icheYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousIndeminity01IO clone(){
		try{
			DHDHousIndeminity01IO object= (DHDHousIndeminity01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.receiptamt== null ) object.receiptamt = null;
			else{
				object.receiptamt = new java.math.BigDecimal(receiptamt.toString());
			}
			if ( this.realincomamt== null ) object.realincomamt = null;
			else{
				object.realincomamt = new java.math.BigDecimal(realincomamt.toString());
			}
			if ( this.indeminityTag== null ) object.indeminityTag = null;
			else{
				object.indeminityTag = this.indeminityTag;
			}
			if ( this.delayIndeminity== null ) object.delayIndeminity = null;
			else{
				object.delayIndeminity = new java.math.BigDecimal(delayIndeminity.toString());
			}
			if ( this.icheDate== null ) object.icheDate = null;
			else{
				object.icheDate = this.icheDate;
			}
			if ( this.icheYn== null ) object.icheYn = null;
			else{
				object.icheYn = this.icheYn;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((receiptamt==null)?0:receiptamt.hashCode());
		result = prime * result + ((realincomamt==null)?0:realincomamt.hashCode());
		result = prime * result + ((indeminityTag==null)?0:indeminityTag.hashCode());
		result = prime * result + ((delayIndeminity==null)?0:delayIndeminity.hashCode());
		result = prime * result + ((icheDate==null)?0:icheDate.hashCode());
		result = prime * result + ((icheYn==null)?0:icheYn.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO other = (kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( receiptamt == null ){
			if ( other.receiptamt != null ) return false;
		}
		else if ( !receiptamt.equals(other.receiptamt) )
			return false;
		if ( realincomamt == null ){
			if ( other.realincomamt != null ) return false;
		}
		else if ( !realincomamt.equals(other.realincomamt) )
			return false;
		if ( indeminityTag == null ){
			if ( other.indeminityTag != null ) return false;
		}
		else if ( !indeminityTag.equals(other.indeminityTag) )
			return false;
		if ( delayIndeminity == null ){
			if ( other.delayIndeminity != null ) return false;
		}
		else if ( !delayIndeminity.equals(other.delayIndeminity) )
			return false;
		if ( icheDate == null ){
			if ( other.icheDate != null ) return false;
		}
		else if ( !icheDate.equals(other.icheDate) )
			return false;
		if ( icheYn == null ){
			if ( other.icheYn != null ) return false;
		}
		else if ( !icheYn.equals(other.icheYn) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\treceiptamt: ");
		sb.append(receiptamt==null?"null":getReceiptamt());
		sb.append("\n");
		sb.append("\trealincomamt: ");
		sb.append(realincomamt==null?"null":getRealincomamt());
		sb.append("\n");
		sb.append("\tindeminityTag: ");
		sb.append(indeminityTag==null?"null":getIndeminityTag());
		sb.append("\n");
		sb.append("\tdelayIndeminity: ");
		sb.append(delayIndeminity==null?"null":getDelayIndeminity());
		sb.append("\n");
		sb.append("\ticheDate: ");
		sb.append(icheDate==null?"null":getIcheDate());
		sb.append("\n");
		sb.append("\ticheYn: ");
		sb.append(icheYn==null?"null":getIcheYn());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* receiptamt */
		messageLen+= 22; /* realincomamt */
		messageLen+= 1; /* indeminityTag */
		messageLen+= 22; /* delayIndeminity */
		messageLen+= 8; /* icheDate */
		messageLen+= 1; /* icheYn */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("receiptamt");
	
		fieldNames.add("realincomamt");
	
		fieldNames.add("indeminityTag");
	
		fieldNames.add("delayIndeminity");
	
		fieldNames.add("icheDate");
	
		fieldNames.add("icheYn");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("receiptamt", get("receiptamt"));
	
		fieldValueMap.put("realincomamt", get("realincomamt"));
	
		fieldValueMap.put("indeminityTag", get("indeminityTag"));
	
		fieldValueMap.put("delayIndeminity", get("delayIndeminity"));
	
		fieldValueMap.put("icheDate", get("icheDate"));
	
		fieldValueMap.put("icheYn", get("icheYn"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 204160144 : /* receiptamt */
			return getReceiptamt();
		case 1301329322 : /* realincomamt */
			return getRealincomamt();
		case -577366216 : /* indeminityTag */
			return getIndeminityTag();
		case -1325119771 : /* delayIndeminity */
			return getDelayIndeminity();
		case -947127323 : /* icheDate */
			return getIcheDate();
		case -1194279668 : /* icheYn */
			return getIcheYn();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 204160144 : /* receiptamt */
			setReceiptamt((java.math.BigDecimal) value);
			return;
		case 1301329322 : /* realincomamt */
			setRealincomamt((java.math.BigDecimal) value);
			return;
		case -577366216 : /* indeminityTag */
			setIndeminityTag((java.lang.String) value);
			return;
		case -1325119771 : /* delayIndeminity */
			setDelayIndeminity((java.math.BigDecimal) value);
			return;
		case -947127323 : /* icheDate */
			setIcheDate((java.lang.String) value);
			return;
		case -1194279668 : /* icheYn */
			setIcheYn((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
