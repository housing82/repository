/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_세대별공급내역_업로드 ( HD_HOUS_SUPPLY_CONV )
 */
@XmlType(propOrder={"deptCode", "housetag", "seq", "buildno", "houseno", "square", "type", "classJrw", "optioncode", "contractyesno"}, name="DHDHousSupplyConv01IO")
@XmlRootElement(name="DHDHousSupplyConv01IO")
@SuppressWarnings("all")
public class DHDHousSupplyConv01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1231559839L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_세대별공급내역_업로드 ( HD_HOUS_SUPPLY_CONV )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012453(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012453(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012453(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012454(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012454(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012454(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012455(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012455(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012455(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012455(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012455(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012455(C),SYS_C0012962(P) SYS_C0012962(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012456(C)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012456(C)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012456(C)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012457(C)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012457(C)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012457(C)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 평형
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 평형
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 평형
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 평형
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << type >> [[ */
	
	@XmlTransient
	private boolean isSet_type = false;
	
	protected boolean isSet_type()
	{
		return this.isSet_type;
	}
	
	protected void setIsSet_type(boolean value)
	{
		this.isSet_type = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="TYPE", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String type  = null;
	
	/**
	 * @Description TYPE
	 */
	public java.lang.String getType(){
		return type;
	}
	
	/**
	 * @Description TYPE
	 */
	@JsonProperty("type")
	public void setType( java.lang.String type ) {
		isSet_type = true;
		this.type = type;
	}
	
	/** Property set << type >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << classJrw >> [[ */
	
	@XmlTransient
	private boolean isSet_classJrw = false;
	
	protected boolean isSet_classJrw()
	{
		return this.isSet_classJrw;
	}
	
	protected void setIsSet_classJrw(boolean value)
	{
		this.isSet_classJrw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="군", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String classJrw  = null;
	
	/**
	 * @Description 군
	 */
	public java.lang.String getClassJrw(){
		return classJrw;
	}
	
	/**
	 * @Description 군
	 */
	@JsonProperty("classJrw")
	public void setClassJrw( java.lang.String classJrw ) {
		isSet_classJrw = true;
		this.classJrw = classJrw;
	}
	
	/** Property set << classJrw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optioncode >> [[ */
	
	@XmlTransient
	private boolean isSet_optioncode = false;
	
	protected boolean isSet_optioncode()
	{
		return this.isSet_optioncode;
	}
	
	protected void setIsSet_optioncode(boolean value)
	{
		this.isSet_optioncode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선택사양코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String optioncode  = null;
	
	/**
	 * @Description 선택사양코드
	 */
	public java.lang.String getOptioncode(){
		return optioncode;
	}
	
	/**
	 * @Description 선택사양코드
	 */
	@JsonProperty("optioncode")
	public void setOptioncode( java.lang.String optioncode ) {
		isSet_optioncode = true;
		this.optioncode = optioncode;
	}
	
	/** Property set << optioncode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contractyesno >> [[ */
	
	@XmlTransient
	private boolean isSet_contractyesno = false;
	
	protected boolean isSet_contractyesno()
	{
		return this.isSet_contractyesno;
	}
	
	protected void setIsSet_contractyesno(boolean value)
	{
		this.isSet_contractyesno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약여부 [SYS_C0012458(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String contractyesno  = null;
	
	/**
	 * @Description 계약여부 [SYS_C0012458(C)]
	 */
	public java.lang.String getContractyesno(){
		return contractyesno;
	}
	
	/**
	 * @Description 계약여부 [SYS_C0012458(C)]
	 */
	@JsonProperty("contractyesno")
	public void setContractyesno( java.lang.String contractyesno ) {
		isSet_contractyesno = true;
		this.contractyesno = contractyesno;
	}
	
	/** Property set << contractyesno >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSupplyConv01IO clone(){
		try{
			DHDHousSupplyConv01IO object= (DHDHousSupplyConv01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.type== null ) object.type = null;
			else{
				object.type = this.type;
			}
			if ( this.classJrw== null ) object.classJrw = null;
			else{
				object.classJrw = this.classJrw;
			}
			if ( this.optioncode== null ) object.optioncode = null;
			else{
				object.optioncode = this.optioncode;
			}
			if ( this.contractyesno== null ) object.contractyesno = null;
			else{
				object.contractyesno = this.contractyesno;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((type==null)?0:type.hashCode());
		result = prime * result + ((classJrw==null)?0:classJrw.hashCode());
		result = prime * result + ((optioncode==null)?0:optioncode.hashCode());
		result = prime * result + ((contractyesno==null)?0:contractyesno.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( type == null ){
			if ( other.type != null ) return false;
		}
		else if ( !type.equals(other.type) )
			return false;
		if ( classJrw == null ){
			if ( other.classJrw != null ) return false;
		}
		else if ( !classJrw.equals(other.classJrw) )
			return false;
		if ( optioncode == null ){
			if ( other.optioncode != null ) return false;
		}
		else if ( !optioncode.equals(other.optioncode) )
			return false;
		if ( contractyesno == null ){
			if ( other.contractyesno != null ) return false;
		}
		else if ( !contractyesno.equals(other.contractyesno) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttype: ");
		sb.append(type==null?"null":getType());
		sb.append("\n");
		sb.append("\tclassJrw: ");
		sb.append(classJrw==null?"null":getClassJrw());
		sb.append("\n");
		sb.append("\toptioncode: ");
		sb.append(optioncode==null?"null":getOptioncode());
		sb.append("\n");
		sb.append("\tcontractyesno: ");
		sb.append(contractyesno==null?"null":getContractyesno());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* seq */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 22; /* square */
		messageLen+= 4; /* type */
		messageLen+= 1; /* classJrw */
		messageLen+= 2; /* optioncode */
		messageLen+= 1; /* contractyesno */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("seq");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("square");
	
		fieldNames.add("type");
	
		fieldNames.add("classJrw");
	
		fieldNames.add("optioncode");
	
		fieldNames.add("contractyesno");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("type", get("type"));
	
		fieldValueMap.put("classJrw", get("classJrw"));
	
		fieldValueMap.put("optioncode", get("optioncode"));
	
		fieldValueMap.put("contractyesno", get("contractyesno"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 113759 : /* seq */
			return getSeq();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -894674659 : /* square */
			return getSquare();
		case 3575610 : /* type */
			return getType();
		case 692414359 : /* classJrw */
			return getClassJrw();
		case 1374024674 : /* optioncode */
			return getOptioncode();
		case -488796906 : /* contractyesno */
			return getContractyesno();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case 3575610 : /* type */
			setType((java.lang.String) value);
			return;
		case 692414359 : /* classJrw */
			setClassJrw((java.lang.String) value);
			return;
		case 1374024674 : /* optioncode */
			setOptioncode((java.lang.String) value);
			return;
		case -488796906 : /* contractyesno */
			setContractyesno((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
