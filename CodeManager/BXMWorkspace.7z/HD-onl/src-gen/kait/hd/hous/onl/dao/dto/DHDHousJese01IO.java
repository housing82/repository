/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_재세공과금 ( HD_HOUS_JESE )
 */
@XmlType(propOrder={"custCode", "seq", "deptCode", "housetag", "deposit1", "indate1", "inamt1", "deposit2", "indate2", "inamt2", "deposit3", "indate3", "inamt3", "jungsanBdate", "jungsanSdate", "sisulBdate", "sisulSdate", "dungBdate", "dungSdate", "boBdate", "boSdate", "bubmuBuild", "bubmuLand", "etcSdate", "etcAdate", "etcIdate", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousJese01IO")
@XmlRootElement(name="DHDHousJese01IO")
@SuppressWarnings("all")
public class DHDHousJese01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 623460201L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_재세공과금 ( HD_HOUS_JESE )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객코드 [SYS_C0012259(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 고객코드 [SYS_C0012259(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 고객코드 [SYS_C0012259(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012260(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012260(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012260(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012260(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012260(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012260(C),SYS_C0012938(P) SYS_C0012938(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012261(C)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012261(C)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012261(C)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012262(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012262(C)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012262(C)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deposit1 >> [[ */
	
	@XmlTransient
	private boolean isSet_deposit1 = false;
	
	protected boolean isSet_deposit1()
	{
		return this.isSet_deposit1;
	}
	
	protected void setIsSet_deposit1(boolean value)
	{
		this.isSet_deposit1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="재산세_계좌", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String deposit1  = null;
	
	/**
	 * @Description 재산세_계좌
	 */
	public java.lang.String getDeposit1(){
		return deposit1;
	}
	
	/**
	 * @Description 재산세_계좌
	 */
	@JsonProperty("deposit1")
	public void setDeposit1( java.lang.String deposit1 ) {
		isSet_deposit1 = true;
		this.deposit1 = deposit1;
	}
	
	/** Property set << deposit1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indate1 >> [[ */
	
	@XmlTransient
	private boolean isSet_indate1 = false;
	
	protected boolean isSet_indate1()
	{
		return this.isSet_indate1;
	}
	
	protected void setIsSet_indate1(boolean value)
	{
		this.isSet_indate1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="재산세_입금일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String indate1  = null;
	
	/**
	 * @Description 재산세_입금일
	 */
	public java.lang.String getIndate1(){
		return indate1;
	}
	
	/**
	 * @Description 재산세_입금일
	 */
	@JsonProperty("indate1")
	public void setIndate1( java.lang.String indate1 ) {
		isSet_indate1 = true;
		this.indate1 = indate1;
	}
	
	/** Property set << indate1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inamt1 >> [[ */
	
	@XmlTransient
	private boolean isSet_inamt1 = false;
	
	protected boolean isSet_inamt1()
	{
		return this.isSet_inamt1;
	}
	
	protected void setIsSet_inamt1(boolean value)
	{
		this.isSet_inamt1 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 재산세_입금액
	 */
	public void setInamt1(java.lang.String value) {
		isSet_inamt1 = true;
		this.inamt1 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 재산세_입금액
	 */
	public void setInamt1(double value) {
		isSet_inamt1 = true;
		this.inamt1 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 재산세_입금액
	 */
	public void setInamt1(long value) {
		isSet_inamt1 = true;
		this.inamt1 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="재산세_입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inamt1  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 재산세_입금액
	 */
	public java.math.BigDecimal getInamt1(){
		return inamt1;
	}
	
	/**
	 * @Description 재산세_입금액
	 */
	@JsonProperty("inamt1")
	public void setInamt1( java.math.BigDecimal inamt1 ) {
		isSet_inamt1 = true;
		this.inamt1 = inamt1;
	}
	
	/** Property set << inamt1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deposit2 >> [[ */
	
	@XmlTransient
	private boolean isSet_deposit2 = false;
	
	protected boolean isSet_deposit2()
	{
		return this.isSet_deposit2;
	}
	
	protected void setIsSet_deposit2(boolean value)
	{
		this.isSet_deposit2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이자_계좌", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String deposit2  = null;
	
	/**
	 * @Description 기간이자_계좌
	 */
	public java.lang.String getDeposit2(){
		return deposit2;
	}
	
	/**
	 * @Description 기간이자_계좌
	 */
	@JsonProperty("deposit2")
	public void setDeposit2( java.lang.String deposit2 ) {
		isSet_deposit2 = true;
		this.deposit2 = deposit2;
	}
	
	/** Property set << deposit2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indate2 >> [[ */
	
	@XmlTransient
	private boolean isSet_indate2 = false;
	
	protected boolean isSet_indate2()
	{
		return this.isSet_indate2;
	}
	
	protected void setIsSet_indate2(boolean value)
	{
		this.isSet_indate2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이자_입금일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String indate2  = null;
	
	/**
	 * @Description 기간이자_입금일
	 */
	public java.lang.String getIndate2(){
		return indate2;
	}
	
	/**
	 * @Description 기간이자_입금일
	 */
	@JsonProperty("indate2")
	public void setIndate2( java.lang.String indate2 ) {
		isSet_indate2 = true;
		this.indate2 = indate2;
	}
	
	/** Property set << indate2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inamt2 >> [[ */
	
	@XmlTransient
	private boolean isSet_inamt2 = false;
	
	protected boolean isSet_inamt2()
	{
		return this.isSet_inamt2;
	}
	
	protected void setIsSet_inamt2(boolean value)
	{
		this.isSet_inamt2 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기간이자_입금액
	 */
	public void setInamt2(java.lang.String value) {
		isSet_inamt2 = true;
		this.inamt2 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기간이자_입금액
	 */
	public void setInamt2(double value) {
		isSet_inamt2 = true;
		this.inamt2 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기간이자_입금액
	 */
	public void setInamt2(long value) {
		isSet_inamt2 = true;
		this.inamt2 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기간이자_입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inamt2  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기간이자_입금액
	 */
	public java.math.BigDecimal getInamt2(){
		return inamt2;
	}
	
	/**
	 * @Description 기간이자_입금액
	 */
	@JsonProperty("inamt2")
	public void setInamt2( java.math.BigDecimal inamt2 ) {
		isSet_inamt2 = true;
		this.inamt2 = inamt2;
	}
	
	/** Property set << inamt2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deposit3 >> [[ */
	
	@XmlTransient
	private boolean isSet_deposit3 = false;
	
	protected boolean isSet_deposit3()
	{
		return this.isSet_deposit3;
	}
	
	protected void setIsSet_deposit3(boolean value)
	{
		this.isSet_deposit3 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="관리비_계좌", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String deposit3  = null;
	
	/**
	 * @Description 관리비_계좌
	 */
	public java.lang.String getDeposit3(){
		return deposit3;
	}
	
	/**
	 * @Description 관리비_계좌
	 */
	@JsonProperty("deposit3")
	public void setDeposit3( java.lang.String deposit3 ) {
		isSet_deposit3 = true;
		this.deposit3 = deposit3;
	}
	
	/** Property set << deposit3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indate3 >> [[ */
	
	@XmlTransient
	private boolean isSet_indate3 = false;
	
	protected boolean isSet_indate3()
	{
		return this.isSet_indate3;
	}
	
	protected void setIsSet_indate3(boolean value)
	{
		this.isSet_indate3 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="관리비_입금일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String indate3  = null;
	
	/**
	 * @Description 관리비_입금일
	 */
	public java.lang.String getIndate3(){
		return indate3;
	}
	
	/**
	 * @Description 관리비_입금일
	 */
	@JsonProperty("indate3")
	public void setIndate3( java.lang.String indate3 ) {
		isSet_indate3 = true;
		this.indate3 = indate3;
	}
	
	/** Property set << indate3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inamt3 >> [[ */
	
	@XmlTransient
	private boolean isSet_inamt3 = false;
	
	protected boolean isSet_inamt3()
	{
		return this.isSet_inamt3;
	}
	
	protected void setIsSet_inamt3(boolean value)
	{
		this.isSet_inamt3 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 관리비_입금액
	 */
	public void setInamt3(java.lang.String value) {
		isSet_inamt3 = true;
		this.inamt3 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 관리비_입금액
	 */
	public void setInamt3(double value) {
		isSet_inamt3 = true;
		this.inamt3 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 관리비_입금액
	 */
	public void setInamt3(long value) {
		isSet_inamt3 = true;
		this.inamt3 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="관리비_입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inamt3  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 관리비_입금액
	 */
	public java.math.BigDecimal getInamt3(){
		return inamt3;
	}
	
	/**
	 * @Description 관리비_입금액
	 */
	@JsonProperty("inamt3")
	public void setInamt3( java.math.BigDecimal inamt3 ) {
		isSet_inamt3 = true;
		this.inamt3 = inamt3;
	}
	
	/** Property set << inamt3 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jungsanBdate >> [[ */
	
	@XmlTransient
	private boolean isSet_jungsanBdate = false;
	
	protected boolean isSet_jungsanBdate()
	{
		return this.isSet_jungsanBdate;
	}
	
	protected void setIsSet_jungsanBdate(boolean value)
	{
		this.isSet_jungsanBdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="정산서_발급일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String jungsanBdate  = null;
	
	/**
	 * @Description 정산서_발급일
	 */
	public java.lang.String getJungsanBdate(){
		return jungsanBdate;
	}
	
	/**
	 * @Description 정산서_발급일
	 */
	@JsonProperty("jungsanBdate")
	public void setJungsanBdate( java.lang.String jungsanBdate ) {
		isSet_jungsanBdate = true;
		this.jungsanBdate = jungsanBdate;
	}
	
	/** Property set << jungsanBdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << jungsanSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_jungsanSdate = false;
	
	protected boolean isSet_jungsanSdate()
	{
		return this.isSet_jungsanSdate;
	}
	
	protected void setIsSet_jungsanSdate(boolean value)
	{
		this.isSet_jungsanSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="정산서_수령일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String jungsanSdate  = null;
	
	/**
	 * @Description 정산서_수령일
	 */
	public java.lang.String getJungsanSdate(){
		return jungsanSdate;
	}
	
	/**
	 * @Description 정산서_수령일
	 */
	@JsonProperty("jungsanSdate")
	public void setJungsanSdate( java.lang.String jungsanSdate ) {
		isSet_jungsanSdate = true;
		this.jungsanSdate = jungsanSdate;
	}
	
	/** Property set << jungsanSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sisulBdate >> [[ */
	
	@XmlTransient
	private boolean isSet_sisulBdate = false;
	
	protected boolean isSet_sisulBdate()
	{
		return this.isSet_sisulBdate;
	}
	
	protected void setIsSet_sisulBdate(boolean value)
	{
		this.isSet_sisulBdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시설물인수증_발급일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String sisulBdate  = null;
	
	/**
	 * @Description 시설물인수증_발급일
	 */
	public java.lang.String getSisulBdate(){
		return sisulBdate;
	}
	
	/**
	 * @Description 시설물인수증_발급일
	 */
	@JsonProperty("sisulBdate")
	public void setSisulBdate( java.lang.String sisulBdate ) {
		isSet_sisulBdate = true;
		this.sisulBdate = sisulBdate;
	}
	
	/** Property set << sisulBdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sisulSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_sisulSdate = false;
	
	protected boolean isSet_sisulSdate()
	{
		return this.isSet_sisulSdate;
	}
	
	protected void setIsSet_sisulSdate(boolean value)
	{
		this.isSet_sisulSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시설물인수증_수령일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String sisulSdate  = null;
	
	/**
	 * @Description 시설물인수증_수령일
	 */
	public java.lang.String getSisulSdate(){
		return sisulSdate;
	}
	
	/**
	 * @Description 시설물인수증_수령일
	 */
	@JsonProperty("sisulSdate")
	public void setSisulSdate( java.lang.String sisulSdate ) {
		isSet_sisulSdate = true;
		this.sisulSdate = sisulSdate;
	}
	
	/** Property set << sisulSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dungBdate >> [[ */
	
	@XmlTransient
	private boolean isSet_dungBdate = false;
	
	protected boolean isSet_dungBdate()
	{
		return this.isSet_dungBdate;
	}
	
	protected void setIsSet_dungBdate(boolean value)
	{
		this.isSet_dungBdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="등기이전일_건물", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String dungBdate  = null;
	
	/**
	 * @Description 등기이전일_건물
	 */
	public java.lang.String getDungBdate(){
		return dungBdate;
	}
	
	/**
	 * @Description 등기이전일_건물
	 */
	@JsonProperty("dungBdate")
	public void setDungBdate( java.lang.String dungBdate ) {
		isSet_dungBdate = true;
		this.dungBdate = dungBdate;
	}
	
	/** Property set << dungBdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dungSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_dungSdate = false;
	
	protected boolean isSet_dungSdate()
	{
		return this.isSet_dungSdate;
	}
	
	protected void setIsSet_dungSdate(boolean value)
	{
		this.isSet_dungSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="등기이전일_토지", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String dungSdate  = null;
	
	/**
	 * @Description 등기이전일_토지
	 */
	public java.lang.String getDungSdate(){
		return dungSdate;
	}
	
	/**
	 * @Description 등기이전일_토지
	 */
	@JsonProperty("dungSdate")
	public void setDungSdate( java.lang.String dungSdate ) {
		isSet_dungSdate = true;
		this.dungSdate = dungSdate;
	}
	
	/** Property set << dungSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << boBdate >> [[ */
	
	@XmlTransient
	private boolean isSet_boBdate = false;
	
	protected boolean isSet_boBdate()
	{
		return this.isSet_boBdate;
	}
	
	protected void setIsSet_boBdate(boolean value)
	{
		this.isSet_boBdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="보존등기일_건물", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String boBdate  = null;
	
	/**
	 * @Description 보존등기일_건물
	 */
	public java.lang.String getBoBdate(){
		return boBdate;
	}
	
	/**
	 * @Description 보존등기일_건물
	 */
	@JsonProperty("boBdate")
	public void setBoBdate( java.lang.String boBdate ) {
		isSet_boBdate = true;
		this.boBdate = boBdate;
	}
	
	/** Property set << boBdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << boSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_boSdate = false;
	
	protected boolean isSet_boSdate()
	{
		return this.isSet_boSdate;
	}
	
	protected void setIsSet_boSdate(boolean value)
	{
		this.isSet_boSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="보존등기일_토지", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String boSdate  = null;
	
	/**
	 * @Description 보존등기일_토지
	 */
	public java.lang.String getBoSdate(){
		return boSdate;
	}
	
	/**
	 * @Description 보존등기일_토지
	 */
	@JsonProperty("boSdate")
	public void setBoSdate( java.lang.String boSdate ) {
		isSet_boSdate = true;
		this.boSdate = boSdate;
	}
	
	/** Property set << boSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bubmuBuild >> [[ */
	
	@XmlTransient
	private boolean isSet_bubmuBuild = false;
	
	protected boolean isSet_bubmuBuild()
	{
		return this.isSet_bubmuBuild;
	}
	
	protected void setIsSet_bubmuBuild(boolean value)
	{
		this.isSet_bubmuBuild = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="법무사_건물", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String bubmuBuild  = null;
	
	/**
	 * @Description 법무사_건물
	 */
	public java.lang.String getBubmuBuild(){
		return bubmuBuild;
	}
	
	/**
	 * @Description 법무사_건물
	 */
	@JsonProperty("bubmuBuild")
	public void setBubmuBuild( java.lang.String bubmuBuild ) {
		isSet_bubmuBuild = true;
		this.bubmuBuild = bubmuBuild;
	}
	
	/** Property set << bubmuBuild >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bubmuLand >> [[ */
	
	@XmlTransient
	private boolean isSet_bubmuLand = false;
	
	protected boolean isSet_bubmuLand()
	{
		return this.isSet_bubmuLand;
	}
	
	protected void setIsSet_bubmuLand(boolean value)
	{
		this.isSet_bubmuLand = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="법무사_토지", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String bubmuLand  = null;
	
	/**
	 * @Description 법무사_토지
	 */
	public java.lang.String getBubmuLand(){
		return bubmuLand;
	}
	
	/**
	 * @Description 법무사_토지
	 */
	@JsonProperty("bubmuLand")
	public void setBubmuLand( java.lang.String bubmuLand ) {
		isSet_bubmuLand = true;
		this.bubmuLand = bubmuLand;
	}
	
	/** Property set << bubmuLand >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etcSdate >> [[ */
	
	@XmlTransient
	private boolean isSet_etcSdate = false;
	
	protected boolean isSet_etcSdate()
	{
		return this.isSet_etcSdate;
	}
	
	protected void setIsSet_etcSdate(boolean value)
	{
		this.isSet_etcSdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기타_근저당설정일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String etcSdate  = null;
	
	/**
	 * @Description 기타_근저당설정일
	 */
	public java.lang.String getEtcSdate(){
		return etcSdate;
	}
	
	/**
	 * @Description 기타_근저당설정일
	 */
	@JsonProperty("etcSdate")
	public void setEtcSdate( java.lang.String etcSdate ) {
		isSet_etcSdate = true;
		this.etcSdate = etcSdate;
	}
	
	/** Property set << etcSdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etcAdate >> [[ */
	
	@XmlTransient
	private boolean isSet_etcAdate = false;
	
	protected boolean isSet_etcAdate()
	{
		return this.isSet_etcAdate;
	}
	
	protected void setIsSet_etcAdate(boolean value)
	{
		this.isSet_etcAdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기타_등기서류교부일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String etcAdate  = null;
	
	/**
	 * @Description 기타_등기서류교부일
	 */
	public java.lang.String getEtcAdate(){
		return etcAdate;
	}
	
	/**
	 * @Description 기타_등기서류교부일
	 */
	@JsonProperty("etcAdate")
	public void setEtcAdate( java.lang.String etcAdate ) {
		isSet_etcAdate = true;
		this.etcAdate = etcAdate;
	}
	
	/** Property set << etcAdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etcIdate >> [[ */
	
	@XmlTransient
	private boolean isSet_etcIdate = false;
	
	protected boolean isSet_etcIdate()
	{
		return this.isSet_etcIdate;
	}
	
	protected void setIsSet_etcIdate(boolean value)
	{
		this.isSet_etcIdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기타_입주일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String etcIdate  = null;
	
	/**
	 * @Description 기타_입주일
	 */
	public java.lang.String getEtcIdate(){
		return etcIdate;
	}
	
	/**
	 * @Description 기타_입주일
	 */
	@JsonProperty("etcIdate")
	public void setEtcIdate( java.lang.String etcIdate ) {
		isSet_etcIdate = true;
		this.etcIdate = etcIdate;
	}
	
	/** Property set << etcIdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousJese01IO clone(){
		try{
			DHDHousJese01IO object= (DHDHousJese01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.deposit1== null ) object.deposit1 = null;
			else{
				object.deposit1 = this.deposit1;
			}
			if ( this.indate1== null ) object.indate1 = null;
			else{
				object.indate1 = this.indate1;
			}
			if ( this.inamt1== null ) object.inamt1 = null;
			else{
				object.inamt1 = new java.math.BigDecimal(inamt1.toString());
			}
			if ( this.deposit2== null ) object.deposit2 = null;
			else{
				object.deposit2 = this.deposit2;
			}
			if ( this.indate2== null ) object.indate2 = null;
			else{
				object.indate2 = this.indate2;
			}
			if ( this.inamt2== null ) object.inamt2 = null;
			else{
				object.inamt2 = new java.math.BigDecimal(inamt2.toString());
			}
			if ( this.deposit3== null ) object.deposit3 = null;
			else{
				object.deposit3 = this.deposit3;
			}
			if ( this.indate3== null ) object.indate3 = null;
			else{
				object.indate3 = this.indate3;
			}
			if ( this.inamt3== null ) object.inamt3 = null;
			else{
				object.inamt3 = new java.math.BigDecimal(inamt3.toString());
			}
			if ( this.jungsanBdate== null ) object.jungsanBdate = null;
			else{
				object.jungsanBdate = this.jungsanBdate;
			}
			if ( this.jungsanSdate== null ) object.jungsanSdate = null;
			else{
				object.jungsanSdate = this.jungsanSdate;
			}
			if ( this.sisulBdate== null ) object.sisulBdate = null;
			else{
				object.sisulBdate = this.sisulBdate;
			}
			if ( this.sisulSdate== null ) object.sisulSdate = null;
			else{
				object.sisulSdate = this.sisulSdate;
			}
			if ( this.dungBdate== null ) object.dungBdate = null;
			else{
				object.dungBdate = this.dungBdate;
			}
			if ( this.dungSdate== null ) object.dungSdate = null;
			else{
				object.dungSdate = this.dungSdate;
			}
			if ( this.boBdate== null ) object.boBdate = null;
			else{
				object.boBdate = this.boBdate;
			}
			if ( this.boSdate== null ) object.boSdate = null;
			else{
				object.boSdate = this.boSdate;
			}
			if ( this.bubmuBuild== null ) object.bubmuBuild = null;
			else{
				object.bubmuBuild = this.bubmuBuild;
			}
			if ( this.bubmuLand== null ) object.bubmuLand = null;
			else{
				object.bubmuLand = this.bubmuLand;
			}
			if ( this.etcSdate== null ) object.etcSdate = null;
			else{
				object.etcSdate = this.etcSdate;
			}
			if ( this.etcAdate== null ) object.etcAdate = null;
			else{
				object.etcAdate = this.etcAdate;
			}
			if ( this.etcIdate== null ) object.etcIdate = null;
			else{
				object.etcIdate = this.etcIdate;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((deposit1==null)?0:deposit1.hashCode());
		result = prime * result + ((indate1==null)?0:indate1.hashCode());
		result = prime * result + ((inamt1==null)?0:inamt1.hashCode());
		result = prime * result + ((deposit2==null)?0:deposit2.hashCode());
		result = prime * result + ((indate2==null)?0:indate2.hashCode());
		result = prime * result + ((inamt2==null)?0:inamt2.hashCode());
		result = prime * result + ((deposit3==null)?0:deposit3.hashCode());
		result = prime * result + ((indate3==null)?0:indate3.hashCode());
		result = prime * result + ((inamt3==null)?0:inamt3.hashCode());
		result = prime * result + ((jungsanBdate==null)?0:jungsanBdate.hashCode());
		result = prime * result + ((jungsanSdate==null)?0:jungsanSdate.hashCode());
		result = prime * result + ((sisulBdate==null)?0:sisulBdate.hashCode());
		result = prime * result + ((sisulSdate==null)?0:sisulSdate.hashCode());
		result = prime * result + ((dungBdate==null)?0:dungBdate.hashCode());
		result = prime * result + ((dungSdate==null)?0:dungSdate.hashCode());
		result = prime * result + ((boBdate==null)?0:boBdate.hashCode());
		result = prime * result + ((boSdate==null)?0:boSdate.hashCode());
		result = prime * result + ((bubmuBuild==null)?0:bubmuBuild.hashCode());
		result = prime * result + ((bubmuLand==null)?0:bubmuLand.hashCode());
		result = prime * result + ((etcSdate==null)?0:etcSdate.hashCode());
		result = prime * result + ((etcAdate==null)?0:etcAdate.hashCode());
		result = prime * result + ((etcIdate==null)?0:etcIdate.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousJese01IO other = (kait.hd.hous.onl.dao.dto.DHDHousJese01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( deposit1 == null ){
			if ( other.deposit1 != null ) return false;
		}
		else if ( !deposit1.equals(other.deposit1) )
			return false;
		if ( indate1 == null ){
			if ( other.indate1 != null ) return false;
		}
		else if ( !indate1.equals(other.indate1) )
			return false;
		if ( inamt1 == null ){
			if ( other.inamt1 != null ) return false;
		}
		else if ( !inamt1.equals(other.inamt1) )
			return false;
		if ( deposit2 == null ){
			if ( other.deposit2 != null ) return false;
		}
		else if ( !deposit2.equals(other.deposit2) )
			return false;
		if ( indate2 == null ){
			if ( other.indate2 != null ) return false;
		}
		else if ( !indate2.equals(other.indate2) )
			return false;
		if ( inamt2 == null ){
			if ( other.inamt2 != null ) return false;
		}
		else if ( !inamt2.equals(other.inamt2) )
			return false;
		if ( deposit3 == null ){
			if ( other.deposit3 != null ) return false;
		}
		else if ( !deposit3.equals(other.deposit3) )
			return false;
		if ( indate3 == null ){
			if ( other.indate3 != null ) return false;
		}
		else if ( !indate3.equals(other.indate3) )
			return false;
		if ( inamt3 == null ){
			if ( other.inamt3 != null ) return false;
		}
		else if ( !inamt3.equals(other.inamt3) )
			return false;
		if ( jungsanBdate == null ){
			if ( other.jungsanBdate != null ) return false;
		}
		else if ( !jungsanBdate.equals(other.jungsanBdate) )
			return false;
		if ( jungsanSdate == null ){
			if ( other.jungsanSdate != null ) return false;
		}
		else if ( !jungsanSdate.equals(other.jungsanSdate) )
			return false;
		if ( sisulBdate == null ){
			if ( other.sisulBdate != null ) return false;
		}
		else if ( !sisulBdate.equals(other.sisulBdate) )
			return false;
		if ( sisulSdate == null ){
			if ( other.sisulSdate != null ) return false;
		}
		else if ( !sisulSdate.equals(other.sisulSdate) )
			return false;
		if ( dungBdate == null ){
			if ( other.dungBdate != null ) return false;
		}
		else if ( !dungBdate.equals(other.dungBdate) )
			return false;
		if ( dungSdate == null ){
			if ( other.dungSdate != null ) return false;
		}
		else if ( !dungSdate.equals(other.dungSdate) )
			return false;
		if ( boBdate == null ){
			if ( other.boBdate != null ) return false;
		}
		else if ( !boBdate.equals(other.boBdate) )
			return false;
		if ( boSdate == null ){
			if ( other.boSdate != null ) return false;
		}
		else if ( !boSdate.equals(other.boSdate) )
			return false;
		if ( bubmuBuild == null ){
			if ( other.bubmuBuild != null ) return false;
		}
		else if ( !bubmuBuild.equals(other.bubmuBuild) )
			return false;
		if ( bubmuLand == null ){
			if ( other.bubmuLand != null ) return false;
		}
		else if ( !bubmuLand.equals(other.bubmuLand) )
			return false;
		if ( etcSdate == null ){
			if ( other.etcSdate != null ) return false;
		}
		else if ( !etcSdate.equals(other.etcSdate) )
			return false;
		if ( etcAdate == null ){
			if ( other.etcAdate != null ) return false;
		}
		else if ( !etcAdate.equals(other.etcAdate) )
			return false;
		if ( etcIdate == null ){
			if ( other.etcIdate != null ) return false;
		}
		else if ( !etcIdate.equals(other.etcIdate) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousJese01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tdeposit1: ");
		sb.append(deposit1==null?"null":getDeposit1());
		sb.append("\n");
		sb.append("\tindate1: ");
		sb.append(indate1==null?"null":getIndate1());
		sb.append("\n");
		sb.append("\tinamt1: ");
		sb.append(inamt1==null?"null":getInamt1());
		sb.append("\n");
		sb.append("\tdeposit2: ");
		sb.append(deposit2==null?"null":getDeposit2());
		sb.append("\n");
		sb.append("\tindate2: ");
		sb.append(indate2==null?"null":getIndate2());
		sb.append("\n");
		sb.append("\tinamt2: ");
		sb.append(inamt2==null?"null":getInamt2());
		sb.append("\n");
		sb.append("\tdeposit3: ");
		sb.append(deposit3==null?"null":getDeposit3());
		sb.append("\n");
		sb.append("\tindate3: ");
		sb.append(indate3==null?"null":getIndate3());
		sb.append("\n");
		sb.append("\tinamt3: ");
		sb.append(inamt3==null?"null":getInamt3());
		sb.append("\n");
		sb.append("\tjungsanBdate: ");
		sb.append(jungsanBdate==null?"null":getJungsanBdate());
		sb.append("\n");
		sb.append("\tjungsanSdate: ");
		sb.append(jungsanSdate==null?"null":getJungsanSdate());
		sb.append("\n");
		sb.append("\tsisulBdate: ");
		sb.append(sisulBdate==null?"null":getSisulBdate());
		sb.append("\n");
		sb.append("\tsisulSdate: ");
		sb.append(sisulSdate==null?"null":getSisulSdate());
		sb.append("\n");
		sb.append("\tdungBdate: ");
		sb.append(dungBdate==null?"null":getDungBdate());
		sb.append("\n");
		sb.append("\tdungSdate: ");
		sb.append(dungSdate==null?"null":getDungSdate());
		sb.append("\n");
		sb.append("\tboBdate: ");
		sb.append(boBdate==null?"null":getBoBdate());
		sb.append("\n");
		sb.append("\tboSdate: ");
		sb.append(boSdate==null?"null":getBoSdate());
		sb.append("\n");
		sb.append("\tbubmuBuild: ");
		sb.append(bubmuBuild==null?"null":getBubmuBuild());
		sb.append("\n");
		sb.append("\tbubmuLand: ");
		sb.append(bubmuLand==null?"null":getBubmuLand());
		sb.append("\n");
		sb.append("\tetcSdate: ");
		sb.append(etcSdate==null?"null":getEtcSdate());
		sb.append("\n");
		sb.append("\tetcAdate: ");
		sb.append(etcAdate==null?"null":getEtcAdate());
		sb.append("\n");
		sb.append("\tetcIdate: ");
		sb.append(etcIdate==null?"null":getEtcIdate());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 20; /* deposit1 */
		messageLen+= 8; /* indate1 */
		messageLen+= 22; /* inamt1 */
		messageLen+= 20; /* deposit2 */
		messageLen+= 8; /* indate2 */
		messageLen+= 22; /* inamt2 */
		messageLen+= 20; /* deposit3 */
		messageLen+= 8; /* indate3 */
		messageLen+= 22; /* inamt3 */
		messageLen+= 8; /* jungsanBdate */
		messageLen+= 8; /* jungsanSdate */
		messageLen+= 8; /* sisulBdate */
		messageLen+= 8; /* sisulSdate */
		messageLen+= 8; /* dungBdate */
		messageLen+= 8; /* dungSdate */
		messageLen+= 8; /* boBdate */
		messageLen+= 8; /* boSdate */
		messageLen+= 50; /* bubmuBuild */
		messageLen+= 50; /* bubmuLand */
		messageLen+= 8; /* etcSdate */
		messageLen+= 8; /* etcAdate */
		messageLen+= 8; /* etcIdate */
		messageLen+= 200; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("deposit1");
	
		fieldNames.add("indate1");
	
		fieldNames.add("inamt1");
	
		fieldNames.add("deposit2");
	
		fieldNames.add("indate2");
	
		fieldNames.add("inamt2");
	
		fieldNames.add("deposit3");
	
		fieldNames.add("indate3");
	
		fieldNames.add("inamt3");
	
		fieldNames.add("jungsanBdate");
	
		fieldNames.add("jungsanSdate");
	
		fieldNames.add("sisulBdate");
	
		fieldNames.add("sisulSdate");
	
		fieldNames.add("dungBdate");
	
		fieldNames.add("dungSdate");
	
		fieldNames.add("boBdate");
	
		fieldNames.add("boSdate");
	
		fieldNames.add("bubmuBuild");
	
		fieldNames.add("bubmuLand");
	
		fieldNames.add("etcSdate");
	
		fieldNames.add("etcAdate");
	
		fieldNames.add("etcIdate");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("deposit1", get("deposit1"));
	
		fieldValueMap.put("indate1", get("indate1"));
	
		fieldValueMap.put("inamt1", get("inamt1"));
	
		fieldValueMap.put("deposit2", get("deposit2"));
	
		fieldValueMap.put("indate2", get("indate2"));
	
		fieldValueMap.put("inamt2", get("inamt2"));
	
		fieldValueMap.put("deposit3", get("deposit3"));
	
		fieldValueMap.put("indate3", get("indate3"));
	
		fieldValueMap.put("inamt3", get("inamt3"));
	
		fieldValueMap.put("jungsanBdate", get("jungsanBdate"));
	
		fieldValueMap.put("jungsanSdate", get("jungsanSdate"));
	
		fieldValueMap.put("sisulBdate", get("sisulBdate"));
	
		fieldValueMap.put("sisulSdate", get("sisulSdate"));
	
		fieldValueMap.put("dungBdate", get("dungBdate"));
	
		fieldValueMap.put("dungSdate", get("dungSdate"));
	
		fieldValueMap.put("boBdate", get("boBdate"));
	
		fieldValueMap.put("boSdate", get("boSdate"));
	
		fieldValueMap.put("bubmuBuild", get("bubmuBuild"));
	
		fieldValueMap.put("bubmuLand", get("bubmuLand"));
	
		fieldValueMap.put("etcSdate", get("etcSdate"));
	
		fieldValueMap.put("etcAdate", get("etcAdate"));
	
		fieldValueMap.put("etcIdate", get("etcIdate"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 943439187 : /* deposit1 */
			return getDeposit1();
		case 1943169086 : /* indate1 */
			return getIndate1();
		case -1184321010 : /* inamt1 */
			return getInamt1();
		case 943439188 : /* deposit2 */
			return getDeposit2();
		case 1943169087 : /* indate2 */
			return getIndate2();
		case -1184321009 : /* inamt2 */
			return getInamt2();
		case 943439189 : /* deposit3 */
			return getDeposit3();
		case 1943169088 : /* indate3 */
			return getIndate3();
		case -1184321008 : /* inamt3 */
			return getInamt3();
		case 1343561556 : /* jungsanBdate */
			return getJungsanBdate();
		case 1359261413 : /* jungsanSdate */
			return getJungsanSdate();
		case 546043708 : /* sisulBdate */
			return getSisulBdate();
		case 561743565 : /* sisulSdate */
			return getSisulSdate();
		case -752452826 : /* dungBdate */
			return getDungBdate();
		case -736752969 : /* dungSdate */
			return getDungSdate();
		case 22911683 : /* boBdate */
			return getBoBdate();
		case 38611540 : /* boSdate */
			return getBoSdate();
		case 1562265687 : /* bubmuBuild */
			return getBubmuBuild();
		case 1020505826 : /* bubmuLand */
			return getBubmuLand();
		case -1579556499 : /* etcSdate */
			return getEtcSdate();
		case -1596179877 : /* etcAdate */
			return getEtcAdate();
		case -1588791709 : /* etcIdate */
			return getEtcIdate();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 943439187 : /* deposit1 */
			setDeposit1((java.lang.String) value);
			return;
		case 1943169086 : /* indate1 */
			setIndate1((java.lang.String) value);
			return;
		case -1184321010 : /* inamt1 */
			setInamt1((java.math.BigDecimal) value);
			return;
		case 943439188 : /* deposit2 */
			setDeposit2((java.lang.String) value);
			return;
		case 1943169087 : /* indate2 */
			setIndate2((java.lang.String) value);
			return;
		case -1184321009 : /* inamt2 */
			setInamt2((java.math.BigDecimal) value);
			return;
		case 943439189 : /* deposit3 */
			setDeposit3((java.lang.String) value);
			return;
		case 1943169088 : /* indate3 */
			setIndate3((java.lang.String) value);
			return;
		case -1184321008 : /* inamt3 */
			setInamt3((java.math.BigDecimal) value);
			return;
		case 1343561556 : /* jungsanBdate */
			setJungsanBdate((java.lang.String) value);
			return;
		case 1359261413 : /* jungsanSdate */
			setJungsanSdate((java.lang.String) value);
			return;
		case 546043708 : /* sisulBdate */
			setSisulBdate((java.lang.String) value);
			return;
		case 561743565 : /* sisulSdate */
			setSisulSdate((java.lang.String) value);
			return;
		case -752452826 : /* dungBdate */
			setDungBdate((java.lang.String) value);
			return;
		case -736752969 : /* dungSdate */
			setDungSdate((java.lang.String) value);
			return;
		case 22911683 : /* boBdate */
			setBoBdate((java.lang.String) value);
			return;
		case 38611540 : /* boSdate */
			setBoSdate((java.lang.String) value);
			return;
		case 1562265687 : /* bubmuBuild */
			setBubmuBuild((java.lang.String) value);
			return;
		case 1020505826 : /* bubmuLand */
			setBubmuLand((java.lang.String) value);
			return;
		case -1579556499 : /* etcSdate */
			setEtcSdate((java.lang.String) value);
			return;
		case -1596179877 : /* etcAdate */
			setEtcAdate((java.lang.String) value);
			return;
		case -1588791709 : /* etcIdate */
			setEtcIdate((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
