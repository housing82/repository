/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_HOUS_SELL_CONV
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "bseq", "custCode", "seq", "changetag", "contractdate", "lastchangedate", "changedate"}, name="DHDHousSellConv01IO")
@XmlRootElement(name="DHDHousSellConv01IO")
@SuppressWarnings("all")
public class DHDHousSellConv01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1378699586L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_HOUS_SELL_CONV";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012403(C)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description  [SYS_C0012403(C)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description  [SYS_C0012403(C)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012404(C)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description  [SYS_C0012404(C)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description  [SYS_C0012404(C)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bseq >> [[ */
	
	@XmlTransient
	private boolean isSet_bseq = false;
	
	protected boolean isSet_bseq()
	{
		return this.isSet_bseq;
	}
	
	protected void setIsSet_bseq(boolean value)
	{
		this.isSet_bseq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float bseq  = .0F;
	
	/**
	 * @Description 
	 */
	public java.lang.Float getBseq(){
		return bseq;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("bseq")
	public void setBseq( java.lang.Float bseq ) {
		isSet_bseq = true;
		this.bseq = bseq;
	}
	
	/** Property set << bseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012405(C) HD_HOUS_SELL_CONV(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description  [SYS_C0012405(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description  [SYS_C0012405(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description  [SYS_C0012406(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description  [SYS_C0012406(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description  [SYS_C0012406(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012406(C) HD_HOUS_SELL_CONV(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description  [SYS_C0012406(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description  [SYS_C0012406(C) HD_HOUS_SELL_CONV(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changetag >> [[ */
	
	@XmlTransient
	private boolean isSet_changetag = false;
	
	protected boolean isSet_changetag()
	{
		return this.isSet_changetag;
	}
	
	protected void setIsSet_changetag(boolean value)
	{
		this.isSet_changetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012407(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String changetag  = null;
	
	/**
	 * @Description  [SYS_C0012407(C)]
	 */
	public java.lang.String getChangetag(){
		return changetag;
	}
	
	/**
	 * @Description  [SYS_C0012407(C)]
	 */
	@JsonProperty("changetag")
	public void setChangetag( java.lang.String changetag ) {
		isSet_changetag = true;
		this.changetag = changetag;
	}
	
	/** Property set << changetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contractdate >> [[ */
	
	@XmlTransient
	private boolean isSet_contractdate = false;
	
	protected boolean isSet_contractdate()
	{
		return this.isSet_contractdate;
	}
	
	protected void setIsSet_contractdate(boolean value)
	{
		this.isSet_contractdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012408(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String contractdate  = null;
	
	/**
	 * @Description  [SYS_C0012408(C)]
	 */
	public java.lang.String getContractdate(){
		return contractdate;
	}
	
	/**
	 * @Description  [SYS_C0012408(C)]
	 */
	@JsonProperty("contractdate")
	public void setContractdate( java.lang.String contractdate ) {
		isSet_contractdate = true;
		this.contractdate = contractdate;
	}
	
	/** Property set << contractdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << lastchangedate >> [[ */
	
	@XmlTransient
	private boolean isSet_lastchangedate = false;
	
	protected boolean isSet_lastchangedate()
	{
		return this.isSet_lastchangedate;
	}
	
	protected void setIsSet_lastchangedate(boolean value)
	{
		this.isSet_lastchangedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String lastchangedate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getLastchangedate(){
		return lastchangedate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("lastchangedate")
	public void setLastchangedate( java.lang.String lastchangedate ) {
		isSet_lastchangedate = true;
		this.lastchangedate = lastchangedate;
	}
	
	/** Property set << lastchangedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changedate >> [[ */
	
	@XmlTransient
	private boolean isSet_changedate = false;
	
	protected boolean isSet_changedate()
	{
		return this.isSet_changedate;
	}
	
	protected void setIsSet_changedate(boolean value)
	{
		this.isSet_changedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0012409(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String changedate  = null;
	
	/**
	 * @Description  [SYS_C0012409(C)]
	 */
	public java.lang.String getChangedate(){
		return changedate;
	}
	
	/**
	 * @Description  [SYS_C0012409(C)]
	 */
	@JsonProperty("changedate")
	public void setChangedate( java.lang.String changedate ) {
		isSet_changedate = true;
		this.changedate = changedate;
	}
	
	/** Property set << changedate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSellConv01IO clone(){
		try{
			DHDHousSellConv01IO object= (DHDHousSellConv01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.bseq== null ) object.bseq = null;
			else{
				object.bseq = this.bseq;
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.changetag== null ) object.changetag = null;
			else{
				object.changetag = this.changetag;
			}
			if ( this.contractdate== null ) object.contractdate = null;
			else{
				object.contractdate = this.contractdate;
			}
			if ( this.lastchangedate== null ) object.lastchangedate = null;
			else{
				object.lastchangedate = this.lastchangedate;
			}
			if ( this.changedate== null ) object.changedate = null;
			else{
				object.changedate = this.changedate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((bseq==null)?0:bseq.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((changetag==null)?0:changetag.hashCode());
		result = prime * result + ((contractdate==null)?0:contractdate.hashCode());
		result = prime * result + ((lastchangedate==null)?0:lastchangedate.hashCode());
		result = prime * result + ((changedate==null)?0:changedate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( bseq == null ){
			if ( other.bseq != null ) return false;
		}
		else if ( !bseq.equals(other.bseq) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( changetag == null ){
			if ( other.changetag != null ) return false;
		}
		else if ( !changetag.equals(other.changetag) )
			return false;
		if ( contractdate == null ){
			if ( other.contractdate != null ) return false;
		}
		else if ( !contractdate.equals(other.contractdate) )
			return false;
		if ( lastchangedate == null ){
			if ( other.lastchangedate != null ) return false;
		}
		else if ( !lastchangedate.equals(other.lastchangedate) )
			return false;
		if ( changedate == null ){
			if ( other.changedate != null ) return false;
		}
		else if ( !changedate.equals(other.changedate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tbseq: ");
		sb.append(bseq==null?"null":getBseq());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tchangetag: ");
		sb.append(changetag==null?"null":getChangetag());
		sb.append("\n");
		sb.append("\tcontractdate: ");
		sb.append(contractdate==null?"null":getContractdate());
		sb.append("\n");
		sb.append("\tlastchangedate: ");
		sb.append(lastchangedate==null?"null":getLastchangedate());
		sb.append("\n");
		sb.append("\tchangedate: ");
		sb.append(changedate==null?"null":getChangedate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 22; /* bseq */
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 1; /* changetag */
		messageLen+= 8; /* contractdate */
		messageLen+= 8; /* lastchangedate */
		messageLen+= 8; /* changedate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("bseq");
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("changetag");
	
		fieldNames.add("contractdate");
	
		fieldNames.add("lastchangedate");
	
		fieldNames.add("changedate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("bseq", get("bseq"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("changetag", get("changetag"));
	
		fieldValueMap.put("contractdate", get("contractdate"));
	
		fieldValueMap.put("lastchangedate", get("lastchangedate"));
	
		fieldValueMap.put("changedate", get("changedate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 3033277 : /* bseq */
			return getBseq();
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 1455279594 : /* changetag */
			return getChangetag();
		case -1401870400 : /* contractdate */
			return getContractdate();
		case 379157108 : /* lastchangedate */
			return getLastchangedate();
		case -2131448994 : /* changedate */
			return getChangedate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 3033277 : /* bseq */
			setBseq((java.lang.Float) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 1455279594 : /* changetag */
			setChangetag((java.lang.String) value);
			return;
		case -1401870400 : /* contractdate */
			setContractdate((java.lang.String) value);
			return;
		case 379157108 : /* lastchangedate */
			setLastchangedate((java.lang.String) value);
			return;
		case -2131448994 : /* changedate */
			setChangedate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
