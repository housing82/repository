/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_계약서출력이력 ( HD_HOUS_SEALHISTORY )
 */
@XmlType(propOrder={"custCode", "seq", "sn", "deptCode", "housetag", "printDate", "sealtype", "printDutyId", "printIp"}, name="DHDHousSealhistory01IO")
@XmlRootElement(name="DHDHousSealhistory01IO")
@SuppressWarnings("all")
public class DHDHousSealhistory01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 460486537L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_계약서출력이력 ( HD_HOUS_SEALHISTORY )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012332(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012332(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012332(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012333(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012333(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012333(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012333(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012333(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012333(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sn >> [[ */
	
	@XmlTransient
	private boolean isSet_sn = false;
	
	protected boolean isSet_sn()
	{
		return this.isSet_sn;
	}
	
	protected void setIsSet_sn(boolean value)
	{
		this.isSet_sn = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 출력순번 [SYS_C0012334(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public void setSn(java.lang.String value) {
		isSet_sn = true;
		this.sn = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 출력순번 [SYS_C0012334(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public void setSn(double value) {
		isSet_sn = true;
		this.sn = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 출력순번 [SYS_C0012334(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public void setSn(long value) {
		isSet_sn = true;
		this.sn = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="출력순번 [SYS_C0012334(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sn  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 출력순번 [SYS_C0012334(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	public java.math.BigDecimal getSn(){
		return sn;
	}
	
	/**
	 * @Description 출력순번 [SYS_C0012334(C),SYS_C0012949(P) SYS_C0012949(UNIQUE)]
	 */
	@JsonProperty("sn")
	public void setSn( java.math.BigDecimal sn ) {
		isSet_sn = true;
		this.sn = sn;
	}
	
	/** Property set << sn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printDate >> [[ */
	
	@XmlTransient
	private boolean isSet_printDate = false;
	
	protected boolean isSet_printDate()
	{
		return this.isSet_printDate;
	}
	
	protected void setIsSet_printDate(boolean value)
	{
		this.isSet_printDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력일자", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String printDate  = null;
	
	/**
	 * @Description 출력일자
	 */
	public java.lang.String getPrintDate(){
		return printDate;
	}
	
	/**
	 * @Description 출력일자
	 */
	@JsonProperty("printDate")
	public void setPrintDate( java.lang.String printDate ) {
		isSet_printDate = true;
		this.printDate = printDate;
	}
	
	/** Property set << printDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sealtype >> [[ */
	
	@XmlTransient
	private boolean isSet_sealtype = false;
	
	protected boolean isSet_sealtype()
	{
		return this.isSet_sealtype;
	}
	
	protected void setIsSet_sealtype(boolean value)
	{
		this.isSet_sealtype = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="인장구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String sealtype  = null;
	
	/**
	 * @Description 인장구분
	 */
	public java.lang.String getSealtype(){
		return sealtype;
	}
	
	/**
	 * @Description 인장구분
	 */
	@JsonProperty("sealtype")
	public void setSealtype( java.lang.String sealtype ) {
		isSet_sealtype = true;
		this.sealtype = sealtype;
	}
	
	/** Property set << sealtype >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_printDutyId = false;
	
	protected boolean isSet_printDutyId()
	{
		return this.isSet_printDutyId;
	}
	
	protected void setIsSet_printDutyId(boolean value)
	{
		this.isSet_printDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력자", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String printDutyId  = null;
	
	/**
	 * @Description 출력자
	 */
	public java.lang.String getPrintDutyId(){
		return printDutyId;
	}
	
	/**
	 * @Description 출력자
	 */
	@JsonProperty("printDutyId")
	public void setPrintDutyId( java.lang.String printDutyId ) {
		isSet_printDutyId = true;
		this.printDutyId = printDutyId;
	}
	
	/** Property set << printDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << printIp >> [[ */
	
	@XmlTransient
	private boolean isSet_printIp = false;
	
	protected boolean isSet_printIp()
	{
		return this.isSet_printIp;
	}
	
	protected void setIsSet_printIp(boolean value)
	{
		this.isSet_printIp = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="출력IP", formatType="", format="", align="left", length=15, decimal=0, arrayReference="", fill="")
	private java.lang.String printIp  = null;
	
	/**
	 * @Description 출력IP
	 */
	public java.lang.String getPrintIp(){
		return printIp;
	}
	
	/**
	 * @Description 출력IP
	 */
	@JsonProperty("printIp")
	public void setPrintIp( java.lang.String printIp ) {
		isSet_printIp = true;
		this.printIp = printIp;
	}
	
	/** Property set << printIp >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSealhistory01IO clone(){
		try{
			DHDHousSealhistory01IO object= (DHDHousSealhistory01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.sn== null ) object.sn = null;
			else{
				object.sn = new java.math.BigDecimal(sn.toString());
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.printDate== null ) object.printDate = null;
			else{
				object.printDate = this.printDate;
			}
			if ( this.sealtype== null ) object.sealtype = null;
			else{
				object.sealtype = this.sealtype;
			}
			if ( this.printDutyId== null ) object.printDutyId = null;
			else{
				object.printDutyId = this.printDutyId;
			}
			if ( this.printIp== null ) object.printIp = null;
			else{
				object.printIp = this.printIp;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((sn==null)?0:sn.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((printDate==null)?0:printDate.hashCode());
		result = prime * result + ((sealtype==null)?0:sealtype.hashCode());
		result = prime * result + ((printDutyId==null)?0:printDutyId.hashCode());
		result = prime * result + ((printIp==null)?0:printIp.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( sn == null ){
			if ( other.sn != null ) return false;
		}
		else if ( !sn.equals(other.sn) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( printDate == null ){
			if ( other.printDate != null ) return false;
		}
		else if ( !printDate.equals(other.printDate) )
			return false;
		if ( sealtype == null ){
			if ( other.sealtype != null ) return false;
		}
		else if ( !sealtype.equals(other.sealtype) )
			return false;
		if ( printDutyId == null ){
			if ( other.printDutyId != null ) return false;
		}
		else if ( !printDutyId.equals(other.printDutyId) )
			return false;
		if ( printIp == null ){
			if ( other.printIp != null ) return false;
		}
		else if ( !printIp.equals(other.printIp) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tsn: ");
		sb.append(sn==null?"null":getSn());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tprintDate: ");
		sb.append(printDate==null?"null":getPrintDate());
		sb.append("\n");
		sb.append("\tsealtype: ");
		sb.append(sealtype==null?"null":getSealtype());
		sb.append("\n");
		sb.append("\tprintDutyId: ");
		sb.append(printDutyId==null?"null":getPrintDutyId());
		sb.append("\n");
		sb.append("\tprintIp: ");
		sb.append(printIp==null?"null":getPrintIp());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* sn */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 14; /* printDate */
		messageLen+= 1; /* sealtype */
		messageLen+= 12; /* printDutyId */
		messageLen+= 15; /* printIp */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("sn");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("printDate");
	
		fieldNames.add("sealtype");
	
		fieldNames.add("printDutyId");
	
		fieldNames.add("printIp");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("sn", get("sn"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("printDate", get("printDate"));
	
		fieldValueMap.put("sealtype", get("sealtype"));
	
		fieldValueMap.put("printDutyId", get("printDutyId"));
	
		fieldValueMap.put("printIp", get("printIp"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 3675 : /* sn */
			return getSn();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case -1797457925 : /* printDate */
			return getPrintDate();
		case 883627703 : /* sealtype */
			return getSealtype();
		case -761720930 : /* printDutyId */
			return getPrintDutyId();
		case -314719052 : /* printIp */
			return getPrintIp();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 3675 : /* sn */
			setSn((java.math.BigDecimal) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case -1797457925 : /* printDate */
			setPrintDate((java.lang.String) value);
			return;
		case 883627703 : /* sealtype */
			setSealtype((java.lang.String) value);
			return;
		case -761720930 : /* printDutyId */
			setPrintDutyId((java.lang.String) value);
			return;
		case -314719052 : /* printIp */
			setPrintIp((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
