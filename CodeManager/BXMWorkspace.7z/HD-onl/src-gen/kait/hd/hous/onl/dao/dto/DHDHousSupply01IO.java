/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_세대별공급내역 ( HD_HOUS_SUPPLY )
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "square", "type", "classJrw", "optioncode", "vattag", "exclusivearea", "commonarea", "etccommonarea", "parkingarea", "servicearea", "sitearea", "floor", "gubun", "categoryName", "contractyesno", "virdeposit", "bankCode", "bankName", "useYn", "rentTag", "inputDutyId", "inputDate", "chgDutyId", "prtsquare", "chgDate", "predisamt", "virdeposit2"}, name="DHDHousSupply01IO")
@XmlRootElement(name="DHDHousSupply01IO")
@SuppressWarnings("all")
public class DHDHousSupply01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -750676661L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_세대별공급내역 ( HD_HOUS_SUPPLY )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012443(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012443(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012443(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012444(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012444(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012444(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012445(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012445(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012445(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012446(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012446(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012446(C),SYS_C0012960(P) SYS_C0012960(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 평형
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 평형
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 평형
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 평형
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << type >> [[ */
	
	@XmlTransient
	private boolean isSet_type = false;
	
	protected boolean isSet_type()
	{
		return this.isSet_type;
	}
	
	protected void setIsSet_type(boolean value)
	{
		this.isSet_type = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="TYPE", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String type  = null;
	
	/**
	 * @Description TYPE
	 */
	public java.lang.String getType(){
		return type;
	}
	
	/**
	 * @Description TYPE
	 */
	@JsonProperty("type")
	public void setType( java.lang.String type ) {
		isSet_type = true;
		this.type = type;
	}
	
	/** Property set << type >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << classJrw >> [[ */
	
	@XmlTransient
	private boolean isSet_classJrw = false;
	
	protected boolean isSet_classJrw()
	{
		return this.isSet_classJrw;
	}
	
	protected void setIsSet_classJrw(boolean value)
	{
		this.isSet_classJrw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="군", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String classJrw  = null;
	
	/**
	 * @Description 군
	 */
	public java.lang.String getClassJrw(){
		return classJrw;
	}
	
	/**
	 * @Description 군
	 */
	@JsonProperty("classJrw")
	public void setClassJrw( java.lang.String classJrw ) {
		isSet_classJrw = true;
		this.classJrw = classJrw;
	}
	
	/** Property set << classJrw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optioncode >> [[ */
	
	@XmlTransient
	private boolean isSet_optioncode = false;
	
	protected boolean isSet_optioncode()
	{
		return this.isSet_optioncode;
	}
	
	protected void setIsSet_optioncode(boolean value)
	{
		this.isSet_optioncode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선택사양코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String optioncode  = null;
	
	/**
	 * @Description 선택사양코드
	 */
	public java.lang.String getOptioncode(){
		return optioncode;
	}
	
	/**
	 * @Description 선택사양코드
	 */
	@JsonProperty("optioncode")
	public void setOptioncode( java.lang.String optioncode ) {
		isSet_optioncode = true;
		this.optioncode = optioncode;
	}
	
	/** Property set << optioncode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vattag >> [[ */
	
	@XmlTransient
	private boolean isSet_vattag = false;
	
	protected boolean isSet_vattag()
	{
		return this.isSet_vattag;
	}
	
	protected void setIsSet_vattag(boolean value)
	{
		this.isSet_vattag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String vattag  = null;
	
	/**
	 * @Description 부가세여부
	 */
	public java.lang.String getVattag(){
		return vattag;
	}
	
	/**
	 * @Description 부가세여부
	 */
	@JsonProperty("vattag")
	public void setVattag( java.lang.String vattag ) {
		isSet_vattag = true;
		this.vattag = vattag;
	}
	
	/** Property set << vattag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exclusivearea >> [[ */
	
	@XmlTransient
	private boolean isSet_exclusivearea = false;
	
	protected boolean isSet_exclusivearea()
	{
		return this.isSet_exclusivearea;
	}
	
	protected void setIsSet_exclusivearea(boolean value)
	{
		this.isSet_exclusivearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전용면적
	 */
	public void setExclusivearea(java.lang.String value) {
		isSet_exclusivearea = true;
		this.exclusivearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전용면적
	 */
	public void setExclusivearea(double value) {
		isSet_exclusivearea = true;
		this.exclusivearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전용면적
	 */
	public void setExclusivearea(long value) {
		isSet_exclusivearea = true;
		this.exclusivearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전용면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal exclusivearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전용면적
	 */
	public java.math.BigDecimal getExclusivearea(){
		return exclusivearea;
	}
	
	/**
	 * @Description 전용면적
	 */
	@JsonProperty("exclusivearea")
	public void setExclusivearea( java.math.BigDecimal exclusivearea ) {
		isSet_exclusivearea = true;
		this.exclusivearea = exclusivearea;
	}
	
	/** Property set << exclusivearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << commonarea >> [[ */
	
	@XmlTransient
	private boolean isSet_commonarea = false;
	
	protected boolean isSet_commonarea()
	{
		return this.isSet_commonarea;
	}
	
	protected void setIsSet_commonarea(boolean value)
	{
		this.isSet_commonarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주거공용면적
	 */
	public void setCommonarea(java.lang.String value) {
		isSet_commonarea = true;
		this.commonarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주거공용면적
	 */
	public void setCommonarea(double value) {
		isSet_commonarea = true;
		this.commonarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주거공용면적
	 */
	public void setCommonarea(long value) {
		isSet_commonarea = true;
		this.commonarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주거공용면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal commonarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주거공용면적
	 */
	public java.math.BigDecimal getCommonarea(){
		return commonarea;
	}
	
	/**
	 * @Description 주거공용면적
	 */
	@JsonProperty("commonarea")
	public void setCommonarea( java.math.BigDecimal commonarea ) {
		isSet_commonarea = true;
		this.commonarea = commonarea;
	}
	
	/** Property set << commonarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etccommonarea >> [[ */
	
	@XmlTransient
	private boolean isSet_etccommonarea = false;
	
	protected boolean isSet_etccommonarea()
	{
		return this.isSet_etccommonarea;
	}
	
	protected void setIsSet_etccommonarea(boolean value)
	{
		this.isSet_etccommonarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공용면적
	 */
	public void setEtccommonarea(java.lang.String value) {
		isSet_etccommonarea = true;
		this.etccommonarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공용면적
	 */
	public void setEtccommonarea(double value) {
		isSet_etccommonarea = true;
		this.etccommonarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공용면적
	 */
	public void setEtccommonarea(long value) {
		isSet_etccommonarea = true;
		this.etccommonarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공용면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal etccommonarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공용면적
	 */
	public java.math.BigDecimal getEtccommonarea(){
		return etccommonarea;
	}
	
	/**
	 * @Description 기타공용면적
	 */
	@JsonProperty("etccommonarea")
	public void setEtccommonarea( java.math.BigDecimal etccommonarea ) {
		isSet_etccommonarea = true;
		this.etccommonarea = etccommonarea;
	}
	
	/** Property set << etccommonarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << parkingarea >> [[ */
	
	@XmlTransient
	private boolean isSet_parkingarea = false;
	
	protected boolean isSet_parkingarea()
	{
		return this.isSet_parkingarea;
	}
	
	protected void setIsSet_parkingarea(boolean value)
	{
		this.isSet_parkingarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주차장면적
	 */
	public void setParkingarea(java.lang.String value) {
		isSet_parkingarea = true;
		this.parkingarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주차장면적
	 */
	public void setParkingarea(double value) {
		isSet_parkingarea = true;
		this.parkingarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주차장면적
	 */
	public void setParkingarea(long value) {
		isSet_parkingarea = true;
		this.parkingarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주차장면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal parkingarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주차장면적
	 */
	public java.math.BigDecimal getParkingarea(){
		return parkingarea;
	}
	
	/**
	 * @Description 주차장면적
	 */
	@JsonProperty("parkingarea")
	public void setParkingarea( java.math.BigDecimal parkingarea ) {
		isSet_parkingarea = true;
		this.parkingarea = parkingarea;
	}
	
	/** Property set << parkingarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << servicearea >> [[ */
	
	@XmlTransient
	private boolean isSet_servicearea = false;
	
	protected boolean isSet_servicearea()
	{
		return this.isSet_servicearea;
	}
	
	protected void setIsSet_servicearea(boolean value)
	{
		this.isSet_servicearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 서비스면적
	 */
	public void setServicearea(java.lang.String value) {
		isSet_servicearea = true;
		this.servicearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 서비스면적
	 */
	public void setServicearea(double value) {
		isSet_servicearea = true;
		this.servicearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 서비스면적
	 */
	public void setServicearea(long value) {
		isSet_servicearea = true;
		this.servicearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="서비스면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal servicearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 서비스면적
	 */
	public java.math.BigDecimal getServicearea(){
		return servicearea;
	}
	
	/**
	 * @Description 서비스면적
	 */
	@JsonProperty("servicearea")
	public void setServicearea( java.math.BigDecimal servicearea ) {
		isSet_servicearea = true;
		this.servicearea = servicearea;
	}
	
	/** Property set << servicearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sitearea >> [[ */
	
	@XmlTransient
	private boolean isSet_sitearea = false;
	
	protected boolean isSet_sitearea()
	{
		return this.isSet_sitearea;
	}
	
	protected void setIsSet_sitearea(boolean value)
	{
		this.isSet_sitearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 대지면적
	 */
	public void setSitearea(java.lang.String value) {
		isSet_sitearea = true;
		this.sitearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 대지면적
	 */
	public void setSitearea(double value) {
		isSet_sitearea = true;
		this.sitearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 대지면적
	 */
	public void setSitearea(long value) {
		isSet_sitearea = true;
		this.sitearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="대지면적", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sitearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 대지면적
	 */
	public java.math.BigDecimal getSitearea(){
		return sitearea;
	}
	
	/**
	 * @Description 대지면적
	 */
	@JsonProperty("sitearea")
	public void setSitearea( java.math.BigDecimal sitearea ) {
		isSet_sitearea = true;
		this.sitearea = sitearea;
	}
	
	/** Property set << sitearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << floor >> [[ */
	
	@XmlTransient
	private boolean isSet_floor = false;
	
	protected boolean isSet_floor()
	{
		return this.isSet_floor;
	}
	
	protected void setIsSet_floor(boolean value)
	{
		this.isSet_floor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="층", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String floor  = null;
	
	/**
	 * @Description 층
	 */
	public java.lang.String getFloor(){
		return floor;
	}
	
	/**
	 * @Description 층
	 */
	@JsonProperty("floor")
	public void setFloor( java.lang.String floor ) {
		isSet_floor = true;
		this.floor = floor;
	}
	
	/** Property set << floor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << gubun >> [[ */
	
	@XmlTransient
	private boolean isSet_gubun = false;
	
	protected boolean isSet_gubun()
	{
		return this.isSet_gubun;
	}
	
	protected void setIsSet_gubun(boolean value)
	{
		this.isSet_gubun = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String gubun  = null;
	
	/**
	 * @Description 구분
	 */
	public java.lang.String getGubun(){
		return gubun;
	}
	
	/**
	 * @Description 구분
	 */
	@JsonProperty("gubun")
	public void setGubun( java.lang.String gubun ) {
		isSet_gubun = true;
		this.gubun = gubun;
	}
	
	/** Property set << gubun >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << categoryName >> [[ */
	
	@XmlTransient
	private boolean isSet_categoryName = false;
	
	protected boolean isSet_categoryName()
	{
		return this.isSet_categoryName;
	}
	
	protected void setIsSet_categoryName(boolean value)
	{
		this.isSet_categoryName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약업종명칭", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String categoryName  = null;
	
	/**
	 * @Description 계약업종명칭
	 */
	public java.lang.String getCategoryName(){
		return categoryName;
	}
	
	/**
	 * @Description 계약업종명칭
	 */
	@JsonProperty("categoryName")
	public void setCategoryName( java.lang.String categoryName ) {
		isSet_categoryName = true;
		this.categoryName = categoryName;
	}
	
	/** Property set << categoryName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contractyesno >> [[ */
	
	@XmlTransient
	private boolean isSet_contractyesno = false;
	
	protected boolean isSet_contractyesno()
	{
		return this.isSet_contractyesno;
	}
	
	protected void setIsSet_contractyesno(boolean value)
	{
		this.isSet_contractyesno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약여부 [SYS_C0012447(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String contractyesno  = null;
	
	/**
	 * @Description 계약여부 [SYS_C0012447(C)]
	 */
	public java.lang.String getContractyesno(){
		return contractyesno;
	}
	
	/**
	 * @Description 계약여부 [SYS_C0012447(C)]
	 */
	@JsonProperty("contractyesno")
	public void setContractyesno( java.lang.String contractyesno ) {
		isSet_contractyesno = true;
		this.contractyesno = contractyesno;
	}
	
	/** Property set << contractyesno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virdeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_virdeposit = false;
	
	protected boolean isSet_virdeposit()
	{
		return this.isSet_virdeposit;
	}
	
	protected void setIsSet_virdeposit(boolean value)
	{
		this.isSet_virdeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌번호 [XAK1HD_HOUS_SUPPLY(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String virdeposit  = null;
	
	/**
	 * @Description 가상계좌번호 [XAK1HD_HOUS_SUPPLY(UNIQUE)]
	 */
	public java.lang.String getVirdeposit(){
		return virdeposit;
	}
	
	/**
	 * @Description 가상계좌번호 [XAK1HD_HOUS_SUPPLY(UNIQUE)]
	 */
	@JsonProperty("virdeposit")
	public void setVirdeposit( java.lang.String virdeposit ) {
		isSet_virdeposit = true;
		this.virdeposit = virdeposit;
	}
	
	/** Property set << virdeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankCode = false;
	
	protected boolean isSet_bankCode()
	{
		return this.isSet_bankCode;
	}
	
	protected void setIsSet_bankCode(boolean value)
	{
		this.isSet_bankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌은행코드 [XAK1HD_HOUS_SUPPLY(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String bankCode  = null;
	
	/**
	 * @Description 가상계좌은행코드 [XAK1HD_HOUS_SUPPLY(UNIQUE)]
	 */
	public java.lang.String getBankCode(){
		return bankCode;
	}
	
	/**
	 * @Description 가상계좌은행코드 [XAK1HD_HOUS_SUPPLY(UNIQUE)]
	 */
	@JsonProperty("bankCode")
	public void setBankCode( java.lang.String bankCode ) {
		isSet_bankCode = true;
		this.bankCode = bankCode;
	}
	
	/** Property set << bankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankName >> [[ */
	
	@XmlTransient
	private boolean isSet_bankName = false;
	
	protected boolean isSet_bankName()
	{
		return this.isSet_bankName;
	}
	
	protected void setIsSet_bankName(boolean value)
	{
		this.isSet_bankName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌은행명", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String bankName  = null;
	
	/**
	 * @Description 가상계좌은행명
	 */
	public java.lang.String getBankName(){
		return bankName;
	}
	
	/**
	 * @Description 가상계좌은행명
	 */
	@JsonProperty("bankName")
	public void setBankName( java.lang.String bankName ) {
		isSet_bankName = true;
		this.bankName = bankName;
	}
	
	/** Property set << bankName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << useYn >> [[ */
	
	@XmlTransient
	private boolean isSet_useYn = false;
	
	protected boolean isSet_useYn()
	{
		return this.isSet_useYn;
	}
	
	protected void setIsSet_useYn(boolean value)
	{
		this.isSet_useYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사용여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String useYn  = null;
	
	/**
	 * @Description 사용여부
	 */
	public java.lang.String getUseYn(){
		return useYn;
	}
	
	/**
	 * @Description 사용여부
	 */
	@JsonProperty("useYn")
	public void setUseYn( java.lang.String useYn ) {
		isSet_useYn = true;
		this.useYn = useYn;
	}
	
	/** Property set << useYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rentTag >> [[ */
	
	@XmlTransient
	private boolean isSet_rentTag = false;
	
	protected boolean isSet_rentTag()
	{
		return this.isSet_rentTag;
	}
	
	protected void setIsSet_rentTag(boolean value)
	{
		this.isSet_rentTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String rentTag  = null;
	
	/**
	 * @Description 임대구분
	 */
	public java.lang.String getRentTag(){
		return rentTag;
	}
	
	/**
	 * @Description 임대구분
	 */
	@JsonProperty("rentTag")
	public void setRentTag( java.lang.String rentTag ) {
		isSet_rentTag = true;
		this.rentTag = rentTag;
	}
	
	/** Property set << rentTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << prtsquare >> [[ */
	
	@XmlTransient
	private boolean isSet_prtsquare = false;
	
	protected boolean isSet_prtsquare()
	{
		return this.isSet_prtsquare;
	}
	
	protected void setIsSet_prtsquare(boolean value)
	{
		this.isSet_prtsquare = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(java.lang.String value) {
		isSet_prtsquare = true;
		this.prtsquare = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(double value) {
		isSet_prtsquare = true;
		this.prtsquare = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(long value) {
		isSet_prtsquare = true;
		this.prtsquare = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="출력평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal prtsquare  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 출력평형
	 */
	public java.math.BigDecimal getPrtsquare(){
		return prtsquare;
	}
	
	/**
	 * @Description 출력평형
	 */
	@JsonProperty("prtsquare")
	public void setPrtsquare( java.math.BigDecimal prtsquare ) {
		isSet_prtsquare = true;
		this.prtsquare = prtsquare;
	}
	
	/** Property set << prtsquare >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << predisamt >> [[ */
	
	@XmlTransient
	private boolean isSet_predisamt = false;
	
	protected boolean isSet_predisamt()
	{
		return this.isSet_predisamt;
	}
	
	protected void setIsSet_predisamt(boolean value)
	{
		this.isSet_predisamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 선납할인
	 */
	public void setPredisamt(java.lang.String value) {
		isSet_predisamt = true;
		this.predisamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 선납할인
	 */
	public void setPredisamt(double value) {
		isSet_predisamt = true;
		this.predisamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 선납할인
	 */
	public void setPredisamt(long value) {
		isSet_predisamt = true;
		this.predisamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="선납할인", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal predisamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 선납할인
	 */
	public java.math.BigDecimal getPredisamt(){
		return predisamt;
	}
	
	/**
	 * @Description 선납할인
	 */
	@JsonProperty("predisamt")
	public void setPredisamt( java.math.BigDecimal predisamt ) {
		isSet_predisamt = true;
		this.predisamt = predisamt;
	}
	
	/** Property set << predisamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virdeposit2 >> [[ */
	
	@XmlTransient
	private boolean isSet_virdeposit2 = false;
	
	protected boolean isSet_virdeposit2()
	{
		return this.isSet_virdeposit2;
	}
	
	protected void setIsSet_virdeposit2(boolean value)
	{
		this.isSet_virdeposit2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대가상계좌번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String virdeposit2  = null;
	
	/**
	 * @Description 임대가상계좌번호
	 */
	public java.lang.String getVirdeposit2(){
		return virdeposit2;
	}
	
	/**
	 * @Description 임대가상계좌번호
	 */
	@JsonProperty("virdeposit2")
	public void setVirdeposit2( java.lang.String virdeposit2 ) {
		isSet_virdeposit2 = true;
		this.virdeposit2 = virdeposit2;
	}
	
	/** Property set << virdeposit2 >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSupply01IO clone(){
		try{
			DHDHousSupply01IO object= (DHDHousSupply01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.type== null ) object.type = null;
			else{
				object.type = this.type;
			}
			if ( this.classJrw== null ) object.classJrw = null;
			else{
				object.classJrw = this.classJrw;
			}
			if ( this.optioncode== null ) object.optioncode = null;
			else{
				object.optioncode = this.optioncode;
			}
			if ( this.vattag== null ) object.vattag = null;
			else{
				object.vattag = this.vattag;
			}
			if ( this.exclusivearea== null ) object.exclusivearea = null;
			else{
				object.exclusivearea = new java.math.BigDecimal(exclusivearea.toString());
			}
			if ( this.commonarea== null ) object.commonarea = null;
			else{
				object.commonarea = new java.math.BigDecimal(commonarea.toString());
			}
			if ( this.etccommonarea== null ) object.etccommonarea = null;
			else{
				object.etccommonarea = new java.math.BigDecimal(etccommonarea.toString());
			}
			if ( this.parkingarea== null ) object.parkingarea = null;
			else{
				object.parkingarea = new java.math.BigDecimal(parkingarea.toString());
			}
			if ( this.servicearea== null ) object.servicearea = null;
			else{
				object.servicearea = new java.math.BigDecimal(servicearea.toString());
			}
			if ( this.sitearea== null ) object.sitearea = null;
			else{
				object.sitearea = new java.math.BigDecimal(sitearea.toString());
			}
			if ( this.floor== null ) object.floor = null;
			else{
				object.floor = this.floor;
			}
			if ( this.gubun== null ) object.gubun = null;
			else{
				object.gubun = this.gubun;
			}
			if ( this.categoryName== null ) object.categoryName = null;
			else{
				object.categoryName = this.categoryName;
			}
			if ( this.contractyesno== null ) object.contractyesno = null;
			else{
				object.contractyesno = this.contractyesno;
			}
			if ( this.virdeposit== null ) object.virdeposit = null;
			else{
				object.virdeposit = this.virdeposit;
			}
			if ( this.bankCode== null ) object.bankCode = null;
			else{
				object.bankCode = this.bankCode;
			}
			if ( this.bankName== null ) object.bankName = null;
			else{
				object.bankName = this.bankName;
			}
			if ( this.useYn== null ) object.useYn = null;
			else{
				object.useYn = this.useYn;
			}
			if ( this.rentTag== null ) object.rentTag = null;
			else{
				object.rentTag = this.rentTag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.prtsquare== null ) object.prtsquare = null;
			else{
				object.prtsquare = new java.math.BigDecimal(prtsquare.toString());
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.predisamt== null ) object.predisamt = null;
			else{
				object.predisamt = new java.math.BigDecimal(predisamt.toString());
			}
			if ( this.virdeposit2== null ) object.virdeposit2 = null;
			else{
				object.virdeposit2 = this.virdeposit2;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((type==null)?0:type.hashCode());
		result = prime * result + ((classJrw==null)?0:classJrw.hashCode());
		result = prime * result + ((optioncode==null)?0:optioncode.hashCode());
		result = prime * result + ((vattag==null)?0:vattag.hashCode());
		result = prime * result + ((exclusivearea==null)?0:exclusivearea.hashCode());
		result = prime * result + ((commonarea==null)?0:commonarea.hashCode());
		result = prime * result + ((etccommonarea==null)?0:etccommonarea.hashCode());
		result = prime * result + ((parkingarea==null)?0:parkingarea.hashCode());
		result = prime * result + ((servicearea==null)?0:servicearea.hashCode());
		result = prime * result + ((sitearea==null)?0:sitearea.hashCode());
		result = prime * result + ((floor==null)?0:floor.hashCode());
		result = prime * result + ((gubun==null)?0:gubun.hashCode());
		result = prime * result + ((categoryName==null)?0:categoryName.hashCode());
		result = prime * result + ((contractyesno==null)?0:contractyesno.hashCode());
		result = prime * result + ((virdeposit==null)?0:virdeposit.hashCode());
		result = prime * result + ((bankCode==null)?0:bankCode.hashCode());
		result = prime * result + ((bankName==null)?0:bankName.hashCode());
		result = prime * result + ((useYn==null)?0:useYn.hashCode());
		result = prime * result + ((rentTag==null)?0:rentTag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((prtsquare==null)?0:prtsquare.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((predisamt==null)?0:predisamt.hashCode());
		result = prime * result + ((virdeposit2==null)?0:virdeposit2.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSupply01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSupply01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( type == null ){
			if ( other.type != null ) return false;
		}
		else if ( !type.equals(other.type) )
			return false;
		if ( classJrw == null ){
			if ( other.classJrw != null ) return false;
		}
		else if ( !classJrw.equals(other.classJrw) )
			return false;
		if ( optioncode == null ){
			if ( other.optioncode != null ) return false;
		}
		else if ( !optioncode.equals(other.optioncode) )
			return false;
		if ( vattag == null ){
			if ( other.vattag != null ) return false;
		}
		else if ( !vattag.equals(other.vattag) )
			return false;
		if ( exclusivearea == null ){
			if ( other.exclusivearea != null ) return false;
		}
		else if ( !exclusivearea.equals(other.exclusivearea) )
			return false;
		if ( commonarea == null ){
			if ( other.commonarea != null ) return false;
		}
		else if ( !commonarea.equals(other.commonarea) )
			return false;
		if ( etccommonarea == null ){
			if ( other.etccommonarea != null ) return false;
		}
		else if ( !etccommonarea.equals(other.etccommonarea) )
			return false;
		if ( parkingarea == null ){
			if ( other.parkingarea != null ) return false;
		}
		else if ( !parkingarea.equals(other.parkingarea) )
			return false;
		if ( servicearea == null ){
			if ( other.servicearea != null ) return false;
		}
		else if ( !servicearea.equals(other.servicearea) )
			return false;
		if ( sitearea == null ){
			if ( other.sitearea != null ) return false;
		}
		else if ( !sitearea.equals(other.sitearea) )
			return false;
		if ( floor == null ){
			if ( other.floor != null ) return false;
		}
		else if ( !floor.equals(other.floor) )
			return false;
		if ( gubun == null ){
			if ( other.gubun != null ) return false;
		}
		else if ( !gubun.equals(other.gubun) )
			return false;
		if ( categoryName == null ){
			if ( other.categoryName != null ) return false;
		}
		else if ( !categoryName.equals(other.categoryName) )
			return false;
		if ( contractyesno == null ){
			if ( other.contractyesno != null ) return false;
		}
		else if ( !contractyesno.equals(other.contractyesno) )
			return false;
		if ( virdeposit == null ){
			if ( other.virdeposit != null ) return false;
		}
		else if ( !virdeposit.equals(other.virdeposit) )
			return false;
		if ( bankCode == null ){
			if ( other.bankCode != null ) return false;
		}
		else if ( !bankCode.equals(other.bankCode) )
			return false;
		if ( bankName == null ){
			if ( other.bankName != null ) return false;
		}
		else if ( !bankName.equals(other.bankName) )
			return false;
		if ( useYn == null ){
			if ( other.useYn != null ) return false;
		}
		else if ( !useYn.equals(other.useYn) )
			return false;
		if ( rentTag == null ){
			if ( other.rentTag != null ) return false;
		}
		else if ( !rentTag.equals(other.rentTag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( prtsquare == null ){
			if ( other.prtsquare != null ) return false;
		}
		else if ( !prtsquare.equals(other.prtsquare) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( predisamt == null ){
			if ( other.predisamt != null ) return false;
		}
		else if ( !predisamt.equals(other.predisamt) )
			return false;
		if ( virdeposit2 == null ){
			if ( other.virdeposit2 != null ) return false;
		}
		else if ( !virdeposit2.equals(other.virdeposit2) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSupply01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttype: ");
		sb.append(type==null?"null":getType());
		sb.append("\n");
		sb.append("\tclassJrw: ");
		sb.append(classJrw==null?"null":getClassJrw());
		sb.append("\n");
		sb.append("\toptioncode: ");
		sb.append(optioncode==null?"null":getOptioncode());
		sb.append("\n");
		sb.append("\tvattag: ");
		sb.append(vattag==null?"null":getVattag());
		sb.append("\n");
		sb.append("\texclusivearea: ");
		sb.append(exclusivearea==null?"null":getExclusivearea());
		sb.append("\n");
		sb.append("\tcommonarea: ");
		sb.append(commonarea==null?"null":getCommonarea());
		sb.append("\n");
		sb.append("\tetccommonarea: ");
		sb.append(etccommonarea==null?"null":getEtccommonarea());
		sb.append("\n");
		sb.append("\tparkingarea: ");
		sb.append(parkingarea==null?"null":getParkingarea());
		sb.append("\n");
		sb.append("\tservicearea: ");
		sb.append(servicearea==null?"null":getServicearea());
		sb.append("\n");
		sb.append("\tsitearea: ");
		sb.append(sitearea==null?"null":getSitearea());
		sb.append("\n");
		sb.append("\tfloor: ");
		sb.append(floor==null?"null":getFloor());
		sb.append("\n");
		sb.append("\tgubun: ");
		sb.append(gubun==null?"null":getGubun());
		sb.append("\n");
		sb.append("\tcategoryName: ");
		sb.append(categoryName==null?"null":getCategoryName());
		sb.append("\n");
		sb.append("\tcontractyesno: ");
		sb.append(contractyesno==null?"null":getContractyesno());
		sb.append("\n");
		sb.append("\tvirdeposit: ");
		sb.append(virdeposit==null?"null":getVirdeposit());
		sb.append("\n");
		sb.append("\tbankCode: ");
		sb.append(bankCode==null?"null":getBankCode());
		sb.append("\n");
		sb.append("\tbankName: ");
		sb.append(bankName==null?"null":getBankName());
		sb.append("\n");
		sb.append("\tuseYn: ");
		sb.append(useYn==null?"null":getUseYn());
		sb.append("\n");
		sb.append("\trentTag: ");
		sb.append(rentTag==null?"null":getRentTag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tprtsquare: ");
		sb.append(prtsquare==null?"null":getPrtsquare());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tpredisamt: ");
		sb.append(predisamt==null?"null":getPredisamt());
		sb.append("\n");
		sb.append("\tvirdeposit2: ");
		sb.append(virdeposit2==null?"null":getVirdeposit2());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 22; /* square */
		messageLen+= 4; /* type */
		messageLen+= 1; /* classJrw */
		messageLen+= 2; /* optioncode */
		messageLen+= 1; /* vattag */
		messageLen+= 22; /* exclusivearea */
		messageLen+= 22; /* commonarea */
		messageLen+= 22; /* etccommonarea */
		messageLen+= 22; /* parkingarea */
		messageLen+= 22; /* servicearea */
		messageLen+= 22; /* sitearea */
		messageLen+= 4; /* floor */
		messageLen+= 2; /* gubun */
		messageLen+= 40; /* categoryName */
		messageLen+= 1; /* contractyesno */
		messageLen+= 20; /* virdeposit */
		messageLen+= 8; /* bankCode */
		messageLen+= 30; /* bankName */
		messageLen+= 1; /* useYn */
		messageLen+= 2; /* rentTag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 22; /* prtsquare */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* predisamt */
		messageLen+= 20; /* virdeposit2 */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("square");
	
		fieldNames.add("type");
	
		fieldNames.add("classJrw");
	
		fieldNames.add("optioncode");
	
		fieldNames.add("vattag");
	
		fieldNames.add("exclusivearea");
	
		fieldNames.add("commonarea");
	
		fieldNames.add("etccommonarea");
	
		fieldNames.add("parkingarea");
	
		fieldNames.add("servicearea");
	
		fieldNames.add("sitearea");
	
		fieldNames.add("floor");
	
		fieldNames.add("gubun");
	
		fieldNames.add("categoryName");
	
		fieldNames.add("contractyesno");
	
		fieldNames.add("virdeposit");
	
		fieldNames.add("bankCode");
	
		fieldNames.add("bankName");
	
		fieldNames.add("useYn");
	
		fieldNames.add("rentTag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("prtsquare");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("predisamt");
	
		fieldNames.add("virdeposit2");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("type", get("type"));
	
		fieldValueMap.put("classJrw", get("classJrw"));
	
		fieldValueMap.put("optioncode", get("optioncode"));
	
		fieldValueMap.put("vattag", get("vattag"));
	
		fieldValueMap.put("exclusivearea", get("exclusivearea"));
	
		fieldValueMap.put("commonarea", get("commonarea"));
	
		fieldValueMap.put("etccommonarea", get("etccommonarea"));
	
		fieldValueMap.put("parkingarea", get("parkingarea"));
	
		fieldValueMap.put("servicearea", get("servicearea"));
	
		fieldValueMap.put("sitearea", get("sitearea"));
	
		fieldValueMap.put("floor", get("floor"));
	
		fieldValueMap.put("gubun", get("gubun"));
	
		fieldValueMap.put("categoryName", get("categoryName"));
	
		fieldValueMap.put("contractyesno", get("contractyesno"));
	
		fieldValueMap.put("virdeposit", get("virdeposit"));
	
		fieldValueMap.put("bankCode", get("bankCode"));
	
		fieldValueMap.put("bankName", get("bankName"));
	
		fieldValueMap.put("useYn", get("useYn"));
	
		fieldValueMap.put("rentTag", get("rentTag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("prtsquare", get("prtsquare"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("predisamt", get("predisamt"));
	
		fieldValueMap.put("virdeposit2", get("virdeposit2"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -894674659 : /* square */
			return getSquare();
		case 3575610 : /* type */
			return getType();
		case 692414359 : /* classJrw */
			return getClassJrw();
		case 1374024674 : /* optioncode */
			return getOptioncode();
		case -823575599 : /* vattag */
			return getVattag();
		case 1197019179 : /* exclusivearea */
			return getExclusivearea();
		case 1184894200 : /* commonarea */
			return getCommonarea();
		case 1900129676 : /* etccommonarea */
			return getEtccommonarea();
		case -1720326075 : /* parkingarea */
			return getParkingarea();
		case -1927990078 : /* servicearea */
			return getServicearea();
		case 675591252 : /* sitearea */
			return getSitearea();
		case 97526796 : /* floor */
			return getFloor();
		case 98706125 : /* gubun */
			return getGubun();
		case 426048681 : /* categoryName */
			return getCategoryName();
		case -488796906 : /* contractyesno */
			return getContractyesno();
		case 148422047 : /* virdeposit */
			return getVirdeposit();
		case -1859605943 : /* bankCode */
			return getBankCode();
		case -1859291417 : /* bankName */
			return getBankName();
		case 111577852 : /* useYn */
			return getUseYn();
		case 1092875681 : /* rentTag */
			return getRentTag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case -483017137 : /* prtsquare */
			return getPrtsquare();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -1347555619 : /* predisamt */
			return getPredisamt();
		case 306116211 : /* virdeposit2 */
			return getVirdeposit2();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case 3575610 : /* type */
			setType((java.lang.String) value);
			return;
		case 692414359 : /* classJrw */
			setClassJrw((java.lang.String) value);
			return;
		case 1374024674 : /* optioncode */
			setOptioncode((java.lang.String) value);
			return;
		case -823575599 : /* vattag */
			setVattag((java.lang.String) value);
			return;
		case 1197019179 : /* exclusivearea */
			setExclusivearea((java.math.BigDecimal) value);
			return;
		case 1184894200 : /* commonarea */
			setCommonarea((java.math.BigDecimal) value);
			return;
		case 1900129676 : /* etccommonarea */
			setEtccommonarea((java.math.BigDecimal) value);
			return;
		case -1720326075 : /* parkingarea */
			setParkingarea((java.math.BigDecimal) value);
			return;
		case -1927990078 : /* servicearea */
			setServicearea((java.math.BigDecimal) value);
			return;
		case 675591252 : /* sitearea */
			setSitearea((java.math.BigDecimal) value);
			return;
		case 97526796 : /* floor */
			setFloor((java.lang.String) value);
			return;
		case 98706125 : /* gubun */
			setGubun((java.lang.String) value);
			return;
		case 426048681 : /* categoryName */
			setCategoryName((java.lang.String) value);
			return;
		case -488796906 : /* contractyesno */
			setContractyesno((java.lang.String) value);
			return;
		case 148422047 : /* virdeposit */
			setVirdeposit((java.lang.String) value);
			return;
		case -1859605943 : /* bankCode */
			setBankCode((java.lang.String) value);
			return;
		case -1859291417 : /* bankName */
			setBankName((java.lang.String) value);
			return;
		case 111577852 : /* useYn */
			setUseYn((java.lang.String) value);
			return;
		case 1092875681 : /* rentTag */
			setRentTag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case -483017137 : /* prtsquare */
			setPrtsquare((java.math.BigDecimal) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -1347555619 : /* predisamt */
			setPredisamt((java.math.BigDecimal) value);
			return;
		case 306116211 : /* virdeposit2 */
			setVirdeposit2((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
