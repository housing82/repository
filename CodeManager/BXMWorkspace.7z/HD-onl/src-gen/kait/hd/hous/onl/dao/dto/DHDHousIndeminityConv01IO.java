/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_지체보상금_자료올리기 ( HD_HOUS_INDEMINITY_CONV )
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "icheDate", "delayIndeminity", "convYn"}, name="DHDHousIndeminityConv01IO")
@XmlRootElement(name="DHDHousIndeminityConv01IO")
@SuppressWarnings("all")
public class DHDHousIndeminityConv01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1683691726L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_지체보상금_자료올리기 ( HD_HOUS_INDEMINITY_CONV )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012255(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012255(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012255(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012256(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012256(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012256(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012257(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012257(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012257(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012258(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012258(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012258(C),SYS_C0012937(P) SYS_C0012937(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << icheDate >> [[ */
	
	@XmlTransient
	private boolean isSet_icheDate = false;
	
	protected boolean isSet_icheDate()
	{
		return this.isSet_icheDate;
	}
	
	protected void setIsSet_icheDate(boolean value)
	{
		this.isSet_icheDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이체일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String icheDate  = null;
	
	/**
	 * @Description 이체일자
	 */
	public java.lang.String getIcheDate(){
		return icheDate;
	}
	
	/**
	 * @Description 이체일자
	 */
	@JsonProperty("icheDate")
	public void setIcheDate( java.lang.String icheDate ) {
		isSet_icheDate = true;
		this.icheDate = icheDate;
	}
	
	/** Property set << icheDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayIndeminity >> [[ */
	
	@XmlTransient
	private boolean isSet_delayIndeminity = false;
	
	protected boolean isSet_delayIndeminity()
	{
		return this.isSet_delayIndeminity;
	}
	
	protected void setIsSet_delayIndeminity(boolean value)
	{
		this.isSet_delayIndeminity = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 지체상금
	 */
	public void setDelayIndeminity(java.lang.String value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 지체상금
	 */
	public void setDelayIndeminity(double value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 지체상금
	 */
	public void setDelayIndeminity(long value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="지체상금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayIndeminity  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 지체상금
	 */
	public java.math.BigDecimal getDelayIndeminity(){
		return delayIndeminity;
	}
	
	/**
	 * @Description 지체상금
	 */
	@JsonProperty("delayIndeminity")
	public void setDelayIndeminity( java.math.BigDecimal delayIndeminity ) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = delayIndeminity;
	}
	
	/** Property set << delayIndeminity >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << convYn >> [[ */
	
	@XmlTransient
	private boolean isSet_convYn = false;
	
	protected boolean isSet_convYn()
	{
		return this.isSet_convYn;
	}
	
	protected void setIsSet_convYn(boolean value)
	{
		this.isSet_convYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이체여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String convYn  = null;
	
	/**
	 * @Description 이체여부
	 */
	public java.lang.String getConvYn(){
		return convYn;
	}
	
	/**
	 * @Description 이체여부
	 */
	@JsonProperty("convYn")
	public void setConvYn( java.lang.String convYn ) {
		isSet_convYn = true;
		this.convYn = convYn;
	}
	
	/** Property set << convYn >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousIndeminityConv01IO clone(){
		try{
			DHDHousIndeminityConv01IO object= (DHDHousIndeminityConv01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.icheDate== null ) object.icheDate = null;
			else{
				object.icheDate = this.icheDate;
			}
			if ( this.delayIndeminity== null ) object.delayIndeminity = null;
			else{
				object.delayIndeminity = new java.math.BigDecimal(delayIndeminity.toString());
			}
			if ( this.convYn== null ) object.convYn = null;
			else{
				object.convYn = this.convYn;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((icheDate==null)?0:icheDate.hashCode());
		result = prime * result + ((delayIndeminity==null)?0:delayIndeminity.hashCode());
		result = prime * result + ((convYn==null)?0:convYn.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO other = (kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( icheDate == null ){
			if ( other.icheDate != null ) return false;
		}
		else if ( !icheDate.equals(other.icheDate) )
			return false;
		if ( delayIndeminity == null ){
			if ( other.delayIndeminity != null ) return false;
		}
		else if ( !delayIndeminity.equals(other.delayIndeminity) )
			return false;
		if ( convYn == null ){
			if ( other.convYn != null ) return false;
		}
		else if ( !convYn.equals(other.convYn) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\ticheDate: ");
		sb.append(icheDate==null?"null":getIcheDate());
		sb.append("\n");
		sb.append("\tdelayIndeminity: ");
		sb.append(delayIndeminity==null?"null":getDelayIndeminity());
		sb.append("\n");
		sb.append("\tconvYn: ");
		sb.append(convYn==null?"null":getConvYn());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 8; /* icheDate */
		messageLen+= 22; /* delayIndeminity */
		messageLen+= 1; /* convYn */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("icheDate");
	
		fieldNames.add("delayIndeminity");
	
		fieldNames.add("convYn");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("icheDate", get("icheDate"));
	
		fieldValueMap.put("delayIndeminity", get("delayIndeminity"));
	
		fieldValueMap.put("convYn", get("convYn"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -947127323 : /* icheDate */
			return getIcheDate();
		case -1325119771 : /* delayIndeminity */
			return getDelayIndeminity();
		case -1354777239 : /* convYn */
			return getConvYn();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -947127323 : /* icheDate */
			setIcheDate((java.lang.String) value);
			return;
		case -1325119771 : /* delayIndeminity */
			setDelayIndeminity((java.math.BigDecimal) value);
			return;
		case -1354777239 : /* convYn */
			setConvYn((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
