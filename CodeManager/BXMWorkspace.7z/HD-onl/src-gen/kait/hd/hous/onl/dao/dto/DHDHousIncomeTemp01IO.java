/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_세대별입금사항_계산용 ( HD_HOUS_INCOME_TEMP )
 */
@XmlType(propOrder={"seqNum", "custCode", "seq", "counts", "times", "deptCode", "housetag", "buildno", "houseno", "depositNo", "receiptdate", "receiptamt", "receiptlandamt", "receiptbuildamt", "receiptvatamt", "delaydays", "delayamt", "discntdays", "discntamt", "realincomamt", "reallandamt", "realbuildamt", "realvatamt", "bankCode", "bankName", "paytag", "incomtype", "modYn", "realPayTag", "slipdt", "slipseq", "taxdate", "taxseq", "inseq", "calcYn", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "detailmodYn", "outDt", "outTm", "outSeq", "outBank", "remark", "receiptmanageamt", "realmanageamt", "cdno"}, name="DHDHousIncomeTemp01IO")
@XmlRootElement(name="DHDHousIncomeTemp01IO")
@SuppressWarnings("all")
public class DHDHousIncomeTemp01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 706478073L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_세대별입금사항_계산용 ( HD_HOUS_INCOME_TEMP )";

	/*******************************************************************************************************************************
	* Property set << seqNum >> [[ */
	
	@XmlTransient
	private boolean isSet_seqNum = false;
	
	protected boolean isSet_seqNum()
	{
		return this.isSet_seqNum;
	}
	
	protected void setIsSet_seqNum(boolean value)
	{
		this.isSet_seqNum = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description SEQ_NUM [SYS_C0012246(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	public void setSeqNum(java.lang.String value) {
		isSet_seqNum = true;
		this.seqNum = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description SEQ_NUM [SYS_C0012246(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	public void setSeqNum(double value) {
		isSet_seqNum = true;
		this.seqNum = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description SEQ_NUM [SYS_C0012246(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	public void setSeqNum(long value) {
		isSet_seqNum = true;
		this.seqNum = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="SEQ_NUM [SYS_C0012246(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seqNum  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description SEQ_NUM [SYS_C0012246(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	public java.math.BigDecimal getSeqNum(){
		return seqNum;
	}
	
	/**
	 * @Description SEQ_NUM [SYS_C0012246(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	@JsonProperty("seqNum")
	public void setSeqNum( java.math.BigDecimal seqNum ) {
		isSet_seqNum = true;
		this.seqNum = seqNum;
	}
	
	/** Property set << seqNum >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객코드 [SYS_C0012247(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 고객코드 [SYS_C0012247(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 고객코드 [SYS_C0012247(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012248(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float seq  = .0F;
	
	/**
	 * @Description 고객순번 [SYS_C0012248(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	public java.lang.Float getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012248(C),SYS_C0012935(P) SYS_C0012935(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.lang.Float seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << counts >> [[ */
	
	@XmlTransient
	private boolean isSet_counts = false;
	
	protected boolean isSet_counts()
	{
		return this.isSet_counts;
	}
	
	protected void setIsSet_counts(boolean value)
	{
		this.isSet_counts = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="차수 [SYS_C0012249(C),SYS_C0012935(P) SYS_C0012935(UNIQUE),XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String counts  = null;
	
	/**
	 * @Description 차수 [SYS_C0012249(C),SYS_C0012935(P) SYS_C0012935(UNIQUE),XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	public java.lang.String getCounts(){
		return counts;
	}
	
	/**
	 * @Description 차수 [SYS_C0012249(C),SYS_C0012935(P) SYS_C0012935(UNIQUE),XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	@JsonProperty("counts")
	public void setCounts( java.lang.String counts ) {
		isSet_counts = true;
		this.counts = counts;
	}
	
	/** Property set << counts >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << times >> [[ */
	
	@XmlTransient
	private boolean isSet_times = false;
	
	protected boolean isSet_times()
	{
		return this.isSet_times;
	}
	
	protected void setIsSet_times(boolean value)
	{
		this.isSet_times = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="회수 [SYS_C0012250(C),SYS_C0012935(P) SYS_C0012935(UNIQUE),XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float times  = .0F;
	
	/**
	 * @Description 회수 [SYS_C0012250(C),SYS_C0012935(P) SYS_C0012935(UNIQUE),XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	public java.lang.Float getTimes(){
		return times;
	}
	
	/**
	 * @Description 회수 [SYS_C0012250(C),SYS_C0012935(P) SYS_C0012935(UNIQUE),XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	@JsonProperty("times")
	public void setTimes( java.lang.Float times ) {
		isSet_times = true;
		this.times = times;
	}
	
	/** Property set << times >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [XIE1HD_HOUS_INCOME_TEMP(NONUNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptdate >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptdate = false;
	
	protected boolean isSet_receiptdate()
	{
		return this.isSet_receiptdate;
	}
	
	protected void setIsSet_receiptdate(boolean value)
	{
		this.isSet_receiptdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String receiptdate  = null;
	
	/**
	 * @Description 납입일자
	 */
	public java.lang.String getReceiptdate(){
		return receiptdate;
	}
	
	/**
	 * @Description 납입일자
	 */
	@JsonProperty("receiptdate")
	public void setReceiptdate( java.lang.String receiptdate ) {
		isSet_receiptdate = true;
		this.receiptdate = receiptdate;
	}
	
	/** Property set << receiptdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptamt = false;
	
	protected boolean isSet_receiptamt()
	{
		return this.isSet_receiptamt;
	}
	
	protected void setIsSet_receiptamt(boolean value)
	{
		this.isSet_receiptamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입인정금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float receiptamt  = .0F;
	
	/**
	 * @Description 납입인정금액
	 */
	public java.lang.Float getReceiptamt(){
		return receiptamt;
	}
	
	/**
	 * @Description 납입인정금액
	 */
	@JsonProperty("receiptamt")
	public void setReceiptamt( java.lang.Float receiptamt ) {
		isSet_receiptamt = true;
		this.receiptamt = receiptamt;
	}
	
	/** Property set << receiptamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptlandamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptlandamt = false;
	
	protected boolean isSet_receiptlandamt()
	{
		return this.isSet_receiptlandamt;
	}
	
	protected void setIsSet_receiptlandamt(boolean value)
	{
		this.isSet_receiptlandamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 납입토지가액
	 */
	public void setReceiptlandamt(java.lang.String value) {
		isSet_receiptlandamt = true;
		this.receiptlandamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 납입토지가액
	 */
	public void setReceiptlandamt(double value) {
		isSet_receiptlandamt = true;
		this.receiptlandamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 납입토지가액
	 */
	public void setReceiptlandamt(long value) {
		isSet_receiptlandamt = true;
		this.receiptlandamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="납입토지가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptlandamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 납입토지가액
	 */
	public java.math.BigDecimal getReceiptlandamt(){
		return receiptlandamt;
	}
	
	/**
	 * @Description 납입토지가액
	 */
	@JsonProperty("receiptlandamt")
	public void setReceiptlandamt( java.math.BigDecimal receiptlandamt ) {
		isSet_receiptlandamt = true;
		this.receiptlandamt = receiptlandamt;
	}
	
	/** Property set << receiptlandamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptbuildamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptbuildamt = false;
	
	protected boolean isSet_receiptbuildamt()
	{
		return this.isSet_receiptbuildamt;
	}
	
	protected void setIsSet_receiptbuildamt(boolean value)
	{
		this.isSet_receiptbuildamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 납입건물가액
	 */
	public void setReceiptbuildamt(java.lang.String value) {
		isSet_receiptbuildamt = true;
		this.receiptbuildamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 납입건물가액
	 */
	public void setReceiptbuildamt(double value) {
		isSet_receiptbuildamt = true;
		this.receiptbuildamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 납입건물가액
	 */
	public void setReceiptbuildamt(long value) {
		isSet_receiptbuildamt = true;
		this.receiptbuildamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="납입건물가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptbuildamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 납입건물가액
	 */
	public java.math.BigDecimal getReceiptbuildamt(){
		return receiptbuildamt;
	}
	
	/**
	 * @Description 납입건물가액
	 */
	@JsonProperty("receiptbuildamt")
	public void setReceiptbuildamt( java.math.BigDecimal receiptbuildamt ) {
		isSet_receiptbuildamt = true;
		this.receiptbuildamt = receiptbuildamt;
	}
	
	/** Property set << receiptbuildamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptvatamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptvatamt = false;
	
	protected boolean isSet_receiptvatamt()
	{
		return this.isSet_receiptvatamt;
	}
	
	protected void setIsSet_receiptvatamt(boolean value)
	{
		this.isSet_receiptvatamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 납입부가세액
	 */
	public void setReceiptvatamt(java.lang.String value) {
		isSet_receiptvatamt = true;
		this.receiptvatamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 납입부가세액
	 */
	public void setReceiptvatamt(double value) {
		isSet_receiptvatamt = true;
		this.receiptvatamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 납입부가세액
	 */
	public void setReceiptvatamt(long value) {
		isSet_receiptvatamt = true;
		this.receiptvatamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="납입부가세액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptvatamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 납입부가세액
	 */
	public java.math.BigDecimal getReceiptvatamt(){
		return receiptvatamt;
	}
	
	/**
	 * @Description 납입부가세액
	 */
	@JsonProperty("receiptvatamt")
	public void setReceiptvatamt( java.math.BigDecimal receiptvatamt ) {
		isSet_receiptvatamt = true;
		this.receiptvatamt = receiptvatamt;
	}
	
	/** Property set << receiptvatamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delaydays >> [[ */
	
	@XmlTransient
	private boolean isSet_delaydays = false;
	
	protected boolean isSet_delaydays()
	{
		return this.isSet_delaydays;
	}
	
	protected void setIsSet_delaydays(boolean value)
	{
		this.isSet_delaydays = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체일수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float delaydays  = .0F;
	
	/**
	 * @Description 연체일수
	 */
	public java.lang.Float getDelaydays(){
		return delaydays;
	}
	
	/**
	 * @Description 연체일수
	 */
	@JsonProperty("delaydays")
	public void setDelaydays( java.lang.Float delaydays ) {
		isSet_delaydays = true;
		this.delaydays = delaydays;
	}
	
	/** Property set << delaydays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayamt >> [[ */
	
	@XmlTransient
	private boolean isSet_delayamt = false;
	
	protected boolean isSet_delayamt()
	{
		return this.isSet_delayamt;
	}
	
	protected void setIsSet_delayamt(boolean value)
	{
		this.isSet_delayamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 연체료
	 */
	public void setDelayamt(java.lang.String value) {
		isSet_delayamt = true;
		this.delayamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 연체료
	 */
	public void setDelayamt(double value) {
		isSet_delayamt = true;
		this.delayamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 연체료
	 */
	public void setDelayamt(long value) {
		isSet_delayamt = true;
		this.delayamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="연체료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 연체료
	 */
	public java.math.BigDecimal getDelayamt(){
		return delayamt;
	}
	
	/**
	 * @Description 연체료
	 */
	@JsonProperty("delayamt")
	public void setDelayamt( java.math.BigDecimal delayamt ) {
		isSet_delayamt = true;
		this.delayamt = delayamt;
	}
	
	/** Property set << delayamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntdays >> [[ */
	
	@XmlTransient
	private boolean isSet_discntdays = false;
	
	protected boolean isSet_discntdays()
	{
		return this.isSet_discntdays;
	}
	
	protected void setIsSet_discntdays(boolean value)
	{
		this.isSet_discntdays = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="할인일수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float discntdays  = .0F;
	
	/**
	 * @Description 할인일수
	 */
	public java.lang.Float getDiscntdays(){
		return discntdays;
	}
	
	/**
	 * @Description 할인일수
	 */
	@JsonProperty("discntdays")
	public void setDiscntdays( java.lang.Float discntdays ) {
		isSet_discntdays = true;
		this.discntdays = discntdays;
	}
	
	/** Property set << discntdays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << discntamt >> [[ */
	
	@XmlTransient
	private boolean isSet_discntamt = false;
	
	protected boolean isSet_discntamt()
	{
		return this.isSet_discntamt;
	}
	
	protected void setIsSet_discntamt(boolean value)
	{
		this.isSet_discntamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 할인료
	 */
	public void setDiscntamt(java.lang.String value) {
		isSet_discntamt = true;
		this.discntamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 할인료
	 */
	public void setDiscntamt(double value) {
		isSet_discntamt = true;
		this.discntamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 할인료
	 */
	public void setDiscntamt(long value) {
		isSet_discntamt = true;
		this.discntamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="할인료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal discntamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 할인료
	 */
	public java.math.BigDecimal getDiscntamt(){
		return discntamt;
	}
	
	/**
	 * @Description 할인료
	 */
	@JsonProperty("discntamt")
	public void setDiscntamt( java.math.BigDecimal discntamt ) {
		isSet_discntamt = true;
		this.discntamt = discntamt;
	}
	
	/** Property set << discntamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realincomamt >> [[ */
	
	@XmlTransient
	private boolean isSet_realincomamt = false;
	
	protected boolean isSet_realincomamt()
	{
		return this.isSet_realincomamt;
	}
	
	protected void setIsSet_realincomamt(boolean value)
	{
		this.isSet_realincomamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실납입금액
	 */
	public void setRealincomamt(java.lang.String value) {
		isSet_realincomamt = true;
		this.realincomamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실납입금액
	 */
	public void setRealincomamt(double value) {
		isSet_realincomamt = true;
		this.realincomamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실납입금액
	 */
	public void setRealincomamt(long value) {
		isSet_realincomamt = true;
		this.realincomamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실납입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal realincomamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실납입금액
	 */
	public java.math.BigDecimal getRealincomamt(){
		return realincomamt;
	}
	
	/**
	 * @Description 실납입금액
	 */
	@JsonProperty("realincomamt")
	public void setRealincomamt( java.math.BigDecimal realincomamt ) {
		isSet_realincomamt = true;
		this.realincomamt = realincomamt;
	}
	
	/** Property set << realincomamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << reallandamt >> [[ */
	
	@XmlTransient
	private boolean isSet_reallandamt = false;
	
	protected boolean isSet_reallandamt()
	{
		return this.isSet_reallandamt;
	}
	
	protected void setIsSet_reallandamt(boolean value)
	{
		this.isSet_reallandamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실납입토지가액
	 */
	public void setReallandamt(java.lang.String value) {
		isSet_reallandamt = true;
		this.reallandamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실납입토지가액
	 */
	public void setReallandamt(double value) {
		isSet_reallandamt = true;
		this.reallandamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실납입토지가액
	 */
	public void setReallandamt(long value) {
		isSet_reallandamt = true;
		this.reallandamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실납입토지가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal reallandamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실납입토지가액
	 */
	public java.math.BigDecimal getReallandamt(){
		return reallandamt;
	}
	
	/**
	 * @Description 실납입토지가액
	 */
	@JsonProperty("reallandamt")
	public void setReallandamt( java.math.BigDecimal reallandamt ) {
		isSet_reallandamt = true;
		this.reallandamt = reallandamt;
	}
	
	/** Property set << reallandamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realbuildamt >> [[ */
	
	@XmlTransient
	private boolean isSet_realbuildamt = false;
	
	protected boolean isSet_realbuildamt()
	{
		return this.isSet_realbuildamt;
	}
	
	protected void setIsSet_realbuildamt(boolean value)
	{
		this.isSet_realbuildamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실납입건물가액
	 */
	public void setRealbuildamt(java.lang.String value) {
		isSet_realbuildamt = true;
		this.realbuildamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실납입건물가액
	 */
	public void setRealbuildamt(double value) {
		isSet_realbuildamt = true;
		this.realbuildamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실납입건물가액
	 */
	public void setRealbuildamt(long value) {
		isSet_realbuildamt = true;
		this.realbuildamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실납입건물가액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal realbuildamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실납입건물가액
	 */
	public java.math.BigDecimal getRealbuildamt(){
		return realbuildamt;
	}
	
	/**
	 * @Description 실납입건물가액
	 */
	@JsonProperty("realbuildamt")
	public void setRealbuildamt( java.math.BigDecimal realbuildamt ) {
		isSet_realbuildamt = true;
		this.realbuildamt = realbuildamt;
	}
	
	/** Property set << realbuildamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realvatamt >> [[ */
	
	@XmlTransient
	private boolean isSet_realvatamt = false;
	
	protected boolean isSet_realvatamt()
	{
		return this.isSet_realvatamt;
	}
	
	protected void setIsSet_realvatamt(boolean value)
	{
		this.isSet_realvatamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실납입부가세액
	 */
	public void setRealvatamt(java.lang.String value) {
		isSet_realvatamt = true;
		this.realvatamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실납입부가세액
	 */
	public void setRealvatamt(double value) {
		isSet_realvatamt = true;
		this.realvatamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실납입부가세액
	 */
	public void setRealvatamt(long value) {
		isSet_realvatamt = true;
		this.realvatamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실납입부가세액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal realvatamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실납입부가세액
	 */
	public java.math.BigDecimal getRealvatamt(){
		return realvatamt;
	}
	
	/**
	 * @Description 실납입부가세액
	 */
	@JsonProperty("realvatamt")
	public void setRealvatamt( java.math.BigDecimal realvatamt ) {
		isSet_realvatamt = true;
		this.realvatamt = realvatamt;
	}
	
	/** Property set << realvatamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankCode = false;
	
	protected boolean isSet_bankCode()
	{
		return this.isSet_bankCode;
	}
	
	protected void setIsSet_bankCode(boolean value)
	{
		this.isSet_bankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행코드", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String bankCode  = null;
	
	/**
	 * @Description 은행코드
	 */
	public java.lang.String getBankCode(){
		return bankCode;
	}
	
	/**
	 * @Description 은행코드
	 */
	@JsonProperty("bankCode")
	public void setBankCode( java.lang.String bankCode ) {
		isSet_bankCode = true;
		this.bankCode = bankCode;
	}
	
	/** Property set << bankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankName >> [[ */
	
	@XmlTransient
	private boolean isSet_bankName = false;
	
	protected boolean isSet_bankName()
	{
		return this.isSet_bankName;
	}
	
	protected void setIsSet_bankName(boolean value)
	{
		this.isSet_bankName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행명칭", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String bankName  = null;
	
	/**
	 * @Description 은행명칭
	 */
	public java.lang.String getBankName(){
		return bankName;
	}
	
	/**
	 * @Description 은행명칭
	 */
	@JsonProperty("bankName")
	public void setBankName( java.lang.String bankName ) {
		isSet_bankName = true;
		this.bankName = bankName;
	}
	
	/** Property set << bankName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << paytag >> [[ */
	
	@XmlTransient
	private boolean isSet_paytag = false;
	
	protected boolean isSet_paytag()
	{
		return this.isSet_paytag;
	}
	
	protected void setIsSet_paytag(boolean value)
	{
		this.isSet_paytag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String paytag  = null;
	
	/**
	 * @Description 입금구분
	 */
	public java.lang.String getPaytag(){
		return paytag;
	}
	
	/**
	 * @Description 입금구분
	 */
	@JsonProperty("paytag")
	public void setPaytag( java.lang.String paytag ) {
		isSet_paytag = true;
		this.paytag = paytag;
	}
	
	/** Property set << paytag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << incomtype >> [[ */
	
	@XmlTransient
	private boolean isSet_incomtype = false;
	
	protected boolean isSet_incomtype()
	{
		return this.isSet_incomtype;
	}
	
	protected void setIsSet_incomtype(boolean value)
	{
		this.isSet_incomtype = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금형태", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String incomtype  = null;
	
	/**
	 * @Description 입금형태
	 */
	public java.lang.String getIncomtype(){
		return incomtype;
	}
	
	/**
	 * @Description 입금형태
	 */
	@JsonProperty("incomtype")
	public void setIncomtype( java.lang.String incomtype ) {
		isSet_incomtype = true;
		this.incomtype = incomtype;
	}
	
	/** Property set << incomtype >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << modYn >> [[ */
	
	@XmlTransient
	private boolean isSet_modYn = false;
	
	protected boolean isSet_modYn()
	{
		return this.isSet_modYn;
	}
	
	protected void setIsSet_modYn(boolean value)
	{
		this.isSet_modYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="조정여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String modYn  = null;
	
	/**
	 * @Description 조정여부
	 */
	public java.lang.String getModYn(){
		return modYn;
	}
	
	/**
	 * @Description 조정여부
	 */
	@JsonProperty("modYn")
	public void setModYn( java.lang.String modYn ) {
		isSet_modYn = true;
		this.modYn = modYn;
	}
	
	/** Property set << modYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realPayTag >> [[ */
	
	@XmlTransient
	private boolean isSet_realPayTag = false;
	
	protected boolean isSet_realPayTag()
	{
		return this.isSet_realPayTag;
	}
	
	protected void setIsSet_realPayTag(boolean value)
	{
		this.isSet_realPayTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="실제납입TAG", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String realPayTag  = null;
	
	/**
	 * @Description 실제납입TAG
	 */
	public java.lang.String getRealPayTag(){
		return realPayTag;
	}
	
	/**
	 * @Description 실제납입TAG
	 */
	@JsonProperty("realPayTag")
	public void setRealPayTag( java.lang.String realPayTag ) {
		isSet_realPayTag = true;
		this.realPayTag = realPayTag;
	}
	
	/** Property set << realPayTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipdt >> [[ */
	
	@XmlTransient
	private boolean isSet_slipdt = false;
	
	protected boolean isSet_slipdt()
	{
		return this.isSet_slipdt;
	}
	
	protected void setIsSet_slipdt(boolean value)
	{
		this.isSet_slipdt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전표일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipdt  = null;
	
	/**
	 * @Description 전표일자
	 */
	public java.lang.String getSlipdt(){
		return slipdt;
	}
	
	/**
	 * @Description 전표일자
	 */
	@JsonProperty("slipdt")
	public void setSlipdt( java.lang.String slipdt ) {
		isSet_slipdt = true;
		this.slipdt = slipdt;
	}
	
	/** Property set << slipdt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipseq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipseq = false;
	
	protected boolean isSet_slipseq()
	{
		return this.isSet_slipseq;
	}
	
	protected void setIsSet_slipseq(boolean value)
	{
		this.isSet_slipseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전표순번
	 */
	public void setSlipseq(java.lang.String value) {
		isSet_slipseq = true;
		this.slipseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전표순번
	 */
	public void setSlipseq(double value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전표순번
	 */
	public void setSlipseq(long value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전표순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전표순번
	 */
	public java.math.BigDecimal getSlipseq(){
		return slipseq;
	}
	
	/**
	 * @Description 전표순번
	 */
	@JsonProperty("slipseq")
	public void setSlipseq( java.math.BigDecimal slipseq ) {
		isSet_slipseq = true;
		this.slipseq = slipseq;
	}
	
	/** Property set << slipseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << taxdate >> [[ */
	
	@XmlTransient
	private boolean isSet_taxdate = false;
	
	protected boolean isSet_taxdate()
	{
		return this.isSet_taxdate;
	}
	
	protected void setIsSet_taxdate(boolean value)
	{
		this.isSet_taxdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="세금계산서발행일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String taxdate  = null;
	
	/**
	 * @Description 세금계산서발행일자
	 */
	public java.lang.String getTaxdate(){
		return taxdate;
	}
	
	/**
	 * @Description 세금계산서발행일자
	 */
	@JsonProperty("taxdate")
	public void setTaxdate( java.lang.String taxdate ) {
		isSet_taxdate = true;
		this.taxdate = taxdate;
	}
	
	/** Property set << taxdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << taxseq >> [[ */
	
	@XmlTransient
	private boolean isSet_taxseq = false;
	
	protected boolean isSet_taxseq()
	{
		return this.isSet_taxseq;
	}
	
	protected void setIsSet_taxseq(boolean value)
	{
		this.isSet_taxseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 세금계산서발행순번
	 */
	public void setTaxseq(java.lang.String value) {
		isSet_taxseq = true;
		this.taxseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 세금계산서발행순번
	 */
	public void setTaxseq(double value) {
		isSet_taxseq = true;
		this.taxseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 세금계산서발행순번
	 */
	public void setTaxseq(long value) {
		isSet_taxseq = true;
		this.taxseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="세금계산서발행순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal taxseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 세금계산서발행순번
	 */
	public java.math.BigDecimal getTaxseq(){
		return taxseq;
	}
	
	/**
	 * @Description 세금계산서발행순번
	 */
	@JsonProperty("taxseq")
	public void setTaxseq( java.math.BigDecimal taxseq ) {
		isSet_taxseq = true;
		this.taxseq = taxseq;
	}
	
	/** Property set << taxseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inseq >> [[ */
	
	@XmlTransient
	private boolean isSet_inseq = false;
	
	protected boolean isSet_inseq()
	{
		return this.isSet_inseq;
	}
	
	protected void setIsSet_inseq(boolean value)
	{
		this.isSet_inseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 일자별입금순번
	 */
	public void setInseq(java.lang.String value) {
		isSet_inseq = true;
		this.inseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 일자별입금순번
	 */
	public void setInseq(double value) {
		isSet_inseq = true;
		this.inseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 일자별입금순번
	 */
	public void setInseq(long value) {
		isSet_inseq = true;
		this.inseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="일자별입금순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal inseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 일자별입금순번
	 */
	public java.math.BigDecimal getInseq(){
		return inseq;
	}
	
	/**
	 * @Description 일자별입금순번
	 */
	@JsonProperty("inseq")
	public void setInseq( java.math.BigDecimal inseq ) {
		isSet_inseq = true;
		this.inseq = inseq;
	}
	
	/** Property set << inseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << calcYn >> [[ */
	
	@XmlTransient
	private boolean isSet_calcYn = false;
	
	protected boolean isSet_calcYn()
	{
		return this.isSet_calcYn;
	}
	
	protected void setIsSet_calcYn(boolean value)
	{
		this.isSet_calcYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계산여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String calcYn  = null;
	
	/**
	 * @Description 계산여부
	 */
	public java.lang.String getCalcYn(){
		return calcYn;
	}
	
	/**
	 * @Description 계산여부
	 */
	@JsonProperty("calcYn")
	public void setCalcYn( java.lang.String calcYn ) {
		isSet_calcYn = true;
		this.calcYn = calcYn;
	}
	
	/** Property set << calcYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 변경담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 변경담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 변경일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 변경일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << detailmodYn >> [[ */
	
	@XmlTransient
	private boolean isSet_detailmodYn = false;
	
	protected boolean isSet_detailmodYn()
	{
		return this.isSet_detailmodYn;
	}
	
	protected void setIsSet_detailmodYn(boolean value)
	{
		this.isSet_detailmodYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="세부수정여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String detailmodYn  = null;
	
	/**
	 * @Description 세부수정여부
	 */
	public java.lang.String getDetailmodYn(){
		return detailmodYn;
	}
	
	/**
	 * @Description 세부수정여부
	 */
	@JsonProperty("detailmodYn")
	public void setDetailmodYn( java.lang.String detailmodYn ) {
		isSet_detailmodYn = true;
		this.detailmodYn = detailmodYn;
	}
	
	/** Property set << detailmodYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outDt >> [[ */
	
	@XmlTransient
	private boolean isSet_outDt = false;
	
	protected boolean isSet_outDt()
	{
		return this.isSet_outDt;
	}
	
	protected void setIsSet_outDt(boolean value)
	{
		this.isSet_outDt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String outDt  = null;
	
	/**
	 * @Description 외부입력일자
	 */
	public java.lang.String getOutDt(){
		return outDt;
	}
	
	/**
	 * @Description 외부입력일자
	 */
	@JsonProperty("outDt")
	public void setOutDt( java.lang.String outDt ) {
		isSet_outDt = true;
		this.outDt = outDt;
	}
	
	/** Property set << outDt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outTm >> [[ */
	
	@XmlTransient
	private boolean isSet_outTm = false;
	
	protected boolean isSet_outTm()
	{
		return this.isSet_outTm;
	}
	
	protected void setIsSet_outTm(boolean value)
	{
		this.isSet_outTm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력시간", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String outTm  = null;
	
	/**
	 * @Description 외부입력시간
	 */
	public java.lang.String getOutTm(){
		return outTm;
	}
	
	/**
	 * @Description 외부입력시간
	 */
	@JsonProperty("outTm")
	public void setOutTm( java.lang.String outTm ) {
		isSet_outTm = true;
		this.outTm = outTm;
	}
	
	/** Property set << outTm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_outSeq = false;
	
	protected boolean isSet_outSeq()
	{
		return this.isSet_outSeq;
	}
	
	protected void setIsSet_outSeq(boolean value)
	{
		this.isSet_outSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float outSeq  = .0F;
	
	/**
	 * @Description 외부입력순번
	 */
	public java.lang.Float getOutSeq(){
		return outSeq;
	}
	
	/**
	 * @Description 외부입력순번
	 */
	@JsonProperty("outSeq")
	public void setOutSeq( java.lang.Float outSeq ) {
		isSet_outSeq = true;
		this.outSeq = outSeq;
	}
	
	/** Property set << outSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << outBank >> [[ */
	
	@XmlTransient
	private boolean isSet_outBank = false;
	
	protected boolean isSet_outBank()
	{
		return this.isSet_outBank;
	}
	
	protected void setIsSet_outBank(boolean value)
	{
		this.isSet_outBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="외부입력은행", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String outBank  = null;
	
	/**
	 * @Description 외부입력은행
	 */
	public java.lang.String getOutBank(){
		return outBank;
	}
	
	/**
	 * @Description 외부입력은행
	 */
	@JsonProperty("outBank")
	public void setOutBank( java.lang.String outBank ) {
		isSet_outBank = true;
		this.outBank = outBank;
	}
	
	/** Property set << outBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptmanageamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptmanageamt = false;
	
	protected boolean isSet_receiptmanageamt()
	{
		return this.isSet_receiptmanageamt;
	}
	
	protected void setIsSet_receiptmanageamt(boolean value)
	{
		this.isSet_receiptmanageamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입관리비", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float receiptmanageamt  = .0F;
	
	/**
	 * @Description 납입관리비
	 */
	public java.lang.Float getReceiptmanageamt(){
		return receiptmanageamt;
	}
	
	/**
	 * @Description 납입관리비
	 */
	@JsonProperty("receiptmanageamt")
	public void setReceiptmanageamt( java.lang.Float receiptmanageamt ) {
		isSet_receiptmanageamt = true;
		this.receiptmanageamt = receiptmanageamt;
	}
	
	/** Property set << receiptmanageamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realmanageamt >> [[ */
	
	@XmlTransient
	private boolean isSet_realmanageamt = false;
	
	protected boolean isSet_realmanageamt()
	{
		return this.isSet_realmanageamt;
	}
	
	protected void setIsSet_realmanageamt(boolean value)
	{
		this.isSet_realmanageamt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="실납입관리비", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float realmanageamt  = .0F;
	
	/**
	 * @Description 실납입관리비
	 */
	public java.lang.Float getRealmanageamt(){
		return realmanageamt;
	}
	
	/**
	 * @Description 실납입관리비
	 */
	@JsonProperty("realmanageamt")
	public void setRealmanageamt( java.lang.Float realmanageamt ) {
		isSet_realmanageamt = true;
		this.realmanageamt = realmanageamt;
	}
	
	/** Property set << realmanageamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cdno >> [[ */
	
	@XmlTransient
	private boolean isSet_cdno = false;
	
	protected boolean isSet_cdno()
	{
		return this.isSet_cdno;
	}
	
	protected void setIsSet_cdno(boolean value)
	{
		this.isSet_cdno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="카드번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String cdno  = null;
	
	/**
	 * @Description 카드번호
	 */
	public java.lang.String getCdno(){
		return cdno;
	}
	
	/**
	 * @Description 카드번호
	 */
	@JsonProperty("cdno")
	public void setCdno( java.lang.String cdno ) {
		isSet_cdno = true;
		this.cdno = cdno;
	}
	
	/** Property set << cdno >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousIncomeTemp01IO clone(){
		try{
			DHDHousIncomeTemp01IO object= (DHDHousIncomeTemp01IO)super.clone();
			if ( this.seqNum== null ) object.seqNum = null;
			else{
				object.seqNum = new java.math.BigDecimal(seqNum.toString());
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = this.seq;
			}
			if ( this.counts== null ) object.counts = null;
			else{
				object.counts = this.counts;
			}
			if ( this.times== null ) object.times = null;
			else{
				object.times = this.times;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.receiptdate== null ) object.receiptdate = null;
			else{
				object.receiptdate = this.receiptdate;
			}
			if ( this.receiptamt== null ) object.receiptamt = null;
			else{
				object.receiptamt = this.receiptamt;
			}
			if ( this.receiptlandamt== null ) object.receiptlandamt = null;
			else{
				object.receiptlandamt = new java.math.BigDecimal(receiptlandamt.toString());
			}
			if ( this.receiptbuildamt== null ) object.receiptbuildamt = null;
			else{
				object.receiptbuildamt = new java.math.BigDecimal(receiptbuildamt.toString());
			}
			if ( this.receiptvatamt== null ) object.receiptvatamt = null;
			else{
				object.receiptvatamt = new java.math.BigDecimal(receiptvatamt.toString());
			}
			if ( this.delaydays== null ) object.delaydays = null;
			else{
				object.delaydays = this.delaydays;
			}
			if ( this.delayamt== null ) object.delayamt = null;
			else{
				object.delayamt = new java.math.BigDecimal(delayamt.toString());
			}
			if ( this.discntdays== null ) object.discntdays = null;
			else{
				object.discntdays = this.discntdays;
			}
			if ( this.discntamt== null ) object.discntamt = null;
			else{
				object.discntamt = new java.math.BigDecimal(discntamt.toString());
			}
			if ( this.realincomamt== null ) object.realincomamt = null;
			else{
				object.realincomamt = new java.math.BigDecimal(realincomamt.toString());
			}
			if ( this.reallandamt== null ) object.reallandamt = null;
			else{
				object.reallandamt = new java.math.BigDecimal(reallandamt.toString());
			}
			if ( this.realbuildamt== null ) object.realbuildamt = null;
			else{
				object.realbuildamt = new java.math.BigDecimal(realbuildamt.toString());
			}
			if ( this.realvatamt== null ) object.realvatamt = null;
			else{
				object.realvatamt = new java.math.BigDecimal(realvatamt.toString());
			}
			if ( this.bankCode== null ) object.bankCode = null;
			else{
				object.bankCode = this.bankCode;
			}
			if ( this.bankName== null ) object.bankName = null;
			else{
				object.bankName = this.bankName;
			}
			if ( this.paytag== null ) object.paytag = null;
			else{
				object.paytag = this.paytag;
			}
			if ( this.incomtype== null ) object.incomtype = null;
			else{
				object.incomtype = this.incomtype;
			}
			if ( this.modYn== null ) object.modYn = null;
			else{
				object.modYn = this.modYn;
			}
			if ( this.realPayTag== null ) object.realPayTag = null;
			else{
				object.realPayTag = this.realPayTag;
			}
			if ( this.slipdt== null ) object.slipdt = null;
			else{
				object.slipdt = this.slipdt;
			}
			if ( this.slipseq== null ) object.slipseq = null;
			else{
				object.slipseq = new java.math.BigDecimal(slipseq.toString());
			}
			if ( this.taxdate== null ) object.taxdate = null;
			else{
				object.taxdate = this.taxdate;
			}
			if ( this.taxseq== null ) object.taxseq = null;
			else{
				object.taxseq = new java.math.BigDecimal(taxseq.toString());
			}
			if ( this.inseq== null ) object.inseq = null;
			else{
				object.inseq = new java.math.BigDecimal(inseq.toString());
			}
			if ( this.calcYn== null ) object.calcYn = null;
			else{
				object.calcYn = this.calcYn;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.detailmodYn== null ) object.detailmodYn = null;
			else{
				object.detailmodYn = this.detailmodYn;
			}
			if ( this.outDt== null ) object.outDt = null;
			else{
				object.outDt = this.outDt;
			}
			if ( this.outTm== null ) object.outTm = null;
			else{
				object.outTm = this.outTm;
			}
			if ( this.outSeq== null ) object.outSeq = null;
			else{
				object.outSeq = this.outSeq;
			}
			if ( this.outBank== null ) object.outBank = null;
			else{
				object.outBank = this.outBank;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.receiptmanageamt== null ) object.receiptmanageamt = null;
			else{
				object.receiptmanageamt = this.receiptmanageamt;
			}
			if ( this.realmanageamt== null ) object.realmanageamt = null;
			else{
				object.realmanageamt = this.realmanageamt;
			}
			if ( this.cdno== null ) object.cdno = null;
			else{
				object.cdno = this.cdno;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((seqNum==null)?0:seqNum.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((counts==null)?0:counts.hashCode());
		result = prime * result + ((times==null)?0:times.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((receiptdate==null)?0:receiptdate.hashCode());
		result = prime * result + ((receiptamt==null)?0:receiptamt.hashCode());
		result = prime * result + ((receiptlandamt==null)?0:receiptlandamt.hashCode());
		result = prime * result + ((receiptbuildamt==null)?0:receiptbuildamt.hashCode());
		result = prime * result + ((receiptvatamt==null)?0:receiptvatamt.hashCode());
		result = prime * result + ((delaydays==null)?0:delaydays.hashCode());
		result = prime * result + ((delayamt==null)?0:delayamt.hashCode());
		result = prime * result + ((discntdays==null)?0:discntdays.hashCode());
		result = prime * result + ((discntamt==null)?0:discntamt.hashCode());
		result = prime * result + ((realincomamt==null)?0:realincomamt.hashCode());
		result = prime * result + ((reallandamt==null)?0:reallandamt.hashCode());
		result = prime * result + ((realbuildamt==null)?0:realbuildamt.hashCode());
		result = prime * result + ((realvatamt==null)?0:realvatamt.hashCode());
		result = prime * result + ((bankCode==null)?0:bankCode.hashCode());
		result = prime * result + ((bankName==null)?0:bankName.hashCode());
		result = prime * result + ((paytag==null)?0:paytag.hashCode());
		result = prime * result + ((incomtype==null)?0:incomtype.hashCode());
		result = prime * result + ((modYn==null)?0:modYn.hashCode());
		result = prime * result + ((realPayTag==null)?0:realPayTag.hashCode());
		result = prime * result + ((slipdt==null)?0:slipdt.hashCode());
		result = prime * result + ((slipseq==null)?0:slipseq.hashCode());
		result = prime * result + ((taxdate==null)?0:taxdate.hashCode());
		result = prime * result + ((taxseq==null)?0:taxseq.hashCode());
		result = prime * result + ((inseq==null)?0:inseq.hashCode());
		result = prime * result + ((calcYn==null)?0:calcYn.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((detailmodYn==null)?0:detailmodYn.hashCode());
		result = prime * result + ((outDt==null)?0:outDt.hashCode());
		result = prime * result + ((outTm==null)?0:outTm.hashCode());
		result = prime * result + ((outSeq==null)?0:outSeq.hashCode());
		result = prime * result + ((outBank==null)?0:outBank.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((receiptmanageamt==null)?0:receiptmanageamt.hashCode());
		result = prime * result + ((realmanageamt==null)?0:realmanageamt.hashCode());
		result = prime * result + ((cdno==null)?0:cdno.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO other = (kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO)obj;
		if ( seqNum == null ){
			if ( other.seqNum != null ) return false;
		}
		else if ( !seqNum.equals(other.seqNum) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( counts == null ){
			if ( other.counts != null ) return false;
		}
		else if ( !counts.equals(other.counts) )
			return false;
		if ( times == null ){
			if ( other.times != null ) return false;
		}
		else if ( !times.equals(other.times) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( receiptdate == null ){
			if ( other.receiptdate != null ) return false;
		}
		else if ( !receiptdate.equals(other.receiptdate) )
			return false;
		if ( receiptamt == null ){
			if ( other.receiptamt != null ) return false;
		}
		else if ( !receiptamt.equals(other.receiptamt) )
			return false;
		if ( receiptlandamt == null ){
			if ( other.receiptlandamt != null ) return false;
		}
		else if ( !receiptlandamt.equals(other.receiptlandamt) )
			return false;
		if ( receiptbuildamt == null ){
			if ( other.receiptbuildamt != null ) return false;
		}
		else if ( !receiptbuildamt.equals(other.receiptbuildamt) )
			return false;
		if ( receiptvatamt == null ){
			if ( other.receiptvatamt != null ) return false;
		}
		else if ( !receiptvatamt.equals(other.receiptvatamt) )
			return false;
		if ( delaydays == null ){
			if ( other.delaydays != null ) return false;
		}
		else if ( !delaydays.equals(other.delaydays) )
			return false;
		if ( delayamt == null ){
			if ( other.delayamt != null ) return false;
		}
		else if ( !delayamt.equals(other.delayamt) )
			return false;
		if ( discntdays == null ){
			if ( other.discntdays != null ) return false;
		}
		else if ( !discntdays.equals(other.discntdays) )
			return false;
		if ( discntamt == null ){
			if ( other.discntamt != null ) return false;
		}
		else if ( !discntamt.equals(other.discntamt) )
			return false;
		if ( realincomamt == null ){
			if ( other.realincomamt != null ) return false;
		}
		else if ( !realincomamt.equals(other.realincomamt) )
			return false;
		if ( reallandamt == null ){
			if ( other.reallandamt != null ) return false;
		}
		else if ( !reallandamt.equals(other.reallandamt) )
			return false;
		if ( realbuildamt == null ){
			if ( other.realbuildamt != null ) return false;
		}
		else if ( !realbuildamt.equals(other.realbuildamt) )
			return false;
		if ( realvatamt == null ){
			if ( other.realvatamt != null ) return false;
		}
		else if ( !realvatamt.equals(other.realvatamt) )
			return false;
		if ( bankCode == null ){
			if ( other.bankCode != null ) return false;
		}
		else if ( !bankCode.equals(other.bankCode) )
			return false;
		if ( bankName == null ){
			if ( other.bankName != null ) return false;
		}
		else if ( !bankName.equals(other.bankName) )
			return false;
		if ( paytag == null ){
			if ( other.paytag != null ) return false;
		}
		else if ( !paytag.equals(other.paytag) )
			return false;
		if ( incomtype == null ){
			if ( other.incomtype != null ) return false;
		}
		else if ( !incomtype.equals(other.incomtype) )
			return false;
		if ( modYn == null ){
			if ( other.modYn != null ) return false;
		}
		else if ( !modYn.equals(other.modYn) )
			return false;
		if ( realPayTag == null ){
			if ( other.realPayTag != null ) return false;
		}
		else if ( !realPayTag.equals(other.realPayTag) )
			return false;
		if ( slipdt == null ){
			if ( other.slipdt != null ) return false;
		}
		else if ( !slipdt.equals(other.slipdt) )
			return false;
		if ( slipseq == null ){
			if ( other.slipseq != null ) return false;
		}
		else if ( !slipseq.equals(other.slipseq) )
			return false;
		if ( taxdate == null ){
			if ( other.taxdate != null ) return false;
		}
		else if ( !taxdate.equals(other.taxdate) )
			return false;
		if ( taxseq == null ){
			if ( other.taxseq != null ) return false;
		}
		else if ( !taxseq.equals(other.taxseq) )
			return false;
		if ( inseq == null ){
			if ( other.inseq != null ) return false;
		}
		else if ( !inseq.equals(other.inseq) )
			return false;
		if ( calcYn == null ){
			if ( other.calcYn != null ) return false;
		}
		else if ( !calcYn.equals(other.calcYn) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( detailmodYn == null ){
			if ( other.detailmodYn != null ) return false;
		}
		else if ( !detailmodYn.equals(other.detailmodYn) )
			return false;
		if ( outDt == null ){
			if ( other.outDt != null ) return false;
		}
		else if ( !outDt.equals(other.outDt) )
			return false;
		if ( outTm == null ){
			if ( other.outTm != null ) return false;
		}
		else if ( !outTm.equals(other.outTm) )
			return false;
		if ( outSeq == null ){
			if ( other.outSeq != null ) return false;
		}
		else if ( !outSeq.equals(other.outSeq) )
			return false;
		if ( outBank == null ){
			if ( other.outBank != null ) return false;
		}
		else if ( !outBank.equals(other.outBank) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( receiptmanageamt == null ){
			if ( other.receiptmanageamt != null ) return false;
		}
		else if ( !receiptmanageamt.equals(other.receiptmanageamt) )
			return false;
		if ( realmanageamt == null ){
			if ( other.realmanageamt != null ) return false;
		}
		else if ( !realmanageamt.equals(other.realmanageamt) )
			return false;
		if ( cdno == null ){
			if ( other.cdno != null ) return false;
		}
		else if ( !cdno.equals(other.cdno) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO:\n");
		sb.append("\tseqNum: ");
		sb.append(seqNum==null?"null":getSeqNum());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tcounts: ");
		sb.append(counts==null?"null":getCounts());
		sb.append("\n");
		sb.append("\ttimes: ");
		sb.append(times==null?"null":getTimes());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\treceiptdate: ");
		sb.append(receiptdate==null?"null":getReceiptdate());
		sb.append("\n");
		sb.append("\treceiptamt: ");
		sb.append(receiptamt==null?"null":getReceiptamt());
		sb.append("\n");
		sb.append("\treceiptlandamt: ");
		sb.append(receiptlandamt==null?"null":getReceiptlandamt());
		sb.append("\n");
		sb.append("\treceiptbuildamt: ");
		sb.append(receiptbuildamt==null?"null":getReceiptbuildamt());
		sb.append("\n");
		sb.append("\treceiptvatamt: ");
		sb.append(receiptvatamt==null?"null":getReceiptvatamt());
		sb.append("\n");
		sb.append("\tdelaydays: ");
		sb.append(delaydays==null?"null":getDelaydays());
		sb.append("\n");
		sb.append("\tdelayamt: ");
		sb.append(delayamt==null?"null":getDelayamt());
		sb.append("\n");
		sb.append("\tdiscntdays: ");
		sb.append(discntdays==null?"null":getDiscntdays());
		sb.append("\n");
		sb.append("\tdiscntamt: ");
		sb.append(discntamt==null?"null":getDiscntamt());
		sb.append("\n");
		sb.append("\trealincomamt: ");
		sb.append(realincomamt==null?"null":getRealincomamt());
		sb.append("\n");
		sb.append("\treallandamt: ");
		sb.append(reallandamt==null?"null":getReallandamt());
		sb.append("\n");
		sb.append("\trealbuildamt: ");
		sb.append(realbuildamt==null?"null":getRealbuildamt());
		sb.append("\n");
		sb.append("\trealvatamt: ");
		sb.append(realvatamt==null?"null":getRealvatamt());
		sb.append("\n");
		sb.append("\tbankCode: ");
		sb.append(bankCode==null?"null":getBankCode());
		sb.append("\n");
		sb.append("\tbankName: ");
		sb.append(bankName==null?"null":getBankName());
		sb.append("\n");
		sb.append("\tpaytag: ");
		sb.append(paytag==null?"null":getPaytag());
		sb.append("\n");
		sb.append("\tincomtype: ");
		sb.append(incomtype==null?"null":getIncomtype());
		sb.append("\n");
		sb.append("\tmodYn: ");
		sb.append(modYn==null?"null":getModYn());
		sb.append("\n");
		sb.append("\trealPayTag: ");
		sb.append(realPayTag==null?"null":getRealPayTag());
		sb.append("\n");
		sb.append("\tslipdt: ");
		sb.append(slipdt==null?"null":getSlipdt());
		sb.append("\n");
		sb.append("\tslipseq: ");
		sb.append(slipseq==null?"null":getSlipseq());
		sb.append("\n");
		sb.append("\ttaxdate: ");
		sb.append(taxdate==null?"null":getTaxdate());
		sb.append("\n");
		sb.append("\ttaxseq: ");
		sb.append(taxseq==null?"null":getTaxseq());
		sb.append("\n");
		sb.append("\tinseq: ");
		sb.append(inseq==null?"null":getInseq());
		sb.append("\n");
		sb.append("\tcalcYn: ");
		sb.append(calcYn==null?"null":getCalcYn());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tdetailmodYn: ");
		sb.append(detailmodYn==null?"null":getDetailmodYn());
		sb.append("\n");
		sb.append("\toutDt: ");
		sb.append(outDt==null?"null":getOutDt());
		sb.append("\n");
		sb.append("\toutTm: ");
		sb.append(outTm==null?"null":getOutTm());
		sb.append("\n");
		sb.append("\toutSeq: ");
		sb.append(outSeq==null?"null":getOutSeq());
		sb.append("\n");
		sb.append("\toutBank: ");
		sb.append(outBank==null?"null":getOutBank());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\treceiptmanageamt: ");
		sb.append(receiptmanageamt==null?"null":getReceiptmanageamt());
		sb.append("\n");
		sb.append("\trealmanageamt: ");
		sb.append(realmanageamt==null?"null":getRealmanageamt());
		sb.append("\n");
		sb.append("\tcdno: ");
		sb.append(cdno==null?"null":getCdno());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 22; /* seqNum */
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 2; /* counts */
		messageLen+= 22; /* times */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 30; /* depositNo */
		messageLen+= 8; /* receiptdate */
		messageLen+= 22; /* receiptamt */
		messageLen+= 22; /* receiptlandamt */
		messageLen+= 22; /* receiptbuildamt */
		messageLen+= 22; /* receiptvatamt */
		messageLen+= 22; /* delaydays */
		messageLen+= 22; /* delayamt */
		messageLen+= 22; /* discntdays */
		messageLen+= 22; /* discntamt */
		messageLen+= 22; /* realincomamt */
		messageLen+= 22; /* reallandamt */
		messageLen+= 22; /* realbuildamt */
		messageLen+= 22; /* realvatamt */
		messageLen+= 8; /* bankCode */
		messageLen+= 30; /* bankName */
		messageLen+= 2; /* paytag */
		messageLen+= 2; /* incomtype */
		messageLen+= 1; /* modYn */
		messageLen+= 1; /* realPayTag */
		messageLen+= 8; /* slipdt */
		messageLen+= 22; /* slipseq */
		messageLen+= 8; /* taxdate */
		messageLen+= 22; /* taxseq */
		messageLen+= 22; /* inseq */
		messageLen+= 1; /* calcYn */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 1; /* detailmodYn */
		messageLen+= 8; /* outDt */
		messageLen+= 6; /* outTm */
		messageLen+= 22; /* outSeq */
		messageLen+= 6; /* outBank */
		messageLen+= 200; /* remark */
		messageLen+= 22; /* receiptmanageamt */
		messageLen+= 22; /* realmanageamt */
		messageLen+= 30; /* cdno */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("seqNum");
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("counts");
	
		fieldNames.add("times");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("receiptdate");
	
		fieldNames.add("receiptamt");
	
		fieldNames.add("receiptlandamt");
	
		fieldNames.add("receiptbuildamt");
	
		fieldNames.add("receiptvatamt");
	
		fieldNames.add("delaydays");
	
		fieldNames.add("delayamt");
	
		fieldNames.add("discntdays");
	
		fieldNames.add("discntamt");
	
		fieldNames.add("realincomamt");
	
		fieldNames.add("reallandamt");
	
		fieldNames.add("realbuildamt");
	
		fieldNames.add("realvatamt");
	
		fieldNames.add("bankCode");
	
		fieldNames.add("bankName");
	
		fieldNames.add("paytag");
	
		fieldNames.add("incomtype");
	
		fieldNames.add("modYn");
	
		fieldNames.add("realPayTag");
	
		fieldNames.add("slipdt");
	
		fieldNames.add("slipseq");
	
		fieldNames.add("taxdate");
	
		fieldNames.add("taxseq");
	
		fieldNames.add("inseq");
	
		fieldNames.add("calcYn");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("detailmodYn");
	
		fieldNames.add("outDt");
	
		fieldNames.add("outTm");
	
		fieldNames.add("outSeq");
	
		fieldNames.add("outBank");
	
		fieldNames.add("remark");
	
		fieldNames.add("receiptmanageamt");
	
		fieldNames.add("realmanageamt");
	
		fieldNames.add("cdno");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("seqNum", get("seqNum"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("counts", get("counts"));
	
		fieldValueMap.put("times", get("times"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("receiptdate", get("receiptdate"));
	
		fieldValueMap.put("receiptamt", get("receiptamt"));
	
		fieldValueMap.put("receiptlandamt", get("receiptlandamt"));
	
		fieldValueMap.put("receiptbuildamt", get("receiptbuildamt"));
	
		fieldValueMap.put("receiptvatamt", get("receiptvatamt"));
	
		fieldValueMap.put("delaydays", get("delaydays"));
	
		fieldValueMap.put("delayamt", get("delayamt"));
	
		fieldValueMap.put("discntdays", get("discntdays"));
	
		fieldValueMap.put("discntamt", get("discntamt"));
	
		fieldValueMap.put("realincomamt", get("realincomamt"));
	
		fieldValueMap.put("reallandamt", get("reallandamt"));
	
		fieldValueMap.put("realbuildamt", get("realbuildamt"));
	
		fieldValueMap.put("realvatamt", get("realvatamt"));
	
		fieldValueMap.put("bankCode", get("bankCode"));
	
		fieldValueMap.put("bankName", get("bankName"));
	
		fieldValueMap.put("paytag", get("paytag"));
	
		fieldValueMap.put("incomtype", get("incomtype"));
	
		fieldValueMap.put("modYn", get("modYn"));
	
		fieldValueMap.put("realPayTag", get("realPayTag"));
	
		fieldValueMap.put("slipdt", get("slipdt"));
	
		fieldValueMap.put("slipseq", get("slipseq"));
	
		fieldValueMap.put("taxdate", get("taxdate"));
	
		fieldValueMap.put("taxseq", get("taxseq"));
	
		fieldValueMap.put("inseq", get("inseq"));
	
		fieldValueMap.put("calcYn", get("calcYn"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("detailmodYn", get("detailmodYn"));
	
		fieldValueMap.put("outDt", get("outDt"));
	
		fieldValueMap.put("outTm", get("outTm"));
	
		fieldValueMap.put("outSeq", get("outSeq"));
	
		fieldValueMap.put("outBank", get("outBank"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("receiptmanageamt", get("receiptmanageamt"));
	
		fieldValueMap.put("realmanageamt", get("realmanageamt"));
	
		fieldValueMap.put("cdno", get("cdno"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -905894233 : /* seqNum */
			return getSeqNum();
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -1354575548 : /* counts */
			return getCounts();
		case 110364486 : /* times */
			return getTimes();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 2034075110 : /* receiptdate */
			return getReceiptdate();
		case 204160144 : /* receiptamt */
			return getReceiptamt();
		case -2057356603 : /* receiptlandamt */
			return getReceiptlandamt();
		case 832745170 : /* receiptbuildamt */
			return getReceiptbuildamt();
		case 1051385399 : /* receiptvatamt */
			return getReceiptvatamt();
		case -468635558 : /* delaydays */
			return getDelaydays();
		case 816164197 : /* delayamt */
			return getDelayamt();
		case 507016434 : /* discntdays */
			return getDiscntdays();
		case -122194483 : /* discntamt */
			return getDiscntamt();
		case 1301329322 : /* realincomamt */
			return getRealincomamt();
		case -1398647649 : /* reallandamt */
			return getReallandamt();
		case -222113736 : /* realbuildamt */
			return getRealbuildamt();
		case -1005575907 : /* realvatamt */
			return getRealvatamt();
		case -1859605943 : /* bankCode */
			return getBankCode();
		case -1859291417 : /* bankName */
			return getBankName();
		case -995201550 : /* paytag */
			return getPaytag();
		case -1417922698 : /* incomtype */
			return getIncomtype();
		case 104069559 : /* modYn */
			return getModYn();
		case -2093347568 : /* realPayTag */
			return getRealPayTag();
		case -899635760 : /* slipdt */
			return getSlipdt();
		case -2118890721 : /* slipseq */
			return getSlipseq();
		case -1532829223 : /* taxdate */
			return getTaxdate();
		case -880715564 : /* taxseq */
			return getTaxseq();
		case 100360474 : /* inseq */
			return getInseq();
		case -1367784374 : /* calcYn */
			return getCalcYn();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -2037289978 : /* detailmodYn */
			return getDetailmodYn();
		case 106110078 : /* outDt */
			return getOutDt();
		case 106110567 : /* outTm */
			return getOutTm();
		case -1005540815 : /* outSeq */
			return getOutSeq();
		case -1107504470 : /* outBank */
			return getOutBank();
		case -934624384 : /* remark */
			return getRemark();
		case 972174091 : /* receiptmanageamt */
			return getReceiptmanageamt();
		case -1663680923 : /* realmanageamt */
			return getRealmanageamt();
		case 3048930 : /* cdno */
			return getCdno();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -905894233 : /* seqNum */
			setSeqNum((java.math.BigDecimal) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.lang.Float) value);
			return;
		case -1354575548 : /* counts */
			setCounts((java.lang.String) value);
			return;
		case 110364486 : /* times */
			setTimes((java.lang.Float) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 2034075110 : /* receiptdate */
			setReceiptdate((java.lang.String) value);
			return;
		case 204160144 : /* receiptamt */
			setReceiptamt((java.lang.Float) value);
			return;
		case -2057356603 : /* receiptlandamt */
			setReceiptlandamt((java.math.BigDecimal) value);
			return;
		case 832745170 : /* receiptbuildamt */
			setReceiptbuildamt((java.math.BigDecimal) value);
			return;
		case 1051385399 : /* receiptvatamt */
			setReceiptvatamt((java.math.BigDecimal) value);
			return;
		case -468635558 : /* delaydays */
			setDelaydays((java.lang.Float) value);
			return;
		case 816164197 : /* delayamt */
			setDelayamt((java.math.BigDecimal) value);
			return;
		case 507016434 : /* discntdays */
			setDiscntdays((java.lang.Float) value);
			return;
		case -122194483 : /* discntamt */
			setDiscntamt((java.math.BigDecimal) value);
			return;
		case 1301329322 : /* realincomamt */
			setRealincomamt((java.math.BigDecimal) value);
			return;
		case -1398647649 : /* reallandamt */
			setReallandamt((java.math.BigDecimal) value);
			return;
		case -222113736 : /* realbuildamt */
			setRealbuildamt((java.math.BigDecimal) value);
			return;
		case -1005575907 : /* realvatamt */
			setRealvatamt((java.math.BigDecimal) value);
			return;
		case -1859605943 : /* bankCode */
			setBankCode((java.lang.String) value);
			return;
		case -1859291417 : /* bankName */
			setBankName((java.lang.String) value);
			return;
		case -995201550 : /* paytag */
			setPaytag((java.lang.String) value);
			return;
		case -1417922698 : /* incomtype */
			setIncomtype((java.lang.String) value);
			return;
		case 104069559 : /* modYn */
			setModYn((java.lang.String) value);
			return;
		case -2093347568 : /* realPayTag */
			setRealPayTag((java.lang.String) value);
			return;
		case -899635760 : /* slipdt */
			setSlipdt((java.lang.String) value);
			return;
		case -2118890721 : /* slipseq */
			setSlipseq((java.math.BigDecimal) value);
			return;
		case -1532829223 : /* taxdate */
			setTaxdate((java.lang.String) value);
			return;
		case -880715564 : /* taxseq */
			setTaxseq((java.math.BigDecimal) value);
			return;
		case 100360474 : /* inseq */
			setInseq((java.math.BigDecimal) value);
			return;
		case -1367784374 : /* calcYn */
			setCalcYn((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -2037289978 : /* detailmodYn */
			setDetailmodYn((java.lang.String) value);
			return;
		case 106110078 : /* outDt */
			setOutDt((java.lang.String) value);
			return;
		case 106110567 : /* outTm */
			setOutTm((java.lang.String) value);
			return;
		case -1005540815 : /* outSeq */
			setOutSeq((java.lang.Float) value);
			return;
		case -1107504470 : /* outBank */
			setOutBank((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case 972174091 : /* receiptmanageamt */
			setReceiptmanageamt((java.lang.Float) value);
			return;
		case -1663680923 : /* realmanageamt */
			setRealmanageamt((java.lang.Float) value);
			return;
		case 3048930 : /* cdno */
			setCdno((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
