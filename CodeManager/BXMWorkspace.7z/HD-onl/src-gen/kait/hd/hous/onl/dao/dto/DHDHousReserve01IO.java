/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_예약자등록 ( HD_HOUS_RESERVE )
 */
@XmlType(propOrder={"deptCode", "housetag", "buildno", "houseno", "custCode", "square", "type", "classJrw", "options", "reservedate", "reserveamt", "remainamt", "contractdate", "contracttag", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "prtsquare"}, name="DHDHousReserve01IO")
@XmlRootElement(name="DHDHousReserve01IO")
@SuppressWarnings("all")
public class DHDHousReserve01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 1019647822L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_예약자등록 ( HD_HOUS_RESERVE )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012328(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012328(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012328(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012329(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012329(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012329(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012330(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012330(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012330(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012331(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012331(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012331(C),SYS_C0012948(P) SYS_C0012948(UNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 평형
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 평형
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 평형
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 평형
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << type >> [[ */
	
	@XmlTransient
	private boolean isSet_type = false;
	
	protected boolean isSet_type()
	{
		return this.isSet_type;
	}
	
	protected void setIsSet_type(boolean value)
	{
		this.isSet_type = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="TYPE", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String type  = null;
	
	/**
	 * @Description TYPE
	 */
	public java.lang.String getType(){
		return type;
	}
	
	/**
	 * @Description TYPE
	 */
	@JsonProperty("type")
	public void setType( java.lang.String type ) {
		isSet_type = true;
		this.type = type;
	}
	
	/** Property set << type >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << classJrw >> [[ */
	
	@XmlTransient
	private boolean isSet_classJrw = false;
	
	protected boolean isSet_classJrw()
	{
		return this.isSet_classJrw;
	}
	
	protected void setIsSet_classJrw(boolean value)
	{
		this.isSet_classJrw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="군", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String classJrw  = null;
	
	/**
	 * @Description 군
	 */
	public java.lang.String getClassJrw(){
		return classJrw;
	}
	
	/**
	 * @Description 군
	 */
	@JsonProperty("classJrw")
	public void setClassJrw( java.lang.String classJrw ) {
		isSet_classJrw = true;
		this.classJrw = classJrw;
	}
	
	/** Property set << classJrw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << options >> [[ */
	
	@XmlTransient
	private boolean isSet_options = false;
	
	protected boolean isSet_options()
	{
		return this.isSet_options;
	}
	
	protected void setIsSet_options(boolean value)
	{
		this.isSet_options = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선택사양코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String options  = null;
	
	/**
	 * @Description 선택사양코드
	 */
	public java.lang.String getOptions(){
		return options;
	}
	
	/**
	 * @Description 선택사양코드
	 */
	@JsonProperty("options")
	public void setOptions( java.lang.String options ) {
		isSet_options = true;
		this.options = options;
	}
	
	/** Property set << options >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << reservedate >> [[ */
	
	@XmlTransient
	private boolean isSet_reservedate = false;
	
	protected boolean isSet_reservedate()
	{
		return this.isSet_reservedate;
	}
	
	protected void setIsSet_reservedate(boolean value)
	{
		this.isSet_reservedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="예약일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String reservedate  = null;
	
	/**
	 * @Description 예약일
	 */
	public java.lang.String getReservedate(){
		return reservedate;
	}
	
	/**
	 * @Description 예약일
	 */
	@JsonProperty("reservedate")
	public void setReservedate( java.lang.String reservedate ) {
		isSet_reservedate = true;
		this.reservedate = reservedate;
	}
	
	/** Property set << reservedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << reserveamt >> [[ */
	
	@XmlTransient
	private boolean isSet_reserveamt = false;
	
	protected boolean isSet_reserveamt()
	{
		return this.isSet_reserveamt;
	}
	
	protected void setIsSet_reserveamt(boolean value)
	{
		this.isSet_reserveamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 예약금
	 */
	public void setReserveamt(java.lang.String value) {
		isSet_reserveamt = true;
		this.reserveamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 예약금
	 */
	public void setReserveamt(double value) {
		isSet_reserveamt = true;
		this.reserveamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 예약금
	 */
	public void setReserveamt(long value) {
		isSet_reserveamt = true;
		this.reserveamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="예약금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal reserveamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 예약금
	 */
	public java.math.BigDecimal getReserveamt(){
		return reserveamt;
	}
	
	/**
	 * @Description 예약금
	 */
	@JsonProperty("reserveamt")
	public void setReserveamt( java.math.BigDecimal reserveamt ) {
		isSet_reserveamt = true;
		this.reserveamt = reserveamt;
	}
	
	/** Property set << reserveamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remainamt >> [[ */
	
	@XmlTransient
	private boolean isSet_remainamt = false;
	
	protected boolean isSet_remainamt()
	{
		return this.isSet_remainamt;
	}
	
	protected void setIsSet_remainamt(boolean value)
	{
		this.isSet_remainamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 계약금잔액
	 */
	public void setRemainamt(java.lang.String value) {
		isSet_remainamt = true;
		this.remainamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 계약금잔액
	 */
	public void setRemainamt(double value) {
		isSet_remainamt = true;
		this.remainamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 계약금잔액
	 */
	public void setRemainamt(long value) {
		isSet_remainamt = true;
		this.remainamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="계약금잔액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal remainamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 계약금잔액
	 */
	public java.math.BigDecimal getRemainamt(){
		return remainamt;
	}
	
	/**
	 * @Description 계약금잔액
	 */
	@JsonProperty("remainamt")
	public void setRemainamt( java.math.BigDecimal remainamt ) {
		isSet_remainamt = true;
		this.remainamt = remainamt;
	}
	
	/** Property set << remainamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contractdate >> [[ */
	
	@XmlTransient
	private boolean isSet_contractdate = false;
	
	protected boolean isSet_contractdate()
	{
		return this.isSet_contractdate;
	}
	
	protected void setIsSet_contractdate(boolean value)
	{
		this.isSet_contractdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약체결일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String contractdate  = null;
	
	/**
	 * @Description 계약체결일
	 */
	public java.lang.String getContractdate(){
		return contractdate;
	}
	
	/**
	 * @Description 계약체결일
	 */
	@JsonProperty("contractdate")
	public void setContractdate( java.lang.String contractdate ) {
		isSet_contractdate = true;
		this.contractdate = contractdate;
	}
	
	/** Property set << contractdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contracttag >> [[ */
	
	@XmlTransient
	private boolean isSet_contracttag = false;
	
	protected boolean isSet_contracttag()
	{
		return this.isSet_contracttag;
	}
	
	protected void setIsSet_contracttag(boolean value)
	{
		this.isSet_contracttag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String contracttag  = null;
	
	/**
	 * @Description 계약여부
	 */
	public java.lang.String getContracttag(){
		return contracttag;
	}
	
	/**
	 * @Description 계약여부
	 */
	@JsonProperty("contracttag")
	public void setContracttag( java.lang.String contracttag ) {
		isSet_contracttag = true;
		this.contracttag = contracttag;
	}
	
	/** Property set << contracttag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << prtsquare >> [[ */
	
	@XmlTransient
	private boolean isSet_prtsquare = false;
	
	protected boolean isSet_prtsquare()
	{
		return this.isSet_prtsquare;
	}
	
	protected void setIsSet_prtsquare(boolean value)
	{
		this.isSet_prtsquare = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(java.lang.String value) {
		isSet_prtsquare = true;
		this.prtsquare = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(double value) {
		isSet_prtsquare = true;
		this.prtsquare = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(long value) {
		isSet_prtsquare = true;
		this.prtsquare = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="출력평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal prtsquare  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 출력평형
	 */
	public java.math.BigDecimal getPrtsquare(){
		return prtsquare;
	}
	
	/**
	 * @Description 출력평형
	 */
	@JsonProperty("prtsquare")
	public void setPrtsquare( java.math.BigDecimal prtsquare ) {
		isSet_prtsquare = true;
		this.prtsquare = prtsquare;
	}
	
	/** Property set << prtsquare >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousReserve01IO clone(){
		try{
			DHDHousReserve01IO object= (DHDHousReserve01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.type== null ) object.type = null;
			else{
				object.type = this.type;
			}
			if ( this.classJrw== null ) object.classJrw = null;
			else{
				object.classJrw = this.classJrw;
			}
			if ( this.options== null ) object.options = null;
			else{
				object.options = this.options;
			}
			if ( this.reservedate== null ) object.reservedate = null;
			else{
				object.reservedate = this.reservedate;
			}
			if ( this.reserveamt== null ) object.reserveamt = null;
			else{
				object.reserveamt = new java.math.BigDecimal(reserveamt.toString());
			}
			if ( this.remainamt== null ) object.remainamt = null;
			else{
				object.remainamt = new java.math.BigDecimal(remainamt.toString());
			}
			if ( this.contractdate== null ) object.contractdate = null;
			else{
				object.contractdate = this.contractdate;
			}
			if ( this.contracttag== null ) object.contracttag = null;
			else{
				object.contracttag = this.contracttag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.prtsquare== null ) object.prtsquare = null;
			else{
				object.prtsquare = new java.math.BigDecimal(prtsquare.toString());
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((type==null)?0:type.hashCode());
		result = prime * result + ((classJrw==null)?0:classJrw.hashCode());
		result = prime * result + ((options==null)?0:options.hashCode());
		result = prime * result + ((reservedate==null)?0:reservedate.hashCode());
		result = prime * result + ((reserveamt==null)?0:reserveamt.hashCode());
		result = prime * result + ((remainamt==null)?0:remainamt.hashCode());
		result = prime * result + ((contractdate==null)?0:contractdate.hashCode());
		result = prime * result + ((contracttag==null)?0:contracttag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((prtsquare==null)?0:prtsquare.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousReserve01IO other = (kait.hd.hous.onl.dao.dto.DHDHousReserve01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( type == null ){
			if ( other.type != null ) return false;
		}
		else if ( !type.equals(other.type) )
			return false;
		if ( classJrw == null ){
			if ( other.classJrw != null ) return false;
		}
		else if ( !classJrw.equals(other.classJrw) )
			return false;
		if ( options == null ){
			if ( other.options != null ) return false;
		}
		else if ( !options.equals(other.options) )
			return false;
		if ( reservedate == null ){
			if ( other.reservedate != null ) return false;
		}
		else if ( !reservedate.equals(other.reservedate) )
			return false;
		if ( reserveamt == null ){
			if ( other.reserveamt != null ) return false;
		}
		else if ( !reserveamt.equals(other.reserveamt) )
			return false;
		if ( remainamt == null ){
			if ( other.remainamt != null ) return false;
		}
		else if ( !remainamt.equals(other.remainamt) )
			return false;
		if ( contractdate == null ){
			if ( other.contractdate != null ) return false;
		}
		else if ( !contractdate.equals(other.contractdate) )
			return false;
		if ( contracttag == null ){
			if ( other.contracttag != null ) return false;
		}
		else if ( !contracttag.equals(other.contracttag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( prtsquare == null ){
			if ( other.prtsquare != null ) return false;
		}
		else if ( !prtsquare.equals(other.prtsquare) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousReserve01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttype: ");
		sb.append(type==null?"null":getType());
		sb.append("\n");
		sb.append("\tclassJrw: ");
		sb.append(classJrw==null?"null":getClassJrw());
		sb.append("\n");
		sb.append("\toptions: ");
		sb.append(options==null?"null":getOptions());
		sb.append("\n");
		sb.append("\treservedate: ");
		sb.append(reservedate==null?"null":getReservedate());
		sb.append("\n");
		sb.append("\treserveamt: ");
		sb.append(reserveamt==null?"null":getReserveamt());
		sb.append("\n");
		sb.append("\tremainamt: ");
		sb.append(remainamt==null?"null":getRemainamt());
		sb.append("\n");
		sb.append("\tcontractdate: ");
		sb.append(contractdate==null?"null":getContractdate());
		sb.append("\n");
		sb.append("\tcontracttag: ");
		sb.append(contracttag==null?"null":getContracttag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tprtsquare: ");
		sb.append(prtsquare==null?"null":getPrtsquare());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* square */
		messageLen+= 4; /* type */
		messageLen+= 1; /* classJrw */
		messageLen+= 2; /* options */
		messageLen+= 8; /* reservedate */
		messageLen+= 22; /* reserveamt */
		messageLen+= 22; /* remainamt */
		messageLen+= 8; /* contractdate */
		messageLen+= 1; /* contracttag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 22; /* prtsquare */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("custCode");
	
		fieldNames.add("square");
	
		fieldNames.add("type");
	
		fieldNames.add("classJrw");
	
		fieldNames.add("options");
	
		fieldNames.add("reservedate");
	
		fieldNames.add("reserveamt");
	
		fieldNames.add("remainamt");
	
		fieldNames.add("contractdate");
	
		fieldNames.add("contracttag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("prtsquare");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("type", get("type"));
	
		fieldValueMap.put("classJrw", get("classJrw"));
	
		fieldValueMap.put("options", get("options"));
	
		fieldValueMap.put("reservedate", get("reservedate"));
	
		fieldValueMap.put("reserveamt", get("reserveamt"));
	
		fieldValueMap.put("remainamt", get("remainamt"));
	
		fieldValueMap.put("contractdate", get("contractdate"));
	
		fieldValueMap.put("contracttag", get("contracttag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("prtsquare", get("prtsquare"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 604866272 : /* custCode */
			return getCustCode();
		case -894674659 : /* square */
			return getSquare();
		case 3575610 : /* type */
			return getType();
		case 692414359 : /* classJrw */
			return getClassJrw();
		case -1249474914 : /* options */
			return getOptions();
		case -1559871894 : /* reservedate */
			return getReservedate();
		case -1712888948 : /* reserveamt */
			return getReserveamt();
		case 869830620 : /* remainamt */
			return getRemainamt();
		case -1401870400 : /* contractdate */
			return getContractdate();
		case -2123416248 : /* contracttag */
			return getContracttag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -483017137 : /* prtsquare */
			return getPrtsquare();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case 3575610 : /* type */
			setType((java.lang.String) value);
			return;
		case 692414359 : /* classJrw */
			setClassJrw((java.lang.String) value);
			return;
		case -1249474914 : /* options */
			setOptions((java.lang.String) value);
			return;
		case -1559871894 : /* reservedate */
			setReservedate((java.lang.String) value);
			return;
		case -1712888948 : /* reserveamt */
			setReserveamt((java.math.BigDecimal) value);
			return;
		case 869830620 : /* remainamt */
			setRemainamt((java.math.BigDecimal) value);
			return;
		case -1401870400 : /* contractdate */
			setContractdate((java.lang.String) value);
			return;
		case -2123416248 : /* contracttag */
			setContracttag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -483017137 : /* prtsquare */
			setPrtsquare((java.math.BigDecimal) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
