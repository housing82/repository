/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_금융수납기타 ( HD_HOUS_BANKETC )
 */
@XmlType(propOrder={"paymentdate", "paymentseq", "bankKind", "custCode", "seq", "depositNo", "paymentamt", "canceltag", "incometag", "processtag", "deptCode", "housetag", "buildno", "houseno", "indata", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousBanketc01IO")
@XmlRootElement(name="DHDHousBanketc01IO")
@SuppressWarnings("all")
public class DHDHousBanketc01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -200300950L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_금융수납기타 ( HD_HOUS_BANKETC )";

	/*******************************************************************************************************************************
	* Property set << paymentdate >> [[ */
	
	@XmlTransient
	private boolean isSet_paymentdate = false;
	
	protected boolean isSet_paymentdate()
	{
		return this.isSet_paymentdate;
	}
	
	protected void setIsSet_paymentdate(boolean value)
	{
		this.isSet_paymentdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금일자 [SYS_C0012132(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String paymentdate  = null;
	
	/**
	 * @Description 입금일자 [SYS_C0012132(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]
	 */
	public java.lang.String getPaymentdate(){
		return paymentdate;
	}
	
	/**
	 * @Description 입금일자 [SYS_C0012132(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]
	 */
	@JsonProperty("paymentdate")
	public void setPaymentdate( java.lang.String paymentdate ) {
		isSet_paymentdate = true;
		this.paymentdate = paymentdate;
	}
	
	/** Property set << paymentdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << paymentseq >> [[ */
	
	@XmlTransient
	private boolean isSet_paymentseq = false;
	
	protected boolean isSet_paymentseq()
	{
		return this.isSet_paymentseq;
	}
	
	protected void setIsSet_paymentseq(boolean value)
	{
		this.isSet_paymentseq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금순번 [SYS_C0012133(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float paymentseq  = .0F;
	
	/**
	 * @Description 입금순번 [SYS_C0012133(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]
	 */
	public java.lang.Float getPaymentseq(){
		return paymentseq;
	}
	
	/**
	 * @Description 입금순번 [SYS_C0012133(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]
	 */
	@JsonProperty("paymentseq")
	public void setPaymentseq( java.lang.Float paymentseq ) {
		isSet_paymentseq = true;
		this.paymentseq = paymentseq;
	}
	
	/** Property set << paymentseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankKind >> [[ */
	
	@XmlTransient
	private boolean isSet_bankKind = false;
	
	protected boolean isSet_bankKind()
	{
		return this.isSet_bankKind;
	}
	
	protected void setIsSet_bankKind(boolean value)
	{
		this.isSet_bankKind = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행종류 [SYS_C0012134(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String bankKind  = null;
	
	/**
	 * @Description 은행종류 [SYS_C0012134(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]
	 */
	public java.lang.String getBankKind(){
		return bankKind;
	}
	
	/**
	 * @Description 은행종류 [SYS_C0012134(C),SYS_C0012923(P) SYS_C0012923(UNIQUE)]
	 */
	@JsonProperty("bankKind")
	public void setBankKind( java.lang.String bankKind ) {
		isSet_bankKind = true;
		this.bankKind = bankKind;
	}
	
	/** Property set << bankKind >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_depositNo = false;
	
	protected boolean isSet_depositNo()
	{
		return this.isSet_depositNo;
	}
	
	protected void setIsSet_depositNo(boolean value)
	{
		this.isSet_depositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String depositNo  = null;
	
	/**
	 * @Description 계좌번호
	 */
	public java.lang.String getDepositNo(){
		return depositNo;
	}
	
	/**
	 * @Description 계좌번호
	 */
	@JsonProperty("depositNo")
	public void setDepositNo( java.lang.String depositNo ) {
		isSet_depositNo = true;
		this.depositNo = depositNo;
	}
	
	/** Property set << depositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << paymentamt >> [[ */
	
	@XmlTransient
	private boolean isSet_paymentamt = false;
	
	protected boolean isSet_paymentamt()
	{
		return this.isSet_paymentamt;
	}
	
	protected void setIsSet_paymentamt(boolean value)
	{
		this.isSet_paymentamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 입금금액
	 */
	public void setPaymentamt(java.lang.String value) {
		isSet_paymentamt = true;
		this.paymentamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 입금금액
	 */
	public void setPaymentamt(double value) {
		isSet_paymentamt = true;
		this.paymentamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 입금금액
	 */
	public void setPaymentamt(long value) {
		isSet_paymentamt = true;
		this.paymentamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="입금금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal paymentamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 입금금액
	 */
	public java.math.BigDecimal getPaymentamt(){
		return paymentamt;
	}
	
	/**
	 * @Description 입금금액
	 */
	@JsonProperty("paymentamt")
	public void setPaymentamt( java.math.BigDecimal paymentamt ) {
		isSet_paymentamt = true;
		this.paymentamt = paymentamt;
	}
	
	/** Property set << paymentamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << canceltag >> [[ */
	
	@XmlTransient
	private boolean isSet_canceltag = false;
	
	protected boolean isSet_canceltag()
	{
		return this.isSet_canceltag;
	}
	
	protected void setIsSet_canceltag(boolean value)
	{
		this.isSet_canceltag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="취소여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String canceltag  = null;
	
	/**
	 * @Description 취소여부
	 */
	public java.lang.String getCanceltag(){
		return canceltag;
	}
	
	/**
	 * @Description 취소여부
	 */
	@JsonProperty("canceltag")
	public void setCanceltag( java.lang.String canceltag ) {
		isSet_canceltag = true;
		this.canceltag = canceltag;
	}
	
	/** Property set << canceltag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << incometag >> [[ */
	
	@XmlTransient
	private boolean isSet_incometag = false;
	
	protected boolean isSet_incometag()
	{
		return this.isSet_incometag;
	}
	
	protected void setIsSet_incometag(boolean value)
	{
		this.isSet_incometag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입출금구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String incometag  = null;
	
	/**
	 * @Description 입출금구분
	 */
	public java.lang.String getIncometag(){
		return incometag;
	}
	
	/**
	 * @Description 입출금구분
	 */
	@JsonProperty("incometag")
	public void setIncometag( java.lang.String incometag ) {
		isSet_incometag = true;
		this.incometag = incometag;
	}
	
	/** Property set << incometag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << processtag >> [[ */
	
	@XmlTransient
	private boolean isSet_processtag = false;
	
	protected boolean isSet_processtag()
	{
		return this.isSet_processtag;
	}
	
	protected void setIsSet_processtag(boolean value)
	{
		this.isSet_processtag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="처리구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String processtag  = null;
	
	/**
	 * @Description 처리구분
	 */
	public java.lang.String getProcesstag(){
		return processtag;
	}
	
	/**
	 * @Description 처리구분
	 */
	@JsonProperty("processtag")
	public void setProcesstag( java.lang.String processtag ) {
		isSet_processtag = true;
		this.processtag = processtag;
	}
	
	/** Property set << processtag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << indata >> [[ */
	
	@XmlTransient
	private boolean isSet_indata = false;
	
	protected boolean isSet_indata()
	{
		return this.isSet_indata;
	}
	
	protected void setIsSet_indata(boolean value)
	{
		this.isSet_indata = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임포트데이타", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String indata  = null;
	
	/**
	 * @Description 임포트데이타
	 */
	public java.lang.String getIndata(){
		return indata;
	}
	
	/**
	 * @Description 임포트데이타
	 */
	@JsonProperty("indata")
	public void setIndata( java.lang.String indata ) {
		isSet_indata = true;
		this.indata = indata;
	}
	
	/** Property set << indata >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 변경담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 변경담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 변경일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 변경일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousBanketc01IO clone(){
		try{
			DHDHousBanketc01IO object= (DHDHousBanketc01IO)super.clone();
			if ( this.paymentdate== null ) object.paymentdate = null;
			else{
				object.paymentdate = this.paymentdate;
			}
			if ( this.paymentseq== null ) object.paymentseq = null;
			else{
				object.paymentseq = this.paymentseq;
			}
			if ( this.bankKind== null ) object.bankKind = null;
			else{
				object.bankKind = this.bankKind;
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.depositNo== null ) object.depositNo = null;
			else{
				object.depositNo = this.depositNo;
			}
			if ( this.paymentamt== null ) object.paymentamt = null;
			else{
				object.paymentamt = new java.math.BigDecimal(paymentamt.toString());
			}
			if ( this.canceltag== null ) object.canceltag = null;
			else{
				object.canceltag = this.canceltag;
			}
			if ( this.incometag== null ) object.incometag = null;
			else{
				object.incometag = this.incometag;
			}
			if ( this.processtag== null ) object.processtag = null;
			else{
				object.processtag = this.processtag;
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.indata== null ) object.indata = null;
			else{
				object.indata = this.indata;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((paymentdate==null)?0:paymentdate.hashCode());
		result = prime * result + ((paymentseq==null)?0:paymentseq.hashCode());
		result = prime * result + ((bankKind==null)?0:bankKind.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((depositNo==null)?0:depositNo.hashCode());
		result = prime * result + ((paymentamt==null)?0:paymentamt.hashCode());
		result = prime * result + ((canceltag==null)?0:canceltag.hashCode());
		result = prime * result + ((incometag==null)?0:incometag.hashCode());
		result = prime * result + ((processtag==null)?0:processtag.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((indata==null)?0:indata.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO other = (kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO)obj;
		if ( paymentdate == null ){
			if ( other.paymentdate != null ) return false;
		}
		else if ( !paymentdate.equals(other.paymentdate) )
			return false;
		if ( paymentseq == null ){
			if ( other.paymentseq != null ) return false;
		}
		else if ( !paymentseq.equals(other.paymentseq) )
			return false;
		if ( bankKind == null ){
			if ( other.bankKind != null ) return false;
		}
		else if ( !bankKind.equals(other.bankKind) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( depositNo == null ){
			if ( other.depositNo != null ) return false;
		}
		else if ( !depositNo.equals(other.depositNo) )
			return false;
		if ( paymentamt == null ){
			if ( other.paymentamt != null ) return false;
		}
		else if ( !paymentamt.equals(other.paymentamt) )
			return false;
		if ( canceltag == null ){
			if ( other.canceltag != null ) return false;
		}
		else if ( !canceltag.equals(other.canceltag) )
			return false;
		if ( incometag == null ){
			if ( other.incometag != null ) return false;
		}
		else if ( !incometag.equals(other.incometag) )
			return false;
		if ( processtag == null ){
			if ( other.processtag != null ) return false;
		}
		else if ( !processtag.equals(other.processtag) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( indata == null ){
			if ( other.indata != null ) return false;
		}
		else if ( !indata.equals(other.indata) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO:\n");
		sb.append("\tpaymentdate: ");
		sb.append(paymentdate==null?"null":getPaymentdate());
		sb.append("\n");
		sb.append("\tpaymentseq: ");
		sb.append(paymentseq==null?"null":getPaymentseq());
		sb.append("\n");
		sb.append("\tbankKind: ");
		sb.append(bankKind==null?"null":getBankKind());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tdepositNo: ");
		sb.append(depositNo==null?"null":getDepositNo());
		sb.append("\n");
		sb.append("\tpaymentamt: ");
		sb.append(paymentamt==null?"null":getPaymentamt());
		sb.append("\n");
		sb.append("\tcanceltag: ");
		sb.append(canceltag==null?"null":getCanceltag());
		sb.append("\n");
		sb.append("\tincometag: ");
		sb.append(incometag==null?"null":getIncometag());
		sb.append("\n");
		sb.append("\tprocesstag: ");
		sb.append(processtag==null?"null":getProcesstag());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tindata: ");
		sb.append(indata==null?"null":getIndata());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 8; /* paymentdate */
		messageLen+= 22; /* paymentseq */
		messageLen+= 1; /* bankKind */
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 30; /* depositNo */
		messageLen+= 22; /* paymentamt */
		messageLen+= 1; /* canceltag */
		messageLen+= 1; /* incometag */
		messageLen+= 1; /* processtag */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 100; /* indata */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("paymentdate");
	
		fieldNames.add("paymentseq");
	
		fieldNames.add("bankKind");
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("depositNo");
	
		fieldNames.add("paymentamt");
	
		fieldNames.add("canceltag");
	
		fieldNames.add("incometag");
	
		fieldNames.add("processtag");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("indata");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("paymentdate", get("paymentdate"));
	
		fieldValueMap.put("paymentseq", get("paymentseq"));
	
		fieldValueMap.put("bankKind", get("bankKind"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("depositNo", get("depositNo"));
	
		fieldValueMap.put("paymentamt", get("paymentamt"));
	
		fieldValueMap.put("canceltag", get("canceltag"));
	
		fieldValueMap.put("incometag", get("incometag"));
	
		fieldValueMap.put("processtag", get("processtag"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("indata", get("indata"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -1539920204 : /* paymentdate */
			return getPaymentdate();
		case 1612907673 : /* paymentseq */
			return getPaymentseq();
		case -1859373072 : /* bankKind */
			return getBankKind();
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -818155265 : /* depositNo */
			return getDepositNo();
		case 1612890626 : /* paymentamt */
			return getPaymentamt();
		case 476595936 : /* canceltag */
			return getCanceltag();
		case -1418374831 : /* incometag */
			return getIncometag();
		case 422205131 : /* processtag */
			return getProcesstag();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -1184243121 : /* indata */
			return getIndata();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -1539920204 : /* paymentdate */
			setPaymentdate((java.lang.String) value);
			return;
		case 1612907673 : /* paymentseq */
			setPaymentseq((java.lang.Float) value);
			return;
		case -1859373072 : /* bankKind */
			setBankKind((java.lang.String) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case -818155265 : /* depositNo */
			setDepositNo((java.lang.String) value);
			return;
		case 1612890626 : /* paymentamt */
			setPaymentamt((java.math.BigDecimal) value);
			return;
		case 476595936 : /* canceltag */
			setCanceltag((java.lang.String) value);
			return;
		case -1418374831 : /* incometag */
			setIncometag((java.lang.String) value);
			return;
		case 422205131 : /* processtag */
			setProcesstag((java.lang.String) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -1184243121 : /* indata */
			setIndata((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
