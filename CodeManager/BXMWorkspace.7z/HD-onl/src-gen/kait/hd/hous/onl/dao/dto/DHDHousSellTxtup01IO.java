/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_세대별분양대장_자료올리기 ( HD_HOUS_SELL_TXTUP )
 */
@XmlType(propOrder={"deptCode", "housetag", "seq", "sn", "buildno", "houseno", "custCode", "contdate", "receiptdate", "receiptamt", "contYn", "errMessage", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousSellTxtup01IO")
@XmlRootElement(name="DHDHousSellTxtup01IO")
@SuppressWarnings("all")
public class DHDHousSellTxtup01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1306038741L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_세대별분양대장_자료올리기 ( HD_HOUS_SELL_TXTUP )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012429(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012429(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012429(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012430(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012430(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012430(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 올린횟수 [SYS_C0012431(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 올린횟수 [SYS_C0012431(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 올린횟수 [SYS_C0012431(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="올린횟수 [SYS_C0012431(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 올린횟수 [SYS_C0012431(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 올린횟수 [SYS_C0012431(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sn >> [[ */
	
	@XmlTransient
	private boolean isSet_sn = false;
	
	protected boolean isSet_sn()
	{
		return this.isSet_sn;
	}
	
	protected void setIsSet_sn(boolean value)
	{
		this.isSet_sn = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012432(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public void setSn(java.lang.String value) {
		isSet_sn = true;
		this.sn = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012432(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public void setSn(double value) {
		isSet_sn = true;
		this.sn = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012432(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public void setSn(long value) {
		isSet_sn = true;
		this.sn = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012432(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sn  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012432(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	public java.math.BigDecimal getSn(){
		return sn;
	}
	
	/**
	 * @Description 순번 [SYS_C0012432(C),SYS_C0012956(P) SYS_C0012956(UNIQUE)]
	 */
	@JsonProperty("sn")
	public void setSn( java.math.BigDecimal sn ) {
		isSet_sn = true;
		this.sn = sn;
	}
	
	/** Property set << sn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012433(C)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012433(C)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012433(C)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contdate >> [[ */
	
	@XmlTransient
	private boolean isSet_contdate = false;
	
	protected boolean isSet_contdate()
	{
		return this.isSet_contdate;
	}
	
	protected void setIsSet_contdate(boolean value)
	{
		this.isSet_contdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String contdate  = null;
	
	/**
	 * @Description 계약일자
	 */
	public java.lang.String getContdate(){
		return contdate;
	}
	
	/**
	 * @Description 계약일자
	 */
	@JsonProperty("contdate")
	public void setContdate( java.lang.String contdate ) {
		isSet_contdate = true;
		this.contdate = contdate;
	}
	
	/** Property set << contdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptdate >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptdate = false;
	
	protected boolean isSet_receiptdate()
	{
		return this.isSet_receiptdate;
	}
	
	protected void setIsSet_receiptdate(boolean value)
	{
		this.isSet_receiptdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="납입일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String receiptdate  = null;
	
	/**
	 * @Description 납입일자
	 */
	public java.lang.String getReceiptdate(){
		return receiptdate;
	}
	
	/**
	 * @Description 납입일자
	 */
	@JsonProperty("receiptdate")
	public void setReceiptdate( java.lang.String receiptdate ) {
		isSet_receiptdate = true;
		this.receiptdate = receiptdate;
	}
	
	/** Property set << receiptdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << receiptamt >> [[ */
	
	@XmlTransient
	private boolean isSet_receiptamt = false;
	
	protected boolean isSet_receiptamt()
	{
		return this.isSet_receiptamt;
	}
	
	protected void setIsSet_receiptamt(boolean value)
	{
		this.isSet_receiptamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 납입금
	 */
	public void setReceiptamt(java.lang.String value) {
		isSet_receiptamt = true;
		this.receiptamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 납입금
	 */
	public void setReceiptamt(double value) {
		isSet_receiptamt = true;
		this.receiptamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 납입금
	 */
	public void setReceiptamt(long value) {
		isSet_receiptamt = true;
		this.receiptamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="납입금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal receiptamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 납입금
	 */
	public java.math.BigDecimal getReceiptamt(){
		return receiptamt;
	}
	
	/**
	 * @Description 납입금
	 */
	@JsonProperty("receiptamt")
	public void setReceiptamt( java.math.BigDecimal receiptamt ) {
		isSet_receiptamt = true;
		this.receiptamt = receiptamt;
	}
	
	/** Property set << receiptamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contYn >> [[ */
	
	@XmlTransient
	private boolean isSet_contYn = false;
	
	protected boolean isSet_contYn()
	{
		return this.isSet_contYn;
	}
	
	protected void setIsSet_contYn(boolean value)
	{
		this.isSet_contYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="처리여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String contYn  = null;
	
	/**
	 * @Description 처리여부
	 */
	public java.lang.String getContYn(){
		return contYn;
	}
	
	/**
	 * @Description 처리여부
	 */
	@JsonProperty("contYn")
	public void setContYn( java.lang.String contYn ) {
		isSet_contYn = true;
		this.contYn = contYn;
	}
	
	/** Property set << contYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << errMessage >> [[ */
	
	@XmlTransient
	private boolean isSet_errMessage = false;
	
	protected boolean isSet_errMessage()
	{
		return this.isSet_errMessage;
	}
	
	protected void setIsSet_errMessage(boolean value)
	{
		this.isSet_errMessage = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="오류내용", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String errMessage  = null;
	
	/**
	 * @Description 오류내용
	 */
	public java.lang.String getErrMessage(){
		return errMessage;
	}
	
	/**
	 * @Description 오류내용
	 */
	@JsonProperty("errMessage")
	public void setErrMessage( java.lang.String errMessage ) {
		isSet_errMessage = true;
		this.errMessage = errMessage;
	}
	
	/** Property set << errMessage >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSellTxtup01IO clone(){
		try{
			DHDHousSellTxtup01IO object= (DHDHousSellTxtup01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.sn== null ) object.sn = null;
			else{
				object.sn = new java.math.BigDecimal(sn.toString());
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.contdate== null ) object.contdate = null;
			else{
				object.contdate = this.contdate;
			}
			if ( this.receiptdate== null ) object.receiptdate = null;
			else{
				object.receiptdate = this.receiptdate;
			}
			if ( this.receiptamt== null ) object.receiptamt = null;
			else{
				object.receiptamt = new java.math.BigDecimal(receiptamt.toString());
			}
			if ( this.contYn== null ) object.contYn = null;
			else{
				object.contYn = this.contYn;
			}
			if ( this.errMessage== null ) object.errMessage = null;
			else{
				object.errMessage = this.errMessage;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((sn==null)?0:sn.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((contdate==null)?0:contdate.hashCode());
		result = prime * result + ((receiptdate==null)?0:receiptdate.hashCode());
		result = prime * result + ((receiptamt==null)?0:receiptamt.hashCode());
		result = prime * result + ((contYn==null)?0:contYn.hashCode());
		result = prime * result + ((errMessage==null)?0:errMessage.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( sn == null ){
			if ( other.sn != null ) return false;
		}
		else if ( !sn.equals(other.sn) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( contdate == null ){
			if ( other.contdate != null ) return false;
		}
		else if ( !contdate.equals(other.contdate) )
			return false;
		if ( receiptdate == null ){
			if ( other.receiptdate != null ) return false;
		}
		else if ( !receiptdate.equals(other.receiptdate) )
			return false;
		if ( receiptamt == null ){
			if ( other.receiptamt != null ) return false;
		}
		else if ( !receiptamt.equals(other.receiptamt) )
			return false;
		if ( contYn == null ){
			if ( other.contYn != null ) return false;
		}
		else if ( !contYn.equals(other.contYn) )
			return false;
		if ( errMessage == null ){
			if ( other.errMessage != null ) return false;
		}
		else if ( !errMessage.equals(other.errMessage) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tsn: ");
		sb.append(sn==null?"null":getSn());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tcontdate: ");
		sb.append(contdate==null?"null":getContdate());
		sb.append("\n");
		sb.append("\treceiptdate: ");
		sb.append(receiptdate==null?"null":getReceiptdate());
		sb.append("\n");
		sb.append("\treceiptamt: ");
		sb.append(receiptamt==null?"null":getReceiptamt());
		sb.append("\n");
		sb.append("\tcontYn: ");
		sb.append(contYn==null?"null":getContYn());
		sb.append("\n");
		sb.append("\terrMessage: ");
		sb.append(errMessage==null?"null":getErrMessage());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* sn */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 20; /* custCode */
		messageLen+= 8; /* contdate */
		messageLen+= 8; /* receiptdate */
		messageLen+= 22; /* receiptamt */
		messageLen+= 1; /* contYn */
		messageLen+= 100; /* errMessage */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("seq");
	
		fieldNames.add("sn");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("custCode");
	
		fieldNames.add("contdate");
	
		fieldNames.add("receiptdate");
	
		fieldNames.add("receiptamt");
	
		fieldNames.add("contYn");
	
		fieldNames.add("errMessage");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("sn", get("sn"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("contdate", get("contdate"));
	
		fieldValueMap.put("receiptdate", get("receiptdate"));
	
		fieldValueMap.put("receiptamt", get("receiptamt"));
	
		fieldValueMap.put("contYn", get("contYn"));
	
		fieldValueMap.put("errMessage", get("errMessage"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 113759 : /* seq */
			return getSeq();
		case 3675 : /* sn */
			return getSn();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case 604866272 : /* custCode */
			return getCustCode();
		case -567364128 : /* contdate */
			return getContdate();
		case 2034075110 : /* receiptdate */
			return getReceiptdate();
		case 204160144 : /* receiptamt */
			return getReceiptamt();
		case -1354779161 : /* contYn */
			return getContYn();
		case 1172087522 : /* errMessage */
			return getErrMessage();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 3675 : /* sn */
			setSn((java.math.BigDecimal) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case -567364128 : /* contdate */
			setContdate((java.lang.String) value);
			return;
		case 2034075110 : /* receiptdate */
			setReceiptdate((java.lang.String) value);
			return;
		case 204160144 : /* receiptamt */
			setReceiptamt((java.math.BigDecimal) value);
			return;
		case -1354779161 : /* contYn */
			setContYn((java.lang.String) value);
			return;
		case 1172087522 : /* errMessage */
			setErrMessage((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
