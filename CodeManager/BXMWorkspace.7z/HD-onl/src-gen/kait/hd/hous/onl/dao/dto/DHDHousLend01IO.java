/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_대출약정 ( HD_HOUS_LEND )
 */
@XmlType(propOrder={"custCode", "seq", "cnt", "bankCode", "agreedate", "agreeamt", "lendTag", "lenddate", "perpecttag", "realReceiptamt", "stampAmt", "guaranteeAmt", "lendInterest", "rate", "realDate", "exchangePlandate", "exchangePlanamt", "exchangeDate", "exchangeAmt", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousLend01IO")
@XmlRootElement(name="DHDHousLend01IO")
@SuppressWarnings("all")
public class DHDHousLend01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -329955701L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_대출약정 ( HD_HOUS_LEND )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012263(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012263(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012263(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012264(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012264(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012264(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012264(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012264(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012264(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cnt >> [[ */
	
	@XmlTransient
	private boolean isSet_cnt = false;
	
	protected boolean isSet_cnt()
	{
		return this.isSet_cnt;
	}
	
	protected void setIsSet_cnt(boolean value)
	{
		this.isSet_cnt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012265(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public void setCnt(java.lang.String value) {
		isSet_cnt = true;
		this.cnt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012265(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public void setCnt(double value) {
		isSet_cnt = true;
		this.cnt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012265(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public void setCnt(long value) {
		isSet_cnt = true;
		this.cnt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012265(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal cnt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012265(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	public java.math.BigDecimal getCnt(){
		return cnt;
	}
	
	/**
	 * @Description 순번 [SYS_C0012265(C),SYS_C0012939(P) SYS_C0012939(UNIQUE)]
	 */
	@JsonProperty("cnt")
	public void setCnt( java.math.BigDecimal cnt ) {
		isSet_cnt = true;
		this.cnt = cnt;
	}
	
	/** Property set << cnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankCode >> [[ */
	
	@XmlTransient
	private boolean isSet_bankCode = false;
	
	protected boolean isSet_bankCode()
	{
		return this.isSet_bankCode;
	}
	
	protected void setIsSet_bankCode(boolean value)
	{
		this.isSet_bankCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="금융기관 [SYS_C0012266(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String bankCode  = null;
	
	/**
	 * @Description 금융기관 [SYS_C0012266(C)]
	 */
	public java.lang.String getBankCode(){
		return bankCode;
	}
	
	/**
	 * @Description 금융기관 [SYS_C0012266(C)]
	 */
	@JsonProperty("bankCode")
	public void setBankCode( java.lang.String bankCode ) {
		isSet_bankCode = true;
		this.bankCode = bankCode;
	}
	
	/** Property set << bankCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreedate >> [[ */
	
	@XmlTransient
	private boolean isSet_agreedate = false;
	
	protected boolean isSet_agreedate()
	{
		return this.isSet_agreedate;
	}
	
	protected void setIsSet_agreedate(boolean value)
	{
		this.isSet_agreedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String agreedate  = null;
	
	/**
	 * @Description 대출일자
	 */
	public java.lang.String getAgreedate(){
		return agreedate;
	}
	
	/**
	 * @Description 대출일자
	 */
	@JsonProperty("agreedate")
	public void setAgreedate( java.lang.String agreedate ) {
		isSet_agreedate = true;
		this.agreedate = agreedate;
	}
	
	/** Property set << agreedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << agreeamt >> [[ */
	
	@XmlTransient
	private boolean isSet_agreeamt = false;
	
	protected boolean isSet_agreeamt()
	{
		return this.isSet_agreeamt;
	}
	
	protected void setIsSet_agreeamt(boolean value)
	{
		this.isSet_agreeamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 대출금액
	 */
	public void setAgreeamt(java.lang.String value) {
		isSet_agreeamt = true;
		this.agreeamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 대출금액
	 */
	public void setAgreeamt(double value) {
		isSet_agreeamt = true;
		this.agreeamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 대출금액
	 */
	public void setAgreeamt(long value) {
		isSet_agreeamt = true;
		this.agreeamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="대출금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal agreeamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 대출금액
	 */
	public java.math.BigDecimal getAgreeamt(){
		return agreeamt;
	}
	
	/**
	 * @Description 대출금액
	 */
	@JsonProperty("agreeamt")
	public void setAgreeamt( java.math.BigDecimal agreeamt ) {
		isSet_agreeamt = true;
		this.agreeamt = agreeamt;
	}
	
	/** Property set << agreeamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << lendTag >> [[ */
	
	@XmlTransient
	private boolean isSet_lendTag = false;
	
	protected boolean isSet_lendTag()
	{
		return this.isSet_lendTag;
	}
	
	protected void setIsSet_lendTag(boolean value)
	{
		this.isSet_lendTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String lendTag  = null;
	
	/**
	 * @Description 대출구분
	 */
	public java.lang.String getLendTag(){
		return lendTag;
	}
	
	/**
	 * @Description 대출구분
	 */
	@JsonProperty("lendTag")
	public void setLendTag( java.lang.String lendTag ) {
		isSet_lendTag = true;
		this.lendTag = lendTag;
	}
	
	/** Property set << lendTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << lenddate >> [[ */
	
	@XmlTransient
	private boolean isSet_lenddate = false;
	
	protected boolean isSet_lenddate()
	{
		return this.isSet_lenddate;
	}
	
	protected void setIsSet_lenddate(boolean value)
	{
		this.isSet_lenddate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출일(이하항목관리x)", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String lenddate  = null;
	
	/**
	 * @Description 대출일(이하항목관리x)
	 */
	public java.lang.String getLenddate(){
		return lenddate;
	}
	
	/**
	 * @Description 대출일(이하항목관리x)
	 */
	@JsonProperty("lenddate")
	public void setLenddate( java.lang.String lenddate ) {
		isSet_lenddate = true;
		this.lenddate = lenddate;
	}
	
	/** Property set << lenddate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << perpecttag >> [[ */
	
	@XmlTransient
	private boolean isSet_perpecttag = false;
	
	protected boolean isSet_perpecttag()
	{
		return this.isSet_perpecttag;
	}
	
	protected void setIsSet_perpecttag(boolean value)
	{
		this.isSet_perpecttag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상환여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String perpecttag  = null;
	
	/**
	 * @Description 상환여부
	 */
	public java.lang.String getPerpecttag(){
		return perpecttag;
	}
	
	/**
	 * @Description 상환여부
	 */
	@JsonProperty("perpecttag")
	public void setPerpecttag( java.lang.String perpecttag ) {
		isSet_perpecttag = true;
		this.perpecttag = perpecttag;
	}
	
	/** Property set << perpecttag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realReceiptamt >> [[ */
	
	@XmlTransient
	private boolean isSet_realReceiptamt = false;
	
	protected boolean isSet_realReceiptamt()
	{
		return this.isSet_realReceiptamt;
	}
	
	protected void setIsSet_realReceiptamt(boolean value)
	{
		this.isSet_realReceiptamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 실입금액
	 */
	public void setRealReceiptamt(java.lang.String value) {
		isSet_realReceiptamt = true;
		this.realReceiptamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 실입금액
	 */
	public void setRealReceiptamt(double value) {
		isSet_realReceiptamt = true;
		this.realReceiptamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 실입금액
	 */
	public void setRealReceiptamt(long value) {
		isSet_realReceiptamt = true;
		this.realReceiptamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="실입금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal realReceiptamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 실입금액
	 */
	public java.math.BigDecimal getRealReceiptamt(){
		return realReceiptamt;
	}
	
	/**
	 * @Description 실입금액
	 */
	@JsonProperty("realReceiptamt")
	public void setRealReceiptamt( java.math.BigDecimal realReceiptamt ) {
		isSet_realReceiptamt = true;
		this.realReceiptamt = realReceiptamt;
	}
	
	/** Property set << realReceiptamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << stampAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_stampAmt = false;
	
	protected boolean isSet_stampAmt()
	{
		return this.isSet_stampAmt;
	}
	
	protected void setIsSet_stampAmt(boolean value)
	{
		this.isSet_stampAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 인지대
	 */
	public void setStampAmt(java.lang.String value) {
		isSet_stampAmt = true;
		this.stampAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 인지대
	 */
	public void setStampAmt(double value) {
		isSet_stampAmt = true;
		this.stampAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 인지대
	 */
	public void setStampAmt(long value) {
		isSet_stampAmt = true;
		this.stampAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="인지대", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal stampAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 인지대
	 */
	public java.math.BigDecimal getStampAmt(){
		return stampAmt;
	}
	
	/**
	 * @Description 인지대
	 */
	@JsonProperty("stampAmt")
	public void setStampAmt( java.math.BigDecimal stampAmt ) {
		isSet_stampAmt = true;
		this.stampAmt = stampAmt;
	}
	
	/** Property set << stampAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << guaranteeAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_guaranteeAmt = false;
	
	protected boolean isSet_guaranteeAmt()
	{
		return this.isSet_guaranteeAmt;
	}
	
	protected void setIsSet_guaranteeAmt(boolean value)
	{
		this.isSet_guaranteeAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 보증료
	 */
	public void setGuaranteeAmt(java.lang.String value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 보증료
	 */
	public void setGuaranteeAmt(double value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 보증료
	 */
	public void setGuaranteeAmt(long value) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="보증료", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal guaranteeAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 보증료
	 */
	public java.math.BigDecimal getGuaranteeAmt(){
		return guaranteeAmt;
	}
	
	/**
	 * @Description 보증료
	 */
	@JsonProperty("guaranteeAmt")
	public void setGuaranteeAmt( java.math.BigDecimal guaranteeAmt ) {
		isSet_guaranteeAmt = true;
		this.guaranteeAmt = guaranteeAmt;
	}
	
	/** Property set << guaranteeAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << lendInterest >> [[ */
	
	@XmlTransient
	private boolean isSet_lendInterest = false;
	
	protected boolean isSet_lendInterest()
	{
		return this.isSet_lendInterest;
	}
	
	protected void setIsSet_lendInterest(boolean value)
	{
		this.isSet_lendInterest = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 이자
	 */
	public void setLendInterest(java.lang.String value) {
		isSet_lendInterest = true;
		this.lendInterest = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 이자
	 */
	public void setLendInterest(double value) {
		isSet_lendInterest = true;
		this.lendInterest = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 이자
	 */
	public void setLendInterest(long value) {
		isSet_lendInterest = true;
		this.lendInterest = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="이자", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal lendInterest  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 이자
	 */
	public java.math.BigDecimal getLendInterest(){
		return lendInterest;
	}
	
	/**
	 * @Description 이자
	 */
	@JsonProperty("lendInterest")
	public void setLendInterest( java.math.BigDecimal lendInterest ) {
		isSet_lendInterest = true;
		this.lendInterest = lendInterest;
	}
	
	/** Property set << lendInterest >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << rate >> [[ */
	
	@XmlTransient
	private boolean isSet_rate = false;
	
	protected boolean isSet_rate()
	{
		return this.isSet_rate;
	}
	
	protected void setIsSet_rate(boolean value)
	{
		this.isSet_rate = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 이율
	 */
	public void setRate(java.lang.String value) {
		isSet_rate = true;
		this.rate = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 이율
	 */
	public void setRate(double value) {
		isSet_rate = true;
		this.rate = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 이율
	 */
	public void setRate(long value) {
		isSet_rate = true;
		this.rate = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="이율", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal rate  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 이율
	 */
	public java.math.BigDecimal getRate(){
		return rate;
	}
	
	/**
	 * @Description 이율
	 */
	@JsonProperty("rate")
	public void setRate( java.math.BigDecimal rate ) {
		isSet_rate = true;
		this.rate = rate;
	}
	
	/** Property set << rate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << realDate >> [[ */
	
	@XmlTransient
	private boolean isSet_realDate = false;
	
	protected boolean isSet_realDate()
	{
		return this.isSet_realDate;
	}
	
	protected void setIsSet_realDate(boolean value)
	{
		this.isSet_realDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="실납입일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String realDate  = null;
	
	/**
	 * @Description 실납입일자
	 */
	public java.lang.String getRealDate(){
		return realDate;
	}
	
	/**
	 * @Description 실납입일자
	 */
	@JsonProperty("realDate")
	public void setRealDate( java.lang.String realDate ) {
		isSet_realDate = true;
		this.realDate = realDate;
	}
	
	/** Property set << realDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exchangePlandate >> [[ */
	
	@XmlTransient
	private boolean isSet_exchangePlandate = false;
	
	protected boolean isSet_exchangePlandate()
	{
		return this.isSet_exchangePlandate;
	}
	
	protected void setIsSet_exchangePlandate(boolean value)
	{
		this.isSet_exchangePlandate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상환예정일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String exchangePlandate  = null;
	
	/**
	 * @Description 상환예정일
	 */
	public java.lang.String getExchangePlandate(){
		return exchangePlandate;
	}
	
	/**
	 * @Description 상환예정일
	 */
	@JsonProperty("exchangePlandate")
	public void setExchangePlandate( java.lang.String exchangePlandate ) {
		isSet_exchangePlandate = true;
		this.exchangePlandate = exchangePlandate;
	}
	
	/** Property set << exchangePlandate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exchangePlanamt >> [[ */
	
	@XmlTransient
	private boolean isSet_exchangePlanamt = false;
	
	protected boolean isSet_exchangePlanamt()
	{
		return this.isSet_exchangePlanamt;
	}
	
	protected void setIsSet_exchangePlanamt(boolean value)
	{
		this.isSet_exchangePlanamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 상환예정금액
	 */
	public void setExchangePlanamt(java.lang.String value) {
		isSet_exchangePlanamt = true;
		this.exchangePlanamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 상환예정금액
	 */
	public void setExchangePlanamt(double value) {
		isSet_exchangePlanamt = true;
		this.exchangePlanamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 상환예정금액
	 */
	public void setExchangePlanamt(long value) {
		isSet_exchangePlanamt = true;
		this.exchangePlanamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="상환예정금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal exchangePlanamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 상환예정금액
	 */
	public java.math.BigDecimal getExchangePlanamt(){
		return exchangePlanamt;
	}
	
	/**
	 * @Description 상환예정금액
	 */
	@JsonProperty("exchangePlanamt")
	public void setExchangePlanamt( java.math.BigDecimal exchangePlanamt ) {
		isSet_exchangePlanamt = true;
		this.exchangePlanamt = exchangePlanamt;
	}
	
	/** Property set << exchangePlanamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exchangeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_exchangeDate = false;
	
	protected boolean isSet_exchangeDate()
	{
		return this.isSet_exchangeDate;
	}
	
	protected void setIsSet_exchangeDate(boolean value)
	{
		this.isSet_exchangeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상환일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String exchangeDate  = null;
	
	/**
	 * @Description 상환일
	 */
	public java.lang.String getExchangeDate(){
		return exchangeDate;
	}
	
	/**
	 * @Description 상환일
	 */
	@JsonProperty("exchangeDate")
	public void setExchangeDate( java.lang.String exchangeDate ) {
		isSet_exchangeDate = true;
		this.exchangeDate = exchangeDate;
	}
	
	/** Property set << exchangeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exchangeAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_exchangeAmt = false;
	
	protected boolean isSet_exchangeAmt()
	{
		return this.isSet_exchangeAmt;
	}
	
	protected void setIsSet_exchangeAmt(boolean value)
	{
		this.isSet_exchangeAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 상환금액
	 */
	public void setExchangeAmt(java.lang.String value) {
		isSet_exchangeAmt = true;
		this.exchangeAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 상환금액
	 */
	public void setExchangeAmt(double value) {
		isSet_exchangeAmt = true;
		this.exchangeAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 상환금액
	 */
	public void setExchangeAmt(long value) {
		isSet_exchangeAmt = true;
		this.exchangeAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="상환금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal exchangeAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 상환금액
	 */
	public java.math.BigDecimal getExchangeAmt(){
		return exchangeAmt;
	}
	
	/**
	 * @Description 상환금액
	 */
	@JsonProperty("exchangeAmt")
	public void setExchangeAmt( java.math.BigDecimal exchangeAmt ) {
		isSet_exchangeAmt = true;
		this.exchangeAmt = exchangeAmt;
	}
	
	/** Property set << exchangeAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousLend01IO clone(){
		try{
			DHDHousLend01IO object= (DHDHousLend01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.cnt== null ) object.cnt = null;
			else{
				object.cnt = new java.math.BigDecimal(cnt.toString());
			}
			if ( this.bankCode== null ) object.bankCode = null;
			else{
				object.bankCode = this.bankCode;
			}
			if ( this.agreedate== null ) object.agreedate = null;
			else{
				object.agreedate = this.agreedate;
			}
			if ( this.agreeamt== null ) object.agreeamt = null;
			else{
				object.agreeamt = new java.math.BigDecimal(agreeamt.toString());
			}
			if ( this.lendTag== null ) object.lendTag = null;
			else{
				object.lendTag = this.lendTag;
			}
			if ( this.lenddate== null ) object.lenddate = null;
			else{
				object.lenddate = this.lenddate;
			}
			if ( this.perpecttag== null ) object.perpecttag = null;
			else{
				object.perpecttag = this.perpecttag;
			}
			if ( this.realReceiptamt== null ) object.realReceiptamt = null;
			else{
				object.realReceiptamt = new java.math.BigDecimal(realReceiptamt.toString());
			}
			if ( this.stampAmt== null ) object.stampAmt = null;
			else{
				object.stampAmt = new java.math.BigDecimal(stampAmt.toString());
			}
			if ( this.guaranteeAmt== null ) object.guaranteeAmt = null;
			else{
				object.guaranteeAmt = new java.math.BigDecimal(guaranteeAmt.toString());
			}
			if ( this.lendInterest== null ) object.lendInterest = null;
			else{
				object.lendInterest = new java.math.BigDecimal(lendInterest.toString());
			}
			if ( this.rate== null ) object.rate = null;
			else{
				object.rate = new java.math.BigDecimal(rate.toString());
			}
			if ( this.realDate== null ) object.realDate = null;
			else{
				object.realDate = this.realDate;
			}
			if ( this.exchangePlandate== null ) object.exchangePlandate = null;
			else{
				object.exchangePlandate = this.exchangePlandate;
			}
			if ( this.exchangePlanamt== null ) object.exchangePlanamt = null;
			else{
				object.exchangePlanamt = new java.math.BigDecimal(exchangePlanamt.toString());
			}
			if ( this.exchangeDate== null ) object.exchangeDate = null;
			else{
				object.exchangeDate = this.exchangeDate;
			}
			if ( this.exchangeAmt== null ) object.exchangeAmt = null;
			else{
				object.exchangeAmt = new java.math.BigDecimal(exchangeAmt.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((cnt==null)?0:cnt.hashCode());
		result = prime * result + ((bankCode==null)?0:bankCode.hashCode());
		result = prime * result + ((agreedate==null)?0:agreedate.hashCode());
		result = prime * result + ((agreeamt==null)?0:agreeamt.hashCode());
		result = prime * result + ((lendTag==null)?0:lendTag.hashCode());
		result = prime * result + ((lenddate==null)?0:lenddate.hashCode());
		result = prime * result + ((perpecttag==null)?0:perpecttag.hashCode());
		result = prime * result + ((realReceiptamt==null)?0:realReceiptamt.hashCode());
		result = prime * result + ((stampAmt==null)?0:stampAmt.hashCode());
		result = prime * result + ((guaranteeAmt==null)?0:guaranteeAmt.hashCode());
		result = prime * result + ((lendInterest==null)?0:lendInterest.hashCode());
		result = prime * result + ((rate==null)?0:rate.hashCode());
		result = prime * result + ((realDate==null)?0:realDate.hashCode());
		result = prime * result + ((exchangePlandate==null)?0:exchangePlandate.hashCode());
		result = prime * result + ((exchangePlanamt==null)?0:exchangePlanamt.hashCode());
		result = prime * result + ((exchangeDate==null)?0:exchangeDate.hashCode());
		result = prime * result + ((exchangeAmt==null)?0:exchangeAmt.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousLend01IO other = (kait.hd.hous.onl.dao.dto.DHDHousLend01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( cnt == null ){
			if ( other.cnt != null ) return false;
		}
		else if ( !cnt.equals(other.cnt) )
			return false;
		if ( bankCode == null ){
			if ( other.bankCode != null ) return false;
		}
		else if ( !bankCode.equals(other.bankCode) )
			return false;
		if ( agreedate == null ){
			if ( other.agreedate != null ) return false;
		}
		else if ( !agreedate.equals(other.agreedate) )
			return false;
		if ( agreeamt == null ){
			if ( other.agreeamt != null ) return false;
		}
		else if ( !agreeamt.equals(other.agreeamt) )
			return false;
		if ( lendTag == null ){
			if ( other.lendTag != null ) return false;
		}
		else if ( !lendTag.equals(other.lendTag) )
			return false;
		if ( lenddate == null ){
			if ( other.lenddate != null ) return false;
		}
		else if ( !lenddate.equals(other.lenddate) )
			return false;
		if ( perpecttag == null ){
			if ( other.perpecttag != null ) return false;
		}
		else if ( !perpecttag.equals(other.perpecttag) )
			return false;
		if ( realReceiptamt == null ){
			if ( other.realReceiptamt != null ) return false;
		}
		else if ( !realReceiptamt.equals(other.realReceiptamt) )
			return false;
		if ( stampAmt == null ){
			if ( other.stampAmt != null ) return false;
		}
		else if ( !stampAmt.equals(other.stampAmt) )
			return false;
		if ( guaranteeAmt == null ){
			if ( other.guaranteeAmt != null ) return false;
		}
		else if ( !guaranteeAmt.equals(other.guaranteeAmt) )
			return false;
		if ( lendInterest == null ){
			if ( other.lendInterest != null ) return false;
		}
		else if ( !lendInterest.equals(other.lendInterest) )
			return false;
		if ( rate == null ){
			if ( other.rate != null ) return false;
		}
		else if ( !rate.equals(other.rate) )
			return false;
		if ( realDate == null ){
			if ( other.realDate != null ) return false;
		}
		else if ( !realDate.equals(other.realDate) )
			return false;
		if ( exchangePlandate == null ){
			if ( other.exchangePlandate != null ) return false;
		}
		else if ( !exchangePlandate.equals(other.exchangePlandate) )
			return false;
		if ( exchangePlanamt == null ){
			if ( other.exchangePlanamt != null ) return false;
		}
		else if ( !exchangePlanamt.equals(other.exchangePlanamt) )
			return false;
		if ( exchangeDate == null ){
			if ( other.exchangeDate != null ) return false;
		}
		else if ( !exchangeDate.equals(other.exchangeDate) )
			return false;
		if ( exchangeAmt == null ){
			if ( other.exchangeAmt != null ) return false;
		}
		else if ( !exchangeAmt.equals(other.exchangeAmt) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousLend01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tcnt: ");
		sb.append(cnt==null?"null":getCnt());
		sb.append("\n");
		sb.append("\tbankCode: ");
		sb.append(bankCode==null?"null":getBankCode());
		sb.append("\n");
		sb.append("\tagreedate: ");
		sb.append(agreedate==null?"null":getAgreedate());
		sb.append("\n");
		sb.append("\tagreeamt: ");
		sb.append(agreeamt==null?"null":getAgreeamt());
		sb.append("\n");
		sb.append("\tlendTag: ");
		sb.append(lendTag==null?"null":getLendTag());
		sb.append("\n");
		sb.append("\tlenddate: ");
		sb.append(lenddate==null?"null":getLenddate());
		sb.append("\n");
		sb.append("\tperpecttag: ");
		sb.append(perpecttag==null?"null":getPerpecttag());
		sb.append("\n");
		sb.append("\trealReceiptamt: ");
		sb.append(realReceiptamt==null?"null":getRealReceiptamt());
		sb.append("\n");
		sb.append("\tstampAmt: ");
		sb.append(stampAmt==null?"null":getStampAmt());
		sb.append("\n");
		sb.append("\tguaranteeAmt: ");
		sb.append(guaranteeAmt==null?"null":getGuaranteeAmt());
		sb.append("\n");
		sb.append("\tlendInterest: ");
		sb.append(lendInterest==null?"null":getLendInterest());
		sb.append("\n");
		sb.append("\trate: ");
		sb.append(rate==null?"null":getRate());
		sb.append("\n");
		sb.append("\trealDate: ");
		sb.append(realDate==null?"null":getRealDate());
		sb.append("\n");
		sb.append("\texchangePlandate: ");
		sb.append(exchangePlandate==null?"null":getExchangePlandate());
		sb.append("\n");
		sb.append("\texchangePlanamt: ");
		sb.append(exchangePlanamt==null?"null":getExchangePlanamt());
		sb.append("\n");
		sb.append("\texchangeDate: ");
		sb.append(exchangeDate==null?"null":getExchangeDate());
		sb.append("\n");
		sb.append("\texchangeAmt: ");
		sb.append(exchangeAmt==null?"null":getExchangeAmt());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* cnt */
		messageLen+= 8; /* bankCode */
		messageLen+= 8; /* agreedate */
		messageLen+= 22; /* agreeamt */
		messageLen+= 1; /* lendTag */
		messageLen+= 8; /* lenddate */
		messageLen+= 1; /* perpecttag */
		messageLen+= 22; /* realReceiptamt */
		messageLen+= 22; /* stampAmt */
		messageLen+= 22; /* guaranteeAmt */
		messageLen+= 22; /* lendInterest */
		messageLen+= 22; /* rate */
		messageLen+= 8; /* realDate */
		messageLen+= 8; /* exchangePlandate */
		messageLen+= 22; /* exchangePlanamt */
		messageLen+= 8; /* exchangeDate */
		messageLen+= 22; /* exchangeAmt */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("cnt");
	
		fieldNames.add("bankCode");
	
		fieldNames.add("agreedate");
	
		fieldNames.add("agreeamt");
	
		fieldNames.add("lendTag");
	
		fieldNames.add("lenddate");
	
		fieldNames.add("perpecttag");
	
		fieldNames.add("realReceiptamt");
	
		fieldNames.add("stampAmt");
	
		fieldNames.add("guaranteeAmt");
	
		fieldNames.add("lendInterest");
	
		fieldNames.add("rate");
	
		fieldNames.add("realDate");
	
		fieldNames.add("exchangePlandate");
	
		fieldNames.add("exchangePlanamt");
	
		fieldNames.add("exchangeDate");
	
		fieldNames.add("exchangeAmt");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("cnt", get("cnt"));
	
		fieldValueMap.put("bankCode", get("bankCode"));
	
		fieldValueMap.put("agreedate", get("agreedate"));
	
		fieldValueMap.put("agreeamt", get("agreeamt"));
	
		fieldValueMap.put("lendTag", get("lendTag"));
	
		fieldValueMap.put("lenddate", get("lenddate"));
	
		fieldValueMap.put("perpecttag", get("perpecttag"));
	
		fieldValueMap.put("realReceiptamt", get("realReceiptamt"));
	
		fieldValueMap.put("stampAmt", get("stampAmt"));
	
		fieldValueMap.put("guaranteeAmt", get("guaranteeAmt"));
	
		fieldValueMap.put("lendInterest", get("lendInterest"));
	
		fieldValueMap.put("rate", get("rate"));
	
		fieldValueMap.put("realDate", get("realDate"));
	
		fieldValueMap.put("exchangePlandate", get("exchangePlandate"));
	
		fieldValueMap.put("exchangePlanamt", get("exchangePlanamt"));
	
		fieldValueMap.put("exchangeDate", get("exchangeDate"));
	
		fieldValueMap.put("exchangeAmt", get("exchangeAmt"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 98665 : /* cnt */
			return getCnt();
		case -1859605943 : /* bankCode */
			return getBankCode();
		case 975514714 : /* agreedate */
			return getAgreedate();
		case 1832581020 : /* agreeamt */
			return getAgreeamt();
		case 62344235 : /* lendTag */
			return getLendTag();
		case 1933148445 : /* lenddate */
			return getLenddate();
		case 2015639799 : /* perpecttag */
			return getPerpecttag();
		case -331512626 : /* realReceiptamt */
			return getRealReceiptamt();
		case 1312031493 : /* stampAmt */
			return getStampAmt();
		case -1640212960 : /* guaranteeAmt */
			return getGuaranteeAmt();
		case 89148729 : /* lendInterest */
			return getLendInterest();
		case 3493088 : /* rate */
			return getRate();
		case -860635540 : /* realDate */
			return getRealDate();
		case 2076761498 : /* exchangePlandate */
			return getExchangePlandate();
		case -71557540 : /* exchangePlanamt */
			return getExchangePlanamt();
		case 1429219441 : /* exchangeDate */
			return getExchangeDate();
		case -1755013979 : /* exchangeAmt */
			return getExchangeAmt();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 98665 : /* cnt */
			setCnt((java.math.BigDecimal) value);
			return;
		case -1859605943 : /* bankCode */
			setBankCode((java.lang.String) value);
			return;
		case 975514714 : /* agreedate */
			setAgreedate((java.lang.String) value);
			return;
		case 1832581020 : /* agreeamt */
			setAgreeamt((java.math.BigDecimal) value);
			return;
		case 62344235 : /* lendTag */
			setLendTag((java.lang.String) value);
			return;
		case 1933148445 : /* lenddate */
			setLenddate((java.lang.String) value);
			return;
		case 2015639799 : /* perpecttag */
			setPerpecttag((java.lang.String) value);
			return;
		case -331512626 : /* realReceiptamt */
			setRealReceiptamt((java.math.BigDecimal) value);
			return;
		case 1312031493 : /* stampAmt */
			setStampAmt((java.math.BigDecimal) value);
			return;
		case -1640212960 : /* guaranteeAmt */
			setGuaranteeAmt((java.math.BigDecimal) value);
			return;
		case 89148729 : /* lendInterest */
			setLendInterest((java.math.BigDecimal) value);
			return;
		case 3493088 : /* rate */
			setRate((java.math.BigDecimal) value);
			return;
		case -860635540 : /* realDate */
			setRealDate((java.lang.String) value);
			return;
		case 2076761498 : /* exchangePlandate */
			setExchangePlandate((java.lang.String) value);
			return;
		case -71557540 : /* exchangePlanamt */
			setExchangePlanamt((java.math.BigDecimal) value);
			return;
		case 1429219441 : /* exchangeDate */
			setExchangeDate((java.lang.String) value);
			return;
		case -1755013979 : /* exchangeAmt */
			setExchangeAmt((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
