/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_세대별연체이율 ( HD_HOUS_RATE_DELAY )
 */
@XmlType(propOrder={"custCode", "seq", "startDays", "endDays", "startdate", "enddate", "delayrate", "delaycut", "delayunit", "startTag", "endTag", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousRateDelay01IO")
@XmlRootElement(name="DHDHousRateDelay01IO")
@SuppressWarnings("all")
public class DHDHousRateDelay01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -617604907L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_세대별연체이율 ( HD_HOUS_RATE_DELAY )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012277(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012277(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012277(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012278(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012278(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012278(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012278(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012278(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012278(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << startDays >> [[ */
	
	@XmlTransient
	private boolean isSet_startDays = false;
	
	protected boolean isSet_startDays()
	{
		return this.isSet_startDays;
	}
	
	protected void setIsSet_startDays(boolean value)
	{
		this.isSet_startDays = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 시작일수 [SYS_C0012279(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setStartDays(java.lang.String value) {
		isSet_startDays = true;
		this.startDays = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 시작일수 [SYS_C0012279(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setStartDays(double value) {
		isSet_startDays = true;
		this.startDays = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 시작일수 [SYS_C0012279(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setStartDays(long value) {
		isSet_startDays = true;
		this.startDays = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="시작일수 [SYS_C0012279(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal startDays  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 시작일수 [SYS_C0012279(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public java.math.BigDecimal getStartDays(){
		return startDays;
	}
	
	/**
	 * @Description 시작일수 [SYS_C0012279(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	@JsonProperty("startDays")
	public void setStartDays( java.math.BigDecimal startDays ) {
		isSet_startDays = true;
		this.startDays = startDays;
	}
	
	/** Property set << startDays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endDays >> [[ */
	
	@XmlTransient
	private boolean isSet_endDays = false;
	
	protected boolean isSet_endDays()
	{
		return this.isSet_endDays;
	}
	
	protected void setIsSet_endDays(boolean value)
	{
		this.isSet_endDays = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 종료일수 [SYS_C0012280(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setEndDays(java.lang.String value) {
		isSet_endDays = true;
		this.endDays = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 종료일수 [SYS_C0012280(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setEndDays(double value) {
		isSet_endDays = true;
		this.endDays = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 종료일수 [SYS_C0012280(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public void setEndDays(long value) {
		isSet_endDays = true;
		this.endDays = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="종료일수 [SYS_C0012280(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal endDays  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 종료일수 [SYS_C0012280(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public java.math.BigDecimal getEndDays(){
		return endDays;
	}
	
	/**
	 * @Description 종료일수 [SYS_C0012280(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	@JsonProperty("endDays")
	public void setEndDays( java.math.BigDecimal endDays ) {
		isSet_endDays = true;
		this.endDays = endDays;
	}
	
	/** Property set << endDays >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << startdate >> [[ */
	
	@XmlTransient
	private boolean isSet_startdate = false;
	
	protected boolean isSet_startdate()
	{
		return this.isSet_startdate;
	}
	
	protected void setIsSet_startdate(boolean value)
	{
		this.isSet_startdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시작일자 [SYS_C0012281(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String startdate  = null;
	
	/**
	 * @Description 시작일자 [SYS_C0012281(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	public java.lang.String getStartdate(){
		return startdate;
	}
	
	/**
	 * @Description 시작일자 [SYS_C0012281(C),SYS_C0012943(P) SYS_C0012943(UNIQUE)]
	 */
	@JsonProperty("startdate")
	public void setStartdate( java.lang.String startdate ) {
		isSet_startdate = true;
		this.startdate = startdate;
	}
	
	/** Property set << startdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << enddate >> [[ */
	
	@XmlTransient
	private boolean isSet_enddate = false;
	
	protected boolean isSet_enddate()
	{
		return this.isSet_enddate;
	}
	
	protected void setIsSet_enddate(boolean value)
	{
		this.isSet_enddate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="종료일자 [SYS_C0012282(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String enddate  = null;
	
	/**
	 * @Description 종료일자 [SYS_C0012282(C)]
	 */
	public java.lang.String getEnddate(){
		return enddate;
	}
	
	/**
	 * @Description 종료일자 [SYS_C0012282(C)]
	 */
	@JsonProperty("enddate")
	public void setEnddate( java.lang.String enddate ) {
		isSet_enddate = true;
		this.enddate = enddate;
	}
	
	/** Property set << enddate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayrate >> [[ */
	
	@XmlTransient
	private boolean isSet_delayrate = false;
	
	protected boolean isSet_delayrate()
	{
		return this.isSet_delayrate;
	}
	
	protected void setIsSet_delayrate(boolean value)
	{
		this.isSet_delayrate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체율 [SYS_C0012283(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.lang.Float delayrate  = .0F;
	
	/**
	 * @Description 연체율 [SYS_C0012283(C)]
	 */
	public java.lang.Float getDelayrate(){
		return delayrate;
	}
	
	/**
	 * @Description 연체율 [SYS_C0012283(C)]
	 */
	@JsonProperty("delayrate")
	public void setDelayrate( java.lang.Float delayrate ) {
		isSet_delayrate = true;
		this.delayrate = delayrate;
	}
	
	/** Property set << delayrate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delaycut >> [[ */
	
	@XmlTransient
	private boolean isSet_delaycut = false;
	
	protected boolean isSet_delaycut()
	{
		return this.isSet_delaycut;
	}
	
	protected void setIsSet_delaycut(boolean value)
	{
		this.isSet_delaycut = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체절사기준 [SYS_C0012284(C)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String delaycut  = null;
	
	/**
	 * @Description 연체절사기준 [SYS_C0012284(C)]
	 */
	public java.lang.String getDelaycut(){
		return delaycut;
	}
	
	/**
	 * @Description 연체절사기준 [SYS_C0012284(C)]
	 */
	@JsonProperty("delaycut")
	public void setDelaycut( java.lang.String delaycut ) {
		isSet_delaycut = true;
		this.delaycut = delaycut;
	}
	
	/** Property set << delaycut >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayunit >> [[ */
	
	@XmlTransient
	private boolean isSet_delayunit = false;
	
	protected boolean isSet_delayunit()
	{
		return this.isSet_delayunit;
	}
	
	protected void setIsSet_delayunit(boolean value)
	{
		this.isSet_delayunit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체절사단위 [SYS_C0012285(C)]", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String delayunit  = null;
	
	/**
	 * @Description 연체절사단위 [SYS_C0012285(C)]
	 */
	public java.lang.String getDelayunit(){
		return delayunit;
	}
	
	/**
	 * @Description 연체절사단위 [SYS_C0012285(C)]
	 */
	@JsonProperty("delayunit")
	public void setDelayunit( java.lang.String delayunit ) {
		isSet_delayunit = true;
		this.delayunit = delayunit;
	}
	
	/** Property set << delayunit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << startTag >> [[ */
	
	@XmlTransient
	private boolean isSet_startTag = false;
	
	protected boolean isSet_startTag()
	{
		return this.isSet_startTag;
	}
	
	protected void setIsSet_startTag(boolean value)
	{
		this.isSet_startTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="시작일수_포함구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String startTag  = null;
	
	/**
	 * @Description 시작일수_포함구분
	 */
	public java.lang.String getStartTag(){
		return startTag;
	}
	
	/**
	 * @Description 시작일수_포함구분
	 */
	@JsonProperty("startTag")
	public void setStartTag( java.lang.String startTag ) {
		isSet_startTag = true;
		this.startTag = startTag;
	}
	
	/** Property set << startTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endTag >> [[ */
	
	@XmlTransient
	private boolean isSet_endTag = false;
	
	protected boolean isSet_endTag()
	{
		return this.isSet_endTag;
	}
	
	protected void setIsSet_endTag(boolean value)
	{
		this.isSet_endTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="종료일수_포함구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String endTag  = null;
	
	/**
	 * @Description 종료일수_포함구분
	 */
	public java.lang.String getEndTag(){
		return endTag;
	}
	
	/**
	 * @Description 종료일수_포함구분
	 */
	@JsonProperty("endTag")
	public void setEndTag( java.lang.String endTag ) {
		isSet_endTag = true;
		this.endTag = endTag;
	}
	
	/** Property set << endTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousRateDelay01IO clone(){
		try{
			DHDHousRateDelay01IO object= (DHDHousRateDelay01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.startDays== null ) object.startDays = null;
			else{
				object.startDays = new java.math.BigDecimal(startDays.toString());
			}
			if ( this.endDays== null ) object.endDays = null;
			else{
				object.endDays = new java.math.BigDecimal(endDays.toString());
			}
			if ( this.startdate== null ) object.startdate = null;
			else{
				object.startdate = this.startdate;
			}
			if ( this.enddate== null ) object.enddate = null;
			else{
				object.enddate = this.enddate;
			}
			if ( this.delayrate== null ) object.delayrate = null;
			else{
				object.delayrate = this.delayrate;
			}
			if ( this.delaycut== null ) object.delaycut = null;
			else{
				object.delaycut = this.delaycut;
			}
			if ( this.delayunit== null ) object.delayunit = null;
			else{
				object.delayunit = this.delayunit;
			}
			if ( this.startTag== null ) object.startTag = null;
			else{
				object.startTag = this.startTag;
			}
			if ( this.endTag== null ) object.endTag = null;
			else{
				object.endTag = this.endTag;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((startDays==null)?0:startDays.hashCode());
		result = prime * result + ((endDays==null)?0:endDays.hashCode());
		result = prime * result + ((startdate==null)?0:startdate.hashCode());
		result = prime * result + ((enddate==null)?0:enddate.hashCode());
		result = prime * result + ((delayrate==null)?0:delayrate.hashCode());
		result = prime * result + ((delaycut==null)?0:delaycut.hashCode());
		result = prime * result + ((delayunit==null)?0:delayunit.hashCode());
		result = prime * result + ((startTag==null)?0:startTag.hashCode());
		result = prime * result + ((endTag==null)?0:endTag.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO other = (kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( startDays == null ){
			if ( other.startDays != null ) return false;
		}
		else if ( !startDays.equals(other.startDays) )
			return false;
		if ( endDays == null ){
			if ( other.endDays != null ) return false;
		}
		else if ( !endDays.equals(other.endDays) )
			return false;
		if ( startdate == null ){
			if ( other.startdate != null ) return false;
		}
		else if ( !startdate.equals(other.startdate) )
			return false;
		if ( enddate == null ){
			if ( other.enddate != null ) return false;
		}
		else if ( !enddate.equals(other.enddate) )
			return false;
		if ( delayrate == null ){
			if ( other.delayrate != null ) return false;
		}
		else if ( !delayrate.equals(other.delayrate) )
			return false;
		if ( delaycut == null ){
			if ( other.delaycut != null ) return false;
		}
		else if ( !delaycut.equals(other.delaycut) )
			return false;
		if ( delayunit == null ){
			if ( other.delayunit != null ) return false;
		}
		else if ( !delayunit.equals(other.delayunit) )
			return false;
		if ( startTag == null ){
			if ( other.startTag != null ) return false;
		}
		else if ( !startTag.equals(other.startTag) )
			return false;
		if ( endTag == null ){
			if ( other.endTag != null ) return false;
		}
		else if ( !endTag.equals(other.endTag) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tstartDays: ");
		sb.append(startDays==null?"null":getStartDays());
		sb.append("\n");
		sb.append("\tendDays: ");
		sb.append(endDays==null?"null":getEndDays());
		sb.append("\n");
		sb.append("\tstartdate: ");
		sb.append(startdate==null?"null":getStartdate());
		sb.append("\n");
		sb.append("\tenddate: ");
		sb.append(enddate==null?"null":getEnddate());
		sb.append("\n");
		sb.append("\tdelayrate: ");
		sb.append(delayrate==null?"null":getDelayrate());
		sb.append("\n");
		sb.append("\tdelaycut: ");
		sb.append(delaycut==null?"null":getDelaycut());
		sb.append("\n");
		sb.append("\tdelayunit: ");
		sb.append(delayunit==null?"null":getDelayunit());
		sb.append("\n");
		sb.append("\tstartTag: ");
		sb.append(startTag==null?"null":getStartTag());
		sb.append("\n");
		sb.append("\tendTag: ");
		sb.append(endTag==null?"null":getEndTag());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* startDays */
		messageLen+= 22; /* endDays */
		messageLen+= 8; /* startdate */
		messageLen+= 8; /* enddate */
		messageLen+= 22; /* delayrate */
		messageLen+= 2; /* delaycut */
		messageLen+= 2; /* delayunit */
		messageLen+= 1; /* startTag */
		messageLen+= 1; /* endTag */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("startDays");
	
		fieldNames.add("endDays");
	
		fieldNames.add("startdate");
	
		fieldNames.add("enddate");
	
		fieldNames.add("delayrate");
	
		fieldNames.add("delaycut");
	
		fieldNames.add("delayunit");
	
		fieldNames.add("startTag");
	
		fieldNames.add("endTag");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("startDays", get("startDays"));
	
		fieldValueMap.put("endDays", get("endDays"));
	
		fieldValueMap.put("startdate", get("startdate"));
	
		fieldValueMap.put("enddate", get("enddate"));
	
		fieldValueMap.put("delayrate", get("delayrate"));
	
		fieldValueMap.put("delaycut", get("delaycut"));
	
		fieldValueMap.put("delayunit", get("delayunit"));
	
		fieldValueMap.put("startTag", get("startTag"));
	
		fieldValueMap.put("endTag", get("endTag"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -2129778727 : /* startDays */
			return getStartDays();
		case -1607727150 : /* endDays */
			return getEndDays();
		case -2128825584 : /* startdate */
			return getStartdate();
		case -1606774007 : /* enddate */
			return getEnddate();
		case -468218653 : /* delayrate */
			return getDelayrate();
		case 816166367 : /* delaycut */
			return getDelaycut();
		case -468117113 : /* delayunit */
			return getDelayunit();
		case 1316786136 : /* startTag */
			return getStartTag();
		case -1298772801 : /* endTag */
			return getEndTag();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case -2129778727 : /* startDays */
			setStartDays((java.math.BigDecimal) value);
			return;
		case -1607727150 : /* endDays */
			setEndDays((java.math.BigDecimal) value);
			return;
		case -2128825584 : /* startdate */
			setStartdate((java.lang.String) value);
			return;
		case -1606774007 : /* enddate */
			setEnddate((java.lang.String) value);
			return;
		case -468218653 : /* delayrate */
			setDelayrate((java.lang.Float) value);
			return;
		case 816166367 : /* delaycut */
			setDelaycut((java.lang.String) value);
			return;
		case -468117113 : /* delayunit */
			setDelayunit((java.lang.String) value);
			return;
		case 1316786136 : /* startTag */
			setStartTag((java.lang.String) value);
			return;
		case -1298772801 : /* endTag */
			setEndTag((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
