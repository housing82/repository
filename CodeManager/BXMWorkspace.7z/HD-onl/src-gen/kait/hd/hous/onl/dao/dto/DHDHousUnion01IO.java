/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_세대별공동명의자 ( HD_HOUS_UNION )
 */
@XmlType(propOrder={"custCode", "seq", "unionCustcode", "unionCustnm", "regDate", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDHousUnion01IO")
@XmlRootElement(name="DHDHousUnion01IO")
@SuppressWarnings("all")
public class DHDHousUnion01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1990914399L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_세대별공동명의자 ( HD_HOUS_UNION )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012466(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012466(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012466(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012467(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012467(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012467(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012467(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012467(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012467(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << unionCustcode >> [[ */
	
	@XmlTransient
	private boolean isSet_unionCustcode = false;
	
	protected boolean isSet_unionCustcode()
	{
		return this.isSet_unionCustcode;
	}
	
	protected void setIsSet_unionCustcode(boolean value)
	{
		this.isSet_unionCustcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="공동명의자고객코드 [SYS_C0012468(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String unionCustcode  = null;
	
	/**
	 * @Description 공동명의자고객코드 [SYS_C0012468(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	public java.lang.String getUnionCustcode(){
		return unionCustcode;
	}
	
	/**
	 * @Description 공동명의자고객코드 [SYS_C0012468(C),SYS_C0012964(P) SYS_C0012964(UNIQUE)]
	 */
	@JsonProperty("unionCustcode")
	public void setUnionCustcode( java.lang.String unionCustcode ) {
		isSet_unionCustcode = true;
		this.unionCustcode = unionCustcode;
	}
	
	/** Property set << unionCustcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << unionCustnm >> [[ */
	
	@XmlTransient
	private boolean isSet_unionCustnm = false;
	
	protected boolean isSet_unionCustnm()
	{
		return this.isSet_unionCustnm;
	}
	
	protected void setIsSet_unionCustnm(boolean value)
	{
		this.isSet_unionCustnm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="공동명의자고객명", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String unionCustnm  = null;
	
	/**
	 * @Description 공동명의자고객명
	 */
	public java.lang.String getUnionCustnm(){
		return unionCustnm;
	}
	
	/**
	 * @Description 공동명의자고객명
	 */
	@JsonProperty("unionCustnm")
	public void setUnionCustnm( java.lang.String unionCustnm ) {
		isSet_unionCustnm = true;
		this.unionCustnm = unionCustnm;
	}
	
	/** Property set << unionCustnm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << regDate >> [[ */
	
	@XmlTransient
	private boolean isSet_regDate = false;
	
	protected boolean isSet_regDate()
	{
		return this.isSet_regDate;
	}
	
	protected void setIsSet_regDate(boolean value)
	{
		this.isSet_regDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="등록일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String regDate  = null;
	
	/**
	 * @Description 등록일자
	 */
	public java.lang.String getRegDate(){
		return regDate;
	}
	
	/**
	 * @Description 등록일자
	 */
	@JsonProperty("regDate")
	public void setRegDate( java.lang.String regDate ) {
		isSet_regDate = true;
		this.regDate = regDate;
	}
	
	/** Property set << regDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousUnion01IO clone(){
		try{
			DHDHousUnion01IO object= (DHDHousUnion01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.unionCustcode== null ) object.unionCustcode = null;
			else{
				object.unionCustcode = this.unionCustcode;
			}
			if ( this.unionCustnm== null ) object.unionCustnm = null;
			else{
				object.unionCustnm = this.unionCustnm;
			}
			if ( this.regDate== null ) object.regDate = null;
			else{
				object.regDate = this.regDate;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((unionCustcode==null)?0:unionCustcode.hashCode());
		result = prime * result + ((unionCustnm==null)?0:unionCustnm.hashCode());
		result = prime * result + ((regDate==null)?0:regDate.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousUnion01IO other = (kait.hd.hous.onl.dao.dto.DHDHousUnion01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( unionCustcode == null ){
			if ( other.unionCustcode != null ) return false;
		}
		else if ( !unionCustcode.equals(other.unionCustcode) )
			return false;
		if ( unionCustnm == null ){
			if ( other.unionCustnm != null ) return false;
		}
		else if ( !unionCustnm.equals(other.unionCustnm) )
			return false;
		if ( regDate == null ){
			if ( other.regDate != null ) return false;
		}
		else if ( !regDate.equals(other.regDate) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousUnion01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tunionCustcode: ");
		sb.append(unionCustcode==null?"null":getUnionCustcode());
		sb.append("\n");
		sb.append("\tunionCustnm: ");
		sb.append(unionCustnm==null?"null":getUnionCustnm());
		sb.append("\n");
		sb.append("\tregDate: ");
		sb.append(regDate==null?"null":getRegDate());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 20; /* unionCustcode */
		messageLen+= 50; /* unionCustnm */
		messageLen+= 8; /* regDate */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("unionCustcode");
	
		fieldNames.add("unionCustnm");
	
		fieldNames.add("regDate");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("unionCustcode", get("unionCustcode"));
	
		fieldValueMap.put("unionCustnm", get("unionCustnm"));
	
		fieldValueMap.put("regDate", get("regDate"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case 725257903 : /* unionCustcode */
			return getUnionCustcode();
		case 313603841 : /* unionCustnm */
			return getUnionCustnm();
		case 1084994146 : /* regDate */
			return getRegDate();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 725257903 : /* unionCustcode */
			setUnionCustcode((java.lang.String) value);
			return;
		case 313603841 : /* unionCustnm */
			setUnionCustnm((java.lang.String) value);
			return;
		case 1084994146 : /* regDate */
			setRegDate((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
