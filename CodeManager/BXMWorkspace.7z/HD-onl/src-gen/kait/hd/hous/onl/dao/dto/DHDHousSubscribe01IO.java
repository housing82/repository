/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_기본_청약관리 ( HD_HOUS_SUBSCRIBE )
 */
@XmlType(propOrder={"deptCode", "housetag", "seq", "custCode", "custSeq", "custName", "subscribeTag", "subscribeDate", "subscribeAmt", "winDate", "buildno", "houseno", "returnTag", "returnDate", "returnAmt", "virYn", "vdepositNo", "incomYn", "contNo", "registYn", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "errText", "actYn", "remark"}, name="DHDHousSubscribe01IO")
@XmlRootElement(name="DHDHousSubscribe01IO")
@SuppressWarnings("all")
public class DHDHousSubscribe01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -467357156L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_기본_청약관리 ( HD_HOUS_SUBSCRIBE )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업코드 [SYS_C0012437(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 사업코드 [SYS_C0012437(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 사업코드 [SYS_C0012437(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012438(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012438(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012438(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012439(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012439(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012439(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012439(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012439(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012439(C),SYS_C0012958(P) XPKHD_REFER_SQUAREDETAIL(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고개코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 고개코드
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 고개코드
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_custSeq = false;
	
	protected boolean isSet_custSeq()
	{
		return this.isSet_custSeq;
	}
	
	protected void setIsSet_custSeq(boolean value)
	{
		this.isSet_custSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번
	 */
	public void setCustSeq(java.lang.String value) {
		isSet_custSeq = true;
		this.custSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번
	 */
	public void setCustSeq(double value) {
		isSet_custSeq = true;
		this.custSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번
	 */
	public void setCustSeq(long value) {
		isSet_custSeq = true;
		this.custSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal custSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번
	 */
	public java.math.BigDecimal getCustSeq(){
		return custSeq;
	}
	
	/**
	 * @Description 고객순번
	 */
	@JsonProperty("custSeq")
	public void setCustSeq( java.math.BigDecimal custSeq ) {
		isSet_custSeq = true;
		this.custSeq = custSeq;
	}
	
	/** Property set << custSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custName >> [[ */
	
	@XmlTransient
	private boolean isSet_custName = false;
	
	protected boolean isSet_custName()
	{
		return this.isSet_custName;
	}
	
	protected void setIsSet_custName(boolean value)
	{
		this.isSet_custName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="성명", formatType="", format="", align="left", length=100, decimal=0, arrayReference="", fill="")
	private java.lang.String custName  = null;
	
	/**
	 * @Description 성명
	 */
	public java.lang.String getCustName(){
		return custName;
	}
	
	/**
	 * @Description 성명
	 */
	@JsonProperty("custName")
	public void setCustName( java.lang.String custName ) {
		isSet_custName = true;
		this.custName = custName;
	}
	
	/** Property set << custName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << subscribeTag >> [[ */
	
	@XmlTransient
	private boolean isSet_subscribeTag = false;
	
	protected boolean isSet_subscribeTag()
	{
		return this.isSet_subscribeTag;
	}
	
	protected void setIsSet_subscribeTag(boolean value)
	{
		this.isSet_subscribeTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="청약상태", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String subscribeTag  = null;
	
	/**
	 * @Description 청약상태
	 */
	public java.lang.String getSubscribeTag(){
		return subscribeTag;
	}
	
	/**
	 * @Description 청약상태
	 */
	@JsonProperty("subscribeTag")
	public void setSubscribeTag( java.lang.String subscribeTag ) {
		isSet_subscribeTag = true;
		this.subscribeTag = subscribeTag;
	}
	
	/** Property set << subscribeTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << subscribeDate >> [[ */
	
	@XmlTransient
	private boolean isSet_subscribeDate = false;
	
	protected boolean isSet_subscribeDate()
	{
		return this.isSet_subscribeDate;
	}
	
	protected void setIsSet_subscribeDate(boolean value)
	{
		this.isSet_subscribeDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="청약일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String subscribeDate  = null;
	
	/**
	 * @Description 청약일자
	 */
	public java.lang.String getSubscribeDate(){
		return subscribeDate;
	}
	
	/**
	 * @Description 청약일자
	 */
	@JsonProperty("subscribeDate")
	public void setSubscribeDate( java.lang.String subscribeDate ) {
		isSet_subscribeDate = true;
		this.subscribeDate = subscribeDate;
	}
	
	/** Property set << subscribeDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << subscribeAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_subscribeAmt = false;
	
	protected boolean isSet_subscribeAmt()
	{
		return this.isSet_subscribeAmt;
	}
	
	protected void setIsSet_subscribeAmt(boolean value)
	{
		this.isSet_subscribeAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 청약금
	 */
	public void setSubscribeAmt(java.lang.String value) {
		isSet_subscribeAmt = true;
		this.subscribeAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 청약금
	 */
	public void setSubscribeAmt(double value) {
		isSet_subscribeAmt = true;
		this.subscribeAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 청약금
	 */
	public void setSubscribeAmt(long value) {
		isSet_subscribeAmt = true;
		this.subscribeAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="청약금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal subscribeAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 청약금
	 */
	public java.math.BigDecimal getSubscribeAmt(){
		return subscribeAmt;
	}
	
	/**
	 * @Description 청약금
	 */
	@JsonProperty("subscribeAmt")
	public void setSubscribeAmt( java.math.BigDecimal subscribeAmt ) {
		isSet_subscribeAmt = true;
		this.subscribeAmt = subscribeAmt;
	}
	
	/** Property set << subscribeAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << winDate >> [[ */
	
	@XmlTransient
	private boolean isSet_winDate = false;
	
	protected boolean isSet_winDate()
	{
		return this.isSet_winDate;
	}
	
	protected void setIsSet_winDate(boolean value)
	{
		this.isSet_winDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="당첨일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String winDate  = null;
	
	/**
	 * @Description 당첨일
	 */
	public java.lang.String getWinDate(){
		return winDate;
	}
	
	/**
	 * @Description 당첨일
	 */
	@JsonProperty("winDate")
	public void setWinDate( java.lang.String winDate ) {
		isSet_winDate = true;
		this.winDate = winDate;
	}
	
	/** Property set << winDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="당첨동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 당첨동
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 당첨동
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="당첨호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 당첨호
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 당첨호
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnTag >> [[ */
	
	@XmlTransient
	private boolean isSet_returnTag = false;
	
	protected boolean isSet_returnTag()
	{
		return this.isSet_returnTag;
	}
	
	protected void setIsSet_returnTag(boolean value)
	{
		this.isSet_returnTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불유무", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String returnTag  = null;
	
	/**
	 * @Description 환불유무
	 */
	public java.lang.String getReturnTag(){
		return returnTag;
	}
	
	/**
	 * @Description 환불유무
	 */
	@JsonProperty("returnTag")
	public void setReturnTag( java.lang.String returnTag ) {
		isSet_returnTag = true;
		this.returnTag = returnTag;
	}
	
	/** Property set << returnTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnDate >> [[ */
	
	@XmlTransient
	private boolean isSet_returnDate = false;
	
	protected boolean isSet_returnDate()
	{
		return this.isSet_returnDate;
	}
	
	protected void setIsSet_returnDate(boolean value)
	{
		this.isSet_returnDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String returnDate  = null;
	
	/**
	 * @Description 환불일자
	 */
	public java.lang.String getReturnDate(){
		return returnDate;
	}
	
	/**
	 * @Description 환불일자
	 */
	@JsonProperty("returnDate")
	public void setReturnDate( java.lang.String returnDate ) {
		isSet_returnDate = true;
		this.returnDate = returnDate;
	}
	
	/** Property set << returnDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << returnAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_returnAmt = false;
	
	protected boolean isSet_returnAmt()
	{
		return this.isSet_returnAmt;
	}
	
	protected void setIsSet_returnAmt(boolean value)
	{
		this.isSet_returnAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 환불금액
	 */
	public void setReturnAmt(java.lang.String value) {
		isSet_returnAmt = true;
		this.returnAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 환불금액
	 */
	public void setReturnAmt(double value) {
		isSet_returnAmt = true;
		this.returnAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 환불금액
	 */
	public void setReturnAmt(long value) {
		isSet_returnAmt = true;
		this.returnAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="환불금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal returnAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 환불금액
	 */
	public java.math.BigDecimal getReturnAmt(){
		return returnAmt;
	}
	
	/**
	 * @Description 환불금액
	 */
	@JsonProperty("returnAmt")
	public void setReturnAmt( java.math.BigDecimal returnAmt ) {
		isSet_returnAmt = true;
		this.returnAmt = returnAmt;
	}
	
	/** Property set << returnAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virYn >> [[ */
	
	@XmlTransient
	private boolean isSet_virYn = false;
	
	protected boolean isSet_virYn()
	{
		return this.isSet_virYn;
	}
	
	protected void setIsSet_virYn(boolean value)
	{
		this.isSet_virYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌사용여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String virYn  = null;
	
	/**
	 * @Description 가상계좌사용여부
	 */
	public java.lang.String getVirYn(){
		return virYn;
	}
	
	/**
	 * @Description 가상계좌사용여부
	 */
	@JsonProperty("virYn")
	public void setVirYn( java.lang.String virYn ) {
		isSet_virYn = true;
		this.virYn = virYn;
	}
	
	/** Property set << virYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vdepositNo >> [[ */
	
	@XmlTransient
	private boolean isSet_vdepositNo = false;
	
	protected boolean isSet_vdepositNo()
	{
		return this.isSet_vdepositNo;
	}
	
	protected void setIsSet_vdepositNo(boolean value)
	{
		this.isSet_vdepositNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌번호", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String vdepositNo  = null;
	
	/**
	 * @Description 가상계좌번호
	 */
	public java.lang.String getVdepositNo(){
		return vdepositNo;
	}
	
	/**
	 * @Description 가상계좌번호
	 */
	@JsonProperty("vdepositNo")
	public void setVdepositNo( java.lang.String vdepositNo ) {
		isSet_vdepositNo = true;
		this.vdepositNo = vdepositNo;
	}
	
	/** Property set << vdepositNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << incomYn >> [[ */
	
	@XmlTransient
	private boolean isSet_incomYn = false;
	
	protected boolean isSet_incomYn()
	{
		return this.isSet_incomYn;
	}
	
	protected void setIsSet_incomYn(boolean value)
	{
		this.isSet_incomYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금처리여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String incomYn  = null;
	
	/**
	 * @Description 입금처리여부
	 */
	public java.lang.String getIncomYn(){
		return incomYn;
	}
	
	/**
	 * @Description 입금처리여부
	 */
	@JsonProperty("incomYn")
	public void setIncomYn( java.lang.String incomYn ) {
		isSet_incomYn = true;
		this.incomYn = incomYn;
	}
	
	/** Property set << incomYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contNo >> [[ */
	
	@XmlTransient
	private boolean isSet_contNo = false;
	
	protected boolean isSet_contNo()
	{
		return this.isSet_contNo;
	}
	
	protected void setIsSet_contNo(boolean value)
	{
		this.isSet_contNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약서번호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String contNo  = null;
	
	/**
	 * @Description 계약서번호
	 */
	public java.lang.String getContNo(){
		return contNo;
	}
	
	/**
	 * @Description 계약서번호
	 */
	@JsonProperty("contNo")
	public void setContNo( java.lang.String contNo ) {
		isSet_contNo = true;
		this.contNo = contNo;
	}
	
	/** Property set << contNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << registYn >> [[ */
	
	@XmlTransient
	private boolean isSet_registYn = false;
	
	protected boolean isSet_registYn()
	{
		return this.isSet_registYn;
	}
	
	protected void setIsSet_registYn(boolean value)
	{
		this.isSet_registYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약전환여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String registYn  = null;
	
	/**
	 * @Description 계약전환여부
	 */
	public java.lang.String getRegistYn(){
		return registYn;
	}
	
	/**
	 * @Description 계약전환여부
	 */
	@JsonProperty("registYn")
	public void setRegistYn( java.lang.String registYn ) {
		isSet_registYn = true;
		this.registYn = registYn;
	}
	
	/** Property set << registYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << errText >> [[ */
	
	@XmlTransient
	private boolean isSet_errText = false;
	
	protected boolean isSet_errText()
	{
		return this.isSet_errText;
	}
	
	protected void setIsSet_errText(boolean value)
	{
		this.isSet_errText = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="오류내역", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String errText  = null;
	
	/**
	 * @Description 오류내역
	 */
	public java.lang.String getErrText(){
		return errText;
	}
	
	/**
	 * @Description 오류내역
	 */
	@JsonProperty("errText")
	public void setErrText( java.lang.String errText ) {
		isSet_errText = true;
		this.errText = errText;
	}
	
	/** Property set << errText >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << actYn >> [[ */
	
	@XmlTransient
	private boolean isSet_actYn = false;
	
	protected boolean isSet_actYn()
	{
		return this.isSet_actYn;
	}
	
	protected void setIsSet_actYn(boolean value)
	{
		this.isSet_actYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약전환희망여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String actYn  = null;
	
	/**
	 * @Description 계약전환희망여부
	 */
	public java.lang.String getActYn(){
		return actYn;
	}
	
	/**
	 * @Description 계약전환희망여부
	 */
	@JsonProperty("actYn")
	public void setActYn( java.lang.String actYn ) {
		isSet_actYn = true;
		this.actYn = actYn;
	}
	
	/** Property set << actYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=200, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSubscribe01IO clone(){
		try{
			DHDHousSubscribe01IO object= (DHDHousSubscribe01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.custSeq== null ) object.custSeq = null;
			else{
				object.custSeq = new java.math.BigDecimal(custSeq.toString());
			}
			if ( this.custName== null ) object.custName = null;
			else{
				object.custName = this.custName;
			}
			if ( this.subscribeTag== null ) object.subscribeTag = null;
			else{
				object.subscribeTag = this.subscribeTag;
			}
			if ( this.subscribeDate== null ) object.subscribeDate = null;
			else{
				object.subscribeDate = this.subscribeDate;
			}
			if ( this.subscribeAmt== null ) object.subscribeAmt = null;
			else{
				object.subscribeAmt = new java.math.BigDecimal(subscribeAmt.toString());
			}
			if ( this.winDate== null ) object.winDate = null;
			else{
				object.winDate = this.winDate;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.returnTag== null ) object.returnTag = null;
			else{
				object.returnTag = this.returnTag;
			}
			if ( this.returnDate== null ) object.returnDate = null;
			else{
				object.returnDate = this.returnDate;
			}
			if ( this.returnAmt== null ) object.returnAmt = null;
			else{
				object.returnAmt = new java.math.BigDecimal(returnAmt.toString());
			}
			if ( this.virYn== null ) object.virYn = null;
			else{
				object.virYn = this.virYn;
			}
			if ( this.vdepositNo== null ) object.vdepositNo = null;
			else{
				object.vdepositNo = this.vdepositNo;
			}
			if ( this.incomYn== null ) object.incomYn = null;
			else{
				object.incomYn = this.incomYn;
			}
			if ( this.contNo== null ) object.contNo = null;
			else{
				object.contNo = this.contNo;
			}
			if ( this.registYn== null ) object.registYn = null;
			else{
				object.registYn = this.registYn;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.errText== null ) object.errText = null;
			else{
				object.errText = this.errText;
			}
			if ( this.actYn== null ) object.actYn = null;
			else{
				object.actYn = this.actYn;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((custSeq==null)?0:custSeq.hashCode());
		result = prime * result + ((custName==null)?0:custName.hashCode());
		result = prime * result + ((subscribeTag==null)?0:subscribeTag.hashCode());
		result = prime * result + ((subscribeDate==null)?0:subscribeDate.hashCode());
		result = prime * result + ((subscribeAmt==null)?0:subscribeAmt.hashCode());
		result = prime * result + ((winDate==null)?0:winDate.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((returnTag==null)?0:returnTag.hashCode());
		result = prime * result + ((returnDate==null)?0:returnDate.hashCode());
		result = prime * result + ((returnAmt==null)?0:returnAmt.hashCode());
		result = prime * result + ((virYn==null)?0:virYn.hashCode());
		result = prime * result + ((vdepositNo==null)?0:vdepositNo.hashCode());
		result = prime * result + ((incomYn==null)?0:incomYn.hashCode());
		result = prime * result + ((contNo==null)?0:contNo.hashCode());
		result = prime * result + ((registYn==null)?0:registYn.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((errText==null)?0:errText.hashCode());
		result = prime * result + ((actYn==null)?0:actYn.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( custSeq == null ){
			if ( other.custSeq != null ) return false;
		}
		else if ( !custSeq.equals(other.custSeq) )
			return false;
		if ( custName == null ){
			if ( other.custName != null ) return false;
		}
		else if ( !custName.equals(other.custName) )
			return false;
		if ( subscribeTag == null ){
			if ( other.subscribeTag != null ) return false;
		}
		else if ( !subscribeTag.equals(other.subscribeTag) )
			return false;
		if ( subscribeDate == null ){
			if ( other.subscribeDate != null ) return false;
		}
		else if ( !subscribeDate.equals(other.subscribeDate) )
			return false;
		if ( subscribeAmt == null ){
			if ( other.subscribeAmt != null ) return false;
		}
		else if ( !subscribeAmt.equals(other.subscribeAmt) )
			return false;
		if ( winDate == null ){
			if ( other.winDate != null ) return false;
		}
		else if ( !winDate.equals(other.winDate) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( returnTag == null ){
			if ( other.returnTag != null ) return false;
		}
		else if ( !returnTag.equals(other.returnTag) )
			return false;
		if ( returnDate == null ){
			if ( other.returnDate != null ) return false;
		}
		else if ( !returnDate.equals(other.returnDate) )
			return false;
		if ( returnAmt == null ){
			if ( other.returnAmt != null ) return false;
		}
		else if ( !returnAmt.equals(other.returnAmt) )
			return false;
		if ( virYn == null ){
			if ( other.virYn != null ) return false;
		}
		else if ( !virYn.equals(other.virYn) )
			return false;
		if ( vdepositNo == null ){
			if ( other.vdepositNo != null ) return false;
		}
		else if ( !vdepositNo.equals(other.vdepositNo) )
			return false;
		if ( incomYn == null ){
			if ( other.incomYn != null ) return false;
		}
		else if ( !incomYn.equals(other.incomYn) )
			return false;
		if ( contNo == null ){
			if ( other.contNo != null ) return false;
		}
		else if ( !contNo.equals(other.contNo) )
			return false;
		if ( registYn == null ){
			if ( other.registYn != null ) return false;
		}
		else if ( !registYn.equals(other.registYn) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( errText == null ){
			if ( other.errText != null ) return false;
		}
		else if ( !errText.equals(other.errText) )
			return false;
		if ( actYn == null ){
			if ( other.actYn != null ) return false;
		}
		else if ( !actYn.equals(other.actYn) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tcustSeq: ");
		sb.append(custSeq==null?"null":getCustSeq());
		sb.append("\n");
		sb.append("\tcustName: ");
		sb.append(custName==null?"null":getCustName());
		sb.append("\n");
		sb.append("\tsubscribeTag: ");
		sb.append(subscribeTag==null?"null":getSubscribeTag());
		sb.append("\n");
		sb.append("\tsubscribeDate: ");
		sb.append(subscribeDate==null?"null":getSubscribeDate());
		sb.append("\n");
		sb.append("\tsubscribeAmt: ");
		sb.append(subscribeAmt==null?"null":getSubscribeAmt());
		sb.append("\n");
		sb.append("\twinDate: ");
		sb.append(winDate==null?"null":getWinDate());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\treturnTag: ");
		sb.append(returnTag==null?"null":getReturnTag());
		sb.append("\n");
		sb.append("\treturnDate: ");
		sb.append(returnDate==null?"null":getReturnDate());
		sb.append("\n");
		sb.append("\treturnAmt: ");
		sb.append(returnAmt==null?"null":getReturnAmt());
		sb.append("\n");
		sb.append("\tvirYn: ");
		sb.append(virYn==null?"null":getVirYn());
		sb.append("\n");
		sb.append("\tvdepositNo: ");
		sb.append(vdepositNo==null?"null":getVdepositNo());
		sb.append("\n");
		sb.append("\tincomYn: ");
		sb.append(incomYn==null?"null":getIncomYn());
		sb.append("\n");
		sb.append("\tcontNo: ");
		sb.append(contNo==null?"null":getContNo());
		sb.append("\n");
		sb.append("\tregistYn: ");
		sb.append(registYn==null?"null":getRegistYn());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\terrText: ");
		sb.append(errText==null?"null":getErrText());
		sb.append("\n");
		sb.append("\tactYn: ");
		sb.append(actYn==null?"null":getActYn());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* seq */
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* custSeq */
		messageLen+= 100; /* custName */
		messageLen+= 1; /* subscribeTag */
		messageLen+= 8; /* subscribeDate */
		messageLen+= 22; /* subscribeAmt */
		messageLen+= 8; /* winDate */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 1; /* returnTag */
		messageLen+= 8; /* returnDate */
		messageLen+= 22; /* returnAmt */
		messageLen+= 1; /* virYn */
		messageLen+= 50; /* vdepositNo */
		messageLen+= 1; /* incomYn */
		messageLen+= 10; /* contNo */
		messageLen+= 1; /* registYn */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 200; /* errText */
		messageLen+= 1; /* actYn */
		messageLen+= 200; /* remark */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("seq");
	
		fieldNames.add("custCode");
	
		fieldNames.add("custSeq");
	
		fieldNames.add("custName");
	
		fieldNames.add("subscribeTag");
	
		fieldNames.add("subscribeDate");
	
		fieldNames.add("subscribeAmt");
	
		fieldNames.add("winDate");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("returnTag");
	
		fieldNames.add("returnDate");
	
		fieldNames.add("returnAmt");
	
		fieldNames.add("virYn");
	
		fieldNames.add("vdepositNo");
	
		fieldNames.add("incomYn");
	
		fieldNames.add("contNo");
	
		fieldNames.add("registYn");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("errText");
	
		fieldNames.add("actYn");
	
		fieldNames.add("remark");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("custSeq", get("custSeq"));
	
		fieldValueMap.put("custName", get("custName"));
	
		fieldValueMap.put("subscribeTag", get("subscribeTag"));
	
		fieldValueMap.put("subscribeDate", get("subscribeDate"));
	
		fieldValueMap.put("subscribeAmt", get("subscribeAmt"));
	
		fieldValueMap.put("winDate", get("winDate"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("returnTag", get("returnTag"));
	
		fieldValueMap.put("returnDate", get("returnDate"));
	
		fieldValueMap.put("returnAmt", get("returnAmt"));
	
		fieldValueMap.put("virYn", get("virYn"));
	
		fieldValueMap.put("vdepositNo", get("vdepositNo"));
	
		fieldValueMap.put("incomYn", get("incomYn"));
	
		fieldValueMap.put("contNo", get("contNo"));
	
		fieldValueMap.put("registYn", get("registYn"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("errText", get("errText"));
	
		fieldValueMap.put("actYn", get("actYn"));
	
		fieldValueMap.put("remark", get("remark"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 113759 : /* seq */
			return getSeq();
		case 604866272 : /* custCode */
			return getCustCode();
		case 1127905548 : /* custSeq */
			return getCustSeq();
		case 605180798 : /* custName */
			return getCustName();
		case 327806448 : /* subscribeTag */
			return getSubscribeTag();
		case 1571589144 : /* subscribeDate */
			return getSubscribeDate();
		case 327788574 : /* subscribeAmt */
			return getSubscribeAmt();
		case 1348526506 : /* winDate */
			return getWinDate();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -926696374 : /* returnTag */
			return getReturnTag();
		case 1336707326 : /* returnDate */
			return getReturnDate();
		case -926714248 : /* returnAmt */
			return getReturnAmt();
		case 112215956 : /* virYn */
			return getVirYn();
		case 1763054921 : /* vdepositNo */
			return getVdepositNo();
		case 1942655601 : /* incomYn */
			return getIncomYn();
		case -1354779501 : /* contNo */
			return getContNo();
		case -690213589 : /* registYn */
			return getRegistYn();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -1479800782 : /* errText */
			return getErrText();
		case 92645191 : /* actYn */
			return getActYn();
		case -934624384 : /* remark */
			return getRemark();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 1127905548 : /* custSeq */
			setCustSeq((java.math.BigDecimal) value);
			return;
		case 605180798 : /* custName */
			setCustName((java.lang.String) value);
			return;
		case 327806448 : /* subscribeTag */
			setSubscribeTag((java.lang.String) value);
			return;
		case 1571589144 : /* subscribeDate */
			setSubscribeDate((java.lang.String) value);
			return;
		case 327788574 : /* subscribeAmt */
			setSubscribeAmt((java.math.BigDecimal) value);
			return;
		case 1348526506 : /* winDate */
			setWinDate((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -926696374 : /* returnTag */
			setReturnTag((java.lang.String) value);
			return;
		case 1336707326 : /* returnDate */
			setReturnDate((java.lang.String) value);
			return;
		case -926714248 : /* returnAmt */
			setReturnAmt((java.math.BigDecimal) value);
			return;
		case 112215956 : /* virYn */
			setVirYn((java.lang.String) value);
			return;
		case 1763054921 : /* vdepositNo */
			setVdepositNo((java.lang.String) value);
			return;
		case 1942655601 : /* incomYn */
			setIncomYn((java.lang.String) value);
			return;
		case -1354779501 : /* contNo */
			setContNo((java.lang.String) value);
			return;
		case -690213589 : /* registYn */
			setRegistYn((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -1479800782 : /* errText */
			setErrText((java.lang.String) value);
			return;
		case 92645191 : /* actYn */
			setActYn((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
