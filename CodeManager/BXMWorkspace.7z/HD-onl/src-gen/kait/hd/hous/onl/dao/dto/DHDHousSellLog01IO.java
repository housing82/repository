/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_세대별분양대장_LOG ( HD_HOUS_SELL_LOG )
 */
@XmlType(propOrder={"custCode", "seq", "writetag", "writetime", "writeseq", "deptCode", "housetag", "buildno", "houseno", "dongho", "custName", "square", "type", "classJrw", "optioncode", "contracttag", "contractdate", "contractno", "loanTag", "leasetag", "lastchangedate", "changetag", "changedate", "cancelReason", "childBuildno", "childHouseno", "relaCustcode", "relaSeq", "vattag", "exclusivearea", "commonarea", "etccommonarea", "parkingarea", "servicearea", "sitearea", "moveinstartdate", "moveinenddate", "unionCnt", "remark", "refundmentdate", "refundmentamt", "penaltyamt", "loanInterest", "sodukTax", "juminTax", "bankLoanOrgamt", "bankLoanInterest", "loanbank", "loandeposit", "loanuser", "refundDeposit", "refundBank", "compLoanamt", "billReturnamt", "delayIndeminity", "depositCount", "coCustcode", "coSangho", "coCondition", "coCategory", "categoryName", "slipdate", "slipseq", "inputDutyId", "inputDate", "chgDutyId", "chgDate", "applyYn", "applyEmpno", "applyDate", "prtsquare", "bankLoanInterest2", "etcAmt", "renthdYn", "renthdSeq", "balconyTag", "balconyarea", "daymonthTag", "floor", "contCondition", "landReturn", "intCalcDate", "predisamt", "proxyamt", "incontDate", "trustamt", "predisTag", "proxyTag", "trustTag", "virYn", "vdeposit", "repLimitdt", "repYn", "repDate"}, name="DHDHousSellLog01IO")
@XmlRootElement(name="DHDHousSellLog01IO")
@SuppressWarnings("all")
public class DHDHousSellLog01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1259212252L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_세대별분양대장_LOG ( HD_HOUS_SELL_LOG )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객코드 [SYS_C0012410(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 고객코드 [SYS_C0012410(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 고객코드 [SYS_C0012410(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012411(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012411(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012411(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012411(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012411(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012411(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << writetag >> [[ */
	
	@XmlTransient
	private boolean isSet_writetag = false;
	
	protected boolean isSet_writetag()
	{
		return this.isSet_writetag;
	}
	
	protected void setIsSet_writetag(boolean value)
	{
		this.isSet_writetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="작성구분 [SYS_C0012412(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String writetag  = null;
	
	/**
	 * @Description 작성구분 [SYS_C0012412(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public java.lang.String getWritetag(){
		return writetag;
	}
	
	/**
	 * @Description 작성구분 [SYS_C0012412(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	@JsonProperty("writetag")
	public void setWritetag( java.lang.String writetag ) {
		isSet_writetag = true;
		this.writetag = writetag;
	}
	
	/** Property set << writetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << writetime >> [[ */
	
	@XmlTransient
	private boolean isSet_writetime = false;
	
	protected boolean isSet_writetime()
	{
		return this.isSet_writetime;
	}
	
	protected void setIsSet_writetime(boolean value)
	{
		this.isSet_writetime = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="작성시간 [SYS_C0012413(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String writetime  = null;
	
	/**
	 * @Description 작성시간 [SYS_C0012413(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public java.lang.String getWritetime(){
		return writetime;
	}
	
	/**
	 * @Description 작성시간 [SYS_C0012413(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	@JsonProperty("writetime")
	public void setWritetime( java.lang.String writetime ) {
		isSet_writetime = true;
		this.writetime = writetime;
	}
	
	/** Property set << writetime >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << writeseq >> [[ */
	
	@XmlTransient
	private boolean isSet_writeseq = false;
	
	protected boolean isSet_writeseq()
	{
		return this.isSet_writeseq;
	}
	
	protected void setIsSet_writeseq(boolean value)
	{
		this.isSet_writeseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 작성순번 [SYS_C0012414(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public void setWriteseq(java.lang.String value) {
		isSet_writeseq = true;
		this.writeseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 작성순번 [SYS_C0012414(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public void setWriteseq(double value) {
		isSet_writeseq = true;
		this.writeseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 작성순번 [SYS_C0012414(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public void setWriteseq(long value) {
		isSet_writeseq = true;
		this.writeseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="작성순번 [SYS_C0012414(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal writeseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 작성순번 [SYS_C0012414(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	public java.math.BigDecimal getWriteseq(){
		return writeseq;
	}
	
	/**
	 * @Description 작성순번 [SYS_C0012414(C),SYS_C0012955(P) SYS_C0012955(UNIQUE)]
	 */
	@JsonProperty("writeseq")
	public void setWriteseq( java.math.BigDecimal writeseq ) {
		isSet_writeseq = true;
		this.writeseq = writeseq;
	}
	
	/** Property set << writeseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << buildno >> [[ */
	
	@XmlTransient
	private boolean isSet_buildno = false;
	
	protected boolean isSet_buildno()
	{
		return this.isSet_buildno;
	}
	
	protected void setIsSet_buildno(boolean value)
	{
		this.isSet_buildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동 [SYS_C0012415(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String buildno  = null;
	
	/**
	 * @Description 동 [SYS_C0012415(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getBuildno(){
		return buildno;
	}
	
	/**
	 * @Description 동 [SYS_C0012415(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("buildno")
	public void setBuildno( java.lang.String buildno ) {
		isSet_buildno = true;
		this.buildno = buildno;
	}
	
	/** Property set << buildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << houseno >> [[ */
	
	@XmlTransient
	private boolean isSet_houseno = false;
	
	protected boolean isSet_houseno()
	{
		return this.isSet_houseno;
	}
	
	protected void setIsSet_houseno(boolean value)
	{
		this.isSet_houseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="호 [SYS_C0012416(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String houseno  = null;
	
	/**
	 * @Description 호 [SYS_C0012416(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getHouseno(){
		return houseno;
	}
	
	/**
	 * @Description 호 [SYS_C0012416(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("houseno")
	public void setHouseno( java.lang.String houseno ) {
		isSet_houseno = true;
		this.houseno = houseno;
	}
	
	/** Property set << houseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << dongho >> [[ */
	
	@XmlTransient
	private boolean isSet_dongho = false;
	
	protected boolean isSet_dongho()
	{
		return this.isSet_dongho;
	}
	
	protected void setIsSet_dongho(boolean value)
	{
		this.isSet_dongho = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="동호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String dongho  = null;
	
	/**
	 * @Description 동호
	 */
	public java.lang.String getDongho(){
		return dongho;
	}
	
	/**
	 * @Description 동호
	 */
	@JsonProperty("dongho")
	public void setDongho( java.lang.String dongho ) {
		isSet_dongho = true;
		this.dongho = dongho;
	}
	
	/** Property set << dongho >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custName >> [[ */
	
	@XmlTransient
	private boolean isSet_custName = false;
	
	protected boolean isSet_custName()
	{
		return this.isSet_custName;
	}
	
	protected void setIsSet_custName(boolean value)
	{
		this.isSet_custName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="고객명", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String custName  = null;
	
	/**
	 * @Description 고객명
	 */
	public java.lang.String getCustName(){
		return custName;
	}
	
	/**
	 * @Description 고객명
	 */
	@JsonProperty("custName")
	public void setCustName( java.lang.String custName ) {
		isSet_custName = true;
		this.custName = custName;
	}
	
	/** Property set << custName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << square >> [[ */
	
	@XmlTransient
	private boolean isSet_square = false;
	
	protected boolean isSet_square()
	{
		return this.isSet_square;
	}
	
	protected void setIsSet_square(boolean value)
	{
		this.isSet_square = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 평형
	 */
	public void setSquare(java.lang.String value) {
		isSet_square = true;
		this.square = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 평형
	 */
	public void setSquare(double value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 평형
	 */
	public void setSquare(long value) {
		isSet_square = true;
		this.square = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal square  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 평형
	 */
	public java.math.BigDecimal getSquare(){
		return square;
	}
	
	/**
	 * @Description 평형
	 */
	@JsonProperty("square")
	public void setSquare( java.math.BigDecimal square ) {
		isSet_square = true;
		this.square = square;
	}
	
	/** Property set << square >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << type >> [[ */
	
	@XmlTransient
	private boolean isSet_type = false;
	
	protected boolean isSet_type()
	{
		return this.isSet_type;
	}
	
	protected void setIsSet_type(boolean value)
	{
		this.isSet_type = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="타입", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String type  = null;
	
	/**
	 * @Description 타입
	 */
	public java.lang.String getType(){
		return type;
	}
	
	/**
	 * @Description 타입
	 */
	@JsonProperty("type")
	public void setType( java.lang.String type ) {
		isSet_type = true;
		this.type = type;
	}
	
	/** Property set << type >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << classJrw >> [[ */
	
	@XmlTransient
	private boolean isSet_classJrw = false;
	
	protected boolean isSet_classJrw()
	{
		return this.isSet_classJrw;
	}
	
	protected void setIsSet_classJrw(boolean value)
	{
		this.isSet_classJrw = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="군", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String classJrw  = null;
	
	/**
	 * @Description 군
	 */
	public java.lang.String getClassJrw(){
		return classJrw;
	}
	
	/**
	 * @Description 군
	 */
	@JsonProperty("classJrw")
	public void setClassJrw( java.lang.String classJrw ) {
		isSet_classJrw = true;
		this.classJrw = classJrw;
	}
	
	/** Property set << classJrw >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << optioncode >> [[ */
	
	@XmlTransient
	private boolean isSet_optioncode = false;
	
	protected boolean isSet_optioncode()
	{
		return this.isSet_optioncode;
	}
	
	protected void setIsSet_optioncode(boolean value)
	{
		this.isSet_optioncode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선택사양코드", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String optioncode  = null;
	
	/**
	 * @Description 선택사양코드
	 */
	public java.lang.String getOptioncode(){
		return optioncode;
	}
	
	/**
	 * @Description 선택사양코드
	 */
	@JsonProperty("optioncode")
	public void setOptioncode( java.lang.String optioncode ) {
		isSet_optioncode = true;
		this.optioncode = optioncode;
	}
	
	/** Property set << optioncode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contracttag >> [[ */
	
	@XmlTransient
	private boolean isSet_contracttag = false;
	
	protected boolean isSet_contracttag()
	{
		return this.isSet_contracttag;
	}
	
	protected void setIsSet_contracttag(boolean value)
	{
		this.isSet_contracttag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약구분 [SYS_C0012417(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String contracttag  = null;
	
	/**
	 * @Description 계약구분 [SYS_C0012417(C)]
	 */
	public java.lang.String getContracttag(){
		return contracttag;
	}
	
	/**
	 * @Description 계약구분 [SYS_C0012417(C)]
	 */
	@JsonProperty("contracttag")
	public void setContracttag( java.lang.String contracttag ) {
		isSet_contracttag = true;
		this.contracttag = contracttag;
	}
	
	/** Property set << contracttag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contractdate >> [[ */
	
	@XmlTransient
	private boolean isSet_contractdate = false;
	
	protected boolean isSet_contractdate()
	{
		return this.isSet_contractdate;
	}
	
	protected void setIsSet_contractdate(boolean value)
	{
		this.isSet_contractdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약일자 [SYS_C0012418(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String contractdate  = null;
	
	/**
	 * @Description 계약일자 [SYS_C0012418(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getContractdate(){
		return contractdate;
	}
	
	/**
	 * @Description 계약일자 [SYS_C0012418(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("contractdate")
	public void setContractdate( java.lang.String contractdate ) {
		isSet_contractdate = true;
		this.contractdate = contractdate;
	}
	
	/** Property set << contractdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contractno >> [[ */
	
	@XmlTransient
	private boolean isSet_contractno = false;
	
	protected boolean isSet_contractno()
	{
		return this.isSet_contractno;
	}
	
	protected void setIsSet_contractno(boolean value)
	{
		this.isSet_contractno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약번호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String contractno  = null;
	
	/**
	 * @Description 계약번호
	 */
	public java.lang.String getContractno(){
		return contractno;
	}
	
	/**
	 * @Description 계약번호
	 */
	@JsonProperty("contractno")
	public void setContractno( java.lang.String contractno ) {
		isSet_contractno = true;
		this.contractno = contractno;
	}
	
	/** Property set << contractno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << loanTag >> [[ */
	
	@XmlTransient
	private boolean isSet_loanTag = false;
	
	protected boolean isSet_loanTag()
	{
		return this.isSet_loanTag;
	}
	
	protected void setIsSet_loanTag(boolean value)
	{
		this.isSet_loanTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String loanTag  = null;
	
	/**
	 * @Description 대출여부
	 */
	public java.lang.String getLoanTag(){
		return loanTag;
	}
	
	/**
	 * @Description 대출여부
	 */
	@JsonProperty("loanTag")
	public void setLoanTag( java.lang.String loanTag ) {
		isSet_loanTag = true;
		this.loanTag = loanTag;
	}
	
	/** Property set << loanTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << leasetag >> [[ */
	
	@XmlTransient
	private boolean isSet_leasetag = false;
	
	protected boolean isSet_leasetag()
	{
		return this.isSet_leasetag;
	}
	
	protected void setIsSet_leasetag(boolean value)
	{
		this.isSet_leasetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String leasetag  = null;
	
	/**
	 * @Description 임대여부
	 */
	public java.lang.String getLeasetag(){
		return leasetag;
	}
	
	/**
	 * @Description 임대여부
	 */
	@JsonProperty("leasetag")
	public void setLeasetag( java.lang.String leasetag ) {
		isSet_leasetag = true;
		this.leasetag = leasetag;
	}
	
	/** Property set << leasetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << lastchangedate >> [[ */
	
	@XmlTransient
	private boolean isSet_lastchangedate = false;
	
	protected boolean isSet_lastchangedate()
	{
		return this.isSet_lastchangedate;
	}
	
	protected void setIsSet_lastchangedate(boolean value)
	{
		this.isSet_lastchangedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="최종변경계약일 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String lastchangedate  = null;
	
	/**
	 * @Description 최종변경계약일 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getLastchangedate(){
		return lastchangedate;
	}
	
	/**
	 * @Description 최종변경계약일 [XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("lastchangedate")
	public void setLastchangedate( java.lang.String lastchangedate ) {
		isSet_lastchangedate = true;
		this.lastchangedate = lastchangedate;
	}
	
	/** Property set << lastchangedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changetag >> [[ */
	
	@XmlTransient
	private boolean isSet_changetag = false;
	
	protected boolean isSet_changetag()
	{
		return this.isSet_changetag;
	}
	
	protected void setIsSet_changetag(boolean value)
	{
		this.isSet_changetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경구분 [SYS_C0012419(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String changetag  = null;
	
	/**
	 * @Description 변경구분 [SYS_C0012419(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getChangetag(){
		return changetag;
	}
	
	/**
	 * @Description 변경구분 [SYS_C0012419(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("changetag")
	public void setChangetag( java.lang.String changetag ) {
		isSet_changetag = true;
		this.changetag = changetag;
	}
	
	/** Property set << changetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << changedate >> [[ */
	
	@XmlTransient
	private boolean isSet_changedate = false;
	
	protected boolean isSet_changedate()
	{
		return this.isSet_changedate;
	}
	
	protected void setIsSet_changedate(boolean value)
	{
		this.isSet_changedate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경일자 [SYS_C0012420(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String changedate  = null;
	
	/**
	 * @Description 변경일자 [SYS_C0012420(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	public java.lang.String getChangedate(){
		return changedate;
	}
	
	/**
	 * @Description 변경일자 [SYS_C0012420(C) XIE1HD_HOUS_SELL_LOG(NONUNIQUE)]
	 */
	@JsonProperty("changedate")
	public void setChangedate( java.lang.String changedate ) {
		isSet_changedate = true;
		this.changedate = changedate;
	}
	
	/** Property set << changedate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelReason >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelReason = false;
	
	protected boolean isSet_cancelReason()
	{
		return this.isSet_cancelReason;
	}
	
	protected void setIsSet_cancelReason(boolean value)
	{
		this.isSet_cancelReason = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경사유", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelReason  = null;
	
	/**
	 * @Description 변경사유
	 */
	public java.lang.String getCancelReason(){
		return cancelReason;
	}
	
	/**
	 * @Description 변경사유
	 */
	@JsonProperty("cancelReason")
	public void setCancelReason( java.lang.String cancelReason ) {
		isSet_cancelReason = true;
		this.cancelReason = cancelReason;
	}
	
	/** Property set << cancelReason >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << childBuildno >> [[ */
	
	@XmlTransient
	private boolean isSet_childBuildno = false;
	
	protected boolean isSet_childBuildno()
	{
		return this.isSet_childBuildno;
	}
	
	protected void setIsSet_childBuildno(boolean value)
	{
		this.isSet_childBuildno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경동", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String childBuildno  = null;
	
	/**
	 * @Description 변경동
	 */
	public java.lang.String getChildBuildno(){
		return childBuildno;
	}
	
	/**
	 * @Description 변경동
	 */
	@JsonProperty("childBuildno")
	public void setChildBuildno( java.lang.String childBuildno ) {
		isSet_childBuildno = true;
		this.childBuildno = childBuildno;
	}
	
	/** Property set << childBuildno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << childHouseno >> [[ */
	
	@XmlTransient
	private boolean isSet_childHouseno = false;
	
	protected boolean isSet_childHouseno()
	{
		return this.isSet_childHouseno;
	}
	
	protected void setIsSet_childHouseno(boolean value)
	{
		this.isSet_childHouseno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="변경호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String childHouseno  = null;
	
	/**
	 * @Description 변경호
	 */
	public java.lang.String getChildHouseno(){
		return childHouseno;
	}
	
	/**
	 * @Description 변경호
	 */
	@JsonProperty("childHouseno")
	public void setChildHouseno( java.lang.String childHouseno ) {
		isSet_childHouseno = true;
		this.childHouseno = childHouseno;
	}
	
	/** Property set << childHouseno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << relaCustcode >> [[ */
	
	@XmlTransient
	private boolean isSet_relaCustcode = false;
	
	protected boolean isSet_relaCustcode()
	{
		return this.isSet_relaCustcode;
	}
	
	protected void setIsSet_relaCustcode(boolean value)
	{
		this.isSet_relaCustcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연계고객코드", formatType="", format="", align="left", length=13, decimal=0, arrayReference="", fill="")
	private java.lang.String relaCustcode  = null;
	
	/**
	 * @Description 연계고객코드
	 */
	public java.lang.String getRelaCustcode(){
		return relaCustcode;
	}
	
	/**
	 * @Description 연계고객코드
	 */
	@JsonProperty("relaCustcode")
	public void setRelaCustcode( java.lang.String relaCustcode ) {
		isSet_relaCustcode = true;
		this.relaCustcode = relaCustcode;
	}
	
	/** Property set << relaCustcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << relaSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_relaSeq = false;
	
	protected boolean isSet_relaSeq()
	{
		return this.isSet_relaSeq;
	}
	
	protected void setIsSet_relaSeq(boolean value)
	{
		this.isSet_relaSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 연계고객순번
	 */
	public void setRelaSeq(java.lang.String value) {
		isSet_relaSeq = true;
		this.relaSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 연계고객순번
	 */
	public void setRelaSeq(double value) {
		isSet_relaSeq = true;
		this.relaSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 연계고객순번
	 */
	public void setRelaSeq(long value) {
		isSet_relaSeq = true;
		this.relaSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="연계고객순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal relaSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 연계고객순번
	 */
	public java.math.BigDecimal getRelaSeq(){
		return relaSeq;
	}
	
	/**
	 * @Description 연계고객순번
	 */
	@JsonProperty("relaSeq")
	public void setRelaSeq( java.math.BigDecimal relaSeq ) {
		isSet_relaSeq = true;
		this.relaSeq = relaSeq;
	}
	
	/** Property set << relaSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vattag >> [[ */
	
	@XmlTransient
	private boolean isSet_vattag = false;
	
	protected boolean isSet_vattag()
	{
		return this.isSet_vattag;
	}
	
	protected void setIsSet_vattag(boolean value)
	{
		this.isSet_vattag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="부가세여부 [SYS_C0012421(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String vattag  = null;
	
	/**
	 * @Description 부가세여부 [SYS_C0012421(C)]
	 */
	public java.lang.String getVattag(){
		return vattag;
	}
	
	/**
	 * @Description 부가세여부 [SYS_C0012421(C)]
	 */
	@JsonProperty("vattag")
	public void setVattag( java.lang.String vattag ) {
		isSet_vattag = true;
		this.vattag = vattag;
	}
	
	/** Property set << vattag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << exclusivearea >> [[ */
	
	@XmlTransient
	private boolean isSet_exclusivearea = false;
	
	protected boolean isSet_exclusivearea()
	{
		return this.isSet_exclusivearea;
	}
	
	protected void setIsSet_exclusivearea(boolean value)
	{
		this.isSet_exclusivearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 전용면적 [SYS_C0012422(C)]
	 */
	public void setExclusivearea(java.lang.String value) {
		isSet_exclusivearea = true;
		this.exclusivearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 전용면적 [SYS_C0012422(C)]
	 */
	public void setExclusivearea(double value) {
		isSet_exclusivearea = true;
		this.exclusivearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 전용면적 [SYS_C0012422(C)]
	 */
	public void setExclusivearea(long value) {
		isSet_exclusivearea = true;
		this.exclusivearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="전용면적 [SYS_C0012422(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal exclusivearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 전용면적 [SYS_C0012422(C)]
	 */
	public java.math.BigDecimal getExclusivearea(){
		return exclusivearea;
	}
	
	/**
	 * @Description 전용면적 [SYS_C0012422(C)]
	 */
	@JsonProperty("exclusivearea")
	public void setExclusivearea( java.math.BigDecimal exclusivearea ) {
		isSet_exclusivearea = true;
		this.exclusivearea = exclusivearea;
	}
	
	/** Property set << exclusivearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << commonarea >> [[ */
	
	@XmlTransient
	private boolean isSet_commonarea = false;
	
	protected boolean isSet_commonarea()
	{
		return this.isSet_commonarea;
	}
	
	protected void setIsSet_commonarea(boolean value)
	{
		this.isSet_commonarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주거공용면적 [SYS_C0012423(C)]
	 */
	public void setCommonarea(java.lang.String value) {
		isSet_commonarea = true;
		this.commonarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주거공용면적 [SYS_C0012423(C)]
	 */
	public void setCommonarea(double value) {
		isSet_commonarea = true;
		this.commonarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주거공용면적 [SYS_C0012423(C)]
	 */
	public void setCommonarea(long value) {
		isSet_commonarea = true;
		this.commonarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주거공용면적 [SYS_C0012423(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal commonarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주거공용면적 [SYS_C0012423(C)]
	 */
	public java.math.BigDecimal getCommonarea(){
		return commonarea;
	}
	
	/**
	 * @Description 주거공용면적 [SYS_C0012423(C)]
	 */
	@JsonProperty("commonarea")
	public void setCommonarea( java.math.BigDecimal commonarea ) {
		isSet_commonarea = true;
		this.commonarea = commonarea;
	}
	
	/** Property set << commonarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etccommonarea >> [[ */
	
	@XmlTransient
	private boolean isSet_etccommonarea = false;
	
	protected boolean isSet_etccommonarea()
	{
		return this.isSet_etccommonarea;
	}
	
	protected void setIsSet_etccommonarea(boolean value)
	{
		this.isSet_etccommonarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공용면적 [SYS_C0012424(C)]
	 */
	public void setEtccommonarea(java.lang.String value) {
		isSet_etccommonarea = true;
		this.etccommonarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공용면적 [SYS_C0012424(C)]
	 */
	public void setEtccommonarea(double value) {
		isSet_etccommonarea = true;
		this.etccommonarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공용면적 [SYS_C0012424(C)]
	 */
	public void setEtccommonarea(long value) {
		isSet_etccommonarea = true;
		this.etccommonarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공용면적 [SYS_C0012424(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal etccommonarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공용면적 [SYS_C0012424(C)]
	 */
	public java.math.BigDecimal getEtccommonarea(){
		return etccommonarea;
	}
	
	/**
	 * @Description 기타공용면적 [SYS_C0012424(C)]
	 */
	@JsonProperty("etccommonarea")
	public void setEtccommonarea( java.math.BigDecimal etccommonarea ) {
		isSet_etccommonarea = true;
		this.etccommonarea = etccommonarea;
	}
	
	/** Property set << etccommonarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << parkingarea >> [[ */
	
	@XmlTransient
	private boolean isSet_parkingarea = false;
	
	protected boolean isSet_parkingarea()
	{
		return this.isSet_parkingarea;
	}
	
	protected void setIsSet_parkingarea(boolean value)
	{
		this.isSet_parkingarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주차장면적 [SYS_C0012425(C)]
	 */
	public void setParkingarea(java.lang.String value) {
		isSet_parkingarea = true;
		this.parkingarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주차장면적 [SYS_C0012425(C)]
	 */
	public void setParkingarea(double value) {
		isSet_parkingarea = true;
		this.parkingarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주차장면적 [SYS_C0012425(C)]
	 */
	public void setParkingarea(long value) {
		isSet_parkingarea = true;
		this.parkingarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주차장면적 [SYS_C0012425(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal parkingarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주차장면적 [SYS_C0012425(C)]
	 */
	public java.math.BigDecimal getParkingarea(){
		return parkingarea;
	}
	
	/**
	 * @Description 주차장면적 [SYS_C0012425(C)]
	 */
	@JsonProperty("parkingarea")
	public void setParkingarea( java.math.BigDecimal parkingarea ) {
		isSet_parkingarea = true;
		this.parkingarea = parkingarea;
	}
	
	/** Property set << parkingarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << servicearea >> [[ */
	
	@XmlTransient
	private boolean isSet_servicearea = false;
	
	protected boolean isSet_servicearea()
	{
		return this.isSet_servicearea;
	}
	
	protected void setIsSet_servicearea(boolean value)
	{
		this.isSet_servicearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 서비스면적 [SYS_C0012426(C)]
	 */
	public void setServicearea(java.lang.String value) {
		isSet_servicearea = true;
		this.servicearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 서비스면적 [SYS_C0012426(C)]
	 */
	public void setServicearea(double value) {
		isSet_servicearea = true;
		this.servicearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 서비스면적 [SYS_C0012426(C)]
	 */
	public void setServicearea(long value) {
		isSet_servicearea = true;
		this.servicearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="서비스면적 [SYS_C0012426(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal servicearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 서비스면적 [SYS_C0012426(C)]
	 */
	public java.math.BigDecimal getServicearea(){
		return servicearea;
	}
	
	/**
	 * @Description 서비스면적 [SYS_C0012426(C)]
	 */
	@JsonProperty("servicearea")
	public void setServicearea( java.math.BigDecimal servicearea ) {
		isSet_servicearea = true;
		this.servicearea = servicearea;
	}
	
	/** Property set << servicearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sitearea >> [[ */
	
	@XmlTransient
	private boolean isSet_sitearea = false;
	
	protected boolean isSet_sitearea()
	{
		return this.isSet_sitearea;
	}
	
	protected void setIsSet_sitearea(boolean value)
	{
		this.isSet_sitearea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 대지면적 [SYS_C0012427(C)]
	 */
	public void setSitearea(java.lang.String value) {
		isSet_sitearea = true;
		this.sitearea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 대지면적 [SYS_C0012427(C)]
	 */
	public void setSitearea(double value) {
		isSet_sitearea = true;
		this.sitearea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 대지면적 [SYS_C0012427(C)]
	 */
	public void setSitearea(long value) {
		isSet_sitearea = true;
		this.sitearea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="대지면적 [SYS_C0012427(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sitearea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 대지면적 [SYS_C0012427(C)]
	 */
	public java.math.BigDecimal getSitearea(){
		return sitearea;
	}
	
	/**
	 * @Description 대지면적 [SYS_C0012427(C)]
	 */
	@JsonProperty("sitearea")
	public void setSitearea( java.math.BigDecimal sitearea ) {
		isSet_sitearea = true;
		this.sitearea = sitearea;
	}
	
	/** Property set << sitearea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << moveinstartdate >> [[ */
	
	@XmlTransient
	private boolean isSet_moveinstartdate = false;
	
	protected boolean isSet_moveinstartdate()
	{
		return this.isSet_moveinstartdate;
	}
	
	protected void setIsSet_moveinstartdate(boolean value)
	{
		this.isSet_moveinstartdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주시작일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String moveinstartdate  = null;
	
	/**
	 * @Description 입주시작일자
	 */
	public java.lang.String getMoveinstartdate(){
		return moveinstartdate;
	}
	
	/**
	 * @Description 입주시작일자
	 */
	@JsonProperty("moveinstartdate")
	public void setMoveinstartdate( java.lang.String moveinstartdate ) {
		isSet_moveinstartdate = true;
		this.moveinstartdate = moveinstartdate;
	}
	
	/** Property set << moveinstartdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << moveinenddate >> [[ */
	
	@XmlTransient
	private boolean isSet_moveinenddate = false;
	
	protected boolean isSet_moveinenddate()
	{
		return this.isSet_moveinenddate;
	}
	
	protected void setIsSet_moveinenddate(boolean value)
	{
		this.isSet_moveinenddate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입주종료일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String moveinenddate  = null;
	
	/**
	 * @Description 입주종료일자
	 */
	public java.lang.String getMoveinenddate(){
		return moveinenddate;
	}
	
	/**
	 * @Description 입주종료일자
	 */
	@JsonProperty("moveinenddate")
	public void setMoveinenddate( java.lang.String moveinenddate ) {
		isSet_moveinenddate = true;
		this.moveinenddate = moveinenddate;
	}
	
	/** Property set << moveinenddate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << unionCnt >> [[ */
	
	@XmlTransient
	private boolean isSet_unionCnt = false;
	
	protected boolean isSet_unionCnt()
	{
		return this.isSet_unionCnt;
	}
	
	protected void setIsSet_unionCnt(boolean value)
	{
		this.isSet_unionCnt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 명의인원
	 */
	public void setUnionCnt(java.lang.String value) {
		isSet_unionCnt = true;
		this.unionCnt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 명의인원
	 */
	public void setUnionCnt(double value) {
		isSet_unionCnt = true;
		this.unionCnt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 명의인원
	 */
	public void setUnionCnt(long value) {
		isSet_unionCnt = true;
		this.unionCnt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="명의인원", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal unionCnt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 명의인원
	 */
	public java.math.BigDecimal getUnionCnt(){
		return unionCnt;
	}
	
	/**
	 * @Description 명의인원
	 */
	@JsonProperty("unionCnt")
	public void setUnionCnt( java.math.BigDecimal unionCnt ) {
		isSet_unionCnt = true;
		this.unionCnt = unionCnt;
	}
	
	/** Property set << unionCnt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << refundmentdate >> [[ */
	
	@XmlTransient
	private boolean isSet_refundmentdate = false;
	
	protected boolean isSet_refundmentdate()
	{
		return this.isSet_refundmentdate;
	}
	
	protected void setIsSet_refundmentdate(boolean value)
	{
		this.isSet_refundmentdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String refundmentdate  = null;
	
	/**
	 * @Description 환불일자
	 */
	public java.lang.String getRefundmentdate(){
		return refundmentdate;
	}
	
	/**
	 * @Description 환불일자
	 */
	@JsonProperty("refundmentdate")
	public void setRefundmentdate( java.lang.String refundmentdate ) {
		isSet_refundmentdate = true;
		this.refundmentdate = refundmentdate;
	}
	
	/** Property set << refundmentdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << refundmentamt >> [[ */
	
	@XmlTransient
	private boolean isSet_refundmentamt = false;
	
	protected boolean isSet_refundmentamt()
	{
		return this.isSet_refundmentamt;
	}
	
	protected void setIsSet_refundmentamt(boolean value)
	{
		this.isSet_refundmentamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 환불금액
	 */
	public void setRefundmentamt(java.lang.String value) {
		isSet_refundmentamt = true;
		this.refundmentamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 환불금액
	 */
	public void setRefundmentamt(double value) {
		isSet_refundmentamt = true;
		this.refundmentamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 환불금액
	 */
	public void setRefundmentamt(long value) {
		isSet_refundmentamt = true;
		this.refundmentamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="환불금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal refundmentamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 환불금액
	 */
	public java.math.BigDecimal getRefundmentamt(){
		return refundmentamt;
	}
	
	/**
	 * @Description 환불금액
	 */
	@JsonProperty("refundmentamt")
	public void setRefundmentamt( java.math.BigDecimal refundmentamt ) {
		isSet_refundmentamt = true;
		this.refundmentamt = refundmentamt;
	}
	
	/** Property set << refundmentamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << penaltyamt >> [[ */
	
	@XmlTransient
	private boolean isSet_penaltyamt = false;
	
	protected boolean isSet_penaltyamt()
	{
		return this.isSet_penaltyamt;
	}
	
	protected void setIsSet_penaltyamt(boolean value)
	{
		this.isSet_penaltyamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 위약금
	 */
	public void setPenaltyamt(java.lang.String value) {
		isSet_penaltyamt = true;
		this.penaltyamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 위약금
	 */
	public void setPenaltyamt(double value) {
		isSet_penaltyamt = true;
		this.penaltyamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 위약금
	 */
	public void setPenaltyamt(long value) {
		isSet_penaltyamt = true;
		this.penaltyamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="위약금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal penaltyamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 위약금
	 */
	public java.math.BigDecimal getPenaltyamt(){
		return penaltyamt;
	}
	
	/**
	 * @Description 위약금
	 */
	@JsonProperty("penaltyamt")
	public void setPenaltyamt( java.math.BigDecimal penaltyamt ) {
		isSet_penaltyamt = true;
		this.penaltyamt = penaltyamt;
	}
	
	/** Property set << penaltyamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << loanInterest >> [[ */
	
	@XmlTransient
	private boolean isSet_loanInterest = false;
	
	protected boolean isSet_loanInterest()
	{
		return this.isSet_loanInterest;
	}
	
	protected void setIsSet_loanInterest(boolean value)
	{
		this.isSet_loanInterest = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기간이자
	 */
	public void setLoanInterest(java.lang.String value) {
		isSet_loanInterest = true;
		this.loanInterest = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기간이자
	 */
	public void setLoanInterest(double value) {
		isSet_loanInterest = true;
		this.loanInterest = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기간이자
	 */
	public void setLoanInterest(long value) {
		isSet_loanInterest = true;
		this.loanInterest = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기간이자", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal loanInterest  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기간이자
	 */
	public java.math.BigDecimal getLoanInterest(){
		return loanInterest;
	}
	
	/**
	 * @Description 기간이자
	 */
	@JsonProperty("loanInterest")
	public void setLoanInterest( java.math.BigDecimal loanInterest ) {
		isSet_loanInterest = true;
		this.loanInterest = loanInterest;
	}
	
	/** Property set << loanInterest >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << sodukTax >> [[ */
	
	@XmlTransient
	private boolean isSet_sodukTax = false;
	
	protected boolean isSet_sodukTax()
	{
		return this.isSet_sodukTax;
	}
	
	protected void setIsSet_sodukTax(boolean value)
	{
		this.isSet_sodukTax = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 소득세
	 */
	public void setSodukTax(java.lang.String value) {
		isSet_sodukTax = true;
		this.sodukTax = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 소득세
	 */
	public void setSodukTax(double value) {
		isSet_sodukTax = true;
		this.sodukTax = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 소득세
	 */
	public void setSodukTax(long value) {
		isSet_sodukTax = true;
		this.sodukTax = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="소득세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal sodukTax  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 소득세
	 */
	public java.math.BigDecimal getSodukTax(){
		return sodukTax;
	}
	
	/**
	 * @Description 소득세
	 */
	@JsonProperty("sodukTax")
	public void setSodukTax( java.math.BigDecimal sodukTax ) {
		isSet_sodukTax = true;
		this.sodukTax = sodukTax;
	}
	
	/** Property set << sodukTax >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << juminTax >> [[ */
	
	@XmlTransient
	private boolean isSet_juminTax = false;
	
	protected boolean isSet_juminTax()
	{
		return this.isSet_juminTax;
	}
	
	protected void setIsSet_juminTax(boolean value)
	{
		this.isSet_juminTax = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 주민세
	 */
	public void setJuminTax(java.lang.String value) {
		isSet_juminTax = true;
		this.juminTax = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 주민세
	 */
	public void setJuminTax(double value) {
		isSet_juminTax = true;
		this.juminTax = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 주민세
	 */
	public void setJuminTax(long value) {
		isSet_juminTax = true;
		this.juminTax = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="주민세", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal juminTax  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 주민세
	 */
	public java.math.BigDecimal getJuminTax(){
		return juminTax;
	}
	
	/**
	 * @Description 주민세
	 */
	@JsonProperty("juminTax")
	public void setJuminTax( java.math.BigDecimal juminTax ) {
		isSet_juminTax = true;
		this.juminTax = juminTax;
	}
	
	/** Property set << juminTax >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankLoanOrgamt >> [[ */
	
	@XmlTransient
	private boolean isSet_bankLoanOrgamt = false;
	
	protected boolean isSet_bankLoanOrgamt()
	{
		return this.isSet_bankLoanOrgamt;
	}
	
	protected void setIsSet_bankLoanOrgamt(boolean value)
	{
		this.isSet_bankLoanOrgamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 은행대출금
	 */
	public void setBankLoanOrgamt(java.lang.String value) {
		isSet_bankLoanOrgamt = true;
		this.bankLoanOrgamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 은행대출금
	 */
	public void setBankLoanOrgamt(double value) {
		isSet_bankLoanOrgamt = true;
		this.bankLoanOrgamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 은행대출금
	 */
	public void setBankLoanOrgamt(long value) {
		isSet_bankLoanOrgamt = true;
		this.bankLoanOrgamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="은행대출금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal bankLoanOrgamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 은행대출금
	 */
	public java.math.BigDecimal getBankLoanOrgamt(){
		return bankLoanOrgamt;
	}
	
	/**
	 * @Description 은행대출금
	 */
	@JsonProperty("bankLoanOrgamt")
	public void setBankLoanOrgamt( java.math.BigDecimal bankLoanOrgamt ) {
		isSet_bankLoanOrgamt = true;
		this.bankLoanOrgamt = bankLoanOrgamt;
	}
	
	/** Property set << bankLoanOrgamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankLoanInterest >> [[ */
	
	@XmlTransient
	private boolean isSet_bankLoanInterest = false;
	
	protected boolean isSet_bankLoanInterest()
	{
		return this.isSet_bankLoanInterest;
	}
	
	protected void setIsSet_bankLoanInterest(boolean value)
	{
		this.isSet_bankLoanInterest = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 은행대출이자_당기
	 */
	public void setBankLoanInterest(java.lang.String value) {
		isSet_bankLoanInterest = true;
		this.bankLoanInterest = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 은행대출이자_당기
	 */
	public void setBankLoanInterest(double value) {
		isSet_bankLoanInterest = true;
		this.bankLoanInterest = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 은행대출이자_당기
	 */
	public void setBankLoanInterest(long value) {
		isSet_bankLoanInterest = true;
		this.bankLoanInterest = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="은행대출이자_당기", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal bankLoanInterest  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 은행대출이자_당기
	 */
	public java.math.BigDecimal getBankLoanInterest(){
		return bankLoanInterest;
	}
	
	/**
	 * @Description 은행대출이자_당기
	 */
	@JsonProperty("bankLoanInterest")
	public void setBankLoanInterest( java.math.BigDecimal bankLoanInterest ) {
		isSet_bankLoanInterest = true;
		this.bankLoanInterest = bankLoanInterest;
	}
	
	/** Property set << bankLoanInterest >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << loanbank >> [[ */
	
	@XmlTransient
	private boolean isSet_loanbank = false;
	
	protected boolean isSet_loanbank()
	{
		return this.isSet_loanbank;
	}
	
	protected void setIsSet_loanbank(boolean value)
	{
		this.isSet_loanbank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출은행", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String loanbank  = null;
	
	/**
	 * @Description 대출은행
	 */
	public java.lang.String getLoanbank(){
		return loanbank;
	}
	
	/**
	 * @Description 대출은행
	 */
	@JsonProperty("loanbank")
	public void setLoanbank( java.lang.String loanbank ) {
		isSet_loanbank = true;
		this.loanbank = loanbank;
	}
	
	/** Property set << loanbank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << loandeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_loandeposit = false;
	
	protected boolean isSet_loandeposit()
	{
		return this.isSet_loandeposit;
	}
	
	protected void setIsSet_loandeposit(boolean value)
	{
		this.isSet_loandeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출은행계좌", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String loandeposit  = null;
	
	/**
	 * @Description 대출은행계좌
	 */
	public java.lang.String getLoandeposit(){
		return loandeposit;
	}
	
	/**
	 * @Description 대출은행계좌
	 */
	@JsonProperty("loandeposit")
	public void setLoandeposit( java.lang.String loandeposit ) {
		isSet_loandeposit = true;
		this.loandeposit = loandeposit;
	}
	
	/** Property set << loandeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << loanuser >> [[ */
	
	@XmlTransient
	private boolean isSet_loanuser = false;
	
	protected boolean isSet_loanuser()
	{
		return this.isSet_loanuser;
	}
	
	protected void setIsSet_loanuser(boolean value)
	{
		this.isSet_loanuser = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대출은행예금주", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String loanuser  = null;
	
	/**
	 * @Description 대출은행예금주
	 */
	public java.lang.String getLoanuser(){
		return loanuser;
	}
	
	/**
	 * @Description 대출은행예금주
	 */
	@JsonProperty("loanuser")
	public void setLoanuser( java.lang.String loanuser ) {
		isSet_loanuser = true;
		this.loanuser = loanuser;
	}
	
	/** Property set << loanuser >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << refundDeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_refundDeposit = false;
	
	protected boolean isSet_refundDeposit()
	{
		return this.isSet_refundDeposit;
	}
	
	protected void setIsSet_refundDeposit(boolean value)
	{
		this.isSet_refundDeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불계좌번호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String refundDeposit  = null;
	
	/**
	 * @Description 환불계좌번호
	 */
	public java.lang.String getRefundDeposit(){
		return refundDeposit;
	}
	
	/**
	 * @Description 환불계좌번호
	 */
	@JsonProperty("refundDeposit")
	public void setRefundDeposit( java.lang.String refundDeposit ) {
		isSet_refundDeposit = true;
		this.refundDeposit = refundDeposit;
	}
	
	/** Property set << refundDeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << refundBank >> [[ */
	
	@XmlTransient
	private boolean isSet_refundBank = false;
	
	protected boolean isSet_refundBank()
	{
		return this.isSet_refundBank;
	}
	
	protected void setIsSet_refundBank(boolean value)
	{
		this.isSet_refundBank = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="환불은행명칭", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String refundBank  = null;
	
	/**
	 * @Description 환불은행명칭
	 */
	public java.lang.String getRefundBank(){
		return refundBank;
	}
	
	/**
	 * @Description 환불은행명칭
	 */
	@JsonProperty("refundBank")
	public void setRefundBank( java.lang.String refundBank ) {
		isSet_refundBank = true;
		this.refundBank = refundBank;
	}
	
	/** Property set << refundBank >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << compLoanamt >> [[ */
	
	@XmlTransient
	private boolean isSet_compLoanamt = false;
	
	protected boolean isSet_compLoanamt()
	{
		return this.isSet_compLoanamt;
	}
	
	protected void setIsSet_compLoanamt(boolean value)
	{
		this.isSet_compLoanamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 국민주택기금
	 */
	public void setCompLoanamt(java.lang.String value) {
		isSet_compLoanamt = true;
		this.compLoanamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 국민주택기금
	 */
	public void setCompLoanamt(double value) {
		isSet_compLoanamt = true;
		this.compLoanamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 국민주택기금
	 */
	public void setCompLoanamt(long value) {
		isSet_compLoanamt = true;
		this.compLoanamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="국민주택기금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal compLoanamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 국민주택기금
	 */
	public java.math.BigDecimal getCompLoanamt(){
		return compLoanamt;
	}
	
	/**
	 * @Description 국민주택기금
	 */
	@JsonProperty("compLoanamt")
	public void setCompLoanamt( java.math.BigDecimal compLoanamt ) {
		isSet_compLoanamt = true;
		this.compLoanamt = compLoanamt;
	}
	
	/** Property set << compLoanamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << billReturnamt >> [[ */
	
	@XmlTransient
	private boolean isSet_billReturnamt = false;
	
	protected boolean isSet_billReturnamt()
	{
		return this.isSet_billReturnamt;
	}
	
	protected void setIsSet_billReturnamt(boolean value)
	{
		this.isSet_billReturnamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 채권상환금액 [SYS_C0012428(C)]
	 */
	public void setBillReturnamt(java.lang.String value) {
		isSet_billReturnamt = true;
		this.billReturnamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 채권상환금액 [SYS_C0012428(C)]
	 */
	public void setBillReturnamt(double value) {
		isSet_billReturnamt = true;
		this.billReturnamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 채권상환금액 [SYS_C0012428(C)]
	 */
	public void setBillReturnamt(long value) {
		isSet_billReturnamt = true;
		this.billReturnamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="채권상환금액 [SYS_C0012428(C)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal billReturnamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 채권상환금액 [SYS_C0012428(C)]
	 */
	public java.math.BigDecimal getBillReturnamt(){
		return billReturnamt;
	}
	
	/**
	 * @Description 채권상환금액 [SYS_C0012428(C)]
	 */
	@JsonProperty("billReturnamt")
	public void setBillReturnamt( java.math.BigDecimal billReturnamt ) {
		isSet_billReturnamt = true;
		this.billReturnamt = billReturnamt;
	}
	
	/** Property set << billReturnamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << delayIndeminity >> [[ */
	
	@XmlTransient
	private boolean isSet_delayIndeminity = false;
	
	protected boolean isSet_delayIndeminity()
	{
		return this.isSet_delayIndeminity;
	}
	
	protected void setIsSet_delayIndeminity(boolean value)
	{
		this.isSet_delayIndeminity = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 지체보상금
	 */
	public void setDelayIndeminity(java.lang.String value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 지체보상금
	 */
	public void setDelayIndeminity(double value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 지체보상금
	 */
	public void setDelayIndeminity(long value) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="지체보상금", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal delayIndeminity  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 지체보상금
	 */
	public java.math.BigDecimal getDelayIndeminity(){
		return delayIndeminity;
	}
	
	/**
	 * @Description 지체보상금
	 */
	@JsonProperty("delayIndeminity")
	public void setDelayIndeminity( java.math.BigDecimal delayIndeminity ) {
		isSet_delayIndeminity = true;
		this.delayIndeminity = delayIndeminity;
	}
	
	/** Property set << delayIndeminity >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depositCount >> [[ */
	
	@XmlTransient
	private boolean isSet_depositCount = false;
	
	protected boolean isSet_depositCount()
	{
		return this.isSet_depositCount;
	}
	
	protected void setIsSet_depositCount(boolean value)
	{
		this.isSet_depositCount = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 구좌수
	 */
	public void setDepositCount(java.lang.String value) {
		isSet_depositCount = true;
		this.depositCount = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 구좌수
	 */
	public void setDepositCount(double value) {
		isSet_depositCount = true;
		this.depositCount = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 구좌수
	 */
	public void setDepositCount(long value) {
		isSet_depositCount = true;
		this.depositCount = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="구좌수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal depositCount  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 구좌수
	 */
	public java.math.BigDecimal getDepositCount(){
		return depositCount;
	}
	
	/**
	 * @Description 구좌수
	 */
	@JsonProperty("depositCount")
	public void setDepositCount( java.math.BigDecimal depositCount ) {
		isSet_depositCount = true;
		this.depositCount = depositCount;
	}
	
	/** Property set << depositCount >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << coCustcode >> [[ */
	
	@XmlTransient
	private boolean isSet_coCustcode = false;
	
	protected boolean isSet_coCustcode()
	{
		return this.isSet_coCustcode;
	}
	
	protected void setIsSet_coCustcode(boolean value)
	{
		this.isSet_coCustcode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사업자코드", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String coCustcode  = null;
	
	/**
	 * @Description 사업자코드
	 */
	public java.lang.String getCoCustcode(){
		return coCustcode;
	}
	
	/**
	 * @Description 사업자코드
	 */
	@JsonProperty("coCustcode")
	public void setCoCustcode( java.lang.String coCustcode ) {
		isSet_coCustcode = true;
		this.coCustcode = coCustcode;
	}
	
	/** Property set << coCustcode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << coSangho >> [[ */
	
	@XmlTransient
	private boolean isSet_coSangho = false;
	
	protected boolean isSet_coSangho()
	{
		return this.isSet_coSangho;
	}
	
	protected void setIsSet_coSangho(boolean value)
	{
		this.isSet_coSangho = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="상호", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String coSangho  = null;
	
	/**
	 * @Description 상호
	 */
	public java.lang.String getCoSangho(){
		return coSangho;
	}
	
	/**
	 * @Description 상호
	 */
	@JsonProperty("coSangho")
	public void setCoSangho( java.lang.String coSangho ) {
		isSet_coSangho = true;
		this.coSangho = coSangho;
	}
	
	/** Property set << coSangho >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << coCondition >> [[ */
	
	@XmlTransient
	private boolean isSet_coCondition = false;
	
	protected boolean isSet_coCondition()
	{
		return this.isSet_coCondition;
	}
	
	protected void setIsSet_coCondition(boolean value)
	{
		this.isSet_coCondition = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="업태", formatType="", format="", align="left", length=30, decimal=0, arrayReference="", fill="")
	private java.lang.String coCondition  = null;
	
	/**
	 * @Description 업태
	 */
	public java.lang.String getCoCondition(){
		return coCondition;
	}
	
	/**
	 * @Description 업태
	 */
	@JsonProperty("coCondition")
	public void setCoCondition( java.lang.String coCondition ) {
		isSet_coCondition = true;
		this.coCondition = coCondition;
	}
	
	/** Property set << coCondition >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << coCategory >> [[ */
	
	@XmlTransient
	private boolean isSet_coCategory = false;
	
	protected boolean isSet_coCategory()
	{
		return this.isSet_coCategory;
	}
	
	protected void setIsSet_coCategory(boolean value)
	{
		this.isSet_coCategory = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="업종", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String coCategory  = null;
	
	/**
	 * @Description 업종
	 */
	public java.lang.String getCoCategory(){
		return coCategory;
	}
	
	/**
	 * @Description 업종
	 */
	@JsonProperty("coCategory")
	public void setCoCategory( java.lang.String coCategory ) {
		isSet_coCategory = true;
		this.coCategory = coCategory;
	}
	
	/** Property set << coCategory >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << categoryName >> [[ */
	
	@XmlTransient
	private boolean isSet_categoryName = false;
	
	protected boolean isSet_categoryName()
	{
		return this.isSet_categoryName;
	}
	
	protected void setIsSet_categoryName(boolean value)
	{
		this.isSet_categoryName = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약업종코드", formatType="", format="", align="left", length=40, decimal=0, arrayReference="", fill="")
	private java.lang.String categoryName  = null;
	
	/**
	 * @Description 계약업종코드
	 */
	public java.lang.String getCategoryName(){
		return categoryName;
	}
	
	/**
	 * @Description 계약업종코드
	 */
	@JsonProperty("categoryName")
	public void setCategoryName( java.lang.String categoryName ) {
		isSet_categoryName = true;
		this.categoryName = categoryName;
	}
	
	/** Property set << categoryName >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipdate >> [[ */
	
	@XmlTransient
	private boolean isSet_slipdate = false;
	
	protected boolean isSet_slipdate()
	{
		return this.isSet_slipdate;
	}
	
	protected void setIsSet_slipdate(boolean value)
	{
		this.isSet_slipdate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="해약전표일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String slipdate  = null;
	
	/**
	 * @Description 해약전표일자
	 */
	public java.lang.String getSlipdate(){
		return slipdate;
	}
	
	/**
	 * @Description 해약전표일자
	 */
	@JsonProperty("slipdate")
	public void setSlipdate( java.lang.String slipdate ) {
		isSet_slipdate = true;
		this.slipdate = slipdate;
	}
	
	/** Property set << slipdate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << slipseq >> [[ */
	
	@XmlTransient
	private boolean isSet_slipseq = false;
	
	protected boolean isSet_slipseq()
	{
		return this.isSet_slipseq;
	}
	
	protected void setIsSet_slipseq(boolean value)
	{
		this.isSet_slipseq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 해약전표순번
	 */
	public void setSlipseq(java.lang.String value) {
		isSet_slipseq = true;
		this.slipseq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 해약전표순번
	 */
	public void setSlipseq(double value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 해약전표순번
	 */
	public void setSlipseq(long value) {
		isSet_slipseq = true;
		this.slipseq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="해약전표순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal slipseq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 해약전표순번
	 */
	public java.math.BigDecimal getSlipseq(){
		return slipseq;
	}
	
	/**
	 * @Description 해약전표순번
	 */
	@JsonProperty("slipseq")
	public void setSlipseq( java.math.BigDecimal slipseq ) {
		isSet_slipseq = true;
		this.slipseq = slipseq;
	}
	
	/** Property set << slipseq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << applyYn >> [[ */
	
	@XmlTransient
	private boolean isSet_applyYn = false;
	
	protected boolean isSet_applyYn()
	{
		return this.isSet_applyYn;
	}
	
	protected void setIsSet_applyYn(boolean value)
	{
		this.isSet_applyYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="승인여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String applyYn  = null;
	
	/**
	 * @Description 승인여부
	 */
	public java.lang.String getApplyYn(){
		return applyYn;
	}
	
	/**
	 * @Description 승인여부
	 */
	@JsonProperty("applyYn")
	public void setApplyYn( java.lang.String applyYn ) {
		isSet_applyYn = true;
		this.applyYn = applyYn;
	}
	
	/** Property set << applyYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << applyEmpno >> [[ */
	
	@XmlTransient
	private boolean isSet_applyEmpno = false;
	
	protected boolean isSet_applyEmpno()
	{
		return this.isSet_applyEmpno;
	}
	
	protected void setIsSet_applyEmpno(boolean value)
	{
		this.isSet_applyEmpno = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="승인자", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String applyEmpno  = null;
	
	/**
	 * @Description 승인자
	 */
	public java.lang.String getApplyEmpno(){
		return applyEmpno;
	}
	
	/**
	 * @Description 승인자
	 */
	@JsonProperty("applyEmpno")
	public void setApplyEmpno( java.lang.String applyEmpno ) {
		isSet_applyEmpno = true;
		this.applyEmpno = applyEmpno;
	}
	
	/** Property set << applyEmpno >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << applyDate >> [[ */
	
	@XmlTransient
	private boolean isSet_applyDate = false;
	
	protected boolean isSet_applyDate()
	{
		return this.isSet_applyDate;
	}
	
	protected void setIsSet_applyDate(boolean value)
	{
		this.isSet_applyDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="승인일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String applyDate  = null;
	
	/**
	 * @Description 승인일시
	 */
	public java.lang.String getApplyDate(){
		return applyDate;
	}
	
	/**
	 * @Description 승인일시
	 */
	@JsonProperty("applyDate")
	public void setApplyDate( java.lang.String applyDate ) {
		isSet_applyDate = true;
		this.applyDate = applyDate;
	}
	
	/** Property set << applyDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << prtsquare >> [[ */
	
	@XmlTransient
	private boolean isSet_prtsquare = false;
	
	protected boolean isSet_prtsquare()
	{
		return this.isSet_prtsquare;
	}
	
	protected void setIsSet_prtsquare(boolean value)
	{
		this.isSet_prtsquare = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(java.lang.String value) {
		isSet_prtsquare = true;
		this.prtsquare = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(double value) {
		isSet_prtsquare = true;
		this.prtsquare = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 출력평형
	 */
	public void setPrtsquare(long value) {
		isSet_prtsquare = true;
		this.prtsquare = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="출력평형", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal prtsquare  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 출력평형
	 */
	public java.math.BigDecimal getPrtsquare(){
		return prtsquare;
	}
	
	/**
	 * @Description 출력평형
	 */
	@JsonProperty("prtsquare")
	public void setPrtsquare( java.math.BigDecimal prtsquare ) {
		isSet_prtsquare = true;
		this.prtsquare = prtsquare;
	}
	
	/** Property set << prtsquare >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bankLoanInterest2 >> [[ */
	
	@XmlTransient
	private boolean isSet_bankLoanInterest2 = false;
	
	protected boolean isSet_bankLoanInterest2()
	{
		return this.isSet_bankLoanInterest2;
	}
	
	protected void setIsSet_bankLoanInterest2(boolean value)
	{
		this.isSet_bankLoanInterest2 = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 은행대출이자_전기
	 */
	public void setBankLoanInterest2(java.lang.String value) {
		isSet_bankLoanInterest2 = true;
		this.bankLoanInterest2 = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 은행대출이자_전기
	 */
	public void setBankLoanInterest2(double value) {
		isSet_bankLoanInterest2 = true;
		this.bankLoanInterest2 = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 은행대출이자_전기
	 */
	public void setBankLoanInterest2(long value) {
		isSet_bankLoanInterest2 = true;
		this.bankLoanInterest2 = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="은행대출이자_전기", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal bankLoanInterest2  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 은행대출이자_전기
	 */
	public java.math.BigDecimal getBankLoanInterest2(){
		return bankLoanInterest2;
	}
	
	/**
	 * @Description 은행대출이자_전기
	 */
	@JsonProperty("bankLoanInterest2")
	public void setBankLoanInterest2( java.math.BigDecimal bankLoanInterest2 ) {
		isSet_bankLoanInterest2 = true;
		this.bankLoanInterest2 = bankLoanInterest2;
	}
	
	/** Property set << bankLoanInterest2 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etcAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_etcAmt = false;
	
	protected boolean isSet_etcAmt()
	{
		return this.isSet_etcAmt;
	}
	
	protected void setIsSet_etcAmt(boolean value)
	{
		this.isSet_etcAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 기타공제금액
	 */
	public void setEtcAmt(java.lang.String value) {
		isSet_etcAmt = true;
		this.etcAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 기타공제금액
	 */
	public void setEtcAmt(double value) {
		isSet_etcAmt = true;
		this.etcAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 기타공제금액
	 */
	public void setEtcAmt(long value) {
		isSet_etcAmt = true;
		this.etcAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="기타공제금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal etcAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 기타공제금액
	 */
	public java.math.BigDecimal getEtcAmt(){
		return etcAmt;
	}
	
	/**
	 * @Description 기타공제금액
	 */
	@JsonProperty("etcAmt")
	public void setEtcAmt( java.math.BigDecimal etcAmt ) {
		isSet_etcAmt = true;
		this.etcAmt = etcAmt;
	}
	
	/** Property set << etcAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << renthdYn >> [[ */
	
	@XmlTransient
	private boolean isSet_renthdYn = false;
	
	protected boolean isSet_renthdYn()
	{
		return this.isSet_renthdYn;
	}
	
	protected void setIsSet_renthdYn(boolean value)
	{
		this.isSet_renthdYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대분양전환여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String renthdYn  = null;
	
	/**
	 * @Description 임대분양전환여부
	 */
	public java.lang.String getRenthdYn(){
		return renthdYn;
	}
	
	/**
	 * @Description 임대분양전환여부
	 */
	@JsonProperty("renthdYn")
	public void setRenthdYn( java.lang.String renthdYn ) {
		isSet_renthdYn = true;
		this.renthdYn = renthdYn;
	}
	
	/** Property set << renthdYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << renthdSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_renthdSeq = false;
	
	protected boolean isSet_renthdSeq()
	{
		return this.isSet_renthdSeq;
	}
	
	protected void setIsSet_renthdSeq(boolean value)
	{
		this.isSet_renthdSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대순번
	 */
	public void setRenthdSeq(java.lang.String value) {
		isSet_renthdSeq = true;
		this.renthdSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대순번
	 */
	public void setRenthdSeq(double value) {
		isSet_renthdSeq = true;
		this.renthdSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대순번
	 */
	public void setRenthdSeq(long value) {
		isSet_renthdSeq = true;
		this.renthdSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대순번", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal renthdSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대순번
	 */
	public java.math.BigDecimal getRenthdSeq(){
		return renthdSeq;
	}
	
	/**
	 * @Description 임대순번
	 */
	@JsonProperty("renthdSeq")
	public void setRenthdSeq( java.math.BigDecimal renthdSeq ) {
		isSet_renthdSeq = true;
		this.renthdSeq = renthdSeq;
	}
	
	/** Property set << renthdSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << balconyTag >> [[ */
	
	@XmlTransient
	private boolean isSet_balconyTag = false;
	
	protected boolean isSet_balconyTag()
	{
		return this.isSet_balconyTag;
	}
	
	protected void setIsSet_balconyTag(boolean value)
	{
		this.isSet_balconyTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="발코니확장구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String balconyTag  = null;
	
	/**
	 * @Description 발코니확장구분
	 */
	public java.lang.String getBalconyTag(){
		return balconyTag;
	}
	
	/**
	 * @Description 발코니확장구분
	 */
	@JsonProperty("balconyTag")
	public void setBalconyTag( java.lang.String balconyTag ) {
		isSet_balconyTag = true;
		this.balconyTag = balconyTag;
	}
	
	/** Property set << balconyTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << balconyarea >> [[ */
	
	@XmlTransient
	private boolean isSet_balconyarea = false;
	
	protected boolean isSet_balconyarea()
	{
		return this.isSet_balconyarea;
	}
	
	protected void setIsSet_balconyarea(boolean value)
	{
		this.isSet_balconyarea = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 발코니확장평수
	 */
	public void setBalconyarea(java.lang.String value) {
		isSet_balconyarea = true;
		this.balconyarea = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 발코니확장평수
	 */
	public void setBalconyarea(double value) {
		isSet_balconyarea = true;
		this.balconyarea = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 발코니확장평수
	 */
	public void setBalconyarea(long value) {
		isSet_balconyarea = true;
		this.balconyarea = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="발코니확장평수", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal balconyarea  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 발코니확장평수
	 */
	public java.math.BigDecimal getBalconyarea(){
		return balconyarea;
	}
	
	/**
	 * @Description 발코니확장평수
	 */
	@JsonProperty("balconyarea")
	public void setBalconyarea( java.math.BigDecimal balconyarea ) {
		isSet_balconyarea = true;
		this.balconyarea = balconyarea;
	}
	
	/** Property set << balconyarea >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << daymonthTag >> [[ */
	
	@XmlTransient
	private boolean isSet_daymonthTag = false;
	
	protected boolean isSet_daymonthTag()
	{
		return this.isSet_daymonthTag;
	}
	
	protected void setIsSet_daymonthTag(boolean value)
	{
		this.isSet_daymonthTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="연체일/월계산구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String daymonthTag  = null;
	
	/**
	 * @Description 연체일/월계산구분
	 */
	public java.lang.String getDaymonthTag(){
		return daymonthTag;
	}
	
	/**
	 * @Description 연체일/월계산구분
	 */
	@JsonProperty("daymonthTag")
	public void setDaymonthTag( java.lang.String daymonthTag ) {
		isSet_daymonthTag = true;
		this.daymonthTag = daymonthTag;
	}
	
	/** Property set << daymonthTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << floor >> [[ */
	
	@XmlTransient
	private boolean isSet_floor = false;
	
	protected boolean isSet_floor()
	{
		return this.isSet_floor;
	}
	
	protected void setIsSet_floor(boolean value)
	{
		this.isSet_floor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="층", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String floor  = null;
	
	/**
	 * @Description 층
	 */
	public java.lang.String getFloor(){
		return floor;
	}
	
	/**
	 * @Description 층
	 */
	@JsonProperty("floor")
	public void setFloor( java.lang.String floor ) {
		isSet_floor = true;
		this.floor = floor;
	}
	
	/** Property set << floor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << contCondition >> [[ */
	
	@XmlTransient
	private boolean isSet_contCondition = false;
	
	protected boolean isSet_contCondition()
	{
		return this.isSet_contCondition;
	}
	
	protected void setIsSet_contCondition(boolean value)
	{
		this.isSet_contCondition = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="계약조건", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String contCondition  = null;
	
	/**
	 * @Description 계약조건
	 */
	public java.lang.String getContCondition(){
		return contCondition;
	}
	
	/**
	 * @Description 계약조건
	 */
	@JsonProperty("contCondition")
	public void setContCondition( java.lang.String contCondition ) {
		isSet_contCondition = true;
		this.contCondition = contCondition;
	}
	
	/** Property set << contCondition >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << landReturn >> [[ */
	
	@XmlTransient
	private boolean isSet_landReturn = false;
	
	protected boolean isSet_landReturn()
	{
		return this.isSet_landReturn;
	}
	
	protected void setIsSet_landReturn(boolean value)
	{
		this.isSet_landReturn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="대지비환급구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String landReturn  = null;
	
	/**
	 * @Description 대지비환급구분
	 */
	public java.lang.String getLandReturn(){
		return landReturn;
	}
	
	/**
	 * @Description 대지비환급구분
	 */
	@JsonProperty("landReturn")
	public void setLandReturn( java.lang.String landReturn ) {
		isSet_landReturn = true;
		this.landReturn = landReturn;
	}
	
	/** Property set << landReturn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << intCalcDate >> [[ */
	
	@XmlTransient
	private boolean isSet_intCalcDate = false;
	
	protected boolean isSet_intCalcDate()
	{
		return this.isSet_intCalcDate;
	}
	
	protected void setIsSet_intCalcDate(boolean value)
	{
		this.isSet_intCalcDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="기간이자산정일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String intCalcDate  = null;
	
	/**
	 * @Description 기간이자산정일
	 */
	public java.lang.String getIntCalcDate(){
		return intCalcDate;
	}
	
	/**
	 * @Description 기간이자산정일
	 */
	@JsonProperty("intCalcDate")
	public void setIntCalcDate( java.lang.String intCalcDate ) {
		isSet_intCalcDate = true;
		this.intCalcDate = intCalcDate;
	}
	
	/** Property set << intCalcDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << predisamt >> [[ */
	
	@XmlTransient
	private boolean isSet_predisamt = false;
	
	protected boolean isSet_predisamt()
	{
		return this.isSet_predisamt;
	}
	
	protected void setIsSet_predisamt(boolean value)
	{
		this.isSet_predisamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 선납할인
	 */
	public void setPredisamt(java.lang.String value) {
		isSet_predisamt = true;
		this.predisamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 선납할인
	 */
	public void setPredisamt(double value) {
		isSet_predisamt = true;
		this.predisamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 선납할인
	 */
	public void setPredisamt(long value) {
		isSet_predisamt = true;
		this.predisamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="선납할인", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal predisamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 선납할인
	 */
	public java.math.BigDecimal getPredisamt(){
		return predisamt;
	}
	
	/**
	 * @Description 선납할인
	 */
	@JsonProperty("predisamt")
	public void setPredisamt( java.math.BigDecimal predisamt ) {
		isSet_predisamt = true;
		this.predisamt = predisamt;
	}
	
	/** Property set << predisamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << proxyamt >> [[ */
	
	@XmlTransient
	private boolean isSet_proxyamt = false;
	
	protected boolean isSet_proxyamt()
	{
		return this.isSet_proxyamt;
	}
	
	protected void setIsSet_proxyamt(boolean value)
	{
		this.isSet_proxyamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 이자대납
	 */
	public void setProxyamt(java.lang.String value) {
		isSet_proxyamt = true;
		this.proxyamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 이자대납
	 */
	public void setProxyamt(double value) {
		isSet_proxyamt = true;
		this.proxyamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 이자대납
	 */
	public void setProxyamt(long value) {
		isSet_proxyamt = true;
		this.proxyamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="이자대납", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal proxyamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 이자대납
	 */
	public java.math.BigDecimal getProxyamt(){
		return proxyamt;
	}
	
	/**
	 * @Description 이자대납
	 */
	@JsonProperty("proxyamt")
	public void setProxyamt( java.math.BigDecimal proxyamt ) {
		isSet_proxyamt = true;
		this.proxyamt = proxyamt;
	}
	
	/** Property set << proxyamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << incontDate >> [[ */
	
	@XmlTransient
	private boolean isSet_incontDate = false;
	
	protected boolean isSet_incontDate()
	{
		return this.isSet_incontDate;
	}
	
	protected void setIsSet_incontDate(boolean value)
	{
		this.isSet_incontDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금기준계약일", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String incontDate  = null;
	
	/**
	 * @Description 입금기준계약일
	 */
	public java.lang.String getIncontDate(){
		return incontDate;
	}
	
	/**
	 * @Description 입금기준계약일
	 */
	@JsonProperty("incontDate")
	public void setIncontDate( java.lang.String incontDate ) {
		isSet_incontDate = true;
		this.incontDate = incontDate;
	}
	
	/** Property set << incontDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << trustamt >> [[ */
	
	@XmlTransient
	private boolean isSet_trustamt = false;
	
	protected boolean isSet_trustamt()
	{
		return this.isSet_trustamt;
	}
	
	protected void setIsSet_trustamt(boolean value)
	{
		this.isSet_trustamt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 임대위탁
	 */
	public void setTrustamt(java.lang.String value) {
		isSet_trustamt = true;
		this.trustamt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 임대위탁
	 */
	public void setTrustamt(double value) {
		isSet_trustamt = true;
		this.trustamt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 임대위탁
	 */
	public void setTrustamt(long value) {
		isSet_trustamt = true;
		this.trustamt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="임대위탁", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal trustamt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 임대위탁
	 */
	public java.math.BigDecimal getTrustamt(){
		return trustamt;
	}
	
	/**
	 * @Description 임대위탁
	 */
	@JsonProperty("trustamt")
	public void setTrustamt( java.math.BigDecimal trustamt ) {
		isSet_trustamt = true;
		this.trustamt = trustamt;
	}
	
	/** Property set << trustamt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << predisTag >> [[ */
	
	@XmlTransient
	private boolean isSet_predisTag = false;
	
	protected boolean isSet_predisTag()
	{
		return this.isSet_predisTag;
	}
	
	protected void setIsSet_predisTag(boolean value)
	{
		this.isSet_predisTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="선납할인여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String predisTag  = null;
	
	/**
	 * @Description 선납할인여부
	 */
	public java.lang.String getPredisTag(){
		return predisTag;
	}
	
	/**
	 * @Description 선납할인여부
	 */
	@JsonProperty("predisTag")
	public void setPredisTag( java.lang.String predisTag ) {
		isSet_predisTag = true;
		this.predisTag = predisTag;
	}
	
	/** Property set << predisTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << proxyTag >> [[ */
	
	@XmlTransient
	private boolean isSet_proxyTag = false;
	
	protected boolean isSet_proxyTag()
	{
		return this.isSet_proxyTag;
	}
	
	protected void setIsSet_proxyTag(boolean value)
	{
		this.isSet_proxyTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="이자대납여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String proxyTag  = null;
	
	/**
	 * @Description 이자대납여부
	 */
	public java.lang.String getProxyTag(){
		return proxyTag;
	}
	
	/**
	 * @Description 이자대납여부
	 */
	@JsonProperty("proxyTag")
	public void setProxyTag( java.lang.String proxyTag ) {
		isSet_proxyTag = true;
		this.proxyTag = proxyTag;
	}
	
	/** Property set << proxyTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << trustTag >> [[ */
	
	@XmlTransient
	private boolean isSet_trustTag = false;
	
	protected boolean isSet_trustTag()
	{
		return this.isSet_trustTag;
	}
	
	protected void setIsSet_trustTag(boolean value)
	{
		this.isSet_trustTag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="임대위탁여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String trustTag  = null;
	
	/**
	 * @Description 임대위탁여부
	 */
	public java.lang.String getTrustTag(){
		return trustTag;
	}
	
	/**
	 * @Description 임대위탁여부
	 */
	@JsonProperty("trustTag")
	public void setTrustTag( java.lang.String trustTag ) {
		isSet_trustTag = true;
		this.trustTag = trustTag;
	}
	
	/** Property set << trustTag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << virYn >> [[ */
	
	@XmlTransient
	private boolean isSet_virYn = false;
	
	protected boolean isSet_virYn()
	{
		return this.isSet_virYn;
	}
	
	protected void setIsSet_virYn(boolean value)
	{
		this.isSet_virYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌사용유무", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String virYn  = null;
	
	/**
	 * @Description 가상계좌사용유무
	 */
	public java.lang.String getVirYn(){
		return virYn;
	}
	
	/**
	 * @Description 가상계좌사용유무
	 */
	@JsonProperty("virYn")
	public void setVirYn( java.lang.String virYn ) {
		isSet_virYn = true;
		this.virYn = virYn;
	}
	
	/** Property set << virYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vdeposit >> [[ */
	
	@XmlTransient
	private boolean isSet_vdeposit = false;
	
	protected boolean isSet_vdeposit()
	{
		return this.isSet_vdeposit;
	}
	
	protected void setIsSet_vdeposit(boolean value)
	{
		this.isSet_vdeposit = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌번호", formatType="", format="", align="left", length=50, decimal=0, arrayReference="", fill="")
	private java.lang.String vdeposit  = null;
	
	/**
	 * @Description 가상계좌번호
	 */
	public java.lang.String getVdeposit(){
		return vdeposit;
	}
	
	/**
	 * @Description 가상계좌번호
	 */
	@JsonProperty("vdeposit")
	public void setVdeposit( java.lang.String vdeposit ) {
		isSet_vdeposit = true;
		this.vdeposit = vdeposit;
	}
	
	/** Property set << vdeposit >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << repLimitdt >> [[ */
	
	@XmlTransient
	private boolean isSet_repLimitdt = false;
	
	protected boolean isSet_repLimitdt()
	{
		return this.isSet_repLimitdt;
	}
	
	protected void setIsSet_repLimitdt(boolean value)
	{
		this.isSet_repLimitdt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String repLimitdt  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRepLimitdt(){
		return repLimitdt;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("repLimitdt")
	public void setRepLimitdt( java.lang.String repLimitdt ) {
		isSet_repLimitdt = true;
		this.repLimitdt = repLimitdt;
	}
	
	/** Property set << repLimitdt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << repYn >> [[ */
	
	@XmlTransient
	private boolean isSet_repYn = false;
	
	protected boolean isSet_repYn()
	{
		return this.isSet_repYn;
	}
	
	protected void setIsSet_repYn(boolean value)
	{
		this.isSet_repYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String repYn  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRepYn(){
		return repYn;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("repYn")
	public void setRepYn( java.lang.String repYn ) {
		isSet_repYn = true;
		this.repYn = repYn;
	}
	
	/** Property set << repYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << repDate >> [[ */
	
	@XmlTransient
	private boolean isSet_repDate = false;
	
	protected boolean isSet_repDate()
	{
		return this.isSet_repDate;
	}
	
	protected void setIsSet_repDate(boolean value)
	{
		this.isSet_repDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String repDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getRepDate(){
		return repDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("repDate")
	public void setRepDate( java.lang.String repDate ) {
		isSet_repDate = true;
		this.repDate = repDate;
	}
	
	/** Property set << repDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousSellLog01IO clone(){
		try{
			DHDHousSellLog01IO object= (DHDHousSellLog01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.writetag== null ) object.writetag = null;
			else{
				object.writetag = this.writetag;
			}
			if ( this.writetime== null ) object.writetime = null;
			else{
				object.writetime = this.writetime;
			}
			if ( this.writeseq== null ) object.writeseq = null;
			else{
				object.writeseq = new java.math.BigDecimal(writeseq.toString());
			}
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.buildno== null ) object.buildno = null;
			else{
				object.buildno = this.buildno;
			}
			if ( this.houseno== null ) object.houseno = null;
			else{
				object.houseno = this.houseno;
			}
			if ( this.dongho== null ) object.dongho = null;
			else{
				object.dongho = this.dongho;
			}
			if ( this.custName== null ) object.custName = null;
			else{
				object.custName = this.custName;
			}
			if ( this.square== null ) object.square = null;
			else{
				object.square = new java.math.BigDecimal(square.toString());
			}
			if ( this.type== null ) object.type = null;
			else{
				object.type = this.type;
			}
			if ( this.classJrw== null ) object.classJrw = null;
			else{
				object.classJrw = this.classJrw;
			}
			if ( this.optioncode== null ) object.optioncode = null;
			else{
				object.optioncode = this.optioncode;
			}
			if ( this.contracttag== null ) object.contracttag = null;
			else{
				object.contracttag = this.contracttag;
			}
			if ( this.contractdate== null ) object.contractdate = null;
			else{
				object.contractdate = this.contractdate;
			}
			if ( this.contractno== null ) object.contractno = null;
			else{
				object.contractno = this.contractno;
			}
			if ( this.loanTag== null ) object.loanTag = null;
			else{
				object.loanTag = this.loanTag;
			}
			if ( this.leasetag== null ) object.leasetag = null;
			else{
				object.leasetag = this.leasetag;
			}
			if ( this.lastchangedate== null ) object.lastchangedate = null;
			else{
				object.lastchangedate = this.lastchangedate;
			}
			if ( this.changetag== null ) object.changetag = null;
			else{
				object.changetag = this.changetag;
			}
			if ( this.changedate== null ) object.changedate = null;
			else{
				object.changedate = this.changedate;
			}
			if ( this.cancelReason== null ) object.cancelReason = null;
			else{
				object.cancelReason = this.cancelReason;
			}
			if ( this.childBuildno== null ) object.childBuildno = null;
			else{
				object.childBuildno = this.childBuildno;
			}
			if ( this.childHouseno== null ) object.childHouseno = null;
			else{
				object.childHouseno = this.childHouseno;
			}
			if ( this.relaCustcode== null ) object.relaCustcode = null;
			else{
				object.relaCustcode = this.relaCustcode;
			}
			if ( this.relaSeq== null ) object.relaSeq = null;
			else{
				object.relaSeq = new java.math.BigDecimal(relaSeq.toString());
			}
			if ( this.vattag== null ) object.vattag = null;
			else{
				object.vattag = this.vattag;
			}
			if ( this.exclusivearea== null ) object.exclusivearea = null;
			else{
				object.exclusivearea = new java.math.BigDecimal(exclusivearea.toString());
			}
			if ( this.commonarea== null ) object.commonarea = null;
			else{
				object.commonarea = new java.math.BigDecimal(commonarea.toString());
			}
			if ( this.etccommonarea== null ) object.etccommonarea = null;
			else{
				object.etccommonarea = new java.math.BigDecimal(etccommonarea.toString());
			}
			if ( this.parkingarea== null ) object.parkingarea = null;
			else{
				object.parkingarea = new java.math.BigDecimal(parkingarea.toString());
			}
			if ( this.servicearea== null ) object.servicearea = null;
			else{
				object.servicearea = new java.math.BigDecimal(servicearea.toString());
			}
			if ( this.sitearea== null ) object.sitearea = null;
			else{
				object.sitearea = new java.math.BigDecimal(sitearea.toString());
			}
			if ( this.moveinstartdate== null ) object.moveinstartdate = null;
			else{
				object.moveinstartdate = this.moveinstartdate;
			}
			if ( this.moveinenddate== null ) object.moveinenddate = null;
			else{
				object.moveinenddate = this.moveinenddate;
			}
			if ( this.unionCnt== null ) object.unionCnt = null;
			else{
				object.unionCnt = new java.math.BigDecimal(unionCnt.toString());
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.refundmentdate== null ) object.refundmentdate = null;
			else{
				object.refundmentdate = this.refundmentdate;
			}
			if ( this.refundmentamt== null ) object.refundmentamt = null;
			else{
				object.refundmentamt = new java.math.BigDecimal(refundmentamt.toString());
			}
			if ( this.penaltyamt== null ) object.penaltyamt = null;
			else{
				object.penaltyamt = new java.math.BigDecimal(penaltyamt.toString());
			}
			if ( this.loanInterest== null ) object.loanInterest = null;
			else{
				object.loanInterest = new java.math.BigDecimal(loanInterest.toString());
			}
			if ( this.sodukTax== null ) object.sodukTax = null;
			else{
				object.sodukTax = new java.math.BigDecimal(sodukTax.toString());
			}
			if ( this.juminTax== null ) object.juminTax = null;
			else{
				object.juminTax = new java.math.BigDecimal(juminTax.toString());
			}
			if ( this.bankLoanOrgamt== null ) object.bankLoanOrgamt = null;
			else{
				object.bankLoanOrgamt = new java.math.BigDecimal(bankLoanOrgamt.toString());
			}
			if ( this.bankLoanInterest== null ) object.bankLoanInterest = null;
			else{
				object.bankLoanInterest = new java.math.BigDecimal(bankLoanInterest.toString());
			}
			if ( this.loanbank== null ) object.loanbank = null;
			else{
				object.loanbank = this.loanbank;
			}
			if ( this.loandeposit== null ) object.loandeposit = null;
			else{
				object.loandeposit = this.loandeposit;
			}
			if ( this.loanuser== null ) object.loanuser = null;
			else{
				object.loanuser = this.loanuser;
			}
			if ( this.refundDeposit== null ) object.refundDeposit = null;
			else{
				object.refundDeposit = this.refundDeposit;
			}
			if ( this.refundBank== null ) object.refundBank = null;
			else{
				object.refundBank = this.refundBank;
			}
			if ( this.compLoanamt== null ) object.compLoanamt = null;
			else{
				object.compLoanamt = new java.math.BigDecimal(compLoanamt.toString());
			}
			if ( this.billReturnamt== null ) object.billReturnamt = null;
			else{
				object.billReturnamt = new java.math.BigDecimal(billReturnamt.toString());
			}
			if ( this.delayIndeminity== null ) object.delayIndeminity = null;
			else{
				object.delayIndeminity = new java.math.BigDecimal(delayIndeminity.toString());
			}
			if ( this.depositCount== null ) object.depositCount = null;
			else{
				object.depositCount = new java.math.BigDecimal(depositCount.toString());
			}
			if ( this.coCustcode== null ) object.coCustcode = null;
			else{
				object.coCustcode = this.coCustcode;
			}
			if ( this.coSangho== null ) object.coSangho = null;
			else{
				object.coSangho = this.coSangho;
			}
			if ( this.coCondition== null ) object.coCondition = null;
			else{
				object.coCondition = this.coCondition;
			}
			if ( this.coCategory== null ) object.coCategory = null;
			else{
				object.coCategory = this.coCategory;
			}
			if ( this.categoryName== null ) object.categoryName = null;
			else{
				object.categoryName = this.categoryName;
			}
			if ( this.slipdate== null ) object.slipdate = null;
			else{
				object.slipdate = this.slipdate;
			}
			if ( this.slipseq== null ) object.slipseq = null;
			else{
				object.slipseq = new java.math.BigDecimal(slipseq.toString());
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			if ( this.applyYn== null ) object.applyYn = null;
			else{
				object.applyYn = this.applyYn;
			}
			if ( this.applyEmpno== null ) object.applyEmpno = null;
			else{
				object.applyEmpno = this.applyEmpno;
			}
			if ( this.applyDate== null ) object.applyDate = null;
			else{
				object.applyDate = this.applyDate;
			}
			if ( this.prtsquare== null ) object.prtsquare = null;
			else{
				object.prtsquare = new java.math.BigDecimal(prtsquare.toString());
			}
			if ( this.bankLoanInterest2== null ) object.bankLoanInterest2 = null;
			else{
				object.bankLoanInterest2 = new java.math.BigDecimal(bankLoanInterest2.toString());
			}
			if ( this.etcAmt== null ) object.etcAmt = null;
			else{
				object.etcAmt = new java.math.BigDecimal(etcAmt.toString());
			}
			if ( this.renthdYn== null ) object.renthdYn = null;
			else{
				object.renthdYn = this.renthdYn;
			}
			if ( this.renthdSeq== null ) object.renthdSeq = null;
			else{
				object.renthdSeq = new java.math.BigDecimal(renthdSeq.toString());
			}
			if ( this.balconyTag== null ) object.balconyTag = null;
			else{
				object.balconyTag = this.balconyTag;
			}
			if ( this.balconyarea== null ) object.balconyarea = null;
			else{
				object.balconyarea = new java.math.BigDecimal(balconyarea.toString());
			}
			if ( this.daymonthTag== null ) object.daymonthTag = null;
			else{
				object.daymonthTag = this.daymonthTag;
			}
			if ( this.floor== null ) object.floor = null;
			else{
				object.floor = this.floor;
			}
			if ( this.contCondition== null ) object.contCondition = null;
			else{
				object.contCondition = this.contCondition;
			}
			if ( this.landReturn== null ) object.landReturn = null;
			else{
				object.landReturn = this.landReturn;
			}
			if ( this.intCalcDate== null ) object.intCalcDate = null;
			else{
				object.intCalcDate = this.intCalcDate;
			}
			if ( this.predisamt== null ) object.predisamt = null;
			else{
				object.predisamt = new java.math.BigDecimal(predisamt.toString());
			}
			if ( this.proxyamt== null ) object.proxyamt = null;
			else{
				object.proxyamt = new java.math.BigDecimal(proxyamt.toString());
			}
			if ( this.incontDate== null ) object.incontDate = null;
			else{
				object.incontDate = this.incontDate;
			}
			if ( this.trustamt== null ) object.trustamt = null;
			else{
				object.trustamt = new java.math.BigDecimal(trustamt.toString());
			}
			if ( this.predisTag== null ) object.predisTag = null;
			else{
				object.predisTag = this.predisTag;
			}
			if ( this.proxyTag== null ) object.proxyTag = null;
			else{
				object.proxyTag = this.proxyTag;
			}
			if ( this.trustTag== null ) object.trustTag = null;
			else{
				object.trustTag = this.trustTag;
			}
			if ( this.virYn== null ) object.virYn = null;
			else{
				object.virYn = this.virYn;
			}
			if ( this.vdeposit== null ) object.vdeposit = null;
			else{
				object.vdeposit = this.vdeposit;
			}
			if ( this.repLimitdt== null ) object.repLimitdt = null;
			else{
				object.repLimitdt = this.repLimitdt;
			}
			if ( this.repYn== null ) object.repYn = null;
			else{
				object.repYn = this.repYn;
			}
			if ( this.repDate== null ) object.repDate = null;
			else{
				object.repDate = this.repDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((writetag==null)?0:writetag.hashCode());
		result = prime * result + ((writetime==null)?0:writetime.hashCode());
		result = prime * result + ((writeseq==null)?0:writeseq.hashCode());
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((buildno==null)?0:buildno.hashCode());
		result = prime * result + ((houseno==null)?0:houseno.hashCode());
		result = prime * result + ((dongho==null)?0:dongho.hashCode());
		result = prime * result + ((custName==null)?0:custName.hashCode());
		result = prime * result + ((square==null)?0:square.hashCode());
		result = prime * result + ((type==null)?0:type.hashCode());
		result = prime * result + ((classJrw==null)?0:classJrw.hashCode());
		result = prime * result + ((optioncode==null)?0:optioncode.hashCode());
		result = prime * result + ((contracttag==null)?0:contracttag.hashCode());
		result = prime * result + ((contractdate==null)?0:contractdate.hashCode());
		result = prime * result + ((contractno==null)?0:contractno.hashCode());
		result = prime * result + ((loanTag==null)?0:loanTag.hashCode());
		result = prime * result + ((leasetag==null)?0:leasetag.hashCode());
		result = prime * result + ((lastchangedate==null)?0:lastchangedate.hashCode());
		result = prime * result + ((changetag==null)?0:changetag.hashCode());
		result = prime * result + ((changedate==null)?0:changedate.hashCode());
		result = prime * result + ((cancelReason==null)?0:cancelReason.hashCode());
		result = prime * result + ((childBuildno==null)?0:childBuildno.hashCode());
		result = prime * result + ((childHouseno==null)?0:childHouseno.hashCode());
		result = prime * result + ((relaCustcode==null)?0:relaCustcode.hashCode());
		result = prime * result + ((relaSeq==null)?0:relaSeq.hashCode());
		result = prime * result + ((vattag==null)?0:vattag.hashCode());
		result = prime * result + ((exclusivearea==null)?0:exclusivearea.hashCode());
		result = prime * result + ((commonarea==null)?0:commonarea.hashCode());
		result = prime * result + ((etccommonarea==null)?0:etccommonarea.hashCode());
		result = prime * result + ((parkingarea==null)?0:parkingarea.hashCode());
		result = prime * result + ((servicearea==null)?0:servicearea.hashCode());
		result = prime * result + ((sitearea==null)?0:sitearea.hashCode());
		result = prime * result + ((moveinstartdate==null)?0:moveinstartdate.hashCode());
		result = prime * result + ((moveinenddate==null)?0:moveinenddate.hashCode());
		result = prime * result + ((unionCnt==null)?0:unionCnt.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((refundmentdate==null)?0:refundmentdate.hashCode());
		result = prime * result + ((refundmentamt==null)?0:refundmentamt.hashCode());
		result = prime * result + ((penaltyamt==null)?0:penaltyamt.hashCode());
		result = prime * result + ((loanInterest==null)?0:loanInterest.hashCode());
		result = prime * result + ((sodukTax==null)?0:sodukTax.hashCode());
		result = prime * result + ((juminTax==null)?0:juminTax.hashCode());
		result = prime * result + ((bankLoanOrgamt==null)?0:bankLoanOrgamt.hashCode());
		result = prime * result + ((bankLoanInterest==null)?0:bankLoanInterest.hashCode());
		result = prime * result + ((loanbank==null)?0:loanbank.hashCode());
		result = prime * result + ((loandeposit==null)?0:loandeposit.hashCode());
		result = prime * result + ((loanuser==null)?0:loanuser.hashCode());
		result = prime * result + ((refundDeposit==null)?0:refundDeposit.hashCode());
		result = prime * result + ((refundBank==null)?0:refundBank.hashCode());
		result = prime * result + ((compLoanamt==null)?0:compLoanamt.hashCode());
		result = prime * result + ((billReturnamt==null)?0:billReturnamt.hashCode());
		result = prime * result + ((delayIndeminity==null)?0:delayIndeminity.hashCode());
		result = prime * result + ((depositCount==null)?0:depositCount.hashCode());
		result = prime * result + ((coCustcode==null)?0:coCustcode.hashCode());
		result = prime * result + ((coSangho==null)?0:coSangho.hashCode());
		result = prime * result + ((coCondition==null)?0:coCondition.hashCode());
		result = prime * result + ((coCategory==null)?0:coCategory.hashCode());
		result = prime * result + ((categoryName==null)?0:categoryName.hashCode());
		result = prime * result + ((slipdate==null)?0:slipdate.hashCode());
		result = prime * result + ((slipseq==null)?0:slipseq.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		result = prime * result + ((applyYn==null)?0:applyYn.hashCode());
		result = prime * result + ((applyEmpno==null)?0:applyEmpno.hashCode());
		result = prime * result + ((applyDate==null)?0:applyDate.hashCode());
		result = prime * result + ((prtsquare==null)?0:prtsquare.hashCode());
		result = prime * result + ((bankLoanInterest2==null)?0:bankLoanInterest2.hashCode());
		result = prime * result + ((etcAmt==null)?0:etcAmt.hashCode());
		result = prime * result + ((renthdYn==null)?0:renthdYn.hashCode());
		result = prime * result + ((renthdSeq==null)?0:renthdSeq.hashCode());
		result = prime * result + ((balconyTag==null)?0:balconyTag.hashCode());
		result = prime * result + ((balconyarea==null)?0:balconyarea.hashCode());
		result = prime * result + ((daymonthTag==null)?0:daymonthTag.hashCode());
		result = prime * result + ((floor==null)?0:floor.hashCode());
		result = prime * result + ((contCondition==null)?0:contCondition.hashCode());
		result = prime * result + ((landReturn==null)?0:landReturn.hashCode());
		result = prime * result + ((intCalcDate==null)?0:intCalcDate.hashCode());
		result = prime * result + ((predisamt==null)?0:predisamt.hashCode());
		result = prime * result + ((proxyamt==null)?0:proxyamt.hashCode());
		result = prime * result + ((incontDate==null)?0:incontDate.hashCode());
		result = prime * result + ((trustamt==null)?0:trustamt.hashCode());
		result = prime * result + ((predisTag==null)?0:predisTag.hashCode());
		result = prime * result + ((proxyTag==null)?0:proxyTag.hashCode());
		result = prime * result + ((trustTag==null)?0:trustTag.hashCode());
		result = prime * result + ((virYn==null)?0:virYn.hashCode());
		result = prime * result + ((vdeposit==null)?0:vdeposit.hashCode());
		result = prime * result + ((repLimitdt==null)?0:repLimitdt.hashCode());
		result = prime * result + ((repYn==null)?0:repYn.hashCode());
		result = prime * result + ((repDate==null)?0:repDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO other = (kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( writetag == null ){
			if ( other.writetag != null ) return false;
		}
		else if ( !writetag.equals(other.writetag) )
			return false;
		if ( writetime == null ){
			if ( other.writetime != null ) return false;
		}
		else if ( !writetime.equals(other.writetime) )
			return false;
		if ( writeseq == null ){
			if ( other.writeseq != null ) return false;
		}
		else if ( !writeseq.equals(other.writeseq) )
			return false;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( buildno == null ){
			if ( other.buildno != null ) return false;
		}
		else if ( !buildno.equals(other.buildno) )
			return false;
		if ( houseno == null ){
			if ( other.houseno != null ) return false;
		}
		else if ( !houseno.equals(other.houseno) )
			return false;
		if ( dongho == null ){
			if ( other.dongho != null ) return false;
		}
		else if ( !dongho.equals(other.dongho) )
			return false;
		if ( custName == null ){
			if ( other.custName != null ) return false;
		}
		else if ( !custName.equals(other.custName) )
			return false;
		if ( square == null ){
			if ( other.square != null ) return false;
		}
		else if ( !square.equals(other.square) )
			return false;
		if ( type == null ){
			if ( other.type != null ) return false;
		}
		else if ( !type.equals(other.type) )
			return false;
		if ( classJrw == null ){
			if ( other.classJrw != null ) return false;
		}
		else if ( !classJrw.equals(other.classJrw) )
			return false;
		if ( optioncode == null ){
			if ( other.optioncode != null ) return false;
		}
		else if ( !optioncode.equals(other.optioncode) )
			return false;
		if ( contracttag == null ){
			if ( other.contracttag != null ) return false;
		}
		else if ( !contracttag.equals(other.contracttag) )
			return false;
		if ( contractdate == null ){
			if ( other.contractdate != null ) return false;
		}
		else if ( !contractdate.equals(other.contractdate) )
			return false;
		if ( contractno == null ){
			if ( other.contractno != null ) return false;
		}
		else if ( !contractno.equals(other.contractno) )
			return false;
		if ( loanTag == null ){
			if ( other.loanTag != null ) return false;
		}
		else if ( !loanTag.equals(other.loanTag) )
			return false;
		if ( leasetag == null ){
			if ( other.leasetag != null ) return false;
		}
		else if ( !leasetag.equals(other.leasetag) )
			return false;
		if ( lastchangedate == null ){
			if ( other.lastchangedate != null ) return false;
		}
		else if ( !lastchangedate.equals(other.lastchangedate) )
			return false;
		if ( changetag == null ){
			if ( other.changetag != null ) return false;
		}
		else if ( !changetag.equals(other.changetag) )
			return false;
		if ( changedate == null ){
			if ( other.changedate != null ) return false;
		}
		else if ( !changedate.equals(other.changedate) )
			return false;
		if ( cancelReason == null ){
			if ( other.cancelReason != null ) return false;
		}
		else if ( !cancelReason.equals(other.cancelReason) )
			return false;
		if ( childBuildno == null ){
			if ( other.childBuildno != null ) return false;
		}
		else if ( !childBuildno.equals(other.childBuildno) )
			return false;
		if ( childHouseno == null ){
			if ( other.childHouseno != null ) return false;
		}
		else if ( !childHouseno.equals(other.childHouseno) )
			return false;
		if ( relaCustcode == null ){
			if ( other.relaCustcode != null ) return false;
		}
		else if ( !relaCustcode.equals(other.relaCustcode) )
			return false;
		if ( relaSeq == null ){
			if ( other.relaSeq != null ) return false;
		}
		else if ( !relaSeq.equals(other.relaSeq) )
			return false;
		if ( vattag == null ){
			if ( other.vattag != null ) return false;
		}
		else if ( !vattag.equals(other.vattag) )
			return false;
		if ( exclusivearea == null ){
			if ( other.exclusivearea != null ) return false;
		}
		else if ( !exclusivearea.equals(other.exclusivearea) )
			return false;
		if ( commonarea == null ){
			if ( other.commonarea != null ) return false;
		}
		else if ( !commonarea.equals(other.commonarea) )
			return false;
		if ( etccommonarea == null ){
			if ( other.etccommonarea != null ) return false;
		}
		else if ( !etccommonarea.equals(other.etccommonarea) )
			return false;
		if ( parkingarea == null ){
			if ( other.parkingarea != null ) return false;
		}
		else if ( !parkingarea.equals(other.parkingarea) )
			return false;
		if ( servicearea == null ){
			if ( other.servicearea != null ) return false;
		}
		else if ( !servicearea.equals(other.servicearea) )
			return false;
		if ( sitearea == null ){
			if ( other.sitearea != null ) return false;
		}
		else if ( !sitearea.equals(other.sitearea) )
			return false;
		if ( moveinstartdate == null ){
			if ( other.moveinstartdate != null ) return false;
		}
		else if ( !moveinstartdate.equals(other.moveinstartdate) )
			return false;
		if ( moveinenddate == null ){
			if ( other.moveinenddate != null ) return false;
		}
		else if ( !moveinenddate.equals(other.moveinenddate) )
			return false;
		if ( unionCnt == null ){
			if ( other.unionCnt != null ) return false;
		}
		else if ( !unionCnt.equals(other.unionCnt) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( refundmentdate == null ){
			if ( other.refundmentdate != null ) return false;
		}
		else if ( !refundmentdate.equals(other.refundmentdate) )
			return false;
		if ( refundmentamt == null ){
			if ( other.refundmentamt != null ) return false;
		}
		else if ( !refundmentamt.equals(other.refundmentamt) )
			return false;
		if ( penaltyamt == null ){
			if ( other.penaltyamt != null ) return false;
		}
		else if ( !penaltyamt.equals(other.penaltyamt) )
			return false;
		if ( loanInterest == null ){
			if ( other.loanInterest != null ) return false;
		}
		else if ( !loanInterest.equals(other.loanInterest) )
			return false;
		if ( sodukTax == null ){
			if ( other.sodukTax != null ) return false;
		}
		else if ( !sodukTax.equals(other.sodukTax) )
			return false;
		if ( juminTax == null ){
			if ( other.juminTax != null ) return false;
		}
		else if ( !juminTax.equals(other.juminTax) )
			return false;
		if ( bankLoanOrgamt == null ){
			if ( other.bankLoanOrgamt != null ) return false;
		}
		else if ( !bankLoanOrgamt.equals(other.bankLoanOrgamt) )
			return false;
		if ( bankLoanInterest == null ){
			if ( other.bankLoanInterest != null ) return false;
		}
		else if ( !bankLoanInterest.equals(other.bankLoanInterest) )
			return false;
		if ( loanbank == null ){
			if ( other.loanbank != null ) return false;
		}
		else if ( !loanbank.equals(other.loanbank) )
			return false;
		if ( loandeposit == null ){
			if ( other.loandeposit != null ) return false;
		}
		else if ( !loandeposit.equals(other.loandeposit) )
			return false;
		if ( loanuser == null ){
			if ( other.loanuser != null ) return false;
		}
		else if ( !loanuser.equals(other.loanuser) )
			return false;
		if ( refundDeposit == null ){
			if ( other.refundDeposit != null ) return false;
		}
		else if ( !refundDeposit.equals(other.refundDeposit) )
			return false;
		if ( refundBank == null ){
			if ( other.refundBank != null ) return false;
		}
		else if ( !refundBank.equals(other.refundBank) )
			return false;
		if ( compLoanamt == null ){
			if ( other.compLoanamt != null ) return false;
		}
		else if ( !compLoanamt.equals(other.compLoanamt) )
			return false;
		if ( billReturnamt == null ){
			if ( other.billReturnamt != null ) return false;
		}
		else if ( !billReturnamt.equals(other.billReturnamt) )
			return false;
		if ( delayIndeminity == null ){
			if ( other.delayIndeminity != null ) return false;
		}
		else if ( !delayIndeminity.equals(other.delayIndeminity) )
			return false;
		if ( depositCount == null ){
			if ( other.depositCount != null ) return false;
		}
		else if ( !depositCount.equals(other.depositCount) )
			return false;
		if ( coCustcode == null ){
			if ( other.coCustcode != null ) return false;
		}
		else if ( !coCustcode.equals(other.coCustcode) )
			return false;
		if ( coSangho == null ){
			if ( other.coSangho != null ) return false;
		}
		else if ( !coSangho.equals(other.coSangho) )
			return false;
		if ( coCondition == null ){
			if ( other.coCondition != null ) return false;
		}
		else if ( !coCondition.equals(other.coCondition) )
			return false;
		if ( coCategory == null ){
			if ( other.coCategory != null ) return false;
		}
		else if ( !coCategory.equals(other.coCategory) )
			return false;
		if ( categoryName == null ){
			if ( other.categoryName != null ) return false;
		}
		else if ( !categoryName.equals(other.categoryName) )
			return false;
		if ( slipdate == null ){
			if ( other.slipdate != null ) return false;
		}
		else if ( !slipdate.equals(other.slipdate) )
			return false;
		if ( slipseq == null ){
			if ( other.slipseq != null ) return false;
		}
		else if ( !slipseq.equals(other.slipseq) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		if ( applyYn == null ){
			if ( other.applyYn != null ) return false;
		}
		else if ( !applyYn.equals(other.applyYn) )
			return false;
		if ( applyEmpno == null ){
			if ( other.applyEmpno != null ) return false;
		}
		else if ( !applyEmpno.equals(other.applyEmpno) )
			return false;
		if ( applyDate == null ){
			if ( other.applyDate != null ) return false;
		}
		else if ( !applyDate.equals(other.applyDate) )
			return false;
		if ( prtsquare == null ){
			if ( other.prtsquare != null ) return false;
		}
		else if ( !prtsquare.equals(other.prtsquare) )
			return false;
		if ( bankLoanInterest2 == null ){
			if ( other.bankLoanInterest2 != null ) return false;
		}
		else if ( !bankLoanInterest2.equals(other.bankLoanInterest2) )
			return false;
		if ( etcAmt == null ){
			if ( other.etcAmt != null ) return false;
		}
		else if ( !etcAmt.equals(other.etcAmt) )
			return false;
		if ( renthdYn == null ){
			if ( other.renthdYn != null ) return false;
		}
		else if ( !renthdYn.equals(other.renthdYn) )
			return false;
		if ( renthdSeq == null ){
			if ( other.renthdSeq != null ) return false;
		}
		else if ( !renthdSeq.equals(other.renthdSeq) )
			return false;
		if ( balconyTag == null ){
			if ( other.balconyTag != null ) return false;
		}
		else if ( !balconyTag.equals(other.balconyTag) )
			return false;
		if ( balconyarea == null ){
			if ( other.balconyarea != null ) return false;
		}
		else if ( !balconyarea.equals(other.balconyarea) )
			return false;
		if ( daymonthTag == null ){
			if ( other.daymonthTag != null ) return false;
		}
		else if ( !daymonthTag.equals(other.daymonthTag) )
			return false;
		if ( floor == null ){
			if ( other.floor != null ) return false;
		}
		else if ( !floor.equals(other.floor) )
			return false;
		if ( contCondition == null ){
			if ( other.contCondition != null ) return false;
		}
		else if ( !contCondition.equals(other.contCondition) )
			return false;
		if ( landReturn == null ){
			if ( other.landReturn != null ) return false;
		}
		else if ( !landReturn.equals(other.landReturn) )
			return false;
		if ( intCalcDate == null ){
			if ( other.intCalcDate != null ) return false;
		}
		else if ( !intCalcDate.equals(other.intCalcDate) )
			return false;
		if ( predisamt == null ){
			if ( other.predisamt != null ) return false;
		}
		else if ( !predisamt.equals(other.predisamt) )
			return false;
		if ( proxyamt == null ){
			if ( other.proxyamt != null ) return false;
		}
		else if ( !proxyamt.equals(other.proxyamt) )
			return false;
		if ( incontDate == null ){
			if ( other.incontDate != null ) return false;
		}
		else if ( !incontDate.equals(other.incontDate) )
			return false;
		if ( trustamt == null ){
			if ( other.trustamt != null ) return false;
		}
		else if ( !trustamt.equals(other.trustamt) )
			return false;
		if ( predisTag == null ){
			if ( other.predisTag != null ) return false;
		}
		else if ( !predisTag.equals(other.predisTag) )
			return false;
		if ( proxyTag == null ){
			if ( other.proxyTag != null ) return false;
		}
		else if ( !proxyTag.equals(other.proxyTag) )
			return false;
		if ( trustTag == null ){
			if ( other.trustTag != null ) return false;
		}
		else if ( !trustTag.equals(other.trustTag) )
			return false;
		if ( virYn == null ){
			if ( other.virYn != null ) return false;
		}
		else if ( !virYn.equals(other.virYn) )
			return false;
		if ( vdeposit == null ){
			if ( other.vdeposit != null ) return false;
		}
		else if ( !vdeposit.equals(other.vdeposit) )
			return false;
		if ( repLimitdt == null ){
			if ( other.repLimitdt != null ) return false;
		}
		else if ( !repLimitdt.equals(other.repLimitdt) )
			return false;
		if ( repYn == null ){
			if ( other.repYn != null ) return false;
		}
		else if ( !repYn.equals(other.repYn) )
			return false;
		if ( repDate == null ){
			if ( other.repDate != null ) return false;
		}
		else if ( !repDate.equals(other.repDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\twritetag: ");
		sb.append(writetag==null?"null":getWritetag());
		sb.append("\n");
		sb.append("\twritetime: ");
		sb.append(writetime==null?"null":getWritetime());
		sb.append("\n");
		sb.append("\twriteseq: ");
		sb.append(writeseq==null?"null":getWriteseq());
		sb.append("\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tbuildno: ");
		sb.append(buildno==null?"null":getBuildno());
		sb.append("\n");
		sb.append("\thouseno: ");
		sb.append(houseno==null?"null":getHouseno());
		sb.append("\n");
		sb.append("\tdongho: ");
		sb.append(dongho==null?"null":getDongho());
		sb.append("\n");
		sb.append("\tcustName: ");
		sb.append(custName==null?"null":getCustName());
		sb.append("\n");
		sb.append("\tsquare: ");
		sb.append(square==null?"null":getSquare());
		sb.append("\n");
		sb.append("\ttype: ");
		sb.append(type==null?"null":getType());
		sb.append("\n");
		sb.append("\tclassJrw: ");
		sb.append(classJrw==null?"null":getClassJrw());
		sb.append("\n");
		sb.append("\toptioncode: ");
		sb.append(optioncode==null?"null":getOptioncode());
		sb.append("\n");
		sb.append("\tcontracttag: ");
		sb.append(contracttag==null?"null":getContracttag());
		sb.append("\n");
		sb.append("\tcontractdate: ");
		sb.append(contractdate==null?"null":getContractdate());
		sb.append("\n");
		sb.append("\tcontractno: ");
		sb.append(contractno==null?"null":getContractno());
		sb.append("\n");
		sb.append("\tloanTag: ");
		sb.append(loanTag==null?"null":getLoanTag());
		sb.append("\n");
		sb.append("\tleasetag: ");
		sb.append(leasetag==null?"null":getLeasetag());
		sb.append("\n");
		sb.append("\tlastchangedate: ");
		sb.append(lastchangedate==null?"null":getLastchangedate());
		sb.append("\n");
		sb.append("\tchangetag: ");
		sb.append(changetag==null?"null":getChangetag());
		sb.append("\n");
		sb.append("\tchangedate: ");
		sb.append(changedate==null?"null":getChangedate());
		sb.append("\n");
		sb.append("\tcancelReason: ");
		sb.append(cancelReason==null?"null":getCancelReason());
		sb.append("\n");
		sb.append("\tchildBuildno: ");
		sb.append(childBuildno==null?"null":getChildBuildno());
		sb.append("\n");
		sb.append("\tchildHouseno: ");
		sb.append(childHouseno==null?"null":getChildHouseno());
		sb.append("\n");
		sb.append("\trelaCustcode: ");
		sb.append(relaCustcode==null?"null":getRelaCustcode());
		sb.append("\n");
		sb.append("\trelaSeq: ");
		sb.append(relaSeq==null?"null":getRelaSeq());
		sb.append("\n");
		sb.append("\tvattag: ");
		sb.append(vattag==null?"null":getVattag());
		sb.append("\n");
		sb.append("\texclusivearea: ");
		sb.append(exclusivearea==null?"null":getExclusivearea());
		sb.append("\n");
		sb.append("\tcommonarea: ");
		sb.append(commonarea==null?"null":getCommonarea());
		sb.append("\n");
		sb.append("\tetccommonarea: ");
		sb.append(etccommonarea==null?"null":getEtccommonarea());
		sb.append("\n");
		sb.append("\tparkingarea: ");
		sb.append(parkingarea==null?"null":getParkingarea());
		sb.append("\n");
		sb.append("\tservicearea: ");
		sb.append(servicearea==null?"null":getServicearea());
		sb.append("\n");
		sb.append("\tsitearea: ");
		sb.append(sitearea==null?"null":getSitearea());
		sb.append("\n");
		sb.append("\tmoveinstartdate: ");
		sb.append(moveinstartdate==null?"null":getMoveinstartdate());
		sb.append("\n");
		sb.append("\tmoveinenddate: ");
		sb.append(moveinenddate==null?"null":getMoveinenddate());
		sb.append("\n");
		sb.append("\tunionCnt: ");
		sb.append(unionCnt==null?"null":getUnionCnt());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\trefundmentdate: ");
		sb.append(refundmentdate==null?"null":getRefundmentdate());
		sb.append("\n");
		sb.append("\trefundmentamt: ");
		sb.append(refundmentamt==null?"null":getRefundmentamt());
		sb.append("\n");
		sb.append("\tpenaltyamt: ");
		sb.append(penaltyamt==null?"null":getPenaltyamt());
		sb.append("\n");
		sb.append("\tloanInterest: ");
		sb.append(loanInterest==null?"null":getLoanInterest());
		sb.append("\n");
		sb.append("\tsodukTax: ");
		sb.append(sodukTax==null?"null":getSodukTax());
		sb.append("\n");
		sb.append("\tjuminTax: ");
		sb.append(juminTax==null?"null":getJuminTax());
		sb.append("\n");
		sb.append("\tbankLoanOrgamt: ");
		sb.append(bankLoanOrgamt==null?"null":getBankLoanOrgamt());
		sb.append("\n");
		sb.append("\tbankLoanInterest: ");
		sb.append(bankLoanInterest==null?"null":getBankLoanInterest());
		sb.append("\n");
		sb.append("\tloanbank: ");
		sb.append(loanbank==null?"null":getLoanbank());
		sb.append("\n");
		sb.append("\tloandeposit: ");
		sb.append(loandeposit==null?"null":getLoandeposit());
		sb.append("\n");
		sb.append("\tloanuser: ");
		sb.append(loanuser==null?"null":getLoanuser());
		sb.append("\n");
		sb.append("\trefundDeposit: ");
		sb.append(refundDeposit==null?"null":getRefundDeposit());
		sb.append("\n");
		sb.append("\trefundBank: ");
		sb.append(refundBank==null?"null":getRefundBank());
		sb.append("\n");
		sb.append("\tcompLoanamt: ");
		sb.append(compLoanamt==null?"null":getCompLoanamt());
		sb.append("\n");
		sb.append("\tbillReturnamt: ");
		sb.append(billReturnamt==null?"null":getBillReturnamt());
		sb.append("\n");
		sb.append("\tdelayIndeminity: ");
		sb.append(delayIndeminity==null?"null":getDelayIndeminity());
		sb.append("\n");
		sb.append("\tdepositCount: ");
		sb.append(depositCount==null?"null":getDepositCount());
		sb.append("\n");
		sb.append("\tcoCustcode: ");
		sb.append(coCustcode==null?"null":getCoCustcode());
		sb.append("\n");
		sb.append("\tcoSangho: ");
		sb.append(coSangho==null?"null":getCoSangho());
		sb.append("\n");
		sb.append("\tcoCondition: ");
		sb.append(coCondition==null?"null":getCoCondition());
		sb.append("\n");
		sb.append("\tcoCategory: ");
		sb.append(coCategory==null?"null":getCoCategory());
		sb.append("\n");
		sb.append("\tcategoryName: ");
		sb.append(categoryName==null?"null":getCategoryName());
		sb.append("\n");
		sb.append("\tslipdate: ");
		sb.append(slipdate==null?"null":getSlipdate());
		sb.append("\n");
		sb.append("\tslipseq: ");
		sb.append(slipseq==null?"null":getSlipseq());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("\tapplyYn: ");
		sb.append(applyYn==null?"null":getApplyYn());
		sb.append("\n");
		sb.append("\tapplyEmpno: ");
		sb.append(applyEmpno==null?"null":getApplyEmpno());
		sb.append("\n");
		sb.append("\tapplyDate: ");
		sb.append(applyDate==null?"null":getApplyDate());
		sb.append("\n");
		sb.append("\tprtsquare: ");
		sb.append(prtsquare==null?"null":getPrtsquare());
		sb.append("\n");
		sb.append("\tbankLoanInterest2: ");
		sb.append(bankLoanInterest2==null?"null":getBankLoanInterest2());
		sb.append("\n");
		sb.append("\tetcAmt: ");
		sb.append(etcAmt==null?"null":getEtcAmt());
		sb.append("\n");
		sb.append("\trenthdYn: ");
		sb.append(renthdYn==null?"null":getRenthdYn());
		sb.append("\n");
		sb.append("\trenthdSeq: ");
		sb.append(renthdSeq==null?"null":getRenthdSeq());
		sb.append("\n");
		sb.append("\tbalconyTag: ");
		sb.append(balconyTag==null?"null":getBalconyTag());
		sb.append("\n");
		sb.append("\tbalconyarea: ");
		sb.append(balconyarea==null?"null":getBalconyarea());
		sb.append("\n");
		sb.append("\tdaymonthTag: ");
		sb.append(daymonthTag==null?"null":getDaymonthTag());
		sb.append("\n");
		sb.append("\tfloor: ");
		sb.append(floor==null?"null":getFloor());
		sb.append("\n");
		sb.append("\tcontCondition: ");
		sb.append(contCondition==null?"null":getContCondition());
		sb.append("\n");
		sb.append("\tlandReturn: ");
		sb.append(landReturn==null?"null":getLandReturn());
		sb.append("\n");
		sb.append("\tintCalcDate: ");
		sb.append(intCalcDate==null?"null":getIntCalcDate());
		sb.append("\n");
		sb.append("\tpredisamt: ");
		sb.append(predisamt==null?"null":getPredisamt());
		sb.append("\n");
		sb.append("\tproxyamt: ");
		sb.append(proxyamt==null?"null":getProxyamt());
		sb.append("\n");
		sb.append("\tincontDate: ");
		sb.append(incontDate==null?"null":getIncontDate());
		sb.append("\n");
		sb.append("\ttrustamt: ");
		sb.append(trustamt==null?"null":getTrustamt());
		sb.append("\n");
		sb.append("\tpredisTag: ");
		sb.append(predisTag==null?"null":getPredisTag());
		sb.append("\n");
		sb.append("\tproxyTag: ");
		sb.append(proxyTag==null?"null":getProxyTag());
		sb.append("\n");
		sb.append("\ttrustTag: ");
		sb.append(trustTag==null?"null":getTrustTag());
		sb.append("\n");
		sb.append("\tvirYn: ");
		sb.append(virYn==null?"null":getVirYn());
		sb.append("\n");
		sb.append("\tvdeposit: ");
		sb.append(vdeposit==null?"null":getVdeposit());
		sb.append("\n");
		sb.append("\trepLimitdt: ");
		sb.append(repLimitdt==null?"null":getRepLimitdt());
		sb.append("\n");
		sb.append("\trepYn: ");
		sb.append(repYn==null?"null":getRepYn());
		sb.append("\n");
		sb.append("\trepDate: ");
		sb.append(repDate==null?"null":getRepDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 1; /* writetag */
		messageLen+= 20; /* writetime */
		messageLen+= 22; /* writeseq */
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 10; /* buildno */
		messageLen+= 10; /* houseno */
		messageLen+= 20; /* dongho */
		messageLen+= 50; /* custName */
		messageLen+= 22; /* square */
		messageLen+= 4; /* type */
		messageLen+= 1; /* classJrw */
		messageLen+= 2; /* optioncode */
		messageLen+= 1; /* contracttag */
		messageLen+= 8; /* contractdate */
		messageLen+= 10; /* contractno */
		messageLen+= 1; /* loanTag */
		messageLen+= 1; /* leasetag */
		messageLen+= 8; /* lastchangedate */
		messageLen+= 1; /* changetag */
		messageLen+= 8; /* changedate */
		messageLen+= 50; /* cancelReason */
		messageLen+= 10; /* childBuildno */
		messageLen+= 10; /* childHouseno */
		messageLen+= 13; /* relaCustcode */
		messageLen+= 22; /* relaSeq */
		messageLen+= 1; /* vattag */
		messageLen+= 22; /* exclusivearea */
		messageLen+= 22; /* commonarea */
		messageLen+= 22; /* etccommonarea */
		messageLen+= 22; /* parkingarea */
		messageLen+= 22; /* servicearea */
		messageLen+= 22; /* sitearea */
		messageLen+= 8; /* moveinstartdate */
		messageLen+= 8; /* moveinenddate */
		messageLen+= 22; /* unionCnt */
		messageLen+= 50; /* remark */
		messageLen+= 8; /* refundmentdate */
		messageLen+= 22; /* refundmentamt */
		messageLen+= 22; /* penaltyamt */
		messageLen+= 22; /* loanInterest */
		messageLen+= 22; /* sodukTax */
		messageLen+= 22; /* juminTax */
		messageLen+= 22; /* bankLoanOrgamt */
		messageLen+= 22; /* bankLoanInterest */
		messageLen+= 30; /* loanbank */
		messageLen+= 30; /* loandeposit */
		messageLen+= 30; /* loanuser */
		messageLen+= 30; /* refundDeposit */
		messageLen+= 40; /* refundBank */
		messageLen+= 22; /* compLoanamt */
		messageLen+= 22; /* billReturnamt */
		messageLen+= 22; /* delayIndeminity */
		messageLen+= 22; /* depositCount */
		messageLen+= 20; /* coCustcode */
		messageLen+= 30; /* coSangho */
		messageLen+= 30; /* coCondition */
		messageLen+= 12; /* coCategory */
		messageLen+= 40; /* categoryName */
		messageLen+= 8; /* slipdate */
		messageLen+= 22; /* slipseq */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
		messageLen+= 1; /* applyYn */
		messageLen+= 12; /* applyEmpno */
		messageLen+= 14; /* applyDate */
		messageLen+= 22; /* prtsquare */
		messageLen+= 22; /* bankLoanInterest2 */
		messageLen+= 22; /* etcAmt */
		messageLen+= 1; /* renthdYn */
		messageLen+= 22; /* renthdSeq */
		messageLen+= 1; /* balconyTag */
		messageLen+= 22; /* balconyarea */
		messageLen+= 1; /* daymonthTag */
		messageLen+= 4; /* floor */
		messageLen+= 2; /* contCondition */
		messageLen+= 2; /* landReturn */
		messageLen+= 8; /* intCalcDate */
		messageLen+= 22; /* predisamt */
		messageLen+= 22; /* proxyamt */
		messageLen+= 8; /* incontDate */
		messageLen+= 22; /* trustamt */
		messageLen+= 1; /* predisTag */
		messageLen+= 1; /* proxyTag */
		messageLen+= 1; /* trustTag */
		messageLen+= 1; /* virYn */
		messageLen+= 50; /* vdeposit */
		messageLen+= 8; /* repLimitdt */
		messageLen+= 1; /* repYn */
		messageLen+= 8; /* repDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("writetag");
	
		fieldNames.add("writetime");
	
		fieldNames.add("writeseq");
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("buildno");
	
		fieldNames.add("houseno");
	
		fieldNames.add("dongho");
	
		fieldNames.add("custName");
	
		fieldNames.add("square");
	
		fieldNames.add("type");
	
		fieldNames.add("classJrw");
	
		fieldNames.add("optioncode");
	
		fieldNames.add("contracttag");
	
		fieldNames.add("contractdate");
	
		fieldNames.add("contractno");
	
		fieldNames.add("loanTag");
	
		fieldNames.add("leasetag");
	
		fieldNames.add("lastchangedate");
	
		fieldNames.add("changetag");
	
		fieldNames.add("changedate");
	
		fieldNames.add("cancelReason");
	
		fieldNames.add("childBuildno");
	
		fieldNames.add("childHouseno");
	
		fieldNames.add("relaCustcode");
	
		fieldNames.add("relaSeq");
	
		fieldNames.add("vattag");
	
		fieldNames.add("exclusivearea");
	
		fieldNames.add("commonarea");
	
		fieldNames.add("etccommonarea");
	
		fieldNames.add("parkingarea");
	
		fieldNames.add("servicearea");
	
		fieldNames.add("sitearea");
	
		fieldNames.add("moveinstartdate");
	
		fieldNames.add("moveinenddate");
	
		fieldNames.add("unionCnt");
	
		fieldNames.add("remark");
	
		fieldNames.add("refundmentdate");
	
		fieldNames.add("refundmentamt");
	
		fieldNames.add("penaltyamt");
	
		fieldNames.add("loanInterest");
	
		fieldNames.add("sodukTax");
	
		fieldNames.add("juminTax");
	
		fieldNames.add("bankLoanOrgamt");
	
		fieldNames.add("bankLoanInterest");
	
		fieldNames.add("loanbank");
	
		fieldNames.add("loandeposit");
	
		fieldNames.add("loanuser");
	
		fieldNames.add("refundDeposit");
	
		fieldNames.add("refundBank");
	
		fieldNames.add("compLoanamt");
	
		fieldNames.add("billReturnamt");
	
		fieldNames.add("delayIndeminity");
	
		fieldNames.add("depositCount");
	
		fieldNames.add("coCustcode");
	
		fieldNames.add("coSangho");
	
		fieldNames.add("coCondition");
	
		fieldNames.add("coCategory");
	
		fieldNames.add("categoryName");
	
		fieldNames.add("slipdate");
	
		fieldNames.add("slipseq");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
		fieldNames.add("applyYn");
	
		fieldNames.add("applyEmpno");
	
		fieldNames.add("applyDate");
	
		fieldNames.add("prtsquare");
	
		fieldNames.add("bankLoanInterest2");
	
		fieldNames.add("etcAmt");
	
		fieldNames.add("renthdYn");
	
		fieldNames.add("renthdSeq");
	
		fieldNames.add("balconyTag");
	
		fieldNames.add("balconyarea");
	
		fieldNames.add("daymonthTag");
	
		fieldNames.add("floor");
	
		fieldNames.add("contCondition");
	
		fieldNames.add("landReturn");
	
		fieldNames.add("intCalcDate");
	
		fieldNames.add("predisamt");
	
		fieldNames.add("proxyamt");
	
		fieldNames.add("incontDate");
	
		fieldNames.add("trustamt");
	
		fieldNames.add("predisTag");
	
		fieldNames.add("proxyTag");
	
		fieldNames.add("trustTag");
	
		fieldNames.add("virYn");
	
		fieldNames.add("vdeposit");
	
		fieldNames.add("repLimitdt");
	
		fieldNames.add("repYn");
	
		fieldNames.add("repDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("writetag", get("writetag"));
	
		fieldValueMap.put("writetime", get("writetime"));
	
		fieldValueMap.put("writeseq", get("writeseq"));
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("buildno", get("buildno"));
	
		fieldValueMap.put("houseno", get("houseno"));
	
		fieldValueMap.put("dongho", get("dongho"));
	
		fieldValueMap.put("custName", get("custName"));
	
		fieldValueMap.put("square", get("square"));
	
		fieldValueMap.put("type", get("type"));
	
		fieldValueMap.put("classJrw", get("classJrw"));
	
		fieldValueMap.put("optioncode", get("optioncode"));
	
		fieldValueMap.put("contracttag", get("contracttag"));
	
		fieldValueMap.put("contractdate", get("contractdate"));
	
		fieldValueMap.put("contractno", get("contractno"));
	
		fieldValueMap.put("loanTag", get("loanTag"));
	
		fieldValueMap.put("leasetag", get("leasetag"));
	
		fieldValueMap.put("lastchangedate", get("lastchangedate"));
	
		fieldValueMap.put("changetag", get("changetag"));
	
		fieldValueMap.put("changedate", get("changedate"));
	
		fieldValueMap.put("cancelReason", get("cancelReason"));
	
		fieldValueMap.put("childBuildno", get("childBuildno"));
	
		fieldValueMap.put("childHouseno", get("childHouseno"));
	
		fieldValueMap.put("relaCustcode", get("relaCustcode"));
	
		fieldValueMap.put("relaSeq", get("relaSeq"));
	
		fieldValueMap.put("vattag", get("vattag"));
	
		fieldValueMap.put("exclusivearea", get("exclusivearea"));
	
		fieldValueMap.put("commonarea", get("commonarea"));
	
		fieldValueMap.put("etccommonarea", get("etccommonarea"));
	
		fieldValueMap.put("parkingarea", get("parkingarea"));
	
		fieldValueMap.put("servicearea", get("servicearea"));
	
		fieldValueMap.put("sitearea", get("sitearea"));
	
		fieldValueMap.put("moveinstartdate", get("moveinstartdate"));
	
		fieldValueMap.put("moveinenddate", get("moveinenddate"));
	
		fieldValueMap.put("unionCnt", get("unionCnt"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("refundmentdate", get("refundmentdate"));
	
		fieldValueMap.put("refundmentamt", get("refundmentamt"));
	
		fieldValueMap.put("penaltyamt", get("penaltyamt"));
	
		fieldValueMap.put("loanInterest", get("loanInterest"));
	
		fieldValueMap.put("sodukTax", get("sodukTax"));
	
		fieldValueMap.put("juminTax", get("juminTax"));
	
		fieldValueMap.put("bankLoanOrgamt", get("bankLoanOrgamt"));
	
		fieldValueMap.put("bankLoanInterest", get("bankLoanInterest"));
	
		fieldValueMap.put("loanbank", get("loanbank"));
	
		fieldValueMap.put("loandeposit", get("loandeposit"));
	
		fieldValueMap.put("loanuser", get("loanuser"));
	
		fieldValueMap.put("refundDeposit", get("refundDeposit"));
	
		fieldValueMap.put("refundBank", get("refundBank"));
	
		fieldValueMap.put("compLoanamt", get("compLoanamt"));
	
		fieldValueMap.put("billReturnamt", get("billReturnamt"));
	
		fieldValueMap.put("delayIndeminity", get("delayIndeminity"));
	
		fieldValueMap.put("depositCount", get("depositCount"));
	
		fieldValueMap.put("coCustcode", get("coCustcode"));
	
		fieldValueMap.put("coSangho", get("coSangho"));
	
		fieldValueMap.put("coCondition", get("coCondition"));
	
		fieldValueMap.put("coCategory", get("coCategory"));
	
		fieldValueMap.put("categoryName", get("categoryName"));
	
		fieldValueMap.put("slipdate", get("slipdate"));
	
		fieldValueMap.put("slipseq", get("slipseq"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
		fieldValueMap.put("applyYn", get("applyYn"));
	
		fieldValueMap.put("applyEmpno", get("applyEmpno"));
	
		fieldValueMap.put("applyDate", get("applyDate"));
	
		fieldValueMap.put("prtsquare", get("prtsquare"));
	
		fieldValueMap.put("bankLoanInterest2", get("bankLoanInterest2"));
	
		fieldValueMap.put("etcAmt", get("etcAmt"));
	
		fieldValueMap.put("renthdYn", get("renthdYn"));
	
		fieldValueMap.put("renthdSeq", get("renthdSeq"));
	
		fieldValueMap.put("balconyTag", get("balconyTag"));
	
		fieldValueMap.put("balconyarea", get("balconyarea"));
	
		fieldValueMap.put("daymonthTag", get("daymonthTag"));
	
		fieldValueMap.put("floor", get("floor"));
	
		fieldValueMap.put("contCondition", get("contCondition"));
	
		fieldValueMap.put("landReturn", get("landReturn"));
	
		fieldValueMap.put("intCalcDate", get("intCalcDate"));
	
		fieldValueMap.put("predisamt", get("predisamt"));
	
		fieldValueMap.put("proxyamt", get("proxyamt"));
	
		fieldValueMap.put("incontDate", get("incontDate"));
	
		fieldValueMap.put("trustamt", get("trustamt"));
	
		fieldValueMap.put("predisTag", get("predisTag"));
	
		fieldValueMap.put("proxyTag", get("proxyTag"));
	
		fieldValueMap.put("trustTag", get("trustTag"));
	
		fieldValueMap.put("virYn", get("virYn"));
	
		fieldValueMap.put("vdeposit", get("vdeposit"));
	
		fieldValueMap.put("repLimitdt", get("repLimitdt"));
	
		fieldValueMap.put("repYn", get("repYn"));
	
		fieldValueMap.put("repDate", get("repDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -1846450341 : /* writetag */
			return getWritetag();
		case -1405377748 : /* writetime */
			return getWritetime();
		case -1846451168 : /* writeseq */
			return getWriteseq();
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 230944943 : /* buildno */
			return getBuildno();
		case 1100516577 : /* houseno */
			return getHouseno();
		case -1326162037 : /* dongho */
			return getDongho();
		case 605180798 : /* custName */
			return getCustName();
		case -894674659 : /* square */
			return getSquare();
		case 3575610 : /* type */
			return getType();
		case 692414359 : /* classJrw */
			return getClassJrw();
		case 1374024674 : /* optioncode */
			return getOptioncode();
		case -2123416248 : /* contracttag */
			return getContracttag();
		case -1401870400 : /* contractdate */
			return getContractdate();
		case 624239187 : /* contractno */
			return getContractno();
		case 336927882 : /* loanTag */
			return getLoanTag();
		case 1574869760 : /* leasetag */
			return getLeasetag();
		case 379157108 : /* lastchangedate */
			return getLastchangedate();
		case 1455279594 : /* changetag */
			return getChangetag();
		case -2131448994 : /* changedate */
			return getChangedate();
		case -1862112930 : /* cancelReason */
			return getCancelReason();
		case 982244339 : /* childBuildno */
			return getChildBuildno();
		case 1851815973 : /* childHouseno */
			return getChildHouseno();
		case -1875482168 : /* relaCustcode */
			return getRelaCustcode();
		case 1090461783 : /* relaSeq */
			return getRelaSeq();
		case -823575599 : /* vattag */
			return getVattag();
		case 1197019179 : /* exclusivearea */
			return getExclusivearea();
		case 1184894200 : /* commonarea */
			return getCommonarea();
		case 1900129676 : /* etccommonarea */
			return getEtccommonarea();
		case -1720326075 : /* parkingarea */
			return getParkingarea();
		case -1927990078 : /* servicearea */
			return getServicearea();
		case 675591252 : /* sitearea */
			return getSitearea();
		case -1249212646 : /* moveinstartdate */
			return getMoveinstartdate();
		case -113122925 : /* moveinenddate */
			return getMoveinenddate();
		case -296547302 : /* unionCnt */
			return getUnionCnt();
		case -934624384 : /* remark */
			return getRemark();
		case -1979118204 : /* refundmentdate */
			return getRefundmentdate();
		case -1172223694 : /* refundmentamt */
			return getRefundmentamt();
		case -872052577 : /* penaltyamt */
			return getPenaltyamt();
		case 959504442 : /* loanInterest */
			return getLoanInterest();
		case 1262624941 : /* sodukTax */
			return getSodukTax();
		case -261041916 : /* juminTax */
			return getJuminTax();
		case -730385200 : /* bankLoanOrgamt */
			return getBankLoanOrgamt();
		case 1728495766 : /* bankLoanInterest */
			return getBankLoanInterest();
		case 1855247148 : /* loanbank */
			return getLoanbank();
		case -374742098 : /* loandeposit */
			return getLoandeposit();
		case 1855830203 : /* loanuser */
			return getLoanuser();
		case 1096546310 : /* refundDeposit */
			return getRefundDeposit();
		case -1711612460 : /* refundBank */
			return getRefundBank();
		case -1958872887 : /* compLoanamt */
			return getCompLoanamt();
		case -1783463343 : /* billReturnamt */
			return getBillReturnamt();
		case -1325119771 : /* delayIndeminity */
			return getDelayIndeminity();
		case 265862417 : /* depositCount */
			return getDepositCount();
		case -368486580 : /* coCustcode */
			return getCoCustcode();
		case -1357594790 : /* coSangho */
			return getCoSangho();
		case -1000031729 : /* coCondition */
			return getCoCondition();
		case -923795062 : /* coCategory */
			return getCoCategory();
		case 426048681 : /* categoryName */
			return getCategoryName();
		case -1261553426 : /* slipdate */
			return getSlipdate();
		case -2118890721 : /* slipseq */
			return getSlipseq();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		case -793220317 : /* applyYn */
			return getApplyYn();
		case 65209787 : /* applyEmpno */
			return getApplyEmpno();
		case -2076147652 : /* applyDate */
			return getApplyDate();
		case -483017137 : /* prtsquare */
			return getPrtsquare();
		case 2043761244 : /* bankLoanInterest2 */
			return getBankLoanInterest2();
		case -1293279340 : /* etcAmt */
			return getEtcAmt();
		case -479993878 : /* renthdYn */
			return getRenthdYn();
		case -1994914262 : /* renthdSeq */
			return getRenthdSeq();
		case -1111260106 : /* balconyTag */
			return getBalconyTag();
		case -88921263 : /* balconyarea */
			return getBalconyarea();
		case -1166132074 : /* daymonthTag */
			return getDaymonthTag();
		case 97526796 : /* floor */
			return getFloor();
		case -2108041719 : /* contCondition */
			return getContCondition();
		case 458055419 : /* landReturn */
			return getLandReturn();
		case 828917938 : /* intCalcDate */
			return getIntCalcDate();
		case -1347555619 : /* predisamt */
			return getPredisamt();
		case -985173862 : /* proxyamt */
			return getProxyamt();
		case -978894299 : /* incontDate */
			return getIncontDate();
		case 1858108528 : /* trustamt */
			return getTrustamt();
		case -1347568497 : /* predisTag */
			return getPredisTag();
		case -985186740 : /* proxyTag */
			return getProxyTag();
		case 1858095650 : /* trustTag */
			return getTrustTag();
		case 112215956 : /* virYn */
			return getVirYn();
		case 1047643496 : /* vdeposit */
			return getVdeposit();
		case 670022190 : /* repLimitdt */
			return getRepLimitdt();
		case 108400786 : /* repYn */
			return getRepYn();
		case 1093305835 : /* repDate */
			return getRepDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case -1846450341 : /* writetag */
			setWritetag((java.lang.String) value);
			return;
		case -1405377748 : /* writetime */
			setWritetime((java.lang.String) value);
			return;
		case -1846451168 : /* writeseq */
			setWriteseq((java.math.BigDecimal) value);
			return;
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 230944943 : /* buildno */
			setBuildno((java.lang.String) value);
			return;
		case 1100516577 : /* houseno */
			setHouseno((java.lang.String) value);
			return;
		case -1326162037 : /* dongho */
			setDongho((java.lang.String) value);
			return;
		case 605180798 : /* custName */
			setCustName((java.lang.String) value);
			return;
		case -894674659 : /* square */
			setSquare((java.math.BigDecimal) value);
			return;
		case 3575610 : /* type */
			setType((java.lang.String) value);
			return;
		case 692414359 : /* classJrw */
			setClassJrw((java.lang.String) value);
			return;
		case 1374024674 : /* optioncode */
			setOptioncode((java.lang.String) value);
			return;
		case -2123416248 : /* contracttag */
			setContracttag((java.lang.String) value);
			return;
		case -1401870400 : /* contractdate */
			setContractdate((java.lang.String) value);
			return;
		case 624239187 : /* contractno */
			setContractno((java.lang.String) value);
			return;
		case 336927882 : /* loanTag */
			setLoanTag((java.lang.String) value);
			return;
		case 1574869760 : /* leasetag */
			setLeasetag((java.lang.String) value);
			return;
		case 379157108 : /* lastchangedate */
			setLastchangedate((java.lang.String) value);
			return;
		case 1455279594 : /* changetag */
			setChangetag((java.lang.String) value);
			return;
		case -2131448994 : /* changedate */
			setChangedate((java.lang.String) value);
			return;
		case -1862112930 : /* cancelReason */
			setCancelReason((java.lang.String) value);
			return;
		case 982244339 : /* childBuildno */
			setChildBuildno((java.lang.String) value);
			return;
		case 1851815973 : /* childHouseno */
			setChildHouseno((java.lang.String) value);
			return;
		case -1875482168 : /* relaCustcode */
			setRelaCustcode((java.lang.String) value);
			return;
		case 1090461783 : /* relaSeq */
			setRelaSeq((java.math.BigDecimal) value);
			return;
		case -823575599 : /* vattag */
			setVattag((java.lang.String) value);
			return;
		case 1197019179 : /* exclusivearea */
			setExclusivearea((java.math.BigDecimal) value);
			return;
		case 1184894200 : /* commonarea */
			setCommonarea((java.math.BigDecimal) value);
			return;
		case 1900129676 : /* etccommonarea */
			setEtccommonarea((java.math.BigDecimal) value);
			return;
		case -1720326075 : /* parkingarea */
			setParkingarea((java.math.BigDecimal) value);
			return;
		case -1927990078 : /* servicearea */
			setServicearea((java.math.BigDecimal) value);
			return;
		case 675591252 : /* sitearea */
			setSitearea((java.math.BigDecimal) value);
			return;
		case -1249212646 : /* moveinstartdate */
			setMoveinstartdate((java.lang.String) value);
			return;
		case -113122925 : /* moveinenddate */
			setMoveinenddate((java.lang.String) value);
			return;
		case -296547302 : /* unionCnt */
			setUnionCnt((java.math.BigDecimal) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -1979118204 : /* refundmentdate */
			setRefundmentdate((java.lang.String) value);
			return;
		case -1172223694 : /* refundmentamt */
			setRefundmentamt((java.math.BigDecimal) value);
			return;
		case -872052577 : /* penaltyamt */
			setPenaltyamt((java.math.BigDecimal) value);
			return;
		case 959504442 : /* loanInterest */
			setLoanInterest((java.math.BigDecimal) value);
			return;
		case 1262624941 : /* sodukTax */
			setSodukTax((java.math.BigDecimal) value);
			return;
		case -261041916 : /* juminTax */
			setJuminTax((java.math.BigDecimal) value);
			return;
		case -730385200 : /* bankLoanOrgamt */
			setBankLoanOrgamt((java.math.BigDecimal) value);
			return;
		case 1728495766 : /* bankLoanInterest */
			setBankLoanInterest((java.math.BigDecimal) value);
			return;
		case 1855247148 : /* loanbank */
			setLoanbank((java.lang.String) value);
			return;
		case -374742098 : /* loandeposit */
			setLoandeposit((java.lang.String) value);
			return;
		case 1855830203 : /* loanuser */
			setLoanuser((java.lang.String) value);
			return;
		case 1096546310 : /* refundDeposit */
			setRefundDeposit((java.lang.String) value);
			return;
		case -1711612460 : /* refundBank */
			setRefundBank((java.lang.String) value);
			return;
		case -1958872887 : /* compLoanamt */
			setCompLoanamt((java.math.BigDecimal) value);
			return;
		case -1783463343 : /* billReturnamt */
			setBillReturnamt((java.math.BigDecimal) value);
			return;
		case -1325119771 : /* delayIndeminity */
			setDelayIndeminity((java.math.BigDecimal) value);
			return;
		case 265862417 : /* depositCount */
			setDepositCount((java.math.BigDecimal) value);
			return;
		case -368486580 : /* coCustcode */
			setCoCustcode((java.lang.String) value);
			return;
		case -1357594790 : /* coSangho */
			setCoSangho((java.lang.String) value);
			return;
		case -1000031729 : /* coCondition */
			setCoCondition((java.lang.String) value);
			return;
		case -923795062 : /* coCategory */
			setCoCategory((java.lang.String) value);
			return;
		case 426048681 : /* categoryName */
			setCategoryName((java.lang.String) value);
			return;
		case -1261553426 : /* slipdate */
			setSlipdate((java.lang.String) value);
			return;
		case -2118890721 : /* slipseq */
			setSlipseq((java.math.BigDecimal) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		case -793220317 : /* applyYn */
			setApplyYn((java.lang.String) value);
			return;
		case 65209787 : /* applyEmpno */
			setApplyEmpno((java.lang.String) value);
			return;
		case -2076147652 : /* applyDate */
			setApplyDate((java.lang.String) value);
			return;
		case -483017137 : /* prtsquare */
			setPrtsquare((java.math.BigDecimal) value);
			return;
		case 2043761244 : /* bankLoanInterest2 */
			setBankLoanInterest2((java.math.BigDecimal) value);
			return;
		case -1293279340 : /* etcAmt */
			setEtcAmt((java.math.BigDecimal) value);
			return;
		case -479993878 : /* renthdYn */
			setRenthdYn((java.lang.String) value);
			return;
		case -1994914262 : /* renthdSeq */
			setRenthdSeq((java.math.BigDecimal) value);
			return;
		case -1111260106 : /* balconyTag */
			setBalconyTag((java.lang.String) value);
			return;
		case -88921263 : /* balconyarea */
			setBalconyarea((java.math.BigDecimal) value);
			return;
		case -1166132074 : /* daymonthTag */
			setDaymonthTag((java.lang.String) value);
			return;
		case 97526796 : /* floor */
			setFloor((java.lang.String) value);
			return;
		case -2108041719 : /* contCondition */
			setContCondition((java.lang.String) value);
			return;
		case 458055419 : /* landReturn */
			setLandReturn((java.lang.String) value);
			return;
		case 828917938 : /* intCalcDate */
			setIntCalcDate((java.lang.String) value);
			return;
		case -1347555619 : /* predisamt */
			setPredisamt((java.math.BigDecimal) value);
			return;
		case -985173862 : /* proxyamt */
			setProxyamt((java.math.BigDecimal) value);
			return;
		case -978894299 : /* incontDate */
			setIncontDate((java.lang.String) value);
			return;
		case 1858108528 : /* trustamt */
			setTrustamt((java.math.BigDecimal) value);
			return;
		case -1347568497 : /* predisTag */
			setPredisTag((java.lang.String) value);
			return;
		case -985186740 : /* proxyTag */
			setProxyTag((java.lang.String) value);
			return;
		case 1858095650 : /* trustTag */
			setTrustTag((java.lang.String) value);
			return;
		case 112215956 : /* virYn */
			setVirYn((java.lang.String) value);
			return;
		case 1047643496 : /* vdeposit */
			setVdeposit((java.lang.String) value);
			return;
		case 670022190 : /* repLimitdt */
			setRepLimitdt((java.lang.String) value);
			return;
		case 108400786 : /* repYn */
			setRepYn((java.lang.String) value);
			return;
		case 1093305835 : /* repDate */
			setRepDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
