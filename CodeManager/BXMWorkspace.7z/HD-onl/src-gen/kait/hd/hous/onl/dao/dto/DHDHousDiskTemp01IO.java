/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.hous.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_디스켓저장 ( HD_HOUS_DISK_TEMP )
 */
@XmlType(propOrder={"deptCode", "housetag", "seq", "data1", "data2"}, name="DHDHousDiskTemp01IO")
@XmlRootElement(name="DHDHousDiskTemp01IO")
@SuppressWarnings("all")
public class DHDHousDiskTemp01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 520180013L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_디스켓저장 ( HD_HOUS_DISK_TEMP )";

	/*******************************************************************************************************************************
	* Property set << deptCode >> [[ */
	
	@XmlTransient
	private boolean isSet_deptCode = false;
	
	protected boolean isSet_deptCode()
	{
		return this.isSet_deptCode;
	}
	
	protected void setIsSet_deptCode(boolean value)
	{
		this.isSet_deptCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="현장코드 [SYS_C0012156(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String deptCode  = null;
	
	/**
	 * @Description 현장코드 [SYS_C0012156(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	public java.lang.String getDeptCode(){
		return deptCode;
	}
	
	/**
	 * @Description 현장코드 [SYS_C0012156(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	@JsonProperty("deptCode")
	public void setDeptCode( java.lang.String deptCode ) {
		isSet_deptCode = true;
		this.deptCode = deptCode;
	}
	
	/** Property set << deptCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << housetag >> [[ */
	
	@XmlTransient
	private boolean isSet_housetag = false;
	
	protected boolean isSet_housetag()
	{
		return this.isSet_housetag;
	}
	
	protected void setIsSet_housetag(boolean value)
	{
		this.isSet_housetag = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="분양구분 [SYS_C0012157(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String housetag  = null;
	
	/**
	 * @Description 분양구분 [SYS_C0012157(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	public java.lang.String getHousetag(){
		return housetag;
	}
	
	/**
	 * @Description 분양구분 [SYS_C0012157(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	@JsonProperty("housetag")
	public void setHousetag( java.lang.String housetag ) {
		isSet_housetag = true;
		this.housetag = housetag;
	}
	
	/** Property set << housetag >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 순번 [SYS_C0012158(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 순번 [SYS_C0012158(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 순번 [SYS_C0012158(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="순번 [SYS_C0012158(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 순번 [SYS_C0012158(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 순번 [SYS_C0012158(C),SYS_C0012929(P) SYS_C0012929(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << data1 >> [[ */
	
	@XmlTransient
	private boolean isSet_data1 = false;
	
	protected boolean isSet_data1()
	{
		return this.isSet_data1;
	}
	
	protected void setIsSet_data1(boolean value)
	{
		this.isSet_data1 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="데이타1", formatType="", format="", align="left", length=1000, decimal=0, arrayReference="", fill="")
	private java.lang.String data1  = null;
	
	/**
	 * @Description 데이타1
	 */
	public java.lang.String getData1(){
		return data1;
	}
	
	/**
	 * @Description 데이타1
	 */
	@JsonProperty("data1")
	public void setData1( java.lang.String data1 ) {
		isSet_data1 = true;
		this.data1 = data1;
	}
	
	/** Property set << data1 >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << data2 >> [[ */
	
	@XmlTransient
	private boolean isSet_data2 = false;
	
	protected boolean isSet_data2()
	{
		return this.isSet_data2;
	}
	
	protected void setIsSet_data2(boolean value)
	{
		this.isSet_data2 = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="데이타2", formatType="", format="", align="left", length=1000, decimal=0, arrayReference="", fill="")
	private java.lang.String data2  = null;
	
	/**
	 * @Description 데이타2
	 */
	public java.lang.String getData2(){
		return data2;
	}
	
	/**
	 * @Description 데이타2
	 */
	@JsonProperty("data2")
	public void setData2( java.lang.String data2 ) {
		isSet_data2 = true;
		this.data2 = data2;
	}
	
	/** Property set << data2 >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDHousDiskTemp01IO clone(){
		try{
			DHDHousDiskTemp01IO object= (DHDHousDiskTemp01IO)super.clone();
			if ( this.deptCode== null ) object.deptCode = null;
			else{
				object.deptCode = this.deptCode;
			}
			if ( this.housetag== null ) object.housetag = null;
			else{
				object.housetag = this.housetag;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.data1== null ) object.data1 = null;
			else{
				object.data1 = this.data1;
			}
			if ( this.data2== null ) object.data2 = null;
			else{
				object.data2 = this.data2;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((deptCode==null)?0:deptCode.hashCode());
		result = prime * result + ((housetag==null)?0:housetag.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((data1==null)?0:data1.hashCode());
		result = prime * result + ((data2==null)?0:data2.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO other = (kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO)obj;
		if ( deptCode == null ){
			if ( other.deptCode != null ) return false;
		}
		else if ( !deptCode.equals(other.deptCode) )
			return false;
		if ( housetag == null ){
			if ( other.housetag != null ) return false;
		}
		else if ( !housetag.equals(other.housetag) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( data1 == null ){
			if ( other.data1 != null ) return false;
		}
		else if ( !data1.equals(other.data1) )
			return false;
		if ( data2 == null ){
			if ( other.data2 != null ) return false;
		}
		else if ( !data2.equals(other.data2) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO:\n");
		sb.append("\tdeptCode: ");
		sb.append(deptCode==null?"null":getDeptCode());
		sb.append("\n");
		sb.append("\thousetag: ");
		sb.append(housetag==null?"null":getHousetag());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tdata1: ");
		sb.append(data1==null?"null":getData1());
		sb.append("\n");
		sb.append("\tdata2: ");
		sb.append(data2==null?"null":getData2());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 12; /* deptCode */
		messageLen+= 1; /* housetag */
		messageLen+= 22; /* seq */
		messageLen+= 1000; /* data1 */
		messageLen+= 1000; /* data2 */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("deptCode");
	
		fieldNames.add("housetag");
	
		fieldNames.add("seq");
	
		fieldNames.add("data1");
	
		fieldNames.add("data2");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("deptCode", get("deptCode"));
	
		fieldValueMap.put("housetag", get("housetag"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("data1", get("data1"));
	
		fieldValueMap.put("data2", get("data2"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			return getDeptCode();
		case -243719046 : /* housetag */
			return getHousetag();
		case 113759 : /* seq */
			return getSeq();
		case 95356359 : /* data1 */
			return getData1();
		case 95356360 : /* data2 */
			return getData2();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 946632146 : /* deptCode */
			setDeptCode((java.lang.String) value);
			return;
		case -243719046 : /* housetag */
			setHousetag((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case 95356359 : /* data1 */
			setData1((java.lang.String) value);
			return;
		case 95356360 : /* data2 */
			setData2((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
