/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.virture.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_분양_가상계좌 ( HD_VIRTURE_ACCOUNT )
 */
@XmlType(propOrder={"troccorgCd", "trIl", "cporgCd", "deptrSeq", "hndorgCd", "trSi", "txSeq", "txCd", "trCd", "fnGb", "vaNo", "depbnkCd", "depAmt", "ytstjmAmt", "depbnkNm", "custNm", "deptSt", "depcntGb"}, name="DHDVirtureAccount01IO")
@XmlRootElement(name="DHDVirtureAccount01IO")
@SuppressWarnings("all")
public class DHDVirtureAccount01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 2092855605L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_분양_가상계좌 ( HD_VIRTURE_ACCOUNT )";

	/*******************************************************************************************************************************
	* Property set << troccorgCd >> [[ */
	
	@XmlTransient
	private boolean isSet_troccorgCd = false;
	
	protected boolean isSet_troccorgCd()
	{
		return this.isSet_troccorgCd;
	}
	
	protected void setIsSet_troccorgCd(boolean value)
	{
		this.isSet_troccorgCd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="제휴은행코드 [SYS_C0012899(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String troccorgCd  = null;
	
	/**
	 * @Description 제휴은행코드 [SYS_C0012899(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	public java.lang.String getTroccorgCd(){
		return troccorgCd;
	}
	
	/**
	 * @Description 제휴은행코드 [SYS_C0012899(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	@JsonProperty("troccorgCd")
	public void setTroccorgCd( java.lang.String troccorgCd ) {
		isSet_troccorgCd = true;
		this.troccorgCd = troccorgCd;
	}
	
	/** Property set << troccorgCd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << trIl >> [[ */
	
	@XmlTransient
	private boolean isSet_trIl = false;
	
	protected boolean isSet_trIl()
	{
		return this.isSet_trIl;
	}
	
	protected void setIsSet_trIl(boolean value)
	{
		this.isSet_trIl = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래일자 [SYS_C0012900(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String trIl  = null;
	
	/**
	 * @Description 거래일자 [SYS_C0012900(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	public java.lang.String getTrIl(){
		return trIl;
	}
	
	/**
	 * @Description 거래일자 [SYS_C0012900(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	@JsonProperty("trIl")
	public void setTrIl( java.lang.String trIl ) {
		isSet_trIl = true;
		this.trIl = trIl;
	}
	
	/** Property set << trIl >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cporgCd >> [[ */
	
	@XmlTransient
	private boolean isSet_cporgCd = false;
	
	protected boolean isSet_cporgCd()
	{
		return this.isSet_cporgCd;
	}
	
	protected void setIsSet_cporgCd(boolean value)
	{
		this.isSet_cporgCd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="제휴기관코드 [SYS_C0012901(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String cporgCd  = null;
	
	/**
	 * @Description 제휴기관코드 [SYS_C0012901(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	public java.lang.String getCporgCd(){
		return cporgCd;
	}
	
	/**
	 * @Description 제휴기관코드 [SYS_C0012901(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	@JsonProperty("cporgCd")
	public void setCporgCd( java.lang.String cporgCd ) {
		isSet_cporgCd = true;
		this.cporgCd = cporgCd;
	}
	
	/** Property set << cporgCd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptrSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_deptrSeq = false;
	
	protected boolean isSet_deptrSeq()
	{
		return this.isSet_deptrSeq;
	}
	
	protected void setIsSet_deptrSeq(boolean value)
	{
		this.isSet_deptrSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="은행별거래번호 [SYS_C0012902(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]", formatType="", format="", align="left", length=7, decimal=0, arrayReference="", fill="")
	private java.lang.String deptrSeq  = null;
	
	/**
	 * @Description 은행별거래번호 [SYS_C0012902(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	public java.lang.String getDeptrSeq(){
		return deptrSeq;
	}
	
	/**
	 * @Description 은행별거래번호 [SYS_C0012902(C),SYS_C0013028(P) SYS_C0013028(UNIQUE)]
	 */
	@JsonProperty("deptrSeq")
	public void setDeptrSeq( java.lang.String deptrSeq ) {
		isSet_deptrSeq = true;
		this.deptrSeq = deptrSeq;
	}
	
	/** Property set << deptrSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << hndorgCd >> [[ */
	
	@XmlTransient
	private boolean isSet_hndorgCd = false;
	
	protected boolean isSet_hndorgCd()
	{
		return this.isSet_hndorgCd;
	}
	
	protected void setIsSet_hndorgCd(boolean value)
	{
		this.isSet_hndorgCd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="취급기관코드 [SYS_C0012903(C)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String hndorgCd  = null;
	
	/**
	 * @Description 취급기관코드 [SYS_C0012903(C)]
	 */
	public java.lang.String getHndorgCd(){
		return hndorgCd;
	}
	
	/**
	 * @Description 취급기관코드 [SYS_C0012903(C)]
	 */
	@JsonProperty("hndorgCd")
	public void setHndorgCd( java.lang.String hndorgCd ) {
		isSet_hndorgCd = true;
		this.hndorgCd = hndorgCd;
	}
	
	/** Property set << hndorgCd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << trSi >> [[ */
	
	@XmlTransient
	private boolean isSet_trSi = false;
	
	protected boolean isSet_trSi()
	{
		return this.isSet_trSi;
	}
	
	protected void setIsSet_trSi(boolean value)
	{
		this.isSet_trSi = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래시간", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String trSi  = null;
	
	/**
	 * @Description 거래시간
	 */
	public java.lang.String getTrSi(){
		return trSi;
	}
	
	/**
	 * @Description 거래시간
	 */
	@JsonProperty("trSi")
	public void setTrSi( java.lang.String trSi ) {
		isSet_trSi = true;
		this.trSi = trSi;
	}
	
	/** Property set << trSi >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << txSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_txSeq = false;
	
	protected boolean isSet_txSeq()
	{
		return this.isSet_txSeq;
	}
	
	protected void setIsSet_txSeq(boolean value)
	{
		this.isSet_txSeq = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전문일련번호", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String txSeq  = null;
	
	/**
	 * @Description 전문일련번호
	 */
	public java.lang.String getTxSeq(){
		return txSeq;
	}
	
	/**
	 * @Description 전문일련번호
	 */
	@JsonProperty("txSeq")
	public void setTxSeq( java.lang.String txSeq ) {
		isSet_txSeq = true;
		this.txSeq = txSeq;
	}
	
	/** Property set << txSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << txCd >> [[ */
	
	@XmlTransient
	private boolean isSet_txCd = false;
	
	protected boolean isSet_txCd()
	{
		return this.isSet_txCd;
	}
	
	protected void setIsSet_txCd(boolean value)
	{
		this.isSet_txCd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="전문구분", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String txCd  = null;
	
	/**
	 * @Description 전문구분
	 */
	public java.lang.String getTxCd(){
		return txCd;
	}
	
	/**
	 * @Description 전문구분
	 */
	@JsonProperty("txCd")
	public void setTxCd( java.lang.String txCd ) {
		isSet_txCd = true;
		this.txCd = txCd;
	}
	
	/** Property set << txCd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << trCd >> [[ */
	
	@XmlTransient
	private boolean isSet_trCd = false;
	
	protected boolean isSet_trCd()
	{
		return this.isSet_trCd;
	}
	
	protected void setIsSet_trCd(boolean value)
	{
		this.isSet_trCd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="업무구분", formatType="", format="", align="left", length=4, decimal=0, arrayReference="", fill="")
	private java.lang.String trCd  = null;
	
	/**
	 * @Description 업무구분
	 */
	public java.lang.String getTrCd(){
		return trCd;
	}
	
	/**
	 * @Description 업무구분
	 */
	@JsonProperty("trCd")
	public void setTrCd( java.lang.String trCd ) {
		isSet_trCd = true;
		this.trCd = trCd;
	}
	
	/** Property set << trCd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << fnGb >> [[ */
	
	@XmlTransient
	private boolean isSet_fnGb = false;
	
	protected boolean isSet_fnGb()
	{
		return this.isSet_fnGb;
	}
	
	protected void setIsSet_fnGb(boolean value)
	{
		this.isSet_fnGb = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 마감구분
	 */
	public void setFnGb(java.lang.String value) {
		isSet_fnGb = true;
		this.fnGb = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 마감구분
	 */
	public void setFnGb(double value) {
		isSet_fnGb = true;
		this.fnGb = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 마감구분
	 */
	public void setFnGb(long value) {
		isSet_fnGb = true;
		this.fnGb = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="마감구분", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal fnGb  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 마감구분
	 */
	public java.math.BigDecimal getFnGb(){
		return fnGb;
	}
	
	/**
	 * @Description 마감구분
	 */
	@JsonProperty("fnGb")
	public void setFnGb( java.math.BigDecimal fnGb ) {
		isSet_fnGb = true;
		this.fnGb = fnGb;
	}
	
	/** Property set << fnGb >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << vaNo >> [[ */
	
	@XmlTransient
	private boolean isSet_vaNo = false;
	
	protected boolean isSet_vaNo()
	{
		return this.isSet_vaNo;
	}
	
	protected void setIsSet_vaNo(boolean value)
	{
		this.isSet_vaNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="가상계좌번호", formatType="", format="", align="left", length=16, decimal=0, arrayReference="", fill="")
	private java.lang.String vaNo  = null;
	
	/**
	 * @Description 가상계좌번호
	 */
	public java.lang.String getVaNo(){
		return vaNo;
	}
	
	/**
	 * @Description 가상계좌번호
	 */
	@JsonProperty("vaNo")
	public void setVaNo( java.lang.String vaNo ) {
		isSet_vaNo = true;
		this.vaNo = vaNo;
	}
	
	/** Property set << vaNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depbnkCd >> [[ */
	
	@XmlTransient
	private boolean isSet_depbnkCd = false;
	
	protected boolean isSet_depbnkCd()
	{
		return this.isSet_depbnkCd;
	}
	
	protected void setIsSet_depbnkCd(boolean value)
	{
		this.isSet_depbnkCd = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금은행코드", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String depbnkCd  = null;
	
	/**
	 * @Description 입금은행코드
	 */
	public java.lang.String getDepbnkCd(){
		return depbnkCd;
	}
	
	/**
	 * @Description 입금은행코드
	 */
	@JsonProperty("depbnkCd")
	public void setDepbnkCd( java.lang.String depbnkCd ) {
		isSet_depbnkCd = true;
		this.depbnkCd = depbnkCd;
	}
	
	/** Property set << depbnkCd >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_depAmt = false;
	
	protected boolean isSet_depAmt()
	{
		return this.isSet_depAmt;
	}
	
	protected void setIsSet_depAmt(boolean value)
	{
		this.isSet_depAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 입금금액
	 */
	public void setDepAmt(java.lang.String value) {
		isSet_depAmt = true;
		this.depAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 입금금액
	 */
	public void setDepAmt(double value) {
		isSet_depAmt = true;
		this.depAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 입금금액
	 */
	public void setDepAmt(long value) {
		isSet_depAmt = true;
		this.depAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="입금금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal depAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 입금금액
	 */
	public java.math.BigDecimal getDepAmt(){
		return depAmt;
	}
	
	/**
	 * @Description 입금금액
	 */
	@JsonProperty("depAmt")
	public void setDepAmt( java.math.BigDecimal depAmt ) {
		isSet_depAmt = true;
		this.depAmt = depAmt;
	}
	
	/** Property set << depAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << ytstjmAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_ytstjmAmt = false;
	
	protected boolean isSet_ytstjmAmt()
	{
		return this.isSet_ytstjmAmt;
	}
	
	protected void setIsSet_ytstjmAmt(boolean value)
	{
		this.isSet_ytstjmAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 미결제타점권금액
	 */
	public void setYtstjmAmt(java.lang.String value) {
		isSet_ytstjmAmt = true;
		this.ytstjmAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 미결제타점권금액
	 */
	public void setYtstjmAmt(double value) {
		isSet_ytstjmAmt = true;
		this.ytstjmAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 미결제타점권금액
	 */
	public void setYtstjmAmt(long value) {
		isSet_ytstjmAmt = true;
		this.ytstjmAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="미결제타점권금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal ytstjmAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 미결제타점권금액
	 */
	public java.math.BigDecimal getYtstjmAmt(){
		return ytstjmAmt;
	}
	
	/**
	 * @Description 미결제타점권금액
	 */
	@JsonProperty("ytstjmAmt")
	public void setYtstjmAmt( java.math.BigDecimal ytstjmAmt ) {
		isSet_ytstjmAmt = true;
		this.ytstjmAmt = ytstjmAmt;
	}
	
	/** Property set << ytstjmAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depbnkNm >> [[ */
	
	@XmlTransient
	private boolean isSet_depbnkNm = false;
	
	protected boolean isSet_depbnkNm()
	{
		return this.isSet_depbnkNm;
	}
	
	protected void setIsSet_depbnkNm(boolean value)
	{
		this.isSet_depbnkNm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금은행명", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String depbnkNm  = null;
	
	/**
	 * @Description 입금은행명
	 */
	public java.lang.String getDepbnkNm(){
		return depbnkNm;
	}
	
	/**
	 * @Description 입금은행명
	 */
	@JsonProperty("depbnkNm")
	public void setDepbnkNm( java.lang.String depbnkNm ) {
		isSet_depbnkNm = true;
		this.depbnkNm = depbnkNm;
	}
	
	/** Property set << depbnkNm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << custNm >> [[ */
	
	@XmlTransient
	private boolean isSet_custNm = false;
	
	protected boolean isSet_custNm()
	{
		return this.isSet_custNm;
	}
	
	protected void setIsSet_custNm(boolean value)
	{
		this.isSet_custNm = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금의뢰인명", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custNm  = null;
	
	/**
	 * @Description 입금의뢰인명
	 */
	public java.lang.String getCustNm(){
		return custNm;
	}
	
	/**
	 * @Description 입금의뢰인명
	 */
	@JsonProperty("custNm")
	public void setCustNm( java.lang.String custNm ) {
		isSet_custNm = true;
		this.custNm = custNm;
	}
	
	/** Property set << custNm >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deptSt >> [[ */
	
	@XmlTransient
	private boolean isSet_deptSt = false;
	
	protected boolean isSet_deptSt()
	{
		return this.isSet_deptSt;
	}
	
	protected void setIsSet_deptSt(boolean value)
	{
		this.isSet_deptSt = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금상태", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String deptSt  = null;
	
	/**
	 * @Description 입금상태
	 */
	public java.lang.String getDeptSt(){
		return deptSt;
	}
	
	/**
	 * @Description 입금상태
	 */
	@JsonProperty("deptSt")
	public void setDeptSt( java.lang.String deptSt ) {
		isSet_deptSt = true;
		this.deptSt = deptSt;
	}
	
	/** Property set << deptSt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << depcntGb >> [[ */
	
	@XmlTransient
	private boolean isSet_depcntGb = false;
	
	protected boolean isSet_depcntGb()
	{
		return this.isSet_depcntGb;
	}
	
	protected void setIsSet_depcntGb(boolean value)
	{
		this.isSet_depcntGb = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입금확인구분", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String depcntGb  = null;
	
	/**
	 * @Description 입금확인구분
	 */
	public java.lang.String getDepcntGb(){
		return depcntGb;
	}
	
	/**
	 * @Description 입금확인구분
	 */
	@JsonProperty("depcntGb")
	public void setDepcntGb( java.lang.String depcntGb ) {
		isSet_depcntGb = true;
		this.depcntGb = depcntGb;
	}
	
	/** Property set << depcntGb >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDVirtureAccount01IO clone(){
		try{
			DHDVirtureAccount01IO object= (DHDVirtureAccount01IO)super.clone();
			if ( this.troccorgCd== null ) object.troccorgCd = null;
			else{
				object.troccorgCd = this.troccorgCd;
			}
			if ( this.trIl== null ) object.trIl = null;
			else{
				object.trIl = this.trIl;
			}
			if ( this.cporgCd== null ) object.cporgCd = null;
			else{
				object.cporgCd = this.cporgCd;
			}
			if ( this.deptrSeq== null ) object.deptrSeq = null;
			else{
				object.deptrSeq = this.deptrSeq;
			}
			if ( this.hndorgCd== null ) object.hndorgCd = null;
			else{
				object.hndorgCd = this.hndorgCd;
			}
			if ( this.trSi== null ) object.trSi = null;
			else{
				object.trSi = this.trSi;
			}
			if ( this.txSeq== null ) object.txSeq = null;
			else{
				object.txSeq = this.txSeq;
			}
			if ( this.txCd== null ) object.txCd = null;
			else{
				object.txCd = this.txCd;
			}
			if ( this.trCd== null ) object.trCd = null;
			else{
				object.trCd = this.trCd;
			}
			if ( this.fnGb== null ) object.fnGb = null;
			else{
				object.fnGb = new java.math.BigDecimal(fnGb.toString());
			}
			if ( this.vaNo== null ) object.vaNo = null;
			else{
				object.vaNo = this.vaNo;
			}
			if ( this.depbnkCd== null ) object.depbnkCd = null;
			else{
				object.depbnkCd = this.depbnkCd;
			}
			if ( this.depAmt== null ) object.depAmt = null;
			else{
				object.depAmt = new java.math.BigDecimal(depAmt.toString());
			}
			if ( this.ytstjmAmt== null ) object.ytstjmAmt = null;
			else{
				object.ytstjmAmt = new java.math.BigDecimal(ytstjmAmt.toString());
			}
			if ( this.depbnkNm== null ) object.depbnkNm = null;
			else{
				object.depbnkNm = this.depbnkNm;
			}
			if ( this.custNm== null ) object.custNm = null;
			else{
				object.custNm = this.custNm;
			}
			if ( this.deptSt== null ) object.deptSt = null;
			else{
				object.deptSt = this.deptSt;
			}
			if ( this.depcntGb== null ) object.depcntGb = null;
			else{
				object.depcntGb = this.depcntGb;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((troccorgCd==null)?0:troccorgCd.hashCode());
		result = prime * result + ((trIl==null)?0:trIl.hashCode());
		result = prime * result + ((cporgCd==null)?0:cporgCd.hashCode());
		result = prime * result + ((deptrSeq==null)?0:deptrSeq.hashCode());
		result = prime * result + ((hndorgCd==null)?0:hndorgCd.hashCode());
		result = prime * result + ((trSi==null)?0:trSi.hashCode());
		result = prime * result + ((txSeq==null)?0:txSeq.hashCode());
		result = prime * result + ((txCd==null)?0:txCd.hashCode());
		result = prime * result + ((trCd==null)?0:trCd.hashCode());
		result = prime * result + ((fnGb==null)?0:fnGb.hashCode());
		result = prime * result + ((vaNo==null)?0:vaNo.hashCode());
		result = prime * result + ((depbnkCd==null)?0:depbnkCd.hashCode());
		result = prime * result + ((depAmt==null)?0:depAmt.hashCode());
		result = prime * result + ((ytstjmAmt==null)?0:ytstjmAmt.hashCode());
		result = prime * result + ((depbnkNm==null)?0:depbnkNm.hashCode());
		result = prime * result + ((custNm==null)?0:custNm.hashCode());
		result = prime * result + ((deptSt==null)?0:deptSt.hashCode());
		result = prime * result + ((depcntGb==null)?0:depcntGb.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO other = (kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO)obj;
		if ( troccorgCd == null ){
			if ( other.troccorgCd != null ) return false;
		}
		else if ( !troccorgCd.equals(other.troccorgCd) )
			return false;
		if ( trIl == null ){
			if ( other.trIl != null ) return false;
		}
		else if ( !trIl.equals(other.trIl) )
			return false;
		if ( cporgCd == null ){
			if ( other.cporgCd != null ) return false;
		}
		else if ( !cporgCd.equals(other.cporgCd) )
			return false;
		if ( deptrSeq == null ){
			if ( other.deptrSeq != null ) return false;
		}
		else if ( !deptrSeq.equals(other.deptrSeq) )
			return false;
		if ( hndorgCd == null ){
			if ( other.hndorgCd != null ) return false;
		}
		else if ( !hndorgCd.equals(other.hndorgCd) )
			return false;
		if ( trSi == null ){
			if ( other.trSi != null ) return false;
		}
		else if ( !trSi.equals(other.trSi) )
			return false;
		if ( txSeq == null ){
			if ( other.txSeq != null ) return false;
		}
		else if ( !txSeq.equals(other.txSeq) )
			return false;
		if ( txCd == null ){
			if ( other.txCd != null ) return false;
		}
		else if ( !txCd.equals(other.txCd) )
			return false;
		if ( trCd == null ){
			if ( other.trCd != null ) return false;
		}
		else if ( !trCd.equals(other.trCd) )
			return false;
		if ( fnGb == null ){
			if ( other.fnGb != null ) return false;
		}
		else if ( !fnGb.equals(other.fnGb) )
			return false;
		if ( vaNo == null ){
			if ( other.vaNo != null ) return false;
		}
		else if ( !vaNo.equals(other.vaNo) )
			return false;
		if ( depbnkCd == null ){
			if ( other.depbnkCd != null ) return false;
		}
		else if ( !depbnkCd.equals(other.depbnkCd) )
			return false;
		if ( depAmt == null ){
			if ( other.depAmt != null ) return false;
		}
		else if ( !depAmt.equals(other.depAmt) )
			return false;
		if ( ytstjmAmt == null ){
			if ( other.ytstjmAmt != null ) return false;
		}
		else if ( !ytstjmAmt.equals(other.ytstjmAmt) )
			return false;
		if ( depbnkNm == null ){
			if ( other.depbnkNm != null ) return false;
		}
		else if ( !depbnkNm.equals(other.depbnkNm) )
			return false;
		if ( custNm == null ){
			if ( other.custNm != null ) return false;
		}
		else if ( !custNm.equals(other.custNm) )
			return false;
		if ( deptSt == null ){
			if ( other.deptSt != null ) return false;
		}
		else if ( !deptSt.equals(other.deptSt) )
			return false;
		if ( depcntGb == null ){
			if ( other.depcntGb != null ) return false;
		}
		else if ( !depcntGb.equals(other.depcntGb) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO:\n");
		sb.append("\ttroccorgCd: ");
		sb.append(troccorgCd==null?"null":getTroccorgCd());
		sb.append("\n");
		sb.append("\ttrIl: ");
		sb.append(trIl==null?"null":getTrIl());
		sb.append("\n");
		sb.append("\tcporgCd: ");
		sb.append(cporgCd==null?"null":getCporgCd());
		sb.append("\n");
		sb.append("\tdeptrSeq: ");
		sb.append(deptrSeq==null?"null":getDeptrSeq());
		sb.append("\n");
		sb.append("\thndorgCd: ");
		sb.append(hndorgCd==null?"null":getHndorgCd());
		sb.append("\n");
		sb.append("\ttrSi: ");
		sb.append(trSi==null?"null":getTrSi());
		sb.append("\n");
		sb.append("\ttxSeq: ");
		sb.append(txSeq==null?"null":getTxSeq());
		sb.append("\n");
		sb.append("\ttxCd: ");
		sb.append(txCd==null?"null":getTxCd());
		sb.append("\n");
		sb.append("\ttrCd: ");
		sb.append(trCd==null?"null":getTrCd());
		sb.append("\n");
		sb.append("\tfnGb: ");
		sb.append(fnGb==null?"null":getFnGb());
		sb.append("\n");
		sb.append("\tvaNo: ");
		sb.append(vaNo==null?"null":getVaNo());
		sb.append("\n");
		sb.append("\tdepbnkCd: ");
		sb.append(depbnkCd==null?"null":getDepbnkCd());
		sb.append("\n");
		sb.append("\tdepAmt: ");
		sb.append(depAmt==null?"null":getDepAmt());
		sb.append("\n");
		sb.append("\tytstjmAmt: ");
		sb.append(ytstjmAmt==null?"null":getYtstjmAmt());
		sb.append("\n");
		sb.append("\tdepbnkNm: ");
		sb.append(depbnkNm==null?"null":getDepbnkNm());
		sb.append("\n");
		sb.append("\tcustNm: ");
		sb.append(custNm==null?"null":getCustNm());
		sb.append("\n");
		sb.append("\tdeptSt: ");
		sb.append(deptSt==null?"null":getDeptSt());
		sb.append("\n");
		sb.append("\tdepcntGb: ");
		sb.append(depcntGb==null?"null":getDepcntGb());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 8; /* troccorgCd */
		messageLen+= 8; /* trIl */
		messageLen+= 8; /* cporgCd */
		messageLen+= 7; /* deptrSeq */
		messageLen+= 8; /* hndorgCd */
		messageLen+= 6; /* trSi */
		messageLen+= 10; /* txSeq */
		messageLen+= 4; /* txCd */
		messageLen+= 4; /* trCd */
		messageLen+= 22; /* fnGb */
		messageLen+= 16; /* vaNo */
		messageLen+= 8; /* depbnkCd */
		messageLen+= 22; /* depAmt */
		messageLen+= 22; /* ytstjmAmt */
		messageLen+= 10; /* depbnkNm */
		messageLen+= 20; /* custNm */
		messageLen+= 1; /* deptSt */
		messageLen+= 1; /* depcntGb */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("troccorgCd");
	
		fieldNames.add("trIl");
	
		fieldNames.add("cporgCd");
	
		fieldNames.add("deptrSeq");
	
		fieldNames.add("hndorgCd");
	
		fieldNames.add("trSi");
	
		fieldNames.add("txSeq");
	
		fieldNames.add("txCd");
	
		fieldNames.add("trCd");
	
		fieldNames.add("fnGb");
	
		fieldNames.add("vaNo");
	
		fieldNames.add("depbnkCd");
	
		fieldNames.add("depAmt");
	
		fieldNames.add("ytstjmAmt");
	
		fieldNames.add("depbnkNm");
	
		fieldNames.add("custNm");
	
		fieldNames.add("deptSt");
	
		fieldNames.add("depcntGb");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("troccorgCd", get("troccorgCd"));
	
		fieldValueMap.put("trIl", get("trIl"));
	
		fieldValueMap.put("cporgCd", get("cporgCd"));
	
		fieldValueMap.put("deptrSeq", get("deptrSeq"));
	
		fieldValueMap.put("hndorgCd", get("hndorgCd"));
	
		fieldValueMap.put("trSi", get("trSi"));
	
		fieldValueMap.put("txSeq", get("txSeq"));
	
		fieldValueMap.put("txCd", get("txCd"));
	
		fieldValueMap.put("trCd", get("trCd"));
	
		fieldValueMap.put("fnGb", get("fnGb"));
	
		fieldValueMap.put("vaNo", get("vaNo"));
	
		fieldValueMap.put("depbnkCd", get("depbnkCd"));
	
		fieldValueMap.put("depAmt", get("depAmt"));
	
		fieldValueMap.put("ytstjmAmt", get("ytstjmAmt"));
	
		fieldValueMap.put("depbnkNm", get("depbnkNm"));
	
		fieldValueMap.put("custNm", get("custNm"));
	
		fieldValueMap.put("deptSt", get("deptSt"));
	
		fieldValueMap.put("depcntGb", get("depcntGb"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -424844492 : /* troccorgCd */
			return getTroccorgCd();
		case 3567681 : /* trIl */
			return getTrIl();
		case 981024280 : /* cporgCd */
			return getCporgCd();
		case 948005458 : /* deptrSeq */
			return getDeptrSeq();
		case -1621238521 : /* hndorgCd */
			return getHndorgCd();
		case 3567988 : /* trSi */
			return getTrSi();
		case 110786363 : /* txSeq */
			return getTxSeq();
		case 3573253 : /* txCd */
			return getTxCd();
		case 3567487 : /* trCd */
			return getTrCd();
		case 3146691 : /* fnGb */
			return getFnGb();
		case 3611084 : /* vaNo */
			return getVaNo();
		case 931284913 : /* depbnkCd */
			return getDepbnkCd();
		case -1335374023 : /* depAmt */
			return getDepAmt();
		case -1245193143 : /* ytstjmAmt */
			return getYtstjmAmt();
		case 931285263 : /* depbnkNm */
			return getDepbnkNm();
		case -1349089422 : /* custNm */
			return getCustNm();
		case -1335325818 : /* deptSt */
			return getDeptSt();
		case 932217205 : /* depcntGb */
			return getDepcntGb();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -424844492 : /* troccorgCd */
			setTroccorgCd((java.lang.String) value);
			return;
		case 3567681 : /* trIl */
			setTrIl((java.lang.String) value);
			return;
		case 981024280 : /* cporgCd */
			setCporgCd((java.lang.String) value);
			return;
		case 948005458 : /* deptrSeq */
			setDeptrSeq((java.lang.String) value);
			return;
		case -1621238521 : /* hndorgCd */
			setHndorgCd((java.lang.String) value);
			return;
		case 3567988 : /* trSi */
			setTrSi((java.lang.String) value);
			return;
		case 110786363 : /* txSeq */
			setTxSeq((java.lang.String) value);
			return;
		case 3573253 : /* txCd */
			setTxCd((java.lang.String) value);
			return;
		case 3567487 : /* trCd */
			setTrCd((java.lang.String) value);
			return;
		case 3146691 : /* fnGb */
			setFnGb((java.math.BigDecimal) value);
			return;
		case 3611084 : /* vaNo */
			setVaNo((java.lang.String) value);
			return;
		case 931284913 : /* depbnkCd */
			setDepbnkCd((java.lang.String) value);
			return;
		case -1335374023 : /* depAmt */
			setDepAmt((java.math.BigDecimal) value);
			return;
		case -1245193143 : /* ytstjmAmt */
			setYtstjmAmt((java.math.BigDecimal) value);
			return;
		case 931285263 : /* depbnkNm */
			setDepbnkNm((java.lang.String) value);
			return;
		case -1349089422 : /* custNm */
			setCustNm((java.lang.String) value);
			return;
		case -1335325818 : /* deptSt */
			setDeptSt((java.lang.String) value);
			return;
		case 932217205 : /* depcntGb */
			setDepcntGb((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
