/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.hd.sale.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description HD_계약_세대별 제한사항 ( HD_SALE_ETC )
 */
@XmlType(propOrder={"custCode", "seq", "etcSeq", "uniqueDiv", "effectNo", "deliveryDate", "creditor", "bondAmt", "cancelYn", "cancelDate", "cancelDesc", "remark", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DHDSaleEtc01IO")
@XmlRootElement(name="DHDSaleEtc01IO")
@SuppressWarnings("all")
public class DHDSaleEtc01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = -1106353822L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "HD_계약_세대별 제한사항 ( HD_SALE_ETC )";

	/*******************************************************************************************************************************
	* Property set << custCode >> [[ */
	
	@XmlTransient
	private boolean isSet_custCode = false;
	
	protected boolean isSet_custCode()
	{
		return this.isSet_custCode;
	}
	
	protected void setIsSet_custCode(boolean value)
	{
		this.isSet_custCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="거래처코드 [SYS_C0012802(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String custCode  = null;
	
	/**
	 * @Description 거래처코드 [SYS_C0012802(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public java.lang.String getCustCode(){
		return custCode;
	}
	
	/**
	 * @Description 거래처코드 [SYS_C0012802(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	@JsonProperty("custCode")
	public void setCustCode( java.lang.String custCode ) {
		isSet_custCode = true;
		this.custCode = custCode;
	}
	
	/** Property set << custCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << seq >> [[ */
	
	@XmlTransient
	private boolean isSet_seq = false;
	
	protected boolean isSet_seq()
	{
		return this.isSet_seq;
	}
	
	protected void setIsSet_seq(boolean value)
	{
		this.isSet_seq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 고객순번 [SYS_C0012803(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public void setSeq(java.lang.String value) {
		isSet_seq = true;
		this.seq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 고객순번 [SYS_C0012803(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public void setSeq(double value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 고객순번 [SYS_C0012803(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public void setSeq(long value) {
		isSet_seq = true;
		this.seq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="고객순번 [SYS_C0012803(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal seq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 고객순번 [SYS_C0012803(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public java.math.BigDecimal getSeq(){
		return seq;
	}
	
	/**
	 * @Description 고객순번 [SYS_C0012803(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	@JsonProperty("seq")
	public void setSeq( java.math.BigDecimal seq ) {
		isSet_seq = true;
		this.seq = seq;
	}
	
	/** Property set << seq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << etcSeq >> [[ */
	
	@XmlTransient
	private boolean isSet_etcSeq = false;
	
	protected boolean isSet_etcSeq()
	{
		return this.isSet_etcSeq;
	}
	
	protected void setIsSet_etcSeq(boolean value)
	{
		this.isSet_etcSeq = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 제한순번 [SYS_C0012804(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public void setEtcSeq(java.lang.String value) {
		isSet_etcSeq = true;
		this.etcSeq = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 제한순번 [SYS_C0012804(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public void setEtcSeq(double value) {
		isSet_etcSeq = true;
		this.etcSeq = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 제한순번 [SYS_C0012804(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public void setEtcSeq(long value) {
		isSet_etcSeq = true;
		this.etcSeq = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="제한순번 [SYS_C0012804(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal etcSeq  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 제한순번 [SYS_C0012804(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	public java.math.BigDecimal getEtcSeq(){
		return etcSeq;
	}
	
	/**
	 * @Description 제한순번 [SYS_C0012804(C),SYS_C0013016(P) SYS_C0013016(UNIQUE)]
	 */
	@JsonProperty("etcSeq")
	public void setEtcSeq( java.math.BigDecimal etcSeq ) {
		isSet_etcSeq = true;
		this.etcSeq = etcSeq;
	}
	
	/** Property set << etcSeq >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << uniqueDiv >> [[ */
	
	@XmlTransient
	private boolean isSet_uniqueDiv = false;
	
	protected boolean isSet_uniqueDiv()
	{
		return this.isSet_uniqueDiv;
	}
	
	protected void setIsSet_uniqueDiv(boolean value)
	{
		this.isSet_uniqueDiv = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="특이사항구분", formatType="", format="", align="left", length=2, decimal=0, arrayReference="", fill="")
	private java.lang.String uniqueDiv  = null;
	
	/**
	 * @Description 특이사항구분
	 */
	public java.lang.String getUniqueDiv(){
		return uniqueDiv;
	}
	
	/**
	 * @Description 특이사항구분
	 */
	@JsonProperty("uniqueDiv")
	public void setUniqueDiv( java.lang.String uniqueDiv ) {
		isSet_uniqueDiv = true;
		this.uniqueDiv = uniqueDiv;
	}
	
	/** Property set << uniqueDiv >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << effectNo >> [[ */
	
	@XmlTransient
	private boolean isSet_effectNo = false;
	
	protected boolean isSet_effectNo()
	{
		return this.isSet_effectNo;
	}
	
	protected void setIsSet_effectNo(boolean value)
	{
		this.isSet_effectNo = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="사건번호", formatType="", format="", align="left", length=20, decimal=0, arrayReference="", fill="")
	private java.lang.String effectNo  = null;
	
	/**
	 * @Description 사건번호
	 */
	public java.lang.String getEffectNo(){
		return effectNo;
	}
	
	/**
	 * @Description 사건번호
	 */
	@JsonProperty("effectNo")
	public void setEffectNo( java.lang.String effectNo ) {
		isSet_effectNo = true;
		this.effectNo = effectNo;
	}
	
	/** Property set << effectNo >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << deliveryDate >> [[ */
	
	@XmlTransient
	private boolean isSet_deliveryDate = false;
	
	protected boolean isSet_deliveryDate()
	{
		return this.isSet_deliveryDate;
	}
	
	protected void setIsSet_deliveryDate(boolean value)
	{
		this.isSet_deliveryDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="송달일자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String deliveryDate  = null;
	
	/**
	 * @Description 송달일자
	 */
	public java.lang.String getDeliveryDate(){
		return deliveryDate;
	}
	
	/**
	 * @Description 송달일자
	 */
	@JsonProperty("deliveryDate")
	public void setDeliveryDate( java.lang.String deliveryDate ) {
		isSet_deliveryDate = true;
		this.deliveryDate = deliveryDate;
	}
	
	/** Property set << deliveryDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << creditor >> [[ */
	
	@XmlTransient
	private boolean isSet_creditor = false;
	
	protected boolean isSet_creditor()
	{
		return this.isSet_creditor;
	}
	
	protected void setIsSet_creditor(boolean value)
	{
		this.isSet_creditor = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="채권자", formatType="", format="", align="left", length=10, decimal=0, arrayReference="", fill="")
	private java.lang.String creditor  = null;
	
	/**
	 * @Description 채권자
	 */
	public java.lang.String getCreditor(){
		return creditor;
	}
	
	/**
	 * @Description 채권자
	 */
	@JsonProperty("creditor")
	public void setCreditor( java.lang.String creditor ) {
		isSet_creditor = true;
		this.creditor = creditor;
	}
	
	/** Property set << creditor >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << bondAmt >> [[ */
	
	@XmlTransient
	private boolean isSet_bondAmt = false;
	
	protected boolean isSet_bondAmt()
	{
		return this.isSet_bondAmt;
	}
	
	protected void setIsSet_bondAmt(boolean value)
	{
		this.isSet_bondAmt = value;
	}
	
	/**
	 * java.math.BigDecimal - String value setter
	 * @Description 채권청구금액
	 */
	public void setBondAmt(java.lang.String value) {
		isSet_bondAmt = true;
		this.bondAmt = new java.math.BigDecimal(value);
	}
	/**
	 * java.math.BigDecimal - Double value setter
	 * @Description 채권청구금액
	 */
	public void setBondAmt(double value) {
		isSet_bondAmt = true;
		this.bondAmt = java.math.BigDecimal.valueOf(value);
	}
	/**
	 * java.math.BigDecimal - Long value setter
	 * @Description 채권청구금액
	 */
	public void setBondAmt(long value) {
		isSet_bondAmt = true;
		this.bondAmt = java.math.BigDecimal.valueOf(value);
	}
	
	@BxmOmm_Field(referenceType="reference", description="채권청구금액", formatType="", format="", align="right", length=22, decimal=0, arrayReference="", fill="")
	private java.math.BigDecimal bondAmt  = new java.math.BigDecimal("0.0");
	
	/**
	 * @Description 채권청구금액
	 */
	public java.math.BigDecimal getBondAmt(){
		return bondAmt;
	}
	
	/**
	 * @Description 채권청구금액
	 */
	@JsonProperty("bondAmt")
	public void setBondAmt( java.math.BigDecimal bondAmt ) {
		isSet_bondAmt = true;
		this.bondAmt = bondAmt;
	}
	
	/** Property set << bondAmt >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelYn >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelYn = false;
	
	protected boolean isSet_cancelYn()
	{
		return this.isSet_cancelYn;
	}
	
	protected void setIsSet_cancelYn(boolean value)
	{
		this.isSet_cancelYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="말소여부", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelYn  = null;
	
	/**
	 * @Description 말소여부
	 */
	public java.lang.String getCancelYn(){
		return cancelYn;
	}
	
	/**
	 * @Description 말소여부
	 */
	@JsonProperty("cancelYn")
	public void setCancelYn( java.lang.String cancelYn ) {
		isSet_cancelYn = true;
		this.cancelYn = cancelYn;
	}
	
	/** Property set << cancelYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelDate >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelDate = false;
	
	protected boolean isSet_cancelDate()
	{
		return this.isSet_cancelDate;
	}
	
	protected void setIsSet_cancelDate(boolean value)
	{
		this.isSet_cancelDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="말소날자", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelDate  = null;
	
	/**
	 * @Description 말소날자
	 */
	public java.lang.String getCancelDate(){
		return cancelDate;
	}
	
	/**
	 * @Description 말소날자
	 */
	@JsonProperty("cancelDate")
	public void setCancelDate( java.lang.String cancelDate ) {
		isSet_cancelDate = true;
		this.cancelDate = cancelDate;
	}
	
	/** Property set << cancelDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << cancelDesc >> [[ */
	
	@XmlTransient
	private boolean isSet_cancelDesc = false;
	
	protected boolean isSet_cancelDesc()
	{
		return this.isSet_cancelDesc;
	}
	
	protected void setIsSet_cancelDesc(boolean value)
	{
		this.isSet_cancelDesc = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="처리내역", formatType="", format="", align="left", length=120, decimal=0, arrayReference="", fill="")
	private java.lang.String cancelDesc  = null;
	
	/**
	 * @Description 처리내역
	 */
	public java.lang.String getCancelDesc(){
		return cancelDesc;
	}
	
	/**
	 * @Description 처리내역
	 */
	@JsonProperty("cancelDesc")
	public void setCancelDesc( java.lang.String cancelDesc ) {
		isSet_cancelDesc = true;
		this.cancelDesc = cancelDesc;
	}
	
	/** Property set << cancelDesc >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << remark >> [[ */
	
	@XmlTransient
	private boolean isSet_remark = false;
	
	protected boolean isSet_remark()
	{
		return this.isSet_remark;
	}
	
	protected void setIsSet_remark(boolean value)
	{
		this.isSet_remark = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="비고", formatType="", format="", align="left", length=120, decimal=0, arrayReference="", fill="")
	private java.lang.String remark  = null;
	
	/**
	 * @Description 비고
	 */
	public java.lang.String getRemark(){
		return remark;
	}
	
	/**
	 * @Description 비고
	 */
	@JsonProperty("remark")
	public void setRemark( java.lang.String remark ) {
		isSet_remark = true;
		this.remark = remark;
	}
	
	/** Property set << remark >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 입력담당
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 입력담당
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="입력일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 입력일시
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 입력일시
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정담당", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 수정담당
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 수정담당
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="수정일시", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 수정일시
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 수정일시
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DHDSaleEtc01IO clone(){
		try{
			DHDSaleEtc01IO object= (DHDSaleEtc01IO)super.clone();
			if ( this.custCode== null ) object.custCode = null;
			else{
				object.custCode = this.custCode;
			}
			if ( this.seq== null ) object.seq = null;
			else{
				object.seq = new java.math.BigDecimal(seq.toString());
			}
			if ( this.etcSeq== null ) object.etcSeq = null;
			else{
				object.etcSeq = new java.math.BigDecimal(etcSeq.toString());
			}
			if ( this.uniqueDiv== null ) object.uniqueDiv = null;
			else{
				object.uniqueDiv = this.uniqueDiv;
			}
			if ( this.effectNo== null ) object.effectNo = null;
			else{
				object.effectNo = this.effectNo;
			}
			if ( this.deliveryDate== null ) object.deliveryDate = null;
			else{
				object.deliveryDate = this.deliveryDate;
			}
			if ( this.creditor== null ) object.creditor = null;
			else{
				object.creditor = this.creditor;
			}
			if ( this.bondAmt== null ) object.bondAmt = null;
			else{
				object.bondAmt = new java.math.BigDecimal(bondAmt.toString());
			}
			if ( this.cancelYn== null ) object.cancelYn = null;
			else{
				object.cancelYn = this.cancelYn;
			}
			if ( this.cancelDate== null ) object.cancelDate = null;
			else{
				object.cancelDate = this.cancelDate;
			}
			if ( this.cancelDesc== null ) object.cancelDesc = null;
			else{
				object.cancelDesc = this.cancelDesc;
			}
			if ( this.remark== null ) object.remark = null;
			else{
				object.remark = this.remark;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((custCode==null)?0:custCode.hashCode());
		result = prime * result + ((seq==null)?0:seq.hashCode());
		result = prime * result + ((etcSeq==null)?0:etcSeq.hashCode());
		result = prime * result + ((uniqueDiv==null)?0:uniqueDiv.hashCode());
		result = prime * result + ((effectNo==null)?0:effectNo.hashCode());
		result = prime * result + ((deliveryDate==null)?0:deliveryDate.hashCode());
		result = prime * result + ((creditor==null)?0:creditor.hashCode());
		result = prime * result + ((bondAmt==null)?0:bondAmt.hashCode());
		result = prime * result + ((cancelYn==null)?0:cancelYn.hashCode());
		result = prime * result + ((cancelDate==null)?0:cancelDate.hashCode());
		result = prime * result + ((cancelDesc==null)?0:cancelDesc.hashCode());
		result = prime * result + ((remark==null)?0:remark.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO other = (kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO)obj;
		if ( custCode == null ){
			if ( other.custCode != null ) return false;
		}
		else if ( !custCode.equals(other.custCode) )
			return false;
		if ( seq == null ){
			if ( other.seq != null ) return false;
		}
		else if ( !seq.equals(other.seq) )
			return false;
		if ( etcSeq == null ){
			if ( other.etcSeq != null ) return false;
		}
		else if ( !etcSeq.equals(other.etcSeq) )
			return false;
		if ( uniqueDiv == null ){
			if ( other.uniqueDiv != null ) return false;
		}
		else if ( !uniqueDiv.equals(other.uniqueDiv) )
			return false;
		if ( effectNo == null ){
			if ( other.effectNo != null ) return false;
		}
		else if ( !effectNo.equals(other.effectNo) )
			return false;
		if ( deliveryDate == null ){
			if ( other.deliveryDate != null ) return false;
		}
		else if ( !deliveryDate.equals(other.deliveryDate) )
			return false;
		if ( creditor == null ){
			if ( other.creditor != null ) return false;
		}
		else if ( !creditor.equals(other.creditor) )
			return false;
		if ( bondAmt == null ){
			if ( other.bondAmt != null ) return false;
		}
		else if ( !bondAmt.equals(other.bondAmt) )
			return false;
		if ( cancelYn == null ){
			if ( other.cancelYn != null ) return false;
		}
		else if ( !cancelYn.equals(other.cancelYn) )
			return false;
		if ( cancelDate == null ){
			if ( other.cancelDate != null ) return false;
		}
		else if ( !cancelDate.equals(other.cancelDate) )
			return false;
		if ( cancelDesc == null ){
			if ( other.cancelDesc != null ) return false;
		}
		else if ( !cancelDesc.equals(other.cancelDesc) )
			return false;
		if ( remark == null ){
			if ( other.remark != null ) return false;
		}
		else if ( !remark.equals(other.remark) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO:\n");
		sb.append("\tcustCode: ");
		sb.append(custCode==null?"null":getCustCode());
		sb.append("\n");
		sb.append("\tseq: ");
		sb.append(seq==null?"null":getSeq());
		sb.append("\n");
		sb.append("\tetcSeq: ");
		sb.append(etcSeq==null?"null":getEtcSeq());
		sb.append("\n");
		sb.append("\tuniqueDiv: ");
		sb.append(uniqueDiv==null?"null":getUniqueDiv());
		sb.append("\n");
		sb.append("\teffectNo: ");
		sb.append(effectNo==null?"null":getEffectNo());
		sb.append("\n");
		sb.append("\tdeliveryDate: ");
		sb.append(deliveryDate==null?"null":getDeliveryDate());
		sb.append("\n");
		sb.append("\tcreditor: ");
		sb.append(creditor==null?"null":getCreditor());
		sb.append("\n");
		sb.append("\tbondAmt: ");
		sb.append(bondAmt==null?"null":getBondAmt());
		sb.append("\n");
		sb.append("\tcancelYn: ");
		sb.append(cancelYn==null?"null":getCancelYn());
		sb.append("\n");
		sb.append("\tcancelDate: ");
		sb.append(cancelDate==null?"null":getCancelDate());
		sb.append("\n");
		sb.append("\tcancelDesc: ");
		sb.append(cancelDesc==null?"null":getCancelDesc());
		sb.append("\n");
		sb.append("\tremark: ");
		sb.append(remark==null?"null":getRemark());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 20; /* custCode */
		messageLen+= 22; /* seq */
		messageLen+= 22; /* etcSeq */
		messageLen+= 2; /* uniqueDiv */
		messageLen+= 20; /* effectNo */
		messageLen+= 8; /* deliveryDate */
		messageLen+= 10; /* creditor */
		messageLen+= 22; /* bondAmt */
		messageLen+= 1; /* cancelYn */
		messageLen+= 8; /* cancelDate */
		messageLen+= 120; /* cancelDesc */
		messageLen+= 120; /* remark */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("custCode");
	
		fieldNames.add("seq");
	
		fieldNames.add("etcSeq");
	
		fieldNames.add("uniqueDiv");
	
		fieldNames.add("effectNo");
	
		fieldNames.add("deliveryDate");
	
		fieldNames.add("creditor");
	
		fieldNames.add("bondAmt");
	
		fieldNames.add("cancelYn");
	
		fieldNames.add("cancelDate");
	
		fieldNames.add("cancelDesc");
	
		fieldNames.add("remark");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("custCode", get("custCode"));
	
		fieldValueMap.put("seq", get("seq"));
	
		fieldValueMap.put("etcSeq", get("etcSeq"));
	
		fieldValueMap.put("uniqueDiv", get("uniqueDiv"));
	
		fieldValueMap.put("effectNo", get("effectNo"));
	
		fieldValueMap.put("deliveryDate", get("deliveryDate"));
	
		fieldValueMap.put("creditor", get("creditor"));
	
		fieldValueMap.put("bondAmt", get("bondAmt"));
	
		fieldValueMap.put("cancelYn", get("cancelYn"));
	
		fieldValueMap.put("cancelDate", get("cancelDate"));
	
		fieldValueMap.put("cancelDesc", get("cancelDesc"));
	
		fieldValueMap.put("remark", get("remark"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			return getCustCode();
		case 113759 : /* seq */
			return getSeq();
		case -1293262293 : /* etcSeq */
			return getEtcSeq();
		case -538336512 : /* uniqueDiv */
			return getUniqueDiv();
		case -1017208014 : /* effectNo */
			return getEffectNo();
		case 681469378 : /* deliveryDate */
			return getDeliveryDate();
		case 1822875292 : /* creditor */
			return getCreditor();
		case 63515653 : /* bondAmt */
			return getBondAmt();
		case -123174097 : /* cancelYn */
			return getCancelYn();
		case 1888142664 : /* cancelDate */
			return getCancelDate();
		case 1888146475 : /* cancelDesc */
			return getCancelDesc();
		case -934624384 : /* remark */
			return getRemark();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case 604866272 : /* custCode */
			setCustCode((java.lang.String) value);
			return;
		case 113759 : /* seq */
			setSeq((java.math.BigDecimal) value);
			return;
		case -1293262293 : /* etcSeq */
			setEtcSeq((java.math.BigDecimal) value);
			return;
		case -538336512 : /* uniqueDiv */
			setUniqueDiv((java.lang.String) value);
			return;
		case -1017208014 : /* effectNo */
			setEffectNo((java.lang.String) value);
			return;
		case 681469378 : /* deliveryDate */
			setDeliveryDate((java.lang.String) value);
			return;
		case 1822875292 : /* creditor */
			setCreditor((java.lang.String) value);
			return;
		case 63515653 : /* bondAmt */
			setBondAmt((java.math.BigDecimal) value);
			return;
		case -123174097 : /* cancelYn */
			setCancelYn((java.lang.String) value);
			return;
		case 1888142664 : /* cancelDate */
			setCancelDate((java.lang.String) value);
			return;
		case 1888146475 : /* cancelDesc */
			setCancelDesc((java.lang.String) value);
			return;
		case -934624384 : /* remark */
			setRemark((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
