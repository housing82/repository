/******************************************************************************
 * Bxm Object Message Mapping(OMM) - Source Generator V6-1
 *
 * 생성된 자바파일은 수정하지 마십시오.
 * OMM 파일 수정시 Java파일을 덮어쓰게 됩니다.
 *
 ******************************************************************************/

package kait.tm.endx.onl.dao.dto;


import bxm.omm.annotation.BxmOmm_Field;
import bxm.omm.predict.Predictable;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Hashtable;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlRootElement;
import bxm.omm.root.IOmmObject;
import com.fasterxml.jackson.annotation.JsonIgnore;
import bxm.omm.predict.FieldInfo;

/**
 * @Description TM_ENDX_HIS_DAY
 */
@XmlType(propOrder={"companyCode", "endDay", "endYn", "inputDutyId", "inputDate", "chgDutyId", "chgDate"}, name="DTMEndxHisDay01IO")
@XmlRootElement(name="DTMEndxHisDay01IO")
@SuppressWarnings("all")
public class DTMEndxHisDay01IO  implements IOmmObject, Predictable, FieldInfo  {

	private static final long serialVersionUID = 629430230L;

	@XmlTransient
	public static final String OMM_DESCRIPTION = "TM_ENDX_HIS_DAY";

	/*******************************************************************************************************************************
	* Property set << companyCode >> [[ */
	
	@XmlTransient
	private boolean isSet_companyCode = false;
	
	protected boolean isSet_companyCode()
	{
		return this.isSet_companyCode;
	}
	
	protected void setIsSet_companyCode(boolean value)
	{
		this.isSet_companyCode = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0013041(C),SYS_C0013044(P) SYS_C0013044(UNIQUE)]", formatType="", format="", align="left", length=6, decimal=0, arrayReference="", fill="")
	private java.lang.String companyCode  = null;
	
	/**
	 * @Description  [SYS_C0013041(C),SYS_C0013044(P) SYS_C0013044(UNIQUE)]
	 */
	public java.lang.String getCompanyCode(){
		return companyCode;
	}
	
	/**
	 * @Description  [SYS_C0013041(C),SYS_C0013044(P) SYS_C0013044(UNIQUE)]
	 */
	@JsonProperty("companyCode")
	public void setCompanyCode( java.lang.String companyCode ) {
		isSet_companyCode = true;
		this.companyCode = companyCode;
	}
	
	/** Property set << companyCode >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endDay >> [[ */
	
	@XmlTransient
	private boolean isSet_endDay = false;
	
	protected boolean isSet_endDay()
	{
		return this.isSet_endDay;
	}
	
	protected void setIsSet_endDay(boolean value)
	{
		this.isSet_endDay = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0013042(C),SYS_C0013044(P) SYS_C0013044(UNIQUE)]", formatType="", format="", align="left", length=8, decimal=0, arrayReference="", fill="")
	private java.lang.String endDay  = null;
	
	/**
	 * @Description  [SYS_C0013042(C),SYS_C0013044(P) SYS_C0013044(UNIQUE)]
	 */
	public java.lang.String getEndDay(){
		return endDay;
	}
	
	/**
	 * @Description  [SYS_C0013042(C),SYS_C0013044(P) SYS_C0013044(UNIQUE)]
	 */
	@JsonProperty("endDay")
	public void setEndDay( java.lang.String endDay ) {
		isSet_endDay = true;
		this.endDay = endDay;
	}
	
	/** Property set << endDay >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << endYn >> [[ */
	
	@XmlTransient
	private boolean isSet_endYn = false;
	
	protected boolean isSet_endYn()
	{
		return this.isSet_endYn;
	}
	
	protected void setIsSet_endYn(boolean value)
	{
		this.isSet_endYn = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description=" [SYS_C0013043(C)]", formatType="", format="", align="left", length=1, decimal=0, arrayReference="", fill="")
	private java.lang.String endYn  = null;
	
	/**
	 * @Description  [SYS_C0013043(C)]
	 */
	public java.lang.String getEndYn(){
		return endYn;
	}
	
	/**
	 * @Description  [SYS_C0013043(C)]
	 */
	@JsonProperty("endYn")
	public void setEndYn( java.lang.String endYn ) {
		isSet_endYn = true;
		this.endYn = endYn;
	}
	
	/** Property set << endYn >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDutyId = false;
	
	protected boolean isSet_inputDutyId()
	{
		return this.isSet_inputDutyId;
	}
	
	protected void setIsSet_inputDutyId(boolean value)
	{
		this.isSet_inputDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDutyId(){
		return inputDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDutyId")
	public void setInputDutyId( java.lang.String inputDutyId ) {
		isSet_inputDutyId = true;
		this.inputDutyId = inputDutyId;
	}
	
	/** Property set << inputDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << inputDate >> [[ */
	
	@XmlTransient
	private boolean isSet_inputDate = false;
	
	protected boolean isSet_inputDate()
	{
		return this.isSet_inputDate;
	}
	
	protected void setIsSet_inputDate(boolean value)
	{
		this.isSet_inputDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String inputDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getInputDate(){
		return inputDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("inputDate")
	public void setInputDate( java.lang.String inputDate ) {
		isSet_inputDate = true;
		this.inputDate = inputDate;
	}
	
	/** Property set << inputDate >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDutyId >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDutyId = false;
	
	protected boolean isSet_chgDutyId()
	{
		return this.isSet_chgDutyId;
	}
	
	protected void setIsSet_chgDutyId(boolean value)
	{
		this.isSet_chgDutyId = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=12, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDutyId  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDutyId(){
		return chgDutyId;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDutyId")
	public void setChgDutyId( java.lang.String chgDutyId ) {
		isSet_chgDutyId = true;
		this.chgDutyId = chgDutyId;
	}
	
	/** Property set << chgDutyId >> ]]
	*******************************************************************************************************************************/
	/*******************************************************************************************************************************
	* Property set << chgDate >> [[ */
	
	@XmlTransient
	private boolean isSet_chgDate = false;
	
	protected boolean isSet_chgDate()
	{
		return this.isSet_chgDate;
	}
	
	protected void setIsSet_chgDate(boolean value)
	{
		this.isSet_chgDate = value;
	}
	
	
	@BxmOmm_Field(referenceType="reference", description="", formatType="", format="", align="left", length=14, decimal=0, arrayReference="", fill="")
	private java.lang.String chgDate  = null;
	
	/**
	 * @Description 
	 */
	public java.lang.String getChgDate(){
		return chgDate;
	}
	
	/**
	 * @Description 
	 */
	@JsonProperty("chgDate")
	public void setChgDate( java.lang.String chgDate ) {
		isSet_chgDate = true;
		this.chgDate = chgDate;
	}
	
	/** Property set << chgDate >> ]]
	*******************************************************************************************************************************/

	@Override
	public DTMEndxHisDay01IO clone(){
		try{
			DTMEndxHisDay01IO object= (DTMEndxHisDay01IO)super.clone();
			if ( this.companyCode== null ) object.companyCode = null;
			else{
				object.companyCode = this.companyCode;
			}
			if ( this.endDay== null ) object.endDay = null;
			else{
				object.endDay = this.endDay;
			}
			if ( this.endYn== null ) object.endYn = null;
			else{
				object.endYn = this.endYn;
			}
			if ( this.inputDutyId== null ) object.inputDutyId = null;
			else{
				object.inputDutyId = this.inputDutyId;
			}
			if ( this.inputDate== null ) object.inputDate = null;
			else{
				object.inputDate = this.inputDate;
			}
			if ( this.chgDutyId== null ) object.chgDutyId = null;
			else{
				object.chgDutyId = this.chgDutyId;
			}
			if ( this.chgDate== null ) object.chgDate = null;
			else{
				object.chgDate = this.chgDate;
			}
			
			return object;
		} 
		catch(CloneNotSupportedException e){
			throw new bxm.omm.exception.CloneFailedException();
		}
		
	}

	
	@Override
	public int hashCode(){
		final int prime=31;
		int result = 1;
		result = prime * result + ((companyCode==null)?0:companyCode.hashCode());
		result = prime * result + ((endDay==null)?0:endDay.hashCode());
		result = prime * result + ((endYn==null)?0:endYn.hashCode());
		result = prime * result + ((inputDutyId==null)?0:inputDutyId.hashCode());
		result = prime * result + ((inputDate==null)?0:inputDate.hashCode());
		result = prime * result + ((chgDutyId==null)?0:chgDutyId.hashCode());
		result = prime * result + ((chgDate==null)?0:chgDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if ( this == obj ) return true;
		if ( obj == null ) return false;
		if ( getClass() != obj.getClass() ) return false;
		final kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO other = (kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO)obj;
		if ( companyCode == null ){
			if ( other.companyCode != null ) return false;
		}
		else if ( !companyCode.equals(other.companyCode) )
			return false;
		if ( endDay == null ){
			if ( other.endDay != null ) return false;
		}
		else if ( !endDay.equals(other.endDay) )
			return false;
		if ( endYn == null ){
			if ( other.endYn != null ) return false;
		}
		else if ( !endYn.equals(other.endYn) )
			return false;
		if ( inputDutyId == null ){
			if ( other.inputDutyId != null ) return false;
		}
		else if ( !inputDutyId.equals(other.inputDutyId) )
			return false;
		if ( inputDate == null ){
			if ( other.inputDate != null ) return false;
		}
		else if ( !inputDate.equals(other.inputDate) )
			return false;
		if ( chgDutyId == null ){
			if ( other.chgDutyId != null ) return false;
		}
		else if ( !chgDutyId.equals(other.chgDutyId) )
			return false;
		if ( chgDate == null ){
			if ( other.chgDate != null ) return false;
		}
		else if ( !chgDate.equals(other.chgDate) )
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
	
		sb.append( "\n[kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO:\n");
		sb.append("\tcompanyCode: ");
		sb.append(companyCode==null?"null":getCompanyCode());
		sb.append("\n");
		sb.append("\tendDay: ");
		sb.append(endDay==null?"null":getEndDay());
		sb.append("\n");
		sb.append("\tendYn: ");
		sb.append(endYn==null?"null":getEndYn());
		sb.append("\n");
		sb.append("\tinputDutyId: ");
		sb.append(inputDutyId==null?"null":getInputDutyId());
		sb.append("\n");
		sb.append("\tinputDate: ");
		sb.append(inputDate==null?"null":getInputDate());
		sb.append("\n");
		sb.append("\tchgDutyId: ");
		sb.append(chgDutyId==null?"null":getChgDutyId());
		sb.append("\n");
		sb.append("\tchgDate: ");
		sb.append(chgDate==null?"null":getChgDate());
		sb.append("\n");
		sb.append("]\n");
	
		return sb.toString();
	}

	/**
	 * Only for Fixed-Length Data
	 */
	@Override
	public long predictMessageLength(){
		long messageLen= 0;
	
		messageLen+= 6; /* companyCode */
		messageLen+= 8; /* endDay */
		messageLen+= 1; /* endYn */
		messageLen+= 12; /* inputDutyId */
		messageLen+= 14; /* inputDate */
		messageLen+= 12; /* chgDutyId */
		messageLen+= 14; /* chgDate */
	
		return messageLen;
	}
	

	@Override
	@JsonIgnore
	public java.util.List<String> getFieldNames(){
		java.util.List<String> fieldNames= new java.util.ArrayList<String>();
	
		fieldNames.add("companyCode");
	
		fieldNames.add("endDay");
	
		fieldNames.add("endYn");
	
		fieldNames.add("inputDutyId");
	
		fieldNames.add("inputDate");
	
		fieldNames.add("chgDutyId");
	
		fieldNames.add("chgDate");
	
	
		return fieldNames;
	}

	@Override
	@JsonIgnore
	public java.util.Map<String, Object> getFieldValues(){
		java.util.Map<String, Object> fieldValueMap= new java.util.HashMap<String, Object>();
	
		fieldValueMap.put("companyCode", get("companyCode"));
	
		fieldValueMap.put("endDay", get("endDay"));
	
		fieldValueMap.put("endYn", get("endYn"));
	
		fieldValueMap.put("inputDutyId", get("inputDutyId"));
	
		fieldValueMap.put("inputDate", get("inputDate"));
	
		fieldValueMap.put("chgDutyId", get("chgDutyId"));
	
		fieldValueMap.put("chgDate", get("chgDate"));
	
	
		return fieldValueMap;
	}

	@XmlTransient
	@JsonIgnore
	private Hashtable<String, Object> htDynamicVariable = new Hashtable<String, Object>();
	
	public Object get(String key) throws IllegalArgumentException{
		switch( key.hashCode() ){
		case -508897270 : /* companyCode */
			return getCompanyCode();
		case -1298788159 : /* endDay */
			return getEndDay();
		case 96651600 : /* endYn */
			return getEndYn();
		case -734418181 : /* inputDutyId */
			return getInputDutyId();
		case 1706477208 : /* inputDate */
			return getInputDate();
		case 1296290259 : /* chgDutyId */
			return getChgDutyId();
		case 743228272 : /* chgDate */
			return getChgDate();
		default :
			if ( htDynamicVariable.containsKey(key) ) return htDynamicVariable.get(key);
			else throw new IllegalArgumentException("Not found element : " + key);
		}
	}
	
	@SuppressWarnings("unchecked")
	public void set(String key, Object value){
		switch( key.hashCode() ){
		case -508897270 : /* companyCode */
			setCompanyCode((java.lang.String) value);
			return;
		case -1298788159 : /* endDay */
			setEndDay((java.lang.String) value);
			return;
		case 96651600 : /* endYn */
			setEndYn((java.lang.String) value);
			return;
		case -734418181 : /* inputDutyId */
			setInputDutyId((java.lang.String) value);
			return;
		case 1706477208 : /* inputDate */
			setInputDate((java.lang.String) value);
			return;
		case 1296290259 : /* chgDutyId */
			setChgDutyId((java.lang.String) value);
			return;
		case 743228272 : /* chgDate */
			setChgDate((java.lang.String) value);
			return;
		default : htDynamicVariable.put(key, value);
		}
	}
}
