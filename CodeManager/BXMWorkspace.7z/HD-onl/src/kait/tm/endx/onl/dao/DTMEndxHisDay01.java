/**
 * Generated Code Skeleton 2017-06-13 18:26:41 
 */
package kait.tm.endx.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/tm/endx/onl/daoDTMEndxHisDay01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "TM_ENDX_HIS_DAY", description = "TM_ENDX_HIS_DAY")
public interface DTMEndxHisDay01
{
	/**
	 * TM_ENDX_HIS_DAY 등록
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 등록", description = "TM_ENDX_HIS_DAY 등록")
	int insertTmEndxHisDay01(kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO dTMEndxHisDay01IO);

	/**
	 * TM_ENDX_HIS_DAY 단건조회
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 단건조회", description = "TM_ENDX_HIS_DAY 단건조회")
	kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO selectTmEndxHisDay01(kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO dTMEndxHisDay01IO);

	/**
	 * TM_ENDX_HIS_DAY 전채건수조회
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 전채건수조회", description = "TM_ENDX_HIS_DAY 전채건수조회")
	java.lang.Integer selectCountTmEndxHisDay01(kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO dTMEndxHisDay01IO);

	/**
	 * TM_ENDX_HIS_DAY 목록조회
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 목록조회", description = "TM_ENDX_HIS_DAY 목록조회")
	java.util.List<kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO> selectListTmEndxHisDay01(
			@Param("in") kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * TM_ENDX_HIS_DAY 수정
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 수정", description = "TM_ENDX_HIS_DAY 수정")
	int updateTmEndxHisDay01(kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO dTMEndxHisDay01IO);

	/**
	 * TM_ENDX_HIS_DAY 병합
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 병합", description = "TM_ENDX_HIS_DAY 병합")
	int mergeTmEndxHisDay01(kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO dTMEndxHisDay01IO);

	/**
	 * TM_ENDX_HIS_DAY 삭제
	 * @TestValues 	companyCode=; endDay=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "TM_ENDX_HIS_DAY 삭제", description = "TM_ENDX_HIS_DAY 삭제")
	int deleteTmEndxHisDay01(kait.tm.endx.onl.dao.dto.DTMEndxHisDay01IO dTMEndxHisDay01IO);


}
