/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGurtIncomeTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP", description = "HD_임대_보증금납입사항_TEMP")
public interface DHDRentGurtIncomeTemp01
{
	/**
	 * HD_임대_보증금납입사항_TEMP 등록
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 등록", description = "HD_임대_보증금납입사항_TEMP 등록")
	int insertHdRentGurtIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO dHDRentGurtIncomeTemp01IO);

	/**
	 * HD_임대_보증금납입사항_TEMP 단건조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 단건조회", description = "HD_임대_보증금납입사항_TEMP 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO selectHdRentGurtIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO dHDRentGurtIncomeTemp01IO);

	/**
	 * HD_임대_보증금납입사항_TEMP 전채건수조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 전채건수조회", description = "HD_임대_보증금납입사항_TEMP 전채건수조회")
	java.lang.Integer selectCountHdRentGurtIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO dHDRentGurtIncomeTemp01IO);

	/**
	 * HD_임대_보증금납입사항_TEMP 목록조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 목록조회", description = "HD_임대_보증금납입사항_TEMP 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO> selectListHdRentGurtIncomeTemp01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_보증금납입사항_TEMP 수정
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 수정", description = "HD_임대_보증금납입사항_TEMP 수정")
	int updateHdRentGurtIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO dHDRentGurtIncomeTemp01IO);

	/**
	 * HD_임대_보증금납입사항_TEMP 병합
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 병합", description = "HD_임대_보증금납입사항_TEMP 병합")
	int mergeHdRentGurtIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO dHDRentGurtIncomeTemp01IO);

	/**
	 * HD_임대_보증금납입사항_TEMP 삭제
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_TEMP 삭제", description = "HD_임대_보증금납입사항_TEMP 삭제")
	int deleteHdRentGurtIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeTemp01IO dHDRentGurtIncomeTemp01IO);


}
