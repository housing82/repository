/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentIncomeTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP", description = "HD_임대_임대료납입사항_TEMP")
public interface DHDRentRentIncomeTemp01
{
	/**
	 * HD_임대_임대료납입사항_TEMP 등록
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 등록", description = "HD_임대_임대료납입사항_TEMP 등록")
	int insertHdRentRentIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO dHDRentRentIncomeTemp01IO);

	/**
	 * HD_임대_임대료납입사항_TEMP 단건조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 단건조회", description = "HD_임대_임대료납입사항_TEMP 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO selectHdRentRentIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO dHDRentRentIncomeTemp01IO);

	/**
	 * HD_임대_임대료납입사항_TEMP 전채건수조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 전채건수조회", description = "HD_임대_임대료납입사항_TEMP 전채건수조회")
	java.lang.Integer selectCountHdRentRentIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO dHDRentRentIncomeTemp01IO);

	/**
	 * HD_임대_임대료납입사항_TEMP 목록조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 목록조회", description = "HD_임대_임대료납입사항_TEMP 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO> selectListHdRentRentIncomeTemp01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료납입사항_TEMP 수정
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 수정", description = "HD_임대_임대료납입사항_TEMP 수정")
	int updateHdRentRentIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO dHDRentRentIncomeTemp01IO);

	/**
	 * HD_임대_임대료납입사항_TEMP 병합
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 병합", description = "HD_임대_임대료납입사항_TEMP 병합")
	int mergeHdRentRentIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO dHDRentRentIncomeTemp01IO);

	/**
	 * HD_임대_임대료납입사항_TEMP 삭제
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_TEMP 삭제", description = "HD_임대_임대료납입사항_TEMP 삭제")
	int deleteHdRentRentIncomeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeTemp01IO dHDRentRentIncomeTemp01IO);


}
