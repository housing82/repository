/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGurtIncomeAdj01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산", description = "HD_임대_보증금납입사항_정산")
public interface DHDRentGurtIncomeAdj01
{
	/**
	 * HD_임대_보증금납입사항_정산 등록
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 등록", description = "HD_임대_보증금납입사항_정산 등록")
	int insertHdRentGurtIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO dHDRentGurtIncomeAdj01IO);

	/**
	 * HD_임대_보증금납입사항_정산 단건조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 단건조회", description = "HD_임대_보증금납입사항_정산 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO selectHdRentGurtIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO dHDRentGurtIncomeAdj01IO);

	/**
	 * HD_임대_보증금납입사항_정산 전채건수조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 전채건수조회", description = "HD_임대_보증금납입사항_정산 전채건수조회")
	java.lang.Integer selectCountHdRentGurtIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO dHDRentGurtIncomeAdj01IO);

	/**
	 * HD_임대_보증금납입사항_정산 목록조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 목록조회", description = "HD_임대_보증금납입사항_정산 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO> selectListHdRentGurtIncomeAdj01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_보증금납입사항_정산 수정
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 수정", description = "HD_임대_보증금납입사항_정산 수정")
	int updateHdRentGurtIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO dHDRentGurtIncomeAdj01IO);

	/**
	 * HD_임대_보증금납입사항_정산 병합
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 병합", description = "HD_임대_보증금납입사항_정산 병합")
	int mergeHdRentGurtIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO dHDRentGurtIncomeAdj01IO);

	/**
	 * HD_임대_보증금납입사항_정산 삭제
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_정산 삭제", description = "HD_임대_보증금납입사항_정산 삭제")
	int deleteHdRentGurtIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeAdj01IO dHDRentGurtIncomeAdj01IO);


}
