/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGurtIncomeDailyAdj01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산", description = "HD_임대_보증금납입사항_일자별_정산")
public interface DHDRentGurtIncomeDailyAdj01
{
	/**
	 * HD_임대_보증금납입사항_일자별_정산 등록
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 등록", description = "HD_임대_보증금납입사항_일자별_정산 등록")
	int insertHdRentGurtIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO dHDRentGurtIncomeDailyAdj01IO);

	/**
	 * HD_임대_보증금납입사항_일자별_정산 단건조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 단건조회", description = "HD_임대_보증금납입사항_일자별_정산 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO selectHdRentGurtIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO dHDRentGurtIncomeDailyAdj01IO);

	/**
	 * HD_임대_보증금납입사항_일자별_정산 전채건수조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 전채건수조회", description = "HD_임대_보증금납입사항_일자별_정산 전채건수조회")
	java.lang.Integer selectCountHdRentGurtIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO dHDRentGurtIncomeDailyAdj01IO);

	/**
	 * HD_임대_보증금납입사항_일자별_정산 목록조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 목록조회", description = "HD_임대_보증금납입사항_일자별_정산 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO> selectListHdRentGurtIncomeDailyAdj01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_보증금납입사항_일자별_정산 수정
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 수정", description = "HD_임대_보증금납입사항_일자별_정산 수정")
	int updateHdRentGurtIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO dHDRentGurtIncomeDailyAdj01IO);

	/**
	 * HD_임대_보증금납입사항_일자별_정산 병합
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 병합", description = "HD_임대_보증금납입사항_일자별_정산 병합")
	int mergeHdRentGurtIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO dHDRentGurtIncomeDailyAdj01IO);

	/**
	 * HD_임대_보증금납입사항_일자별_정산 삭제
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금납입사항_일자별_정산 삭제", description = "HD_임대_보증금납입사항_일자별_정산 삭제")
	int deleteHdRentGurtIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtIncomeDailyAdj01IO dHDRentGurtIncomeDailyAdj01IO);


}
