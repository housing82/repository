/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentIncomeAdj01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산", description = "HD_임대_임대료납입사항_정산")
public interface DHDRentRentIncomeAdj01
{
	/**
	 * HD_임대_임대료납입사항_정산 등록
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 등록", description = "HD_임대_임대료납입사항_정산 등록")
	int insertHdRentRentIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO dHDRentRentIncomeAdj01IO);

	/**
	 * HD_임대_임대료납입사항_정산 단건조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 단건조회", description = "HD_임대_임대료납입사항_정산 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO selectHdRentRentIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO dHDRentRentIncomeAdj01IO);

	/**
	 * HD_임대_임대료납입사항_정산 전채건수조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 전채건수조회", description = "HD_임대_임대료납입사항_정산 전채건수조회")
	java.lang.Integer selectCountHdRentRentIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO dHDRentRentIncomeAdj01IO);

	/**
	 * HD_임대_임대료납입사항_정산 목록조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 목록조회", description = "HD_임대_임대료납입사항_정산 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO> selectListHdRentRentIncomeAdj01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료납입사항_정산 수정
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 수정", description = "HD_임대_임대료납입사항_정산 수정")
	int updateHdRentRentIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO dHDRentRentIncomeAdj01IO);

	/**
	 * HD_임대_임대료납입사항_정산 병합
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 병합", description = "HD_임대_임대료납입사항_정산 병합")
	int mergeHdRentRentIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO dHDRentRentIncomeAdj01IO);

	/**
	 * HD_임대_임대료납입사항_정산 삭제
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_정산 삭제", description = "HD_임대_임대료납입사항_정산 삭제")
	int deleteHdRentRentIncomeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeAdj01IO dHDRentRentIncomeAdj01IO);


}
