/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentEtc01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_세대별제한사항", description = "HD_임대_세대별제한사항")
public interface DHDRentEtc01
{
	/**
	 * HD_임대_세대별제한사항 등록
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 등록", description = "HD_임대_세대별제한사항 등록")
	int insertHdRentEtc01(kait.hd.rent.onl.dao.dto.DHDRentEtc01IO dHDRentEtc01IO);

	/**
	 * HD_임대_세대별제한사항 단건조회
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 단건조회", description = "HD_임대_세대별제한사항 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentEtc01IO selectHdRentEtc01(kait.hd.rent.onl.dao.dto.DHDRentEtc01IO dHDRentEtc01IO);

	/**
	 * HD_임대_세대별제한사항 전채건수조회
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 전채건수조회", description = "HD_임대_세대별제한사항 전채건수조회")
	java.lang.Integer selectCountHdRentEtc01(kait.hd.rent.onl.dao.dto.DHDRentEtc01IO dHDRentEtc01IO);

	/**
	 * HD_임대_세대별제한사항 목록조회
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 목록조회", description = "HD_임대_세대별제한사항 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentEtc01IO> selectListHdRentEtc01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentEtc01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_세대별제한사항 수정
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 수정", description = "HD_임대_세대별제한사항 수정")
	int updateHdRentEtc01(kait.hd.rent.onl.dao.dto.DHDRentEtc01IO dHDRentEtc01IO);

	/**
	 * HD_임대_세대별제한사항 병합
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 병합", description = "HD_임대_세대별제한사항 병합")
	int mergeHdRentEtc01(kait.hd.rent.onl.dao.dto.DHDRentEtc01IO dHDRentEtc01IO);

	/**
	 * HD_임대_세대별제한사항 삭제
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별제한사항 삭제", description = "HD_임대_세대별제한사항 삭제")
	int deleteHdRentEtc01(kait.hd.rent.onl.dao.dto.DHDRentEtc01IO dHDRentEtc01IO);


}
