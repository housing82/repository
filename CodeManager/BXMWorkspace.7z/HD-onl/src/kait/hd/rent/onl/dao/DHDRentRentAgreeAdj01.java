/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentAgreeAdj01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산", description = "HD_임대_임대료약정사항_정산")
public interface DHDRentRentAgreeAdj01
{
	/**
	 * HD_임대_임대료약정사항_정산 등록
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 등록", description = "HD_임대_임대료약정사항_정산 등록")
	int insertHdRentRentAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO dHDRentRentAgreeAdj01IO);

	/**
	 * HD_임대_임대료약정사항_정산 단건조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 단건조회", description = "HD_임대_임대료약정사항_정산 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO selectHdRentRentAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO dHDRentRentAgreeAdj01IO);

	/**
	 * HD_임대_임대료약정사항_정산 전채건수조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 전채건수조회", description = "HD_임대_임대료약정사항_정산 전채건수조회")
	java.lang.Integer selectCountHdRentRentAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO dHDRentRentAgreeAdj01IO);

	/**
	 * HD_임대_임대료약정사항_정산 목록조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 목록조회", description = "HD_임대_임대료약정사항_정산 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO> selectListHdRentRentAgreeAdj01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료약정사항_정산 수정
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 수정", description = "HD_임대_임대료약정사항_정산 수정")
	int updateHdRentRentAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO dHDRentRentAgreeAdj01IO);

	/**
	 * HD_임대_임대료약정사항_정산 병합
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 병합", description = "HD_임대_임대료약정사항_정산 병합")
	int mergeHdRentRentAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO dHDRentRentAgreeAdj01IO);

	/**
	 * HD_임대_임대료약정사항_정산 삭제
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_정산 삭제", description = "HD_임대_임대료약정사항_정산 삭제")
	int deleteHdRentRentAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeAdj01IO dHDRentRentAgreeAdj01IO);


}
