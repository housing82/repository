/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentCancel01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_해약요청", description = "HD_임대_해약요청")
public interface DHDRentCancel01
{
	/**
	 * HD_임대_해약요청 등록
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 등록", description = "HD_임대_해약요청 등록")
	int insertHdRentCancel01(kait.hd.rent.onl.dao.dto.DHDRentCancel01IO dHDRentCancel01IO);

	/**
	 * HD_임대_해약요청 단건조회
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 단건조회", description = "HD_임대_해약요청 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentCancel01IO selectHdRentCancel01(kait.hd.rent.onl.dao.dto.DHDRentCancel01IO dHDRentCancel01IO);

	/**
	 * HD_임대_해약요청 전채건수조회
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 전채건수조회", description = "HD_임대_해약요청 전채건수조회")
	java.lang.Integer selectCountHdRentCancel01(kait.hd.rent.onl.dao.dto.DHDRentCancel01IO dHDRentCancel01IO);

	/**
	 * HD_임대_해약요청 목록조회
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 목록조회", description = "HD_임대_해약요청 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentCancel01IO> selectListHdRentCancel01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentCancel01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_해약요청 수정
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 수정", description = "HD_임대_해약요청 수정")
	int updateHdRentCancel01(kait.hd.rent.onl.dao.dto.DHDRentCancel01IO dHDRentCancel01IO);

	/**
	 * HD_임대_해약요청 병합
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 병합", description = "HD_임대_해약요청 병합")
	int mergeHdRentCancel01(kait.hd.rent.onl.dao.dto.DHDRentCancel01IO dHDRentCancel01IO);

	/**
	 * HD_임대_해약요청 삭제
	 * @TestValues 	custCode=; seq=; processTag=; wantDate=; takeDate=; cancelDate=; cancelTag=; cancelText=; penaltyTag=; penaltyText=; yrate=; penaltyAmt=; returnDeposit=; returnBank=; returnDepositor=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_해약요청 삭제", description = "HD_임대_해약요청 삭제")
	int deleteHdRentCancel01(kait.hd.rent.onl.dao.dto.DHDRentCancel01IO dHDRentCancel01IO);


}
