/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentIncome01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료납입사항", description = "HD_임대_임대료납입사항")
public interface DHDRentRentIncome01
{
	/**
	 * HD_임대_임대료납입사항 등록
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 등록", description = "HD_임대_임대료납입사항 등록")
	int insertHdRentRentIncome01(kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO dHDRentRentIncome01IO);

	/**
	 * HD_임대_임대료납입사항 단건조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 단건조회", description = "HD_임대_임대료납입사항 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO selectHdRentRentIncome01(kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO dHDRentRentIncome01IO);

	/**
	 * HD_임대_임대료납입사항 전채건수조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 전채건수조회", description = "HD_임대_임대료납입사항 전채건수조회")
	java.lang.Integer selectCountHdRentRentIncome01(kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO dHDRentRentIncome01IO);

	/**
	 * HD_임대_임대료납입사항 목록조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 목록조회", description = "HD_임대_임대료납입사항 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO> selectListHdRentRentIncome01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료납입사항 수정
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 수정", description = "HD_임대_임대료납입사항 수정")
	int updateHdRentRentIncome01(kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO dHDRentRentIncome01IO);

	/**
	 * HD_임대_임대료납입사항 병합
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 병합", description = "HD_임대_임대료납입사항 병합")
	int mergeHdRentRentIncome01(kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO dHDRentRentIncome01IO);

	/**
	 * HD_임대_임대료납입사항 삭제
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; times=; deptCode=; housetag=; inDate=; inSeq=; depositNo=; receiptDate=; receiptAmt=; receiptSupply=; receiptVat=; delayDays=; delayAmt=; discntDays=; discntAmt=; realincomAmt=; bankCode=; bankName=; payTag=; incomType=; modYn=; realPayTag=; slipDate=; slipSeq=; taxDate=; taxSeq=; slipType=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; receiptIns=; realincomSupply=; realincomVat=; realincomIns=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항 삭제", description = "HD_임대_임대료납입사항 삭제")
	int deleteHdRentRentIncome01(kait.hd.rent.onl.dao.dto.DHDRentRentIncome01IO dHDRentRentIncome01IO);


}
