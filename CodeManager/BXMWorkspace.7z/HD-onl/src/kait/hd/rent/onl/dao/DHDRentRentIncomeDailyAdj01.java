/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentIncomeDailyAdj01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산", description = "HD_임대_임대료납입사항_일자별_정산")
public interface DHDRentRentIncomeDailyAdj01
{
	/**
	 * HD_임대_임대료납입사항_일자별_정산 등록
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 등록", description = "HD_임대_임대료납입사항_일자별_정산 등록")
	int insertHdRentRentIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO dHDRentRentIncomeDailyAdj01IO);

	/**
	 * HD_임대_임대료납입사항_일자별_정산 단건조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 단건조회", description = "HD_임대_임대료납입사항_일자별_정산 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO selectHdRentRentIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO dHDRentRentIncomeDailyAdj01IO);

	/**
	 * HD_임대_임대료납입사항_일자별_정산 전채건수조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 전채건수조회", description = "HD_임대_임대료납입사항_일자별_정산 전채건수조회")
	java.lang.Integer selectCountHdRentRentIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO dHDRentRentIncomeDailyAdj01IO);

	/**
	 * HD_임대_임대료납입사항_일자별_정산 목록조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 목록조회", description = "HD_임대_임대료납입사항_일자별_정산 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO> selectListHdRentRentIncomeDailyAdj01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료납입사항_일자별_정산 수정
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 수정", description = "HD_임대_임대료납입사항_일자별_정산 수정")
	int updateHdRentRentIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO dHDRentRentIncomeDailyAdj01IO);

	/**
	 * HD_임대_임대료납입사항_일자별_정산 병합
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 병합", description = "HD_임대_임대료납입사항_일자별_정산 병합")
	int mergeHdRentRentIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO dHDRentRentIncomeDailyAdj01IO);

	/**
	 * HD_임대_임대료납입사항_일자별_정산 삭제
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별_정산 삭제", description = "HD_임대_임대료납입사항_일자별_정산 삭제")
	int deleteHdRentRentIncomeDailyAdj01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDailyAdj01IO dHDRentRentIncomeDailyAdj01IO);


}
