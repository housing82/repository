/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRateDiscount01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_세대별할인율", description = "HD_임대_세대별할인율")
public interface DHDRentRateDiscount01
{
	/**
	 * HD_임대_세대별할인율 등록
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 등록", description = "HD_임대_세대별할인율 등록")
	int insertHdRentRateDiscount01(kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO dHDRentRateDiscount01IO);

	/**
	 * HD_임대_세대별할인율 단건조회
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 단건조회", description = "HD_임대_세대별할인율 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO selectHdRentRateDiscount01(kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO dHDRentRateDiscount01IO);

	/**
	 * HD_임대_세대별할인율 전채건수조회
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 전채건수조회", description = "HD_임대_세대별할인율 전채건수조회")
	java.lang.Integer selectCountHdRentRateDiscount01(kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO dHDRentRateDiscount01IO);

	/**
	 * HD_임대_세대별할인율 목록조회
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 목록조회", description = "HD_임대_세대별할인율 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO> selectListHdRentRateDiscount01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_세대별할인율 수정
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 수정", description = "HD_임대_세대별할인율 수정")
	int updateHdRentRateDiscount01(kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO dHDRentRateDiscount01IO);

	/**
	 * HD_임대_세대별할인율 병합
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 병합", description = "HD_임대_세대별할인율 병합")
	int mergeHdRentRateDiscount01(kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO dHDRentRateDiscount01IO);

	/**
	 * HD_임대_세대별할인율 삭제
	 * @TestValues 	custCode=; seq=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별할인율 삭제", description = "HD_임대_세대별할인율 삭제")
	int deleteHdRentRateDiscount01(kait.hd.rent.onl.dao.dto.DHDRentRateDiscount01IO dHDRentRateDiscount01IO);


}
