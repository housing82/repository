/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGiro01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_지로발행", description = "HD_임대_지로발행")
public interface DHDRentGiro01
{
	/**
	 * HD_임대_지로발행 등록
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 등록", description = "HD_임대_지로발행 등록")
	int insertHdRentGiro01(kait.hd.rent.onl.dao.dto.DHDRentGiro01IO dHDRentGiro01IO);

	/**
	 * HD_임대_지로발행 단건조회
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 단건조회", description = "HD_임대_지로발행 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGiro01IO selectHdRentGiro01(kait.hd.rent.onl.dao.dto.DHDRentGiro01IO dHDRentGiro01IO);

	/**
	 * HD_임대_지로발행 전채건수조회
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 전채건수조회", description = "HD_임대_지로발행 전채건수조회")
	java.lang.Integer selectCountHdRentGiro01(kait.hd.rent.onl.dao.dto.DHDRentGiro01IO dHDRentGiro01IO);

	/**
	 * HD_임대_지로발행 목록조회
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 목록조회", description = "HD_임대_지로발행 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGiro01IO> selectListHdRentGiro01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGiro01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_지로발행 수정
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 수정", description = "HD_임대_지로발행 수정")
	int updateHdRentGiro01(kait.hd.rent.onl.dao.dto.DHDRentGiro01IO dHDRentGiro01IO);

	/**
	 * HD_임대_지로발행 병합
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 병합", description = "HD_임대_지로발행 병합")
	int mergeHdRentGiro01(kait.hd.rent.onl.dao.dto.DHDRentGiro01IO dHDRentGiro01IO);

	/**
	 * HD_임대_지로발행 삭제
	 * @TestValues 	custCode=; seq=; giroTag=; billYm=; endDate=; makeDate=; jAmt=; jDamt=; dAmt=; dSamt=; dVamt=; dIamt=; amt=; giroNo=; custNo=; amtNo=; depositNo=; depositTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; jym1=; jymamt1=; jym2=; jymamt2=; jym3=; jymamt3=; printYn=; 
	 */
	@BxmCategory(logicalName = "HD_임대_지로발행 삭제", description = "HD_임대_지로발행 삭제")
	int deleteHdRentGiro01(kait.hd.rent.onl.dao.dto.DHDRentGiro01IO dHDRentGiro01IO);


}
