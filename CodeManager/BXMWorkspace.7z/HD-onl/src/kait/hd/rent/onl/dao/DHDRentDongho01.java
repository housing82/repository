/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentDongho01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_계약동호", description = "HD_임대_계약동호")
public interface DHDRentDongho01
{
	/**
	 * HD_임대_계약동호 등록
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 등록", description = "HD_임대_계약동호 등록")
	int insertHdRentDongho01(kait.hd.rent.onl.dao.dto.DHDRentDongho01IO dHDRentDongho01IO);

	/**
	 * HD_임대_계약동호 단건조회
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 단건조회", description = "HD_임대_계약동호 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentDongho01IO selectHdRentDongho01(kait.hd.rent.onl.dao.dto.DHDRentDongho01IO dHDRentDongho01IO);

	/**
	 * HD_임대_계약동호 전채건수조회
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 전채건수조회", description = "HD_임대_계약동호 전채건수조회")
	java.lang.Integer selectCountHdRentDongho01(kait.hd.rent.onl.dao.dto.DHDRentDongho01IO dHDRentDongho01IO);

	/**
	 * HD_임대_계약동호 목록조회
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 목록조회", description = "HD_임대_계약동호 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentDongho01IO> selectListHdRentDongho01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentDongho01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_계약동호 수정
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 수정", description = "HD_임대_계약동호 수정")
	int updateHdRentDongho01(kait.hd.rent.onl.dao.dto.DHDRentDongho01IO dHDRentDongho01IO);

	/**
	 * HD_임대_계약동호 병합
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 병합", description = "HD_임대_계약동호 병합")
	int mergeHdRentDongho01(kait.hd.rent.onl.dao.dto.DHDRentDongho01IO dHDRentDongho01IO);

	/**
	 * HD_임대_계약동호 삭제
	 * @TestValues 	custCode=; seq=; contSeq=; deptCode=; housetag=; buildno=; houseno=; representYn=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_계약동호 삭제", description = "HD_임대_계약동호 삭제")
	int deleteHdRentDongho01(kait.hd.rent.onl.dao.dto.DHDRentDongho01IO dHDRentDongho01IO);


}
