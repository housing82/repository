/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentAgreeTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP", description = "HD_임대_임대료약정사항_TEMP")
public interface DHDRentRentAgreeTemp01
{
	/**
	 * HD_임대_임대료약정사항_TEMP 등록
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 등록", description = "HD_임대_임대료약정사항_TEMP 등록")
	int insertHdRentRentAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO dHDRentRentAgreeTemp01IO);

	/**
	 * HD_임대_임대료약정사항_TEMP 단건조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 단건조회", description = "HD_임대_임대료약정사항_TEMP 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO selectHdRentRentAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO dHDRentRentAgreeTemp01IO);

	/**
	 * HD_임대_임대료약정사항_TEMP 전채건수조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 전채건수조회", description = "HD_임대_임대료약정사항_TEMP 전채건수조회")
	java.lang.Integer selectCountHdRentRentAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO dHDRentRentAgreeTemp01IO);

	/**
	 * HD_임대_임대료약정사항_TEMP 목록조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 목록조회", description = "HD_임대_임대료약정사항_TEMP 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO> selectListHdRentRentAgreeTemp01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료약정사항_TEMP 수정
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 수정", description = "HD_임대_임대료약정사항_TEMP 수정")
	int updateHdRentRentAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO dHDRentRentAgreeTemp01IO);

	/**
	 * HD_임대_임대료약정사항_TEMP 병합
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 병합", description = "HD_임대_임대료약정사항_TEMP 병합")
	int mergeHdRentRentAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO dHDRentRentAgreeTemp01IO);

	/**
	 * HD_임대_임대료약정사항_TEMP 삭제
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeSdate=; agreeEdate=; agreeDays=; rentAmt=; vatYn=; rentSupply=; rentVat=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; rentIns=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료약정사항_TEMP 삭제", description = "HD_임대_임대료약정사항_TEMP 삭제")
	int deleteHdRentRentAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentRentAgreeTemp01IO dHDRentRentAgreeTemp01IO);


}
