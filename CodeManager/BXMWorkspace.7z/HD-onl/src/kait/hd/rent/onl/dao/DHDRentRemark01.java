/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRemark01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_세대별특이사항", description = "HD_임대_세대별특이사항")
public interface DHDRentRemark01
{
	/**
	 * HD_임대_세대별특이사항 등록
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 등록", description = "HD_임대_세대별특이사항 등록")
	int insertHdRentRemark01(kait.hd.rent.onl.dao.dto.DHDRentRemark01IO dHDRentRemark01IO);

	/**
	 * HD_임대_세대별특이사항 단건조회
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 단건조회", description = "HD_임대_세대별특이사항 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRemark01IO selectHdRentRemark01(kait.hd.rent.onl.dao.dto.DHDRentRemark01IO dHDRentRemark01IO);

	/**
	 * HD_임대_세대별특이사항 전채건수조회
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 전채건수조회", description = "HD_임대_세대별특이사항 전채건수조회")
	java.lang.Integer selectCountHdRentRemark01(kait.hd.rent.onl.dao.dto.DHDRentRemark01IO dHDRentRemark01IO);

	/**
	 * HD_임대_세대별특이사항 목록조회
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 목록조회", description = "HD_임대_세대별특이사항 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRemark01IO> selectListHdRentRemark01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRemark01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_세대별특이사항 수정
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 수정", description = "HD_임대_세대별특이사항 수정")
	int updateHdRentRemark01(kait.hd.rent.onl.dao.dto.DHDRentRemark01IO dHDRentRemark01IO);

	/**
	 * HD_임대_세대별특이사항 병합
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 병합", description = "HD_임대_세대별특이사항 병합")
	int mergeHdRentRemark01(kait.hd.rent.onl.dao.dto.DHDRentRemark01IO dHDRentRemark01IO);

	/**
	 * HD_임대_세대별특이사항 삭제
	 * @TestValues 	custCode=; seq=; remarkSeq=; remarkDate=; remark=; userId=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_임대_세대별특이사항 삭제", description = "HD_임대_세대별특이사항 삭제")
	int deleteHdRentRemark01(kait.hd.rent.onl.dao.dto.DHDRentRemark01IO dHDRentRemark01IO);


}
