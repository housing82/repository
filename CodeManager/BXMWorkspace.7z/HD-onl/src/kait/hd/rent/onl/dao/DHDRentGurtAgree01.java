/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGurtAgree01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_보증금약정사항", description = "HD_임대_보증금약정사항")
public interface DHDRentGurtAgree01
{
	/**
	 * HD_임대_보증금약정사항 등록
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 등록", description = "HD_임대_보증금약정사항 등록")
	int insertHdRentGurtAgree01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO dHDRentGurtAgree01IO);

	/**
	 * HD_임대_보증금약정사항 단건조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 단건조회", description = "HD_임대_보증금약정사항 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO selectHdRentGurtAgree01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO dHDRentGurtAgree01IO);

	/**
	 * HD_임대_보증금약정사항 전채건수조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 전채건수조회", description = "HD_임대_보증금약정사항 전채건수조회")
	java.lang.Integer selectCountHdRentGurtAgree01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO dHDRentGurtAgree01IO);

	/**
	 * HD_임대_보증금약정사항 목록조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 목록조회", description = "HD_임대_보증금약정사항 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO> selectListHdRentGurtAgree01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_보증금약정사항 수정
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 수정", description = "HD_임대_보증금약정사항 수정")
	int updateHdRentGurtAgree01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO dHDRentGurtAgree01IO);

	/**
	 * HD_임대_보증금약정사항 병합
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 병합", description = "HD_임대_보증금약정사항 병합")
	int mergeHdRentGurtAgree01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO dHDRentGurtAgree01IO);

	/**
	 * HD_임대_보증금약정사항 삭제
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항 삭제", description = "HD_임대_보증금약정사항 삭제")
	int deleteHdRentGurtAgree01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgree01IO dHDRentGurtAgree01IO);


}
