/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentRentIncomeDaily01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별", description = "HD_임대_임대료납입사항_일자별")
public interface DHDRentRentIncomeDaily01
{
	/**
	 * HD_임대_임대료납입사항_일자별 등록
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 등록", description = "HD_임대_임대료납입사항_일자별 등록")
	int insertHdRentRentIncomeDaily01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO dHDRentRentIncomeDaily01IO);

	/**
	 * HD_임대_임대료납입사항_일자별 단건조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 단건조회", description = "HD_임대_임대료납입사항_일자별 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO selectHdRentRentIncomeDaily01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO dHDRentRentIncomeDaily01IO);

	/**
	 * HD_임대_임대료납입사항_일자별 전채건수조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 전채건수조회", description = "HD_임대_임대료납입사항_일자별 전채건수조회")
	java.lang.Integer selectCountHdRentRentIncomeDaily01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO dHDRentRentIncomeDaily01IO);

	/**
	 * HD_임대_임대료납입사항_일자별 목록조회
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 목록조회", description = "HD_임대_임대료납입사항_일자별 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO> selectListHdRentRentIncomeDaily01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_임대료납입사항_일자별 수정
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 수정", description = "HD_임대_임대료납입사항_일자별 수정")
	int updateHdRentRentIncomeDaily01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO dHDRentRentIncomeDaily01IO);

	/**
	 * HD_임대_임대료납입사항_일자별 병합
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 병합", description = "HD_임대_임대료납입사항_일자별 병합")
	int mergeHdRentRentIncomeDaily01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO dHDRentRentIncomeDaily01IO);

	/**
	 * HD_임대_임대료납입사항_일자별 삭제
	 * @TestValues 	deptCode=; housetag=; inDate=; inSeq=; custCode=; seq=; depositNo=; inAmt=; inGubun=; inType=; transYn=; cardNo=; modYn=; modDelayAmt=; modDiscAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; outDt=; outTm=; outSeq=; outBank=; remark=; outCustno=; 
	 */
	@BxmCategory(logicalName = "HD_임대_임대료납입사항_일자별 삭제", description = "HD_임대_임대료납입사항_일자별 삭제")
	int deleteHdRentRentIncomeDaily01(kait.hd.rent.onl.dao.dto.DHDRentRentIncomeDaily01IO dHDRentRentIncomeDaily01IO);


}
