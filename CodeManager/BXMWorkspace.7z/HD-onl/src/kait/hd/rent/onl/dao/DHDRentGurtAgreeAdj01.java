/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGurtAgreeAdj01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산", description = "HD_임대_보증금약정사항_정산")
public interface DHDRentGurtAgreeAdj01
{
	/**
	 * HD_임대_보증금약정사항_정산 등록
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 등록", description = "HD_임대_보증금약정사항_정산 등록")
	int insertHdRentGurtAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO dHDRentGurtAgreeAdj01IO);

	/**
	 * HD_임대_보증금약정사항_정산 단건조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 단건조회", description = "HD_임대_보증금약정사항_정산 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO selectHdRentGurtAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO dHDRentGurtAgreeAdj01IO);

	/**
	 * HD_임대_보증금약정사항_정산 전채건수조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 전채건수조회", description = "HD_임대_보증금약정사항_정산 전채건수조회")
	java.lang.Integer selectCountHdRentGurtAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO dHDRentGurtAgreeAdj01IO);

	/**
	 * HD_임대_보증금약정사항_정산 목록조회
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 목록조회", description = "HD_임대_보증금약정사항_정산 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO> selectListHdRentGurtAgreeAdj01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_보증금약정사항_정산 수정
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 수정", description = "HD_임대_보증금약정사항_정산 수정")
	int updateHdRentGurtAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO dHDRentGurtAgreeAdj01IO);

	/**
	 * HD_임대_보증금약정사항_정산 병합
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 병합", description = "HD_임대_보증금약정사항_정산 병합")
	int mergeHdRentGurtAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO dHDRentGurtAgreeAdj01IO);

	/**
	 * HD_임대_보증금약정사항_정산 삭제
	 * @TestValues 	custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_정산 삭제", description = "HD_임대_보증금약정사항_정산 삭제")
	int deleteHdRentGurtAgreeAdj01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeAdj01IO dHDRentGurtAgreeAdj01IO);


}
