/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.rent.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/rent/onl/daoDHDRentGurtAgreeTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP", description = "HD_임대_보증금약정사항_TEMP")
public interface DHDRentGurtAgreeTemp01
{
	/**
	 * HD_임대_보증금약정사항_TEMP 등록
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 등록", description = "HD_임대_보증금약정사항_TEMP 등록")
	int insertHdRentGurtAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO dHDRentGurtAgreeTemp01IO);

	/**
	 * HD_임대_보증금약정사항_TEMP 단건조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 단건조회", description = "HD_임대_보증금약정사항_TEMP 단건조회")
	kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO selectHdRentGurtAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO dHDRentGurtAgreeTemp01IO);

	/**
	 * HD_임대_보증금약정사항_TEMP 전채건수조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 전채건수조회", description = "HD_임대_보증금약정사항_TEMP 전채건수조회")
	java.lang.Integer selectCountHdRentGurtAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO dHDRentGurtAgreeTemp01IO);

	/**
	 * HD_임대_보증금약정사항_TEMP 목록조회
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 목록조회", description = "HD_임대_보증금약정사항_TEMP 목록조회")
	java.util.List<kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO> selectListHdRentGurtAgreeTemp01(
			@Param("in") kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_임대_보증금약정사항_TEMP 수정
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 수정", description = "HD_임대_보증금약정사항_TEMP 수정")
	int updateHdRentGurtAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO dHDRentGurtAgreeTemp01IO);

	/**
	 * HD_임대_보증금약정사항_TEMP 병합
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 병합", description = "HD_임대_보증금약정사항_TEMP 병합")
	int mergeHdRentGurtAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO dHDRentGurtAgreeTemp01IO);

	/**
	 * HD_임대_보증금약정사항_TEMP 삭제
	 * @TestValues 	seqNum=; custCode=; seq=; termChgSeq=; counts=; agreeDate=; agreeAmt=; discntYn=; delayYn=; perpectTag=; receiptAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; slipDate=; slipSeq=; 
	 */
	@BxmCategory(logicalName = "HD_임대_보증금약정사항_TEMP 삭제", description = "HD_임대_보증금약정사항_TEMP 삭제")
	int deleteHdRentGurtAgreeTemp01(kait.hd.rent.onl.dao.dto.DHDRentGurtAgreeTemp01IO dHDRentGurtAgreeTemp01IO);


}
