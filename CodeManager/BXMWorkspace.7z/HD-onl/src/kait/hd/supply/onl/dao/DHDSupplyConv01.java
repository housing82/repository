/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.supply.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/supply/onl/daoDHDSupplyConv01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_자료변환_세대별공급내역", description = "HD_자료변환_세대별공급내역")
public interface DHDSupplyConv01
{
	/**
	 * HD_자료변환_세대별공급내역 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 등록", description = "HD_자료변환_세대별공급내역 등록")
	int insertHdSupplyConv01(kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO dHDSupplyConv01IO);

	/**
	 * HD_자료변환_세대별공급내역 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 단건조회", description = "HD_자료변환_세대별공급내역 단건조회")
	kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO selectHdSupplyConv01(kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO dHDSupplyConv01IO);

	/**
	 * HD_자료변환_세대별공급내역 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 전채건수조회", description = "HD_자료변환_세대별공급내역 전채건수조회")
	java.lang.Integer selectCountHdSupplyConv01(kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO dHDSupplyConv01IO);

	/**
	 * HD_자료변환_세대별공급내역 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 목록조회", description = "HD_자료변환_세대별공급내역 목록조회")
	java.util.List<kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO> selectListHdSupplyConv01(
			@Param("in") kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_자료변환_세대별공급내역 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 수정", description = "HD_자료변환_세대별공급내역 수정")
	int updateHdSupplyConv01(kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO dHDSupplyConv01IO);

	/**
	 * HD_자료변환_세대별공급내역 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 병합", description = "HD_자료변환_세대별공급내역 병합")
	int mergeHdSupplyConv01(kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO dHDSupplyConv01IO);

	/**
	 * HD_자료변환_세대별공급내역 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; options=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; totSupplyamt=; totLandamt=; totBuildamt=; totVatamt=; totManageamt=; amt00=; amt00L=; amt00B=; amt00V=; amt00M=; amt01=; amt01L=; amt01B=; amt01V=; amt01M=; amt02=; amt02L=; amt02B=; amt02V=; amt02M=; amt11=; amt11L=; amt11B=; amt11V=; amt11M=; amt12=; amt12L=; amt12B=; amt12V=; amt12M=; amt13=; amt13L=; amt13B=; amt13V=; amt13M=; amt14=; amt14L=; amt14B=; amt14V=; amt14M=; amt15=; amt15L=; amt15B=; amt15V=; amt15M=; amt16=; amt16L=; amt16B=; amt16V=; amt16M=; amt17=; amt17L=; amt17B=; amt17V=; amt17M=; amt18=; amt18L=; amt18B=; amt18V=; amt18M=; amt19=; amt19L=; amt19B=; amt19V=; amt19M=; amt20=; amt20L=; amt20B=; amt20V=; amt20M=; amt90=; amt90L=; amt90B=; amt90V=; amt90M=; 
	 */
	@BxmCategory(logicalName = "HD_자료변환_세대별공급내역 삭제", description = "HD_자료변환_세대별공급내역 삭제")
	int deleteHdSupplyConv01(kait.hd.supply.onl.dao.dto.DHDSupplyConv01IO dHDSupplyConv01IO);


}
