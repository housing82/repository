/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousBanketc01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_금융수납기타", description = "HD_분양_금융수납기타")
public interface DHDHousBanketc01
{
	/**
	 * HD_분양_금융수납기타 등록
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 등록", description = "HD_분양_금융수납기타 등록")
	int insertHdHousBanketc01(kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO dHDHousBanketc01IO);

	/**
	 * HD_분양_금융수납기타 단건조회
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 단건조회", description = "HD_분양_금융수납기타 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO selectHdHousBanketc01(kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO dHDHousBanketc01IO);

	/**
	 * HD_분양_금융수납기타 전채건수조회
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 전채건수조회", description = "HD_분양_금융수납기타 전채건수조회")
	java.lang.Integer selectCountHdHousBanketc01(kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO dHDHousBanketc01IO);

	/**
	 * HD_분양_금융수납기타 목록조회
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 목록조회", description = "HD_분양_금융수납기타 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO> selectListHdHousBanketc01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_금융수납기타 수정
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 수정", description = "HD_분양_금융수납기타 수정")
	int updateHdHousBanketc01(kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO dHDHousBanketc01IO);

	/**
	 * HD_분양_금융수납기타 병합
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 병합", description = "HD_분양_금융수납기타 병합")
	int mergeHdHousBanketc01(kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO dHDHousBanketc01IO);

	/**
	 * HD_분양_금융수납기타 삭제
	 * @TestValues 	paymentdate=; paymentseq=; bankKind=; custCode=; seq=; depositNo=; paymentamt=; canceltag=; incometag=; processtag=; deptCode=; housetag=; buildno=; houseno=; indata=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납기타 삭제", description = "HD_분양_금융수납기타 삭제")
	int deleteHdHousBanketc01(kait.hd.hous.onl.dao.dto.DHDHousBanketc01IO dHDHousBanketc01IO);


}
