/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousIndeminity01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_지체보상금", description = "HD_계약_지체보상금")
public interface DHDHousIndeminity01
{
	/**
	 * HD_계약_지체보상금 등록
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 등록", description = "HD_계약_지체보상금 등록")
	int insertHdHousIndeminity01(kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO dHDHousIndeminity01IO);

	/**
	 * HD_계약_지체보상금 단건조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 단건조회", description = "HD_계약_지체보상금 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO selectHdHousIndeminity01(kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO dHDHousIndeminity01IO);

	/**
	 * HD_계약_지체보상금 전채건수조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 전채건수조회", description = "HD_계약_지체보상금 전채건수조회")
	java.lang.Integer selectCountHdHousIndeminity01(kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO dHDHousIndeminity01IO);

	/**
	 * HD_계약_지체보상금 목록조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 목록조회", description = "HD_계약_지체보상금 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO> selectListHdHousIndeminity01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_지체보상금 수정
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 수정", description = "HD_계약_지체보상금 수정")
	int updateHdHousIndeminity01(kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO dHDHousIndeminity01IO);

	/**
	 * HD_계약_지체보상금 병합
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 병합", description = "HD_계약_지체보상금 병합")
	int mergeHdHousIndeminity01(kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO dHDHousIndeminity01IO);

	/**
	 * HD_계약_지체보상금 삭제
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; receiptamt=; realincomamt=; indeminityTag=; delayIndeminity=; icheDate=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금 삭제", description = "HD_계약_지체보상금 삭제")
	int deleteHdHousIndeminity01(kait.hd.hous.onl.dao.dto.DHDHousIndeminity01IO dHDHousIndeminity01IO);


}
