/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSupplyChange01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별동호확정", description = "HD_기본_세대별동호확정")
public interface DHDHousSupplyChange01
{
	/**
	 * HD_기본_세대별동호확정 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 등록", description = "HD_기본_세대별동호확정 등록")
	int insertHdHousSupplyChange01(kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO dHDHousSupplyChange01IO);

	/**
	 * HD_기본_세대별동호확정 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 단건조회", description = "HD_기본_세대별동호확정 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO selectHdHousSupplyChange01(kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO dHDHousSupplyChange01IO);

	/**
	 * HD_기본_세대별동호확정 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 전채건수조회", description = "HD_기본_세대별동호확정 전채건수조회")
	java.lang.Integer selectCountHdHousSupplyChange01(kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO dHDHousSupplyChange01IO);

	/**
	 * HD_기본_세대별동호확정 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 목록조회", description = "HD_기본_세대별동호확정 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO> selectListHdHousSupplyChange01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별동호확정 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 수정", description = "HD_기본_세대별동호확정 수정")
	int updateHdHousSupplyChange01(kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO dHDHousSupplyChange01IO);

	/**
	 * HD_기본_세대별동호확정 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 병합", description = "HD_기본_세대별동호확정 병합")
	int mergeHdHousSupplyChange01(kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO dHDHousSupplyChange01IO);

	/**
	 * HD_기본_세대별동호확정 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; changeBuildno=; changeHouseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; prtsquare=; predisamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별동호확정 삭제", description = "HD_기본_세대별동호확정 삭제")
	int deleteHdHousSupplyChange01(kait.hd.hous.onl.dao.dto.DHDHousSupplyChange01IO dHDHousSupplyChange01IO);


}
