/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousDayIncomeConv01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드", description = "HD_분양_일자별입금내역_업로드")
public interface DHDHousDayIncomeConv01
{
	/**
	 * HD_분양_일자별입금내역_업로드 등록
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 등록", description = "HD_분양_일자별입금내역_업로드 등록")
	int insertHdHousDayIncomeConv01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO dHDHousDayIncomeConv01IO);

	/**
	 * HD_분양_일자별입금내역_업로드 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 단건조회", description = "HD_분양_일자별입금내역_업로드 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO selectHdHousDayIncomeConv01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO dHDHousDayIncomeConv01IO);

	/**
	 * HD_분양_일자별입금내역_업로드 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 전채건수조회", description = "HD_분양_일자별입금내역_업로드 전채건수조회")
	java.lang.Integer selectCountHdHousDayIncomeConv01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO dHDHousDayIncomeConv01IO);

	/**
	 * HD_분양_일자별입금내역_업로드 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 목록조회", description = "HD_분양_일자별입금내역_업로드 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO> selectListHdHousDayIncomeConv01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_일자별입금내역_업로드 수정
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 수정", description = "HD_분양_일자별입금내역_업로드 수정")
	int updateHdHousDayIncomeConv01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO dHDHousDayIncomeConv01IO);

	/**
	 * HD_분양_일자별입금내역_업로드 병합
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 병합", description = "HD_분양_일자별입금내역_업로드 병합")
	int mergeHdHousDayIncomeConv01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO dHDHousDayIncomeConv01IO);

	/**
	 * HD_분양_일자별입금내역_업로드 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; indt=; depositNo=; buildno=; houseno=; inamt=; ingun=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_일자별입금내역_업로드 삭제", description = "HD_분양_일자별입금내역_업로드 삭제")
	int deleteHdHousDayIncomeConv01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeConv01IO dHDHousDayIncomeConv01IO);


}
