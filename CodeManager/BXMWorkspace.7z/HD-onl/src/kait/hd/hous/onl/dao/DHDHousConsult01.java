/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousConsult01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_상담일지", description = "HD_기본_상담일지")
public interface DHDHousConsult01
{
	/**
	 * HD_기본_상담일지 등록
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 등록", description = "HD_기본_상담일지 등록")
	int insertHdHousConsult01(kait.hd.hous.onl.dao.dto.DHDHousConsult01IO dHDHousConsult01IO);

	/**
	 * HD_기본_상담일지 단건조회
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 단건조회", description = "HD_기본_상담일지 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousConsult01IO selectHdHousConsult01(kait.hd.hous.onl.dao.dto.DHDHousConsult01IO dHDHousConsult01IO);

	/**
	 * HD_기본_상담일지 전채건수조회
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 전채건수조회", description = "HD_기본_상담일지 전채건수조회")
	java.lang.Integer selectCountHdHousConsult01(kait.hd.hous.onl.dao.dto.DHDHousConsult01IO dHDHousConsult01IO);

	/**
	 * HD_기본_상담일지 목록조회
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 목록조회", description = "HD_기본_상담일지 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousConsult01IO> selectListHdHousConsult01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousConsult01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_상담일지 수정
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 수정", description = "HD_기본_상담일지 수정")
	int updateHdHousConsult01(kait.hd.hous.onl.dao.dto.DHDHousConsult01IO dHDHousConsult01IO);

	/**
	 * HD_기본_상담일지 병합
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 병합", description = "HD_기본_상담일지 병합")
	int mergeHdHousConsult01(kait.hd.hous.onl.dao.dto.DHDHousConsult01IO dHDHousConsult01IO);

	/**
	 * HD_기본_상담일지 삭제
	 * @TestValues 	deptCode=; housetag=; consDate=; consEmp=; seq=; sex=; custnm=; consTime=; square=; tel=; memo=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_상담일지 삭제", description = "HD_기본_상담일지 삭제")
	int deleteHdHousConsult01(kait.hd.hous.onl.dao.dto.DHDHousConsult01IO dHDHousConsult01IO);


}
