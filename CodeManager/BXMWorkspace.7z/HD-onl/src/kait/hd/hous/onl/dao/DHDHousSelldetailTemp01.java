/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSelldetailTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용", description = "HD_계약_세대별약정사항_계산용")
public interface DHDHousSelldetailTemp01
{
	/**
	 * HD_계약_세대별약정사항_계산용 등록
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 등록", description = "HD_계약_세대별약정사항_계산용 등록")
	int insertHdHousSelldetailTemp01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO dHDHousSelldetailTemp01IO);

	/**
	 * HD_계약_세대별약정사항_계산용 단건조회
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 단건조회", description = "HD_계약_세대별약정사항_계산용 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO selectHdHousSelldetailTemp01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO dHDHousSelldetailTemp01IO);

	/**
	 * HD_계약_세대별약정사항_계산용 전채건수조회
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 전채건수조회", description = "HD_계약_세대별약정사항_계산용 전채건수조회")
	java.lang.Integer selectCountHdHousSelldetailTemp01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO dHDHousSelldetailTemp01IO);

	/**
	 * HD_계약_세대별약정사항_계산용 목록조회
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 목록조회", description = "HD_계약_세대별약정사항_계산용 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO> selectListHdHousSelldetailTemp01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별약정사항_계산용 수정
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 수정", description = "HD_계약_세대별약정사항_계산용 수정")
	int updateHdHousSelldetailTemp01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO dHDHousSelldetailTemp01IO);

	/**
	 * HD_계약_세대별약정사항_계산용 병합
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 병합", description = "HD_계약_세대별약정사항_계산용 병합")
	int mergeHdHousSelldetailTemp01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO dHDHousSelldetailTemp01IO);

	/**
	 * HD_계약_세대별약정사항_계산용 삭제
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별약정사항_계산용 삭제", description = "HD_계약_세대별약정사항_계산용 삭제")
	int deleteHdHousSelldetailTemp01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailTemp01IO dHDHousSelldetailTemp01IO);


}
