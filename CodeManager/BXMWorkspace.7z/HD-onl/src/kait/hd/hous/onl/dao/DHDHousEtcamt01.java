/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousEtcamt01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_HOUS_ETCAMT", description = "HD_HOUS_ETCAMT")
public interface DHDHousEtcamt01
{
	/**
	 * HD_HOUS_ETCAMT 등록
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 등록", description = "HD_HOUS_ETCAMT 등록")
	int insertHdHousEtcamt01(kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO dHDHousEtcamt01IO);

	/**
	 * HD_HOUS_ETCAMT 단건조회
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 단건조회", description = "HD_HOUS_ETCAMT 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO selectHdHousEtcamt01(kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO dHDHousEtcamt01IO);

	/**
	 * HD_HOUS_ETCAMT 전채건수조회
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 전채건수조회", description = "HD_HOUS_ETCAMT 전채건수조회")
	java.lang.Integer selectCountHdHousEtcamt01(kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO dHDHousEtcamt01IO);

	/**
	 * HD_HOUS_ETCAMT 목록조회
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 목록조회", description = "HD_HOUS_ETCAMT 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO> selectListHdHousEtcamt01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_HOUS_ETCAMT 수정
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 수정", description = "HD_HOUS_ETCAMT 수정")
	int updateHdHousEtcamt01(kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO dHDHousEtcamt01IO);

	/**
	 * HD_HOUS_ETCAMT 병합
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 병합", description = "HD_HOUS_ETCAMT 병합")
	int mergeHdHousEtcamt01(kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO dHDHousEtcamt01IO);

	/**
	 * HD_HOUS_ETCAMT 삭제
	 * @TestValues 	custCode=; seq=; etcTag=; cnt=; receiptdate=; receiptamt=; bankCode=; depositNo=; deptCode=; housetag=; buildno=; houseno=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_ETCAMT 삭제", description = "HD_HOUS_ETCAMT 삭제")
	int deleteHdHousEtcamt01(kait.hd.hous.onl.dao.dto.DHDHousEtcamt01IO dHDHousEtcamt01IO);


}
