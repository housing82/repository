/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousRateDelay01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별연체이율", description = "HD_계약_세대별연체이율")
public interface DHDHousRateDelay01
{
	/**
	 * HD_계약_세대별연체이율 등록
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 등록", description = "HD_계약_세대별연체이율 등록")
	int insertHdHousRateDelay01(kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO dHDHousRateDelay01IO);

	/**
	 * HD_계약_세대별연체이율 단건조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 단건조회", description = "HD_계약_세대별연체이율 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO selectHdHousRateDelay01(kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO dHDHousRateDelay01IO);

	/**
	 * HD_계약_세대별연체이율 전채건수조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 전채건수조회", description = "HD_계약_세대별연체이율 전채건수조회")
	java.lang.Integer selectCountHdHousRateDelay01(kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO dHDHousRateDelay01IO);

	/**
	 * HD_계약_세대별연체이율 목록조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 목록조회", description = "HD_계약_세대별연체이율 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO> selectListHdHousRateDelay01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별연체이율 수정
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 수정", description = "HD_계약_세대별연체이율 수정")
	int updateHdHousRateDelay01(kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO dHDHousRateDelay01IO);

	/**
	 * HD_계약_세대별연체이율 병합
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 병합", description = "HD_계약_세대별연체이율 병합")
	int mergeHdHousRateDelay01(kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO dHDHousRateDelay01IO);

	/**
	 * HD_계약_세대별연체이율 삭제
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별연체이율 삭제", description = "HD_계약_세대별연체이율 삭제")
	int deleteHdHousRateDelay01(kait.hd.hous.onl.dao.dto.DHDHousRateDelay01IO dHDHousRateDelay01IO);


}
