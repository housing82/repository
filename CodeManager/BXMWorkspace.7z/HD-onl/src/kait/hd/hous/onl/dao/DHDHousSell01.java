/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSell01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별분양대장", description = "HD_계약_세대별분양대장")
public interface DHDHousSell01
{
	/**
	 * HD_계약_세대별분양대장 등록
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 등록", description = "HD_계약_세대별분양대장 등록")
	int insertHdHousSell01(kait.hd.hous.onl.dao.dto.DHDHousSell01IO dHDHousSell01IO);

	/**
	 * HD_계약_세대별분양대장 단건조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 단건조회", description = "HD_계약_세대별분양대장 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSell01IO selectHdHousSell01(kait.hd.hous.onl.dao.dto.DHDHousSell01IO dHDHousSell01IO);

	/**
	 * HD_계약_세대별분양대장 전채건수조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 전채건수조회", description = "HD_계약_세대별분양대장 전채건수조회")
	java.lang.Integer selectCountHdHousSell01(kait.hd.hous.onl.dao.dto.DHDHousSell01IO dHDHousSell01IO);

	/**
	 * HD_계약_세대별분양대장 목록조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 목록조회", description = "HD_계약_세대별분양대장 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSell01IO> selectListHdHousSell01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSell01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별분양대장 수정
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 수정", description = "HD_계약_세대별분양대장 수정")
	int updateHdHousSell01(kait.hd.hous.onl.dao.dto.DHDHousSell01IO dHDHousSell01IO);

	/**
	 * HD_계약_세대별분양대장 병합
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 병합", description = "HD_계약_세대별분양대장 병합")
	int mergeHdHousSell01(kait.hd.hous.onl.dao.dto.DHDHousSell01IO dHDHousSell01IO);

	/**
	 * HD_계약_세대별분양대장 삭제
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; balconyamt=; custCode2=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장 삭제", description = "HD_계약_세대별분양대장 삭제")
	int deleteHdHousSell01(kait.hd.hous.onl.dao.dto.DHDHousSell01IO dHDHousSell01IO);


}
