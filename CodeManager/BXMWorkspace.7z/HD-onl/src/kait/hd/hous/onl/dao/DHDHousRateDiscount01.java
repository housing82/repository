/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousRateDiscount01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별할인이율", description = "HD_계약_세대별할인이율")
public interface DHDHousRateDiscount01
{
	/**
	 * HD_계약_세대별할인이율 등록
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 등록", description = "HD_계약_세대별할인이율 등록")
	int insertHdHousRateDiscount01(kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO dHDHousRateDiscount01IO);

	/**
	 * HD_계약_세대별할인이율 단건조회
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 단건조회", description = "HD_계약_세대별할인이율 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO selectHdHousRateDiscount01(kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO dHDHousRateDiscount01IO);

	/**
	 * HD_계약_세대별할인이율 전채건수조회
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 전채건수조회", description = "HD_계약_세대별할인이율 전채건수조회")
	java.lang.Integer selectCountHdHousRateDiscount01(kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO dHDHousRateDiscount01IO);

	/**
	 * HD_계약_세대별할인이율 목록조회
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 목록조회", description = "HD_계약_세대별할인이율 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO> selectListHdHousRateDiscount01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별할인이율 수정
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 수정", description = "HD_계약_세대별할인이율 수정")
	int updateHdHousRateDiscount01(kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO dHDHousRateDiscount01IO);

	/**
	 * HD_계약_세대별할인이율 병합
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 병합", description = "HD_계약_세대별할인이율 병합")
	int mergeHdHousRateDiscount01(kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO dHDHousRateDiscount01IO);

	/**
	 * HD_계약_세대별할인이율 삭제
	 * @TestValues 	custCode=; seq=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별할인이율 삭제", description = "HD_계약_세대별할인이율 삭제")
	int deleteHdHousRateDiscount01(kait.hd.hous.onl.dao.dto.DHDHousRateDiscount01IO dHDHousRateDiscount01IO);


}
