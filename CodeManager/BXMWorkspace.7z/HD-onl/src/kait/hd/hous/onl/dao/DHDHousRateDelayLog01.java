/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousRateDelayLog01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_세대별연체이율_LOG", description = "HD_세대별연체이율_LOG")
public interface DHDHousRateDelayLog01
{
	/**
	 * HD_세대별연체이율_LOG 등록
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 등록", description = "HD_세대별연체이율_LOG 등록")
	int insertHdHousRateDelayLog01(kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO dHDHousRateDelayLog01IO);

	/**
	 * HD_세대별연체이율_LOG 단건조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 단건조회", description = "HD_세대별연체이율_LOG 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO selectHdHousRateDelayLog01(kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO dHDHousRateDelayLog01IO);

	/**
	 * HD_세대별연체이율_LOG 전채건수조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 전채건수조회", description = "HD_세대별연체이율_LOG 전채건수조회")
	java.lang.Integer selectCountHdHousRateDelayLog01(kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO dHDHousRateDelayLog01IO);

	/**
	 * HD_세대별연체이율_LOG 목록조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 목록조회", description = "HD_세대별연체이율_LOG 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO> selectListHdHousRateDelayLog01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_세대별연체이율_LOG 수정
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 수정", description = "HD_세대별연체이율_LOG 수정")
	int updateHdHousRateDelayLog01(kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO dHDHousRateDelayLog01IO);

	/**
	 * HD_세대별연체이율_LOG 병합
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 병합", description = "HD_세대별연체이율_LOG 병합")
	int mergeHdHousRateDelayLog01(kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO dHDHousRateDelayLog01IO);

	/**
	 * HD_세대별연체이율_LOG 삭제
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; writetag=; writetime=; writeseq=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별연체이율_LOG 삭제", description = "HD_세대별연체이율_LOG 삭제")
	int deleteHdHousRateDelayLog01(kait.hd.hous.onl.dao.dto.DHDHousRateDelayLog01IO dHDHousRateDelayLog01IO);


}
