/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSellTxtup01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기", description = "HD_계약_세대별분양대장_자료올리기")
public interface DHDHousSellTxtup01
{
	/**
	 * HD_계약_세대별분양대장_자료올리기 등록
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 등록", description = "HD_계약_세대별분양대장_자료올리기 등록")
	int insertHdHousSellTxtup01(kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO dHDHousSellTxtup01IO);

	/**
	 * HD_계약_세대별분양대장_자료올리기 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 단건조회", description = "HD_계약_세대별분양대장_자료올리기 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO selectHdHousSellTxtup01(kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO dHDHousSellTxtup01IO);

	/**
	 * HD_계약_세대별분양대장_자료올리기 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 전채건수조회", description = "HD_계약_세대별분양대장_자료올리기 전채건수조회")
	java.lang.Integer selectCountHdHousSellTxtup01(kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO dHDHousSellTxtup01IO);

	/**
	 * HD_계약_세대별분양대장_자료올리기 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 목록조회", description = "HD_계약_세대별분양대장_자료올리기 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO> selectListHdHousSellTxtup01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별분양대장_자료올리기 수정
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 수정", description = "HD_계약_세대별분양대장_자료올리기 수정")
	int updateHdHousSellTxtup01(kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO dHDHousSellTxtup01IO);

	/**
	 * HD_계약_세대별분양대장_자료올리기 병합
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 병합", description = "HD_계약_세대별분양대장_자료올리기 병합")
	int mergeHdHousSellTxtup01(kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO dHDHousSellTxtup01IO);

	/**
	 * HD_계약_세대별분양대장_자료올리기 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; sn=; buildno=; houseno=; custCode=; contdate=; receiptdate=; receiptamt=; contYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별분양대장_자료올리기 삭제", description = "HD_계약_세대별분양대장_자료올리기 삭제")
	int deleteHdHousSellTxtup01(kait.hd.hous.onl.dao.dto.DHDHousSellTxtup01IO dHDHousSellTxtup01IO);


}
