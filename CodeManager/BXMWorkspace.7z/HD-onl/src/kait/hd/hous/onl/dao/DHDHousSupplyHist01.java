/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSupplyHist01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력", description = "HD_기본_세대별공급내역_이력")
public interface DHDHousSupplyHist01
{
	/**
	 * HD_기본_세대별공급내역_이력 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 등록", description = "HD_기본_세대별공급내역_이력 등록")
	int insertHdHousSupplyHist01(kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO dHDHousSupplyHist01IO);

	/**
	 * HD_기본_세대별공급내역_이력 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 단건조회", description = "HD_기본_세대별공급내역_이력 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO selectHdHousSupplyHist01(kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO dHDHousSupplyHist01IO);

	/**
	 * HD_기본_세대별공급내역_이력 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 전채건수조회", description = "HD_기본_세대별공급내역_이력 전채건수조회")
	java.lang.Integer selectCountHdHousSupplyHist01(kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO dHDHousSupplyHist01IO);

	/**
	 * HD_기본_세대별공급내역_이력 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 목록조회", description = "HD_기본_세대별공급내역_이력 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO> selectListHdHousSupplyHist01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별공급내역_이력 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 수정", description = "HD_기본_세대별공급내역_이력 수정")
	int updateHdHousSupplyHist01(kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO dHDHousSupplyHist01IO);

	/**
	 * HD_기본_세대별공급내역_이력 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 병합", description = "HD_기본_세대별공급내역_이력 병합")
	int mergeHdHousSupplyHist01(kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO dHDHousSupplyHist01IO);

	/**
	 * HD_기본_세대별공급내역_이력 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; histDate=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; triTag=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_이력 삭제", description = "HD_기본_세대별공급내역_이력 삭제")
	int deleteHdHousSupplyHist01(kait.hd.hous.onl.dao.dto.DHDHousSupplyHist01IO dHDHousSupplyHist01IO);


}
