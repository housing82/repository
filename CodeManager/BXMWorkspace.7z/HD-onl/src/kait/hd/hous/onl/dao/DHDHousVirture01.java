/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousVirture01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_가상계좌자료", description = "HD_분양_가상계좌자료")
public interface DHDHousVirture01
{
	/**
	 * HD_분양_가상계좌자료 등록
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 등록", description = "HD_분양_가상계좌자료 등록")
	int insertHdHousVirture01(kait.hd.hous.onl.dao.dto.DHDHousVirture01IO dHDHousVirture01IO);

	/**
	 * HD_분양_가상계좌자료 단건조회
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 단건조회", description = "HD_분양_가상계좌자료 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousVirture01IO selectHdHousVirture01(kait.hd.hous.onl.dao.dto.DHDHousVirture01IO dHDHousVirture01IO);

	/**
	 * HD_분양_가상계좌자료 전채건수조회
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 전채건수조회", description = "HD_분양_가상계좌자료 전채건수조회")
	java.lang.Integer selectCountHdHousVirture01(kait.hd.hous.onl.dao.dto.DHDHousVirture01IO dHDHousVirture01IO);

	/**
	 * HD_분양_가상계좌자료 목록조회
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 목록조회", description = "HD_분양_가상계좌자료 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousVirture01IO> selectListHdHousVirture01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousVirture01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_가상계좌자료 수정
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 수정", description = "HD_분양_가상계좌자료 수정")
	int updateHdHousVirture01(kait.hd.hous.onl.dao.dto.DHDHousVirture01IO dHDHousVirture01IO);

	/**
	 * HD_분양_가상계좌자료 병합
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 병합", description = "HD_분양_가상계좌자료 병합")
	int mergeHdHousVirture01(kait.hd.hous.onl.dao.dto.DHDHousVirture01IO dHDHousVirture01IO);

	/**
	 * HD_분양_가상계좌자료 삭제
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; vaNo=; depAmt=; deptSt=; processtag=; deptCode=; housetag=; buildno=; houseno=; custCode=; seq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌자료 삭제", description = "HD_분양_가상계좌자료 삭제")
	int deleteHdHousVirture01(kait.hd.hous.onl.dao.dto.DHDHousVirture01IO dHDHousVirture01IO);


}
