/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousRemark01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별특이사항", description = "HD_계약_세대별특이사항")
public interface DHDHousRemark01
{
	/**
	 * HD_계약_세대별특이사항 등록
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 등록", description = "HD_계약_세대별특이사항 등록")
	int insertHdHousRemark01(kait.hd.hous.onl.dao.dto.DHDHousRemark01IO dHDHousRemark01IO);

	/**
	 * HD_계약_세대별특이사항 단건조회
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 단건조회", description = "HD_계약_세대별특이사항 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousRemark01IO selectHdHousRemark01(kait.hd.hous.onl.dao.dto.DHDHousRemark01IO dHDHousRemark01IO);

	/**
	 * HD_계약_세대별특이사항 전채건수조회
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 전채건수조회", description = "HD_계약_세대별특이사항 전채건수조회")
	java.lang.Integer selectCountHdHousRemark01(kait.hd.hous.onl.dao.dto.DHDHousRemark01IO dHDHousRemark01IO);

	/**
	 * HD_계약_세대별특이사항 목록조회
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 목록조회", description = "HD_계약_세대별특이사항 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousRemark01IO> selectListHdHousRemark01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousRemark01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별특이사항 수정
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 수정", description = "HD_계약_세대별특이사항 수정")
	int updateHdHousRemark01(kait.hd.hous.onl.dao.dto.DHDHousRemark01IO dHDHousRemark01IO);

	/**
	 * HD_계약_세대별특이사항 병합
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 병합", description = "HD_계약_세대별특이사항 병합")
	int mergeHdHousRemark01(kait.hd.hous.onl.dao.dto.DHDHousRemark01IO dHDHousRemark01IO);

	/**
	 * HD_계약_세대별특이사항 삭제
	 * @TestValues 	custCode=; seq=; remarkseq=; reamrkdate=; remark=; userid=; confirmDate=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별특이사항 삭제", description = "HD_계약_세대별특이사항 삭제")
	int deleteHdHousRemark01(kait.hd.hous.onl.dao.dto.DHDHousRemark01IO dHDHousRemark01IO);


}
