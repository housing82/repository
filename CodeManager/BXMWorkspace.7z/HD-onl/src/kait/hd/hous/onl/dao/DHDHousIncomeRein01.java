/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousIncomeRein01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_잔금제계산이력", description = "HD_분양_잔금제계산이력")
public interface DHDHousIncomeRein01
{
	/**
	 * HD_분양_잔금제계산이력 등록
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 등록", description = "HD_분양_잔금제계산이력 등록")
	int insertHdHousIncomeRein01(kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO dHDHousIncomeRein01IO);

	/**
	 * HD_분양_잔금제계산이력 단건조회
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 단건조회", description = "HD_분양_잔금제계산이력 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO selectHdHousIncomeRein01(kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO dHDHousIncomeRein01IO);

	/**
	 * HD_분양_잔금제계산이력 전채건수조회
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 전채건수조회", description = "HD_분양_잔금제계산이력 전채건수조회")
	java.lang.Integer selectCountHdHousIncomeRein01(kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO dHDHousIncomeRein01IO);

	/**
	 * HD_분양_잔금제계산이력 목록조회
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 목록조회", description = "HD_분양_잔금제계산이력 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO> selectListHdHousIncomeRein01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_잔금제계산이력 수정
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 수정", description = "HD_분양_잔금제계산이력 수정")
	int updateHdHousIncomeRein01(kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO dHDHousIncomeRein01IO);

	/**
	 * HD_분양_잔금제계산이력 병합
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 병합", description = "HD_분양_잔금제계산이력 병합")
	int mergeHdHousIncomeRein01(kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO dHDHousIncomeRein01IO);

	/**
	 * HD_분양_잔금제계산이력 삭제
	 * @TestValues 	custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; sliptype=; vdepositNo=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; cdBank=; cdEdate=; cdStype=; 
	 */
	@BxmCategory(logicalName = "HD_분양_잔금제계산이력 삭제", description = "HD_분양_잔금제계산이력 삭제")
	int deleteHdHousIncomeRein01(kait.hd.hous.onl.dao.dto.DHDHousIncomeRein01IO dHDHousIncomeRein01IO);


}
