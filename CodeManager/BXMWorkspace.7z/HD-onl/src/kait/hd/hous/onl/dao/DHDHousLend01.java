/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousLend01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_대출약정", description = "HD_계약_대출약정")
public interface DHDHousLend01
{
	/**
	 * HD_계약_대출약정 등록
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 등록", description = "HD_계약_대출약정 등록")
	int insertHdHousLend01(kait.hd.hous.onl.dao.dto.DHDHousLend01IO dHDHousLend01IO);

	/**
	 * HD_계약_대출약정 단건조회
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 단건조회", description = "HD_계약_대출약정 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousLend01IO selectHdHousLend01(kait.hd.hous.onl.dao.dto.DHDHousLend01IO dHDHousLend01IO);

	/**
	 * HD_계약_대출약정 전채건수조회
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 전채건수조회", description = "HD_계약_대출약정 전채건수조회")
	java.lang.Integer selectCountHdHousLend01(kait.hd.hous.onl.dao.dto.DHDHousLend01IO dHDHousLend01IO);

	/**
	 * HD_계약_대출약정 목록조회
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 목록조회", description = "HD_계약_대출약정 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousLend01IO> selectListHdHousLend01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousLend01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_대출약정 수정
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 수정", description = "HD_계약_대출약정 수정")
	int updateHdHousLend01(kait.hd.hous.onl.dao.dto.DHDHousLend01IO dHDHousLend01IO);

	/**
	 * HD_계약_대출약정 병합
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 병합", description = "HD_계약_대출약정 병합")
	int mergeHdHousLend01(kait.hd.hous.onl.dao.dto.DHDHousLend01IO dHDHousLend01IO);

	/**
	 * HD_계약_대출약정 삭제
	 * @TestValues 	custCode=; seq=; cnt=; bankCode=; agreedate=; agreeamt=; lendTag=; lenddate=; perpecttag=; realReceiptamt=; stampAmt=; guaranteeAmt=; lendInterest=; rate=; realDate=; exchangePlandate=; exchangePlanamt=; exchangeDate=; exchangeAmt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정 삭제", description = "HD_계약_대출약정 삭제")
	int deleteHdHousLend01(kait.hd.hous.onl.dao.dto.DHDHousLend01IO dHDHousLend01IO);


}
