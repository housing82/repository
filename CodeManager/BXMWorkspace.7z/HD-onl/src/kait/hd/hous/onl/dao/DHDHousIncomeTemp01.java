/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousIncomeTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용", description = "HD_분양_세대별입금사항_계산용")
public interface DHDHousIncomeTemp01
{
	/**
	 * HD_분양_세대별입금사항_계산용 등록
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 등록", description = "HD_분양_세대별입금사항_계산용 등록")
	int insertHdHousIncomeTemp01(kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO dHDHousIncomeTemp01IO);

	/**
	 * HD_분양_세대별입금사항_계산용 단건조회
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 단건조회", description = "HD_분양_세대별입금사항_계산용 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO selectHdHousIncomeTemp01(kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO dHDHousIncomeTemp01IO);

	/**
	 * HD_분양_세대별입금사항_계산용 전채건수조회
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 전채건수조회", description = "HD_분양_세대별입금사항_계산용 전채건수조회")
	java.lang.Integer selectCountHdHousIncomeTemp01(kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO dHDHousIncomeTemp01IO);

	/**
	 * HD_분양_세대별입금사항_계산용 목록조회
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 목록조회", description = "HD_분양_세대별입금사항_계산용 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO> selectListHdHousIncomeTemp01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_세대별입금사항_계산용 수정
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 수정", description = "HD_분양_세대별입금사항_계산용 수정")
	int updateHdHousIncomeTemp01(kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO dHDHousIncomeTemp01IO);

	/**
	 * HD_분양_세대별입금사항_계산용 병합
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 병합", description = "HD_분양_세대별입금사항_계산용 병합")
	int mergeHdHousIncomeTemp01(kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO dHDHousIncomeTemp01IO);

	/**
	 * HD_분양_세대별입금사항_계산용 삭제
	 * @TestValues 	seqNum=; custCode=; seq=; counts=; times=; deptCode=; housetag=; buildno=; houseno=; depositNo=; receiptdate=; receiptamt=; receiptlandamt=; receiptbuildamt=; receiptvatamt=; delaydays=; delayamt=; discntdays=; discntamt=; realincomamt=; reallandamt=; realbuildamt=; realvatamt=; bankCode=; bankName=; paytag=; incomtype=; modYn=; realPayTag=; slipdt=; slipseq=; taxdate=; taxseq=; inseq=; calcYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; detailmodYn=; outDt=; outTm=; outSeq=; outBank=; remark=; receiptmanageamt=; realmanageamt=; cdno=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세대별입금사항_계산용 삭제", description = "HD_분양_세대별입금사항_계산용 삭제")
	int deleteHdHousIncomeTemp01(kait.hd.hous.onl.dao.dto.DHDHousIncomeTemp01IO dHDHousIncomeTemp01IO);


}
