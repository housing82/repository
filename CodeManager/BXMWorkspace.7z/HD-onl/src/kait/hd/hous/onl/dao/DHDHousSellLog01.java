/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSellLog01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_세대별분양대장_LOG", description = "HD_세대별분양대장_LOG")
public interface DHDHousSellLog01
{
	/**
	 * HD_세대별분양대장_LOG 등록
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 등록", description = "HD_세대별분양대장_LOG 등록")
	int insertHdHousSellLog01(kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO dHDHousSellLog01IO);

	/**
	 * HD_세대별분양대장_LOG 단건조회
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 단건조회", description = "HD_세대별분양대장_LOG 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO selectHdHousSellLog01(kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO dHDHousSellLog01IO);

	/**
	 * HD_세대별분양대장_LOG 전채건수조회
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 전채건수조회", description = "HD_세대별분양대장_LOG 전채건수조회")
	java.lang.Integer selectCountHdHousSellLog01(kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO dHDHousSellLog01IO);

	/**
	 * HD_세대별분양대장_LOG 목록조회
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 목록조회", description = "HD_세대별분양대장_LOG 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO> selectListHdHousSellLog01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_세대별분양대장_LOG 수정
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 수정", description = "HD_세대별분양대장_LOG 수정")
	int updateHdHousSellLog01(kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO dHDHousSellLog01IO);

	/**
	 * HD_세대별분양대장_LOG 병합
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 병합", description = "HD_세대별분양대장_LOG 병합")
	int mergeHdHousSellLog01(kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO dHDHousSellLog01IO);

	/**
	 * HD_세대별분양대장_LOG 삭제
	 * @TestValues 	custCode=; seq=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; dongho=; custName=; square=; type=; classJrw=; optioncode=; contracttag=; contractdate=; contractno=; loanTag=; leasetag=; lastchangedate=; changetag=; changedate=; cancelReason=; childBuildno=; childHouseno=; relaCustcode=; relaSeq=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; moveinstartdate=; moveinenddate=; unionCnt=; remark=; refundmentdate=; refundmentamt=; penaltyamt=; loanInterest=; sodukTax=; juminTax=; bankLoanOrgamt=; bankLoanInterest=; loanbank=; loandeposit=; loanuser=; refundDeposit=; refundBank=; compLoanamt=; billReturnamt=; delayIndeminity=; depositCount=; coCustcode=; coSangho=; coCondition=; coCategory=; categoryName=; slipdate=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; applyYn=; applyEmpno=; applyDate=; prtsquare=; bankLoanInterest2=; etcAmt=; renthdYn=; renthdSeq=; balconyTag=; balconyarea=; daymonthTag=; floor=; contCondition=; landReturn=; intCalcDate=; predisamt=; proxyamt=; incontDate=; trustamt=; predisTag=; proxyTag=; trustTag=; virYn=; vdeposit=; repLimitdt=; repYn=; repDate=; 
	 */
	@BxmCategory(logicalName = "HD_세대별분양대장_LOG 삭제", description = "HD_세대별분양대장_LOG 삭제")
	int deleteHdHousSellLog01(kait.hd.hous.onl.dao.dto.DHDHousSellLog01IO dHDHousSellLog01IO);


}
