/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousUnion01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별공동명의자", description = "HD_계약_세대별공동명의자")
public interface DHDHousUnion01
{
	/**
	 * HD_계약_세대별공동명의자 등록
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 등록", description = "HD_계약_세대별공동명의자 등록")
	int insertHdHousUnion01(kait.hd.hous.onl.dao.dto.DHDHousUnion01IO dHDHousUnion01IO);

	/**
	 * HD_계약_세대별공동명의자 단건조회
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 단건조회", description = "HD_계약_세대별공동명의자 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousUnion01IO selectHdHousUnion01(kait.hd.hous.onl.dao.dto.DHDHousUnion01IO dHDHousUnion01IO);

	/**
	 * HD_계약_세대별공동명의자 전채건수조회
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 전채건수조회", description = "HD_계약_세대별공동명의자 전채건수조회")
	java.lang.Integer selectCountHdHousUnion01(kait.hd.hous.onl.dao.dto.DHDHousUnion01IO dHDHousUnion01IO);

	/**
	 * HD_계약_세대별공동명의자 목록조회
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 목록조회", description = "HD_계약_세대별공동명의자 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousUnion01IO> selectListHdHousUnion01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousUnion01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별공동명의자 수정
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 수정", description = "HD_계약_세대별공동명의자 수정")
	int updateHdHousUnion01(kait.hd.hous.onl.dao.dto.DHDHousUnion01IO dHDHousUnion01IO);

	/**
	 * HD_계약_세대별공동명의자 병합
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 병합", description = "HD_계약_세대별공동명의자 병합")
	int mergeHdHousUnion01(kait.hd.hous.onl.dao.dto.DHDHousUnion01IO dHDHousUnion01IO);

	/**
	 * HD_계약_세대별공동명의자 삭제
	 * @TestValues 	custCode=; seq=; unionCustcode=; unionCustnm=; regDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별공동명의자 삭제", description = "HD_계약_세대별공동명의자 삭제")
	int deleteHdHousUnion01(kait.hd.hous.onl.dao.dto.DHDHousUnion01IO dHDHousUnion01IO);


}
