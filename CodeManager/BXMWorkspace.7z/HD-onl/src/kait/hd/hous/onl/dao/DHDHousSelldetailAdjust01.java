/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSelldetailAdjust01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_정산_세대별약정사항", description = "HD_정산_세대별약정사항")
public interface DHDHousSelldetailAdjust01
{
	/**
	 * HD_정산_세대별약정사항 등록
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 등록", description = "HD_정산_세대별약정사항 등록")
	int insertHdHousSelldetailAdjust01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO dHDHousSelldetailAdjust01IO);

	/**
	 * HD_정산_세대별약정사항 단건조회
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 단건조회", description = "HD_정산_세대별약정사항 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO selectHdHousSelldetailAdjust01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO dHDHousSelldetailAdjust01IO);

	/**
	 * HD_정산_세대별약정사항 전채건수조회
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 전채건수조회", description = "HD_정산_세대별약정사항 전채건수조회")
	java.lang.Integer selectCountHdHousSelldetailAdjust01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO dHDHousSelldetailAdjust01IO);

	/**
	 * HD_정산_세대별약정사항 목록조회
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 목록조회", description = "HD_정산_세대별약정사항 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO> selectListHdHousSelldetailAdjust01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_정산_세대별약정사항 수정
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 수정", description = "HD_정산_세대별약정사항 수정")
	int updateHdHousSelldetailAdjust01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO dHDHousSelldetailAdjust01IO);

	/**
	 * HD_정산_세대별약정사항 병합
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 병합", description = "HD_정산_세대별약정사항 병합")
	int mergeHdHousSelldetailAdjust01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO dHDHousSelldetailAdjust01IO);

	/**
	 * HD_정산_세대별약정사항 삭제
	 * @TestValues 	custCode=; seq=; counts=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_정산_세대별약정사항 삭제", description = "HD_정산_세대별약정사항 삭제")
	int deleteHdHousSelldetailAdjust01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailAdjust01IO dHDHousSelldetailAdjust01IO);


}
