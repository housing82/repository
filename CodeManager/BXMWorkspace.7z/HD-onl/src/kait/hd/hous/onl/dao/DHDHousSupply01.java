/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSupply01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별공급내역", description = "HD_기본_세대별공급내역")
public interface DHDHousSupply01
{
	/**
	 * HD_기본_세대별공급내역 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 등록", description = "HD_기본_세대별공급내역 등록")
	int insertHdHousSupply01(kait.hd.hous.onl.dao.dto.DHDHousSupply01IO dHDHousSupply01IO);

	/**
	 * HD_기본_세대별공급내역 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 단건조회", description = "HD_기본_세대별공급내역 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSupply01IO selectHdHousSupply01(kait.hd.hous.onl.dao.dto.DHDHousSupply01IO dHDHousSupply01IO);

	/**
	 * HD_기본_세대별공급내역 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 전채건수조회", description = "HD_기본_세대별공급내역 전채건수조회")
	java.lang.Integer selectCountHdHousSupply01(kait.hd.hous.onl.dao.dto.DHDHousSupply01IO dHDHousSupply01IO);

	/**
	 * HD_기본_세대별공급내역 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 목록조회", description = "HD_기본_세대별공급내역 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSupply01IO> selectListHdHousSupply01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSupply01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별공급내역 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 수정", description = "HD_기본_세대별공급내역 수정")
	int updateHdHousSupply01(kait.hd.hous.onl.dao.dto.DHDHousSupply01IO dHDHousSupply01IO);

	/**
	 * HD_기본_세대별공급내역 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 병합", description = "HD_기본_세대별공급내역 병합")
	int mergeHdHousSupply01(kait.hd.hous.onl.dao.dto.DHDHousSupply01IO dHDHousSupply01IO);

	/**
	 * HD_기본_세대별공급내역 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; floor=; gubun=; categoryName=; contractyesno=; virdeposit=; bankCode=; bankName=; useYn=; rentTag=; inputDutyId=; inputDate=; chgDutyId=; prtsquare=; chgDate=; predisamt=; virdeposit2=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역 삭제", description = "HD_기본_세대별공급내역 삭제")
	int deleteHdHousSupply01(kait.hd.hous.onl.dao.dto.DHDHousSupply01IO dHDHousSupply01IO);


}
