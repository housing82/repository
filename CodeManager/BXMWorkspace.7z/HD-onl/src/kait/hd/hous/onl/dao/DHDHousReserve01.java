/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousReserve01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_예약자등록", description = "HD_계약_예약자등록")
public interface DHDHousReserve01
{
	/**
	 * HD_계약_예약자등록 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 등록", description = "HD_계약_예약자등록 등록")
	int insertHdHousReserve01(kait.hd.hous.onl.dao.dto.DHDHousReserve01IO dHDHousReserve01IO);

	/**
	 * HD_계약_예약자등록 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 단건조회", description = "HD_계약_예약자등록 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousReserve01IO selectHdHousReserve01(kait.hd.hous.onl.dao.dto.DHDHousReserve01IO dHDHousReserve01IO);

	/**
	 * HD_계약_예약자등록 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 전채건수조회", description = "HD_계약_예약자등록 전채건수조회")
	java.lang.Integer selectCountHdHousReserve01(kait.hd.hous.onl.dao.dto.DHDHousReserve01IO dHDHousReserve01IO);

	/**
	 * HD_계약_예약자등록 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 목록조회", description = "HD_계약_예약자등록 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousReserve01IO> selectListHdHousReserve01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousReserve01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_예약자등록 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 수정", description = "HD_계약_예약자등록 수정")
	int updateHdHousReserve01(kait.hd.hous.onl.dao.dto.DHDHousReserve01IO dHDHousReserve01IO);

	/**
	 * HD_계약_예약자등록 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 병합", description = "HD_계약_예약자등록 병합")
	int mergeHdHousReserve01(kait.hd.hous.onl.dao.dto.DHDHousReserve01IO dHDHousReserve01IO);

	/**
	 * HD_계약_예약자등록 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; custCode=; square=; type=; classJrw=; options=; reservedate=; reserveamt=; remainamt=; contractdate=; contracttag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; 
	 */
	@BxmCategory(logicalName = "HD_계약_예약자등록 삭제", description = "HD_계약_예약자등록 삭제")
	int deleteHdHousReserve01(kait.hd.hous.onl.dao.dto.DHDHousReserve01IO dHDHousReserve01IO);


}
