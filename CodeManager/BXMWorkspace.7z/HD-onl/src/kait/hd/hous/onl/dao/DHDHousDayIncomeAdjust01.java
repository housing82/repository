/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousDayIncomeAdjust01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_정산_일자별입금내역", description = "HD_정산_일자별입금내역")
public interface DHDHousDayIncomeAdjust01
{
	/**
	 * HD_정산_일자별입금내역 등록
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 등록", description = "HD_정산_일자별입금내역 등록")
	int insertHdHousDayIncomeAdjust01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO dHDHousDayIncomeAdjust01IO);

	/**
	 * HD_정산_일자별입금내역 단건조회
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 단건조회", description = "HD_정산_일자별입금내역 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO selectHdHousDayIncomeAdjust01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO dHDHousDayIncomeAdjust01IO);

	/**
	 * HD_정산_일자별입금내역 전채건수조회
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 전채건수조회", description = "HD_정산_일자별입금내역 전채건수조회")
	java.lang.Integer selectCountHdHousDayIncomeAdjust01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO dHDHousDayIncomeAdjust01IO);

	/**
	 * HD_정산_일자별입금내역 목록조회
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 목록조회", description = "HD_정산_일자별입금내역 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO> selectListHdHousDayIncomeAdjust01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_정산_일자별입금내역 수정
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 수정", description = "HD_정산_일자별입금내역 수정")
	int updateHdHousDayIncomeAdjust01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO dHDHousDayIncomeAdjust01IO);

	/**
	 * HD_정산_일자별입금내역 병합
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 병합", description = "HD_정산_일자별입금내역 병합")
	int mergeHdHousDayIncomeAdjust01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO dHDHousDayIncomeAdjust01IO);

	/**
	 * HD_정산_일자별입금내역 삭제
	 * @TestValues 	deptCode=; housetag=; indt=; inseq=; buildno=; houseno=; custCode=; seq=; custName=; depositNo=; inamt=; ingubun=; intype=; iheYn=; cdno=; modYn=; modRamt=; modDamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; vdepositNo=; 
	 */
	@BxmCategory(logicalName = "HD_정산_일자별입금내역 삭제", description = "HD_정산_일자별입금내역 삭제")
	int deleteHdHousDayIncomeAdjust01(kait.hd.hous.onl.dao.dto.DHDHousDayIncomeAdjust01IO dHDHousDayIncomeAdjust01IO);


}
