/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousRateDelay120701.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207", description = "HD_HOUS_RATE_DELAY_1207")
public interface DHDHousRateDelay120701
{
	/**
	 * HD_HOUS_RATE_DELAY_1207 등록
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207 등록", description = "HD_HOUS_RATE_DELAY_1207 등록")
	int insertHdHousRateDelay120701(kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO dHDHousRateDelay120701IO);

	/**
	 * HD_HOUS_RATE_DELAY_1207 단건조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207 단건조회", description = "HD_HOUS_RATE_DELAY_1207 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO selectHdHousRateDelay120701(kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO dHDHousRateDelay120701IO);

	/**
	 * HD_HOUS_RATE_DELAY_1207 전채건수조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207 전채건수조회", description = "HD_HOUS_RATE_DELAY_1207 전채건수조회")
	java.lang.Integer selectCountHdHousRateDelay120701(kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO dHDHousRateDelay120701IO);

	/**
	 * HD_HOUS_RATE_DELAY_1207 목록조회
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207 목록조회", description = "HD_HOUS_RATE_DELAY_1207 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO> selectListHdHousRateDelay120701(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_HOUS_RATE_DELAY_1207 수정
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207 수정", description = "HD_HOUS_RATE_DELAY_1207 수정")
	int updateHdHousRateDelay120701(kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO dHDHousRateDelay120701IO);

	/**
	 * HD_HOUS_RATE_DELAY_1207 삭제
	 * @TestValues 	custCode=; seq=; startDays=; endDays=; startdate=; enddate=; delayrate=; delaycut=; delayunit=; startTag=; endTag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_RATE_DELAY_1207 삭제", description = "HD_HOUS_RATE_DELAY_1207 삭제")
	int deleteHdHousRateDelay120701(kait.hd.hous.onl.dao.dto.DHDHousRateDelay120701IO dHDHousRateDelay120701IO);


}
