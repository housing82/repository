/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSubscribe01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_청약관리", description = "HD_기본_청약관리")
public interface DHDHousSubscribe01
{
	/**
	 * HD_기본_청약관리 등록
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 등록", description = "HD_기본_청약관리 등록")
	int insertHdHousSubscribe01(kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO dHDHousSubscribe01IO);

	/**
	 * HD_기본_청약관리 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 단건조회", description = "HD_기본_청약관리 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO selectHdHousSubscribe01(kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO dHDHousSubscribe01IO);

	/**
	 * HD_기본_청약관리 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 전채건수조회", description = "HD_기본_청약관리 전채건수조회")
	java.lang.Integer selectCountHdHousSubscribe01(kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO dHDHousSubscribe01IO);

	/**
	 * HD_기본_청약관리 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 목록조회", description = "HD_기본_청약관리 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO> selectListHdHousSubscribe01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_청약관리 수정
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 수정", description = "HD_기본_청약관리 수정")
	int updateHdHousSubscribe01(kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO dHDHousSubscribe01IO);

	/**
	 * HD_기본_청약관리 병합
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 병합", description = "HD_기본_청약관리 병합")
	int mergeHdHousSubscribe01(kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO dHDHousSubscribe01IO);

	/**
	 * HD_기본_청약관리 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; custSeq=; custName=; subscribeTag=; subscribeDate=; subscribeAmt=; winDate=; buildno=; houseno=; returnTag=; returnDate=; returnAmt=; virYn=; vdepositNo=; incomYn=; contNo=; registYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; errText=; actYn=; remark=; 
	 */
	@BxmCategory(logicalName = "HD_기본_청약관리 삭제", description = "HD_기본_청약관리 삭제")
	int deleteHdHousSubscribe01(kait.hd.hous.onl.dao.dto.DHDHousSubscribe01IO dHDHousSubscribe01IO);


}
