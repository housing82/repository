/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousIndeminityConv01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기", description = "HD_계약_지체보상금_자료올리기")
public interface DHDHousIndeminityConv01
{
	/**
	 * HD_계약_지체보상금_자료올리기 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 등록", description = "HD_계약_지체보상금_자료올리기 등록")
	int insertHdHousIndeminityConv01(kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO dHDHousIndeminityConv01IO);

	/**
	 * HD_계약_지체보상금_자료올리기 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 단건조회", description = "HD_계약_지체보상금_자료올리기 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO selectHdHousIndeminityConv01(kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO dHDHousIndeminityConv01IO);

	/**
	 * HD_계약_지체보상금_자료올리기 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 전채건수조회", description = "HD_계약_지체보상금_자료올리기 전채건수조회")
	java.lang.Integer selectCountHdHousIndeminityConv01(kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO dHDHousIndeminityConv01IO);

	/**
	 * HD_계약_지체보상금_자료올리기 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 목록조회", description = "HD_계약_지체보상금_자료올리기 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO> selectListHdHousIndeminityConv01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_지체보상금_자료올리기 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 수정", description = "HD_계약_지체보상금_자료올리기 수정")
	int updateHdHousIndeminityConv01(kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO dHDHousIndeminityConv01IO);

	/**
	 * HD_계약_지체보상금_자료올리기 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 병합", description = "HD_계약_지체보상금_자료올리기 병합")
	int mergeHdHousIndeminityConv01(kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO dHDHousIndeminityConv01IO);

	/**
	 * HD_계약_지체보상금_자료올리기 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; icheDate=; delayIndeminity=; convYn=; 
	 */
	@BxmCategory(logicalName = "HD_계약_지체보상금_자료올리기 삭제", description = "HD_계약_지체보상금_자료올리기 삭제")
	int deleteHdHousIndeminityConv01(kait.hd.hous.onl.dao.dto.DHDHousIndeminityConv01IO dHDHousIndeminityConv01IO);


}
