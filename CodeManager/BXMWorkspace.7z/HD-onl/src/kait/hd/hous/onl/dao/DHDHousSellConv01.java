/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSellConv01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_HOUS_SELL_CONV", description = "HD_HOUS_SELL_CONV")
public interface DHDHousSellConv01
{
	/**
	 * HD_HOUS_SELL_CONV 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; bseq=; custCode=; seq=; changetag=; contractdate=; lastchangedate=; changedate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_SELL_CONV 등록", description = "HD_HOUS_SELL_CONV 등록")
	int insertHdHousSellConv01(kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO dHDHousSellConv01IO);

	/**
	 * HD_HOUS_SELL_CONV 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; bseq=; custCode=; seq=; changetag=; contractdate=; lastchangedate=; changedate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_SELL_CONV 단건조회", description = "HD_HOUS_SELL_CONV 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO selectHdHousSellConv01(kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO dHDHousSellConv01IO);

	/**
	 * HD_HOUS_SELL_CONV 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; bseq=; custCode=; seq=; changetag=; contractdate=; lastchangedate=; changedate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_SELL_CONV 전채건수조회", description = "HD_HOUS_SELL_CONV 전채건수조회")
	java.lang.Integer selectCountHdHousSellConv01(kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO dHDHousSellConv01IO);

	/**
	 * HD_HOUS_SELL_CONV 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; bseq=; custCode=; seq=; changetag=; contractdate=; lastchangedate=; changedate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_SELL_CONV 목록조회", description = "HD_HOUS_SELL_CONV 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO> selectListHdHousSellConv01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_HOUS_SELL_CONV 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; bseq=; custCode=; seq=; changetag=; contractdate=; lastchangedate=; changedate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_SELL_CONV 수정", description = "HD_HOUS_SELL_CONV 수정")
	int updateHdHousSellConv01(kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO dHDHousSellConv01IO);

	/**
	 * HD_HOUS_SELL_CONV 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; bseq=; custCode=; seq=; changetag=; contractdate=; lastchangedate=; changedate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_SELL_CONV 삭제", description = "HD_HOUS_SELL_CONV 삭제")
	int deleteHdHousSellConv01(kait.hd.hous.onl.dao.dto.DHDHousSellConv01IO dHDHousSellConv01IO);


}
