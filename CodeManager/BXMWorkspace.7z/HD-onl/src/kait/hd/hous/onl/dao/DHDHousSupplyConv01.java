/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSupplyConv01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드", description = "HD_기본_세대별공급내역_업로드")
public interface DHDHousSupplyConv01
{
	/**
	 * HD_기본_세대별공급내역_업로드 등록
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 등록", description = "HD_기본_세대별공급내역_업로드 등록")
	int insertHdHousSupplyConv01(kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO dHDHousSupplyConv01IO);

	/**
	 * HD_기본_세대별공급내역_업로드 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 단건조회", description = "HD_기본_세대별공급내역_업로드 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO selectHdHousSupplyConv01(kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO dHDHousSupplyConv01IO);

	/**
	 * HD_기본_세대별공급내역_업로드 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 전채건수조회", description = "HD_기본_세대별공급내역_업로드 전채건수조회")
	java.lang.Integer selectCountHdHousSupplyConv01(kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO dHDHousSupplyConv01IO);

	/**
	 * HD_기본_세대별공급내역_업로드 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 목록조회", description = "HD_기본_세대별공급내역_업로드 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO> selectListHdHousSupplyConv01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별공급내역_업로드 수정
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 수정", description = "HD_기본_세대별공급내역_업로드 수정")
	int updateHdHousSupplyConv01(kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO dHDHousSupplyConv01IO);

	/**
	 * HD_기본_세대별공급내역_업로드 병합
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 병합", description = "HD_기본_세대별공급내역_업로드 병합")
	int mergeHdHousSupplyConv01(kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO dHDHousSupplyConv01IO);

	/**
	 * HD_기본_세대별공급내역_업로드 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; buildno=; houseno=; square=; type=; classJrw=; optioncode=; contractyesno=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별공급내역_업로드 삭제", description = "HD_기본_세대별공급내역_업로드 삭제")
	int deleteHdHousSupplyConv01(kait.hd.hous.onl.dao.dto.DHDHousSupplyConv01IO dHDHousSupplyConv01IO);


}
