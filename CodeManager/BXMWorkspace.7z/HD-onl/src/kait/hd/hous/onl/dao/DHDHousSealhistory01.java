/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSealhistory01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_계약서출력이력", description = "HD_계약_계약서출력이력")
public interface DHDHousSealhistory01
{
	/**
	 * HD_계약_계약서출력이력 등록
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 등록", description = "HD_계약_계약서출력이력 등록")
	int insertHdHousSealhistory01(kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO dHDHousSealhistory01IO);

	/**
	 * HD_계약_계약서출력이력 단건조회
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 단건조회", description = "HD_계약_계약서출력이력 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO selectHdHousSealhistory01(kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO dHDHousSealhistory01IO);

	/**
	 * HD_계약_계약서출력이력 전채건수조회
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 전채건수조회", description = "HD_계약_계약서출력이력 전채건수조회")
	java.lang.Integer selectCountHdHousSealhistory01(kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO dHDHousSealhistory01IO);

	/**
	 * HD_계약_계약서출력이력 목록조회
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 목록조회", description = "HD_계약_계약서출력이력 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO> selectListHdHousSealhistory01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_계약서출력이력 수정
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 수정", description = "HD_계약_계약서출력이력 수정")
	int updateHdHousSealhistory01(kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO dHDHousSealhistory01IO);

	/**
	 * HD_계약_계약서출력이력 병합
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 병합", description = "HD_계약_계약서출력이력 병합")
	int mergeHdHousSealhistory01(kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO dHDHousSealhistory01IO);

	/**
	 * HD_계약_계약서출력이력 삭제
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; printDate=; sealtype=; printDutyId=; printIp=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서출력이력 삭제", description = "HD_계약_계약서출력이력 삭제")
	int deleteHdHousSealhistory01(kait.hd.hous.onl.dao.dto.DHDHousSealhistory01IO dHDHousSealhistory01IO);


}
