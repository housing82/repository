/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousDiskTemp01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_디스켓저장", description = "HD_계약_디스켓저장")
public interface DHDHousDiskTemp01
{
	/**
	 * HD_계약_디스켓저장 등록
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 등록", description = "HD_계약_디스켓저장 등록")
	int insertHdHousDiskTemp01(kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO dHDHousDiskTemp01IO);

	/**
	 * HD_계약_디스켓저장 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 단건조회", description = "HD_계약_디스켓저장 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO selectHdHousDiskTemp01(kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO dHDHousDiskTemp01IO);

	/**
	 * HD_계약_디스켓저장 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 전채건수조회", description = "HD_계약_디스켓저장 전채건수조회")
	java.lang.Integer selectCountHdHousDiskTemp01(kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO dHDHousDiskTemp01IO);

	/**
	 * HD_계약_디스켓저장 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 목록조회", description = "HD_계약_디스켓저장 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO> selectListHdHousDiskTemp01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_디스켓저장 수정
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 수정", description = "HD_계약_디스켓저장 수정")
	int updateHdHousDiskTemp01(kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO dHDHousDiskTemp01IO);

	/**
	 * HD_계약_디스켓저장 병합
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 병합", description = "HD_계약_디스켓저장 병합")
	int mergeHdHousDiskTemp01(kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO dHDHousDiskTemp01IO);

	/**
	 * HD_계약_디스켓저장 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; data1=; data2=; 
	 */
	@BxmCategory(logicalName = "HD_계약_디스켓저장 삭제", description = "HD_계약_디스켓저장 삭제")
	int deleteHdHousDiskTemp01(kait.hd.hous.onl.dao.dto.DHDHousDiskTemp01IO dHDHousDiskTemp01IO);


}
