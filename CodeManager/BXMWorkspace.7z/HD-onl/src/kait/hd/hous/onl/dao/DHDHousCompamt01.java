/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousCompamt01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_국민주택기금", description = "HD_계약_국민주택기금")
public interface DHDHousCompamt01
{
	/**
	 * HD_계약_국민주택기금 등록
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 등록", description = "HD_계약_국민주택기금 등록")
	int insertHdHousCompamt01(kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO dHDHousCompamt01IO);

	/**
	 * HD_계약_국민주택기금 단건조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 단건조회", description = "HD_계약_국민주택기금 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO selectHdHousCompamt01(kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO dHDHousCompamt01IO);

	/**
	 * HD_계약_국민주택기금 전채건수조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 전채건수조회", description = "HD_계약_국민주택기금 전채건수조회")
	java.lang.Integer selectCountHdHousCompamt01(kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO dHDHousCompamt01IO);

	/**
	 * HD_계약_국민주택기금 목록조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 목록조회", description = "HD_계약_국민주택기금 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO> selectListHdHousCompamt01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_국민주택기금 수정
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 수정", description = "HD_계약_국민주택기금 수정")
	int updateHdHousCompamt01(kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO dHDHousCompamt01IO);

	/**
	 * HD_계약_국민주택기금 병합
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 병합", description = "HD_계약_국민주택기금 병합")
	int mergeHdHousCompamt01(kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO dHDHousCompamt01IO);

	/**
	 * HD_계약_국민주택기금 삭제
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; icheDate=; icheAmt=; icheYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_국민주택기금 삭제", description = "HD_계약_국민주택기금 삭제")
	int deleteHdHousCompamt01(kait.hd.hous.onl.dao.dto.DHDHousCompamt01IO dHDHousCompamt01IO);


}
