/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousLendTxtup01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기", description = "HD_계약_대출약정_자료올리기")
public interface DHDHousLendTxtup01
{
	/**
	 * HD_계약_대출약정_자료올리기 등록
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 등록", description = "HD_계약_대출약정_자료올리기 등록")
	int insertHdHousLendTxtup01(kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO dHDHousLendTxtup01IO);

	/**
	 * HD_계약_대출약정_자료올리기 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 단건조회", description = "HD_계약_대출약정_자료올리기 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO selectHdHousLendTxtup01(kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO dHDHousLendTxtup01IO);

	/**
	 * HD_계약_대출약정_자료올리기 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 전채건수조회", description = "HD_계약_대출약정_자료올리기 전채건수조회")
	java.lang.Integer selectCountHdHousLendTxtup01(kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO dHDHousLendTxtup01IO);

	/**
	 * HD_계약_대출약정_자료올리기 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 목록조회", description = "HD_계약_대출약정_자료올리기 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO> selectListHdHousLendTxtup01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_대출약정_자료올리기 수정
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 수정", description = "HD_계약_대출약정_자료올리기 수정")
	int updateHdHousLendTxtup01(kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO dHDHousLendTxtup01IO);

	/**
	 * HD_계약_대출약정_자료올리기 병합
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 병합", description = "HD_계약_대출약정_자료올리기 병합")
	int mergeHdHousLendTxtup01(kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO dHDHousLendTxtup01IO);

	/**
	 * HD_계약_대출약정_자료올리기 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; custCode=; buildno=; houseno=; bankCode=; agreedate=; agreeamt=; lendYn=; errMessage=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_대출약정_자료올리기 삭제", description = "HD_계약_대출약정_자료올리기 삭제")
	int deleteHdHousLendTxtup01(kait.hd.hous.onl.dao.dto.DHDHousLendTxtup01IO dHDHousLendTxtup01IO);


}
