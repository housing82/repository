/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousSelldetailLog01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_세대별약정사항_LOG", description = "HD_세대별약정사항_LOG")
public interface DHDHousSelldetailLog01
{
	/**
	 * HD_세대별약정사항_LOG 등록
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 등록", description = "HD_세대별약정사항_LOG 등록")
	int insertHdHousSelldetailLog01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO dHDHousSelldetailLog01IO);

	/**
	 * HD_세대별약정사항_LOG 단건조회
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 단건조회", description = "HD_세대별약정사항_LOG 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO selectHdHousSelldetailLog01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO dHDHousSelldetailLog01IO);

	/**
	 * HD_세대별약정사항_LOG 전채건수조회
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 전채건수조회", description = "HD_세대별약정사항_LOG 전채건수조회")
	java.lang.Integer selectCountHdHousSelldetailLog01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO dHDHousSelldetailLog01IO);

	/**
	 * HD_세대별약정사항_LOG 목록조회
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 목록조회", description = "HD_세대별약정사항_LOG 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO> selectListHdHousSelldetailLog01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_세대별약정사항_LOG 수정
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 수정", description = "HD_세대별약정사항_LOG 수정")
	int updateHdHousSelldetailLog01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO dHDHousSelldetailLog01IO);

	/**
	 * HD_세대별약정사항_LOG 병합
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 병합", description = "HD_세대별약정사항_LOG 병합")
	int mergeHdHousSelldetailLog01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO dHDHousSelldetailLog01IO);

	/**
	 * HD_세대별약정사항_LOG 삭제
	 * @TestValues 	custCode=; seq=; counts=; writetag=; writetime=; writeseq=; deptCode=; housetag=; buildno=; houseno=; agreedate=; landamt=; buildamt=; vatamt=; bunamt=; dcYn=; acYn=; perpecttag=; receiptamt=; distributeRate=; slipdt=; slipseq=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_세대별약정사항_LOG 삭제", description = "HD_세대별약정사항_LOG 삭제")
	int deleteHdHousSelldetailLog01(kait.hd.hous.onl.dao.dto.DHDHousSelldetailLog01IO dHDHousSelldetailLog01IO);


}
