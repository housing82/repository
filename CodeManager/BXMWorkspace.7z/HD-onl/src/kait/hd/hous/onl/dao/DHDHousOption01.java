/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousOption01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_HOUS_OPTION", description = "HD_HOUS_OPTION")
public interface DHDHousOption01
{
	/**
	 * HD_HOUS_OPTION 등록
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 등록", description = "HD_HOUS_OPTION 등록")
	int insertHdHousOption01(kait.hd.hous.onl.dao.dto.DHDHousOption01IO dHDHousOption01IO);

	/**
	 * HD_HOUS_OPTION 단건조회
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 단건조회", description = "HD_HOUS_OPTION 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousOption01IO selectHdHousOption01(kait.hd.hous.onl.dao.dto.DHDHousOption01IO dHDHousOption01IO);

	/**
	 * HD_HOUS_OPTION 전채건수조회
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 전채건수조회", description = "HD_HOUS_OPTION 전채건수조회")
	java.lang.Integer selectCountHdHousOption01(kait.hd.hous.onl.dao.dto.DHDHousOption01IO dHDHousOption01IO);

	/**
	 * HD_HOUS_OPTION 목록조회
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 목록조회", description = "HD_HOUS_OPTION 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousOption01IO> selectListHdHousOption01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousOption01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_HOUS_OPTION 수정
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 수정", description = "HD_HOUS_OPTION 수정")
	int updateHdHousOption01(kait.hd.hous.onl.dao.dto.DHDHousOption01IO dHDHousOption01IO);

	/**
	 * HD_HOUS_OPTION 병합
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 병합", description = "HD_HOUS_OPTION 병합")
	int mergeHdHousOption01(kait.hd.hous.onl.dao.dto.DHDHousOption01IO dHDHousOption01IO);

	/**
	 * HD_HOUS_OPTION 삭제
	 * @TestValues 	custCode=; seq=; optseq=; deptCode=; housetag=; buildno=; houseno=; optionSup=; optionVat=; contDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_HOUS_OPTION 삭제", description = "HD_HOUS_OPTION 삭제")
	int deleteHdHousOption01(kait.hd.hous.onl.dao.dto.DHDHousOption01IO dHDHousOption01IO);


}
