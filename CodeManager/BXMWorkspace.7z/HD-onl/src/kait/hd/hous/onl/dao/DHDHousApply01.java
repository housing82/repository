/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousApply01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_계약서승인이력", description = "HD_계약_계약서승인이력")
public interface DHDHousApply01
{
	/**
	 * HD_계약_계약서승인이력 등록
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 등록", description = "HD_계약_계약서승인이력 등록")
	int insertHdHousApply01(kait.hd.hous.onl.dao.dto.DHDHousApply01IO dHDHousApply01IO);

	/**
	 * HD_계약_계약서승인이력 단건조회
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 단건조회", description = "HD_계약_계약서승인이력 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousApply01IO selectHdHousApply01(kait.hd.hous.onl.dao.dto.DHDHousApply01IO dHDHousApply01IO);

	/**
	 * HD_계약_계약서승인이력 전채건수조회
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 전채건수조회", description = "HD_계약_계약서승인이력 전채건수조회")
	java.lang.Integer selectCountHdHousApply01(kait.hd.hous.onl.dao.dto.DHDHousApply01IO dHDHousApply01IO);

	/**
	 * HD_계약_계약서승인이력 목록조회
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 목록조회", description = "HD_계약_계약서승인이력 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousApply01IO> selectListHdHousApply01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousApply01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_계약서승인이력 수정
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 수정", description = "HD_계약_계약서승인이력 수정")
	int updateHdHousApply01(kait.hd.hous.onl.dao.dto.DHDHousApply01IO dHDHousApply01IO);

	/**
	 * HD_계약_계약서승인이력 병합
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 병합", description = "HD_계약_계약서승인이력 병합")
	int mergeHdHousApply01(kait.hd.hous.onl.dao.dto.DHDHousApply01IO dHDHousApply01IO);

	/**
	 * HD_계약_계약서승인이력 삭제
	 * @TestValues 	custCode=; seq=; sn=; deptCode=; housetag=; buildno=; houseno=; applyYn=; applyEmpno=; applyDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_계약서승인이력 삭제", description = "HD_계약_계약서승인이력 삭제")
	int deleteHdHousApply01(kait.hd.hous.onl.dao.dto.DHDHousApply01IO dHDHousApply01IO);


}
