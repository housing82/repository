/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousJese01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_재세공과금", description = "HD_기본_재세공과금")
public interface DHDHousJese01
{
	/**
	 * HD_기본_재세공과금 등록
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 등록", description = "HD_기본_재세공과금 등록")
	int insertHdHousJese01(kait.hd.hous.onl.dao.dto.DHDHousJese01IO dHDHousJese01IO);

	/**
	 * HD_기본_재세공과금 단건조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 단건조회", description = "HD_기본_재세공과금 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousJese01IO selectHdHousJese01(kait.hd.hous.onl.dao.dto.DHDHousJese01IO dHDHousJese01IO);

	/**
	 * HD_기본_재세공과금 전채건수조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 전채건수조회", description = "HD_기본_재세공과금 전채건수조회")
	java.lang.Integer selectCountHdHousJese01(kait.hd.hous.onl.dao.dto.DHDHousJese01IO dHDHousJese01IO);

	/**
	 * HD_기본_재세공과금 목록조회
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 목록조회", description = "HD_기본_재세공과금 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousJese01IO> selectListHdHousJese01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousJese01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_재세공과금 수정
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 수정", description = "HD_기본_재세공과금 수정")
	int updateHdHousJese01(kait.hd.hous.onl.dao.dto.DHDHousJese01IO dHDHousJese01IO);

	/**
	 * HD_기본_재세공과금 병합
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 병합", description = "HD_기본_재세공과금 병합")
	int mergeHdHousJese01(kait.hd.hous.onl.dao.dto.DHDHousJese01IO dHDHousJese01IO);

	/**
	 * HD_기본_재세공과금 삭제
	 * @TestValues 	custCode=; seq=; deptCode=; housetag=; deposit1=; indate1=; inamt1=; deposit2=; indate2=; inamt2=; deposit3=; indate3=; inamt3=; jungsanBdate=; jungsanSdate=; sisulBdate=; sisulSdate=; dungBdate=; dungSdate=; boBdate=; boSdate=; bubmuBuild=; bubmuLand=; etcSdate=; etcAdate=; etcIdate=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_재세공과금 삭제", description = "HD_기본_재세공과금 삭제")
	int deleteHdHousJese01(kait.hd.hous.onl.dao.dto.DHDHousJese01IO dHDHousJese01IO);


}
