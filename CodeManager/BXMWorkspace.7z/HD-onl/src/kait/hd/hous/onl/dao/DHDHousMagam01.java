/**
 * Generated Code Skeleton 2017-06-13 18:26:37 
 */
package kait.hd.hous.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/hous/onl/daoDHDHousMagam01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_현장마감", description = "HD_분양_현장마감")
public interface DHDHousMagam01
{
	/**
	 * HD_분양_현장마감 등록
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 등록", description = "HD_분양_현장마감 등록")
	int insertHdHousMagam01(kait.hd.hous.onl.dao.dto.DHDHousMagam01IO dHDHousMagam01IO);

	/**
	 * HD_분양_현장마감 단건조회
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 단건조회", description = "HD_분양_현장마감 단건조회")
	kait.hd.hous.onl.dao.dto.DHDHousMagam01IO selectHdHousMagam01(kait.hd.hous.onl.dao.dto.DHDHousMagam01IO dHDHousMagam01IO);

	/**
	 * HD_분양_현장마감 전채건수조회
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 전채건수조회", description = "HD_분양_현장마감 전채건수조회")
	java.lang.Integer selectCountHdHousMagam01(kait.hd.hous.onl.dao.dto.DHDHousMagam01IO dHDHousMagam01IO);

	/**
	 * HD_분양_현장마감 목록조회
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 목록조회", description = "HD_분양_현장마감 목록조회")
	java.util.List<kait.hd.hous.onl.dao.dto.DHDHousMagam01IO> selectListHdHousMagam01(
			@Param("in") kait.hd.hous.onl.dao.dto.DHDHousMagam01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_현장마감 수정
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 수정", description = "HD_분양_현장마감 수정")
	int updateHdHousMagam01(kait.hd.hous.onl.dao.dto.DHDHousMagam01IO dHDHousMagam01IO);

	/**
	 * HD_분양_현장마감 병합
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 병합", description = "HD_분양_현장마감 병합")
	int mergeHdHousMagam01(kait.hd.hous.onl.dao.dto.DHDHousMagam01IO dHDHousMagam01IO);

	/**
	 * HD_분양_현장마감 삭제
	 * @TestValues 	deptCode=; housetag=; magamdate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_현장마감 삭제", description = "HD_분양_현장마감 삭제")
	int deleteHdHousMagam01(kait.hd.hous.onl.dao.dto.DHDHousMagam01IO dHDHousMagam01IO);


}
