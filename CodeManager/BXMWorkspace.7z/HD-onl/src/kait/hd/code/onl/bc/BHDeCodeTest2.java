package kait.hd.code.onl.bc;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bxm.common.annotaion.BxmCategory;
import bxm.container.annotation.BxmBean;
import bxm.dft.app.KaitApplicationException;
import bxm.dft.context.DefaultApplicationContext;

import kait.hd.acmast.onl.dao.DHDAcmastE01;
import kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO;
import kait.hd.code.onl.bc.dto.BHDeCodeTest201In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest201Out;
import kait.hd.code.onl.bc.dto.BHDeCodeTest202In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest202Out;
import kait.hd.code.onl.bc.dto.BHDeCodeTest203In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest203Out;
import kait.hd.code.onl.dao.DHDCodeAcnt01;
import kait.hd.code.onl.dao.DHDCodeAgency01;
import kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO;
import kait.hd.code.onl.dao.dto.DHDCodeAgency01IO;


/**
 * Generated Code Skeleton 2017-06-23 18:03:49
 * 
 * <b>History :</b>
 * <pre>
 * 
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           CodeSkeleton       			2017-06-23 18:03:49          신규작성
 * </pre>
 * 
 * @since 2017-06-23 18:03:49
 * @version 3.0.0
 * @author Developer
 * @see "BXM Bean"
 */
@BxmBean
@BxmCategory(type = "BC", logicalName = "분양계정관리22", description = "분양계정관리22")
public class BHDeCodeTest2 {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private DHDAcmastE01 dHDAcmastE01;
	private DHDCodeAcnt01 dHDCodeAcnt01;
	private DHDCodeAgency01 dHDCodeAgency01;

	
	@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")
	public BHDeCodeTest201Out searchFieldSelect(BHDeCodeTest201In bHDeCodeTest201In) throws KaitApplicationException {
		logger.debug("[START-BC] searchFieldSelect input:\n{}", bHDeCodeTest201In);

		if(bHDeCodeTest201In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDAcmastE01 = DefaultApplicationContext.getBean(dHDAcmastE01, DHDAcmastE01.class);
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);
		dHDCodeAgency01 = DefaultApplicationContext.getBean(dHDCodeAgency01, DHDCodeAgency01.class);

		/** ### Output Variable ### */
		BHDeCodeTest201Out out = null;

		/** ### Callee Input Setting ### */
		DHDAcmastE01IO inDHDAcmastE01IO = bHDeCodeTest201In.getInDHDAcmastE01IO();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeTest201In.getInDHDCodeAcnt01IO();
		DHDCodeAgency01IO inDHDCodeAgency01IO = bHDeCodeTest201In.getInDHDCodeAgency01IO();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO01 = bHDeCodeTest201In.getInDHDCodeAcnt01IO01();
		int inPageNum = 0;
		int inPageCount = 0;


		/** ### Execute Callee ### */
		int outInsertHdAcmastE01 = dHDAcmastE01.insertHdAcmastE01(inDHDAcmastE01IO);
		DHDCodeAcnt01IO outDHDCodeAcnt01IO = dHDCodeAcnt01.selectHdCodeAcnt01(inDHDCodeAcnt01IO);
		Integer outSelectCountHdCodeAgency01 = dHDCodeAgency01.selectCountHdCodeAgency01(inDHDCodeAgency01IO);
		List<DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List = dHDCodeAcnt01.selectListHdCodeAcnt01(inDHDCodeAcnt01IO01, inPageNum, inPageCount);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeTest201Out();
		out.setOutInsertHdAcmastE01(outInsertHdAcmastE01);
		out.setOutDHDCodeAcnt01IO(outDHDCodeAcnt01IO);
		out.setOutSelectCountHdCodeAgency01(outSelectCountHdCodeAgency01);
		out.setOutSelectListHdCodeAcnt01List(outSelectListHdCodeAcnt01List);


		logger.debug("[END-BC] searchFieldSelect output:\n{}", out);
		return out;
	}


	@BxmCategory(logicalName = "분양계정 조회", description = "분양계정 조회")
	public BHDeCodeTest202Out getCodeAccount(BHDeCodeTest202In bHDeCodeTest202In) throws KaitApplicationException {
		logger.debug("[START-BC] getCodeAccount input:\n{}", bHDeCodeTest202In);

		if(bHDeCodeTest202In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);

		/** ### Output Variable ### */
		BHDeCodeTest202Out out = null;

		/** ### Callee Input Setting ### */
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeTest202In.getInDHDCodeAcnt01IO();

		/** ### Execute Callee ### */
		int outInsertHdCodeAcnt01 = dHDCodeAcnt01.insertHdCodeAcnt01(inDHDCodeAcnt01IO);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeTest202Out();
		out.setOutInsertHdCodeAcnt01(outInsertHdCodeAcnt01);


		logger.debug("[END-BC] getCodeAccount output:\n{}", out);
		return out;
	}


	@BxmCategory(logicalName = "분양계정 삭제", description = "분양계정 삭제")
	public BHDeCodeTest203Out removeCodeAccount(BHDeCodeTest203In bHDeCodeTest203In) throws KaitApplicationException {
		logger.debug("[START-BC] removeCodeAccount input:\n{}", bHDeCodeTest203In);

		if(bHDeCodeTest203In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDCodeAgency01 = DefaultApplicationContext.getBean(dHDCodeAgency01, DHDCodeAgency01.class);

		/** ### Output Variable ### */
		BHDeCodeTest203Out out = null;

		/** ### Callee Input Setting ### */
		DHDCodeAgency01IO inDHDCodeAgency01IO = bHDeCodeTest203In.getInDHDCodeAgency01IO();

		/** ### Execute Callee ### */
		int outDeleteHdCodeAgency01 = dHDCodeAgency01.deleteHdCodeAgency01(inDHDCodeAgency01IO);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeTest203Out();
		out.setOutDeleteHdCodeAgency01(outDeleteHdCodeAgency01);


		logger.debug("[END-BC] removeCodeAccount output:\n{}", out);
		return out;
	}



}	
