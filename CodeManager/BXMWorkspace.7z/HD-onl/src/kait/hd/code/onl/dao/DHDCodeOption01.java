/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeOption01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_CODE_OPTION", description = "HD_CODE_OPTION")
public interface DHDCodeOption01
{
	/**
	 * HD_CODE_OPTION 등록
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 등록", description = "HD_CODE_OPTION 등록")
	int insertHdCodeOption01(kait.hd.code.onl.dao.dto.DHDCodeOption01IO dHDCodeOption01IO);

	/**
	 * HD_CODE_OPTION 단건조회
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 단건조회", description = "HD_CODE_OPTION 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeOption01IO selectHdCodeOption01(kait.hd.code.onl.dao.dto.DHDCodeOption01IO dHDCodeOption01IO);

	/**
	 * HD_CODE_OPTION 전채건수조회
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 전채건수조회", description = "HD_CODE_OPTION 전채건수조회")
	java.lang.Integer selectCountHdCodeOption01(kait.hd.code.onl.dao.dto.DHDCodeOption01IO dHDCodeOption01IO);

	/**
	 * HD_CODE_OPTION 목록조회
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 목록조회", description = "HD_CODE_OPTION 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeOption01IO> selectListHdCodeOption01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeOption01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_CODE_OPTION 수정
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 수정", description = "HD_CODE_OPTION 수정")
	int updateHdCodeOption01(kait.hd.code.onl.dao.dto.DHDCodeOption01IO dHDCodeOption01IO);

	/**
	 * HD_CODE_OPTION 병합
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 병합", description = "HD_CODE_OPTION 병합")
	int mergeHdCodeOption01(kait.hd.code.onl.dao.dto.DHDCodeOption01IO dHDCodeOption01IO);

	/**
	 * HD_CODE_OPTION 삭제
	 * @TestValues 	deptCode=; housetag=; optseq=; square=; type=; optionName=; optionSup=; optionVat=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtseq=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_OPTION 삭제", description = "HD_CODE_OPTION 삭제")
	int deleteHdCodeOption01(kait.hd.code.onl.dao.dto.DHDCodeOption01IO dHDCodeOption01IO);


}
