package kait.hd.code.onl.sc;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bxm.common.annotaion.BxmCategory;
import bxm.container.annotation.BxmService;
import bxm.container.annotation.BxmServiceOperation;
import bxm.dft.app.KaitApplicationException;
import bxm.dft.context.DefaultApplicationContext;
import bxm.kait.util.CommonHdrUtils;

import kait.hd.code.onl.bc.BHDeCodeTest2;
import kait.hd.code.onl.sc.dto.SHDCODE00201Out;
import kait.hd.code.onl.sc.dto.SHDCODE00201In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest201In;
import kait.hd.code.onl.sc.dto.SHDCODE00201Sub01;
import kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO;
import kait.hd.code.onl.sc.dto.SHDCODE00201Sub02;
import kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO;
import kait.hd.code.onl.sc.dto.SHDCODE00201Sub03;
import kait.hd.code.onl.dao.dto.DHDCodeAgency01IO;
import kait.hd.code.onl.sc.dto.SHDCODE00201Sub04;
import kait.hd.code.onl.bc.dto.BHDeCodeTest201Out;
import kait.hd.code.onl.sc.dto.BHDeCodeTest201Out;
import kait.hd.code.onl.sc.dto.SHDCODE00202Out;
import kait.hd.code.onl.sc.dto.SHDCODE00202In;
import kait.hd.code.onl.sc.dto.SHDCODE00203Out;
import kait.hd.code.onl.sc.dto.SHDCODE00203In;


/**
 * Generated Code Skeleton 2017-06-23 18:42:49
 * 
 * <b>History :</b>
 * <pre>
 * 
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           CodeSkeleton       			2017-06-23 18:42:49          신규작성
 * </pre>
 * 
 * @since 2017-06-23 18:42:49
 * @version 3.0.0
 * @author Developer
 * @see "BXM Service"
 */
@BxmService("SHDCODE002")
@BxmCategory(type = "SC", logicalName = "분양계정관리22", description = "분양계정관리22")
public class SHDCODE002 {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private BHDeCodeTest2 bHDeCodeTest2;


	@BxmServiceOperation("SHDCODE00201")
	@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")
	public SHDCODE00201Out searchFieldDetail(SHDCODE00201In sHDCODE00201In) throws KaitApplicationException {
		logger.debug("[START-SC] searchFieldDetail input:\n{}", sHDCODE00201In);
		
		/** ### Validate Parameter ### */

		/** ### Bean Initialize ### */
		bHDeCodeTest2 = DefaultApplicationContext.getBean(bHDeCodeTest2, BHDeCodeTest2.class);

		/** ### Output Variable ### */
		SHDCODE00201Out out = null;
		
		/** ### Set Bean Input Value  ### */
		BHDeCodeTest201In inBHDeCodeTest201In = new BHDeCodeTest201In();
		SHDCODE00201Sub01 inSHDCODE00201Sub01 = sHDCODE00201In.getInSHDCODE00201Sub01();
		DHDAcmastE01IO inDHDAcmastE01IO = new DHDAcmastE01IO();

		if( inSHDCODE00201Sub01 != null ) {
			inDHDAcmastE01IO.setJcode(inSHDCODE00201Sub01.getJcode());
			inDHDAcmastE01IO.setJacntcode(inSHDCODE00201Sub01.getJacntcode());
			inDHDAcmastE01IO.setJacntname(inSHDCODE00201Sub01.getJacntname());
			inDHDAcmastE01IO.setInputDutyId(inSHDCODE00201Sub01.getInputDutyId());
			inDHDAcmastE01IO.setInputDate(inSHDCODE00201Sub01.getInputDate());
			inDHDAcmastE01IO.setChgDutyId(inSHDCODE00201Sub01.getChgDutyId());
			inDHDAcmastE01IO.setChgDate(inSHDCODE00201Sub01.getChgDate());
		}
		inBHDeCodeTest201In.setInDHDAcmastE01IO(inDHDAcmastE01IO);

		SHDCODE00201Sub02 inSHDCODE00201Sub02 = sHDCODE00201In.getInSHDCODE00201Sub02();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = new DHDCodeAcnt01IO();

		if( inSHDCODE00201Sub02 != null ) {
			inDHDCodeAcnt01IO.setDeptCode(inSHDCODE00201Sub02.getDeptCode());
			inDHDCodeAcnt01IO.setJcode(inSHDCODE00201Sub02.getJcode());
			inDHDCodeAcnt01IO.setJacntcode(inSHDCODE00201Sub02.getJacntcode());
			inDHDCodeAcnt01IO.setJacntname(inSHDCODE00201Sub02.getJacntname());
			inDHDCodeAcnt01IO.setDetailcode(inSHDCODE00201Sub02.getDetailcode());
			inDHDCodeAcnt01IO.setInputDutyId(inSHDCODE00201Sub02.getInputDutyId());
			inDHDCodeAcnt01IO.setInputDate(inSHDCODE00201Sub02.getInputDate());
			inDHDCodeAcnt01IO.setChgDutyId(inSHDCODE00201Sub02.getChgDutyId());
			inDHDCodeAcnt01IO.setChgDate(inSHDCODE00201Sub02.getChgDate());
		}
		inBHDeCodeTest201In.setInDHDCodeAcnt01IO(inDHDCodeAcnt01IO);

		SHDCODE00201Sub03 inSHDCODE00201Sub03 = sHDCODE00201In.getInSHDCODE00201Sub03();
		DHDCodeAgency01IO inDHDCodeAgency01IO = new DHDCodeAgency01IO();

		if( inSHDCODE00201Sub03 != null ) {
			inDHDCodeAgency01IO.setDeptCode(inSHDCODE00201Sub03.getDeptCode());
			inDHDCodeAgency01IO.setHousetag(inSHDCODE00201Sub03.getHousetag());
			inDHDCodeAgency01IO.setAgencyCode(inSHDCODE00201Sub03.getAgencyCode());
			inDHDCodeAgency01IO.setAgencyName(inSHDCODE00201Sub03.getAgencyName());
			inDHDCodeAgency01IO.setRemark(inSHDCODE00201Sub03.getRemark());
			inDHDCodeAgency01IO.setInputDutyId(inSHDCODE00201Sub03.getInputDutyId());
			inDHDCodeAgency01IO.setInputDate(inSHDCODE00201Sub03.getInputDate());
			inDHDCodeAgency01IO.setChgDutyId(inSHDCODE00201Sub03.getChgDutyId());
			inDHDCodeAgency01IO.setChgDate(inSHDCODE00201Sub03.getChgDate());
		}
		inBHDeCodeTest201In.setInDHDCodeAgency01IO(inDHDCodeAgency01IO);

		SHDCODE00201Sub04 inSHDCODE00201Sub04 = sHDCODE00201In.getInSHDCODE00201Sub04();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO01 = new DHDCodeAcnt01IO();

		if( inSHDCODE00201Sub04 != null ) {
			inDHDCodeAcnt01IO01.setDeptCode(inSHDCODE00201Sub04.getDeptCode());
			inDHDCodeAcnt01IO01.setJcode(inSHDCODE00201Sub04.getJcode());
			inDHDCodeAcnt01IO01.setJacntcode(inSHDCODE00201Sub04.getJacntcode());
			inDHDCodeAcnt01IO01.setJacntname(inSHDCODE00201Sub04.getJacntname());
			inDHDCodeAcnt01IO01.setDetailcode(inSHDCODE00201Sub04.getDetailcode());
			inDHDCodeAcnt01IO01.setInputDutyId(inSHDCODE00201Sub04.getInputDutyId());
			inDHDCodeAcnt01IO01.setInputDate(inSHDCODE00201Sub04.getInputDate());
			inDHDCodeAcnt01IO01.setChgDutyId(inSHDCODE00201Sub04.getChgDutyId());
			inDHDCodeAcnt01IO01.setChgDate(inSHDCODE00201Sub04.getChgDate());
		}
		inBHDeCodeTest201In.setInDHDCodeAcnt01IO01(inDHDCodeAcnt01IO01);



		/** ### Execute Bean ### */
		BHDeCodeTest201Out outBHDeCodeTest201Out = bHDeCodeTest2.searchFieldSelect(inBHDeCodeTest201In);

		/** ### Set Output Value  ### */
		out = new SHDCODE00201Out();
	// [OUT-FIELD] size: 1
/**
 [OUT-FIELD] outBHDeCodeTest201Out: {type=D:/Developer/BXMWorkspace/HD-onl/src/kait/hd/code/onl/bc/dto/BHDeCodeTest201Out.omm, calleeAnnotations=[@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")], kind=omm}
calleeOutputType : kait.hd.code.onl.bc.dto.BHDeCodeTest201Out
Type: Integer, Name: outInsertHdAcmastE01, Length: 9, Description: HD_ACMAST_E 등록 결과, ArrayReference: null, ArrayReferenceType: null
Type: kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO, Name: outDHDCodeAcnt01IO, Length: 0, Description: HD_분양_전표_계정 ( HD_CODE_ACNT ), ArrayReference: null, ArrayReferenceType: null
Type: Integer, Name: outSelectCountHdCodeAgency01, Length: 9, Description: HD_코드-대행사 전채건수조회 결과, ArrayReference: null, ArrayReferenceType: null
Type: Integer, Name: outSelectListHdCodeAcnt01Cnt, Length: 9, Description: HD_분양_전표_계정 목록조회 결과 건수, ArrayReference: null, ArrayReferenceType: null
Type: kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO, Name: outSelectListHdCodeAcnt01List, Length: 0, Description: HD_분양_전표_계정 목록조회 결과, ArrayReference: outSelectListHdCodeAcnt01Cnt, ArrayReferenceType: null


*/
		/** ### Set [search] OkResultMessage Code ### */
		CommonHdrUtils.setOkResultMessage("");
		
		logger.debug("[END-SC] searchFieldDetail output:\n{}", out);
		return out;
	}


	@BxmServiceOperation("SHDCODE00202")
	@BxmCategory(logicalName = "분양계정 조회", description = "분양계정 조회")
	public SHDCODE00202Out getCodeAccount(SHDCODE00202In sHDCODE00202In) throws KaitApplicationException {
		logger.debug("[START-SC] getCodeAccount input:\n{}", sHDCODE00202In);
		
		/** ### Validate Parameter ### */

		/** ### Bean Initialize ### */

		/** ### Output Variable ### */
		SHDCODE00202Out out = null;
		
		/** ### Set Bean Input Value  ### */

		/** ### Execute Bean ### */

		/** ### Set Output Value  ### */
		out = new SHDCODE00202Out();
	// [OUT-FIELD] size: 0
/**

*/
		/** ### Set [get] OkResultMessage Code ### */
		CommonHdrUtils.setOkResultMessage("");
		
		logger.debug("[END-SC] getCodeAccount output:\n{}", out);
		return out;
	}


	@BxmServiceOperation("SHDCODE00203")
	@BxmCategory(logicalName = "분양계정 저장", description = "분양계정 저장")
	public SHDCODE00203Out saveCodeAccount(SHDCODE00203In sHDCODE00203In) throws KaitApplicationException {
		logger.debug("[START-SC] saveCodeAccount input:\n{}", sHDCODE00203In);
		
		/** ### Validate Parameter ### */

		/** ### Bean Initialize ### */

		/** ### Output Variable ### */
		SHDCODE00203Out out = null;
		
		/** ### Set Bean Input Value  ### */

		/** ### Execute Bean ### */

		/** ### Set Output Value  ### */
		out = new SHDCODE00203Out();
	// [OUT-FIELD] size: 0
/**

*/
		/** ### Set [save] OkResultMessage Code ### */
		CommonHdrUtils.setOkResultMessage("");
		
		logger.debug("[END-SC] saveCodeAccount output:\n{}", out);
		return out;
	}



}	
