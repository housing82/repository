/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeDeptHist01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_사업코드_이력", description = "HD_코드_사업코드_이력")
public interface DHDCodeDeptHist01
{
	/**
	 * HD_코드_사업코드_이력 등록
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 등록", description = "HD_코드_사업코드_이력 등록")
	int insertHdCodeDeptHist01(kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO dHDCodeDeptHist01IO);

	/**
	 * HD_코드_사업코드_이력 단건조회
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 단건조회", description = "HD_코드_사업코드_이력 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO selectHdCodeDeptHist01(kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO dHDCodeDeptHist01IO);

	/**
	 * HD_코드_사업코드_이력 전채건수조회
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 전채건수조회", description = "HD_코드_사업코드_이력 전채건수조회")
	java.lang.Integer selectCountHdCodeDeptHist01(kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO dHDCodeDeptHist01IO);

	/**
	 * HD_코드_사업코드_이력 목록조회
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 목록조회", description = "HD_코드_사업코드_이력 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO> selectListHdCodeDeptHist01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_사업코드_이력 수정
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 수정", description = "HD_코드_사업코드_이력 수정")
	int updateHdCodeDeptHist01(kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO dHDCodeDeptHist01IO);

	/**
	 * HD_코드_사업코드_이력 병합
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 병합", description = "HD_코드_사업코드_이력 병합")
	int mergeHdCodeDeptHist01(kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO dHDCodeDeptHist01IO);

	/**
	 * HD_코드_사업코드_이력 삭제
	 * @TestValues 	histDate=; deptCode=; deptName=; tel=; zip=; addr1=; addr2=; listtag=; jobtag=; companyCode=; amisDeptcode=; taxTag=; sihangVendor=; sihangName=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; sigongName=; sigongDepyo=; sigongCharge=; sigongTel=; modelZip=; modelAddr1=; modelAddr2=; modelTel=; deptTypeCode=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; smsName=; smsTel=; oldDeptcode=; triTag=; modtag=; zipOrg=; addr1Org=; addr2Org=; addrTag=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; modelZipOrg=; modelAddr1Org=; modelAddr2Org=; modelAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_사업코드_이력 삭제", description = "HD_코드_사업코드_이력 삭제")
	int deleteHdCodeDeptHist01(kait.hd.code.onl.dao.dto.DHDCodeDeptHist01IO dHDCodeDeptHist01IO);


}
