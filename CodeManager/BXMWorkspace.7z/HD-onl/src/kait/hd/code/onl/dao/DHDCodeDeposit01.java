/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeDeposit01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드-계좌번호", description = "HD_코드-계좌번호")
public interface DHDCodeDeposit01
{
	/**
	 * HD_코드-계좌번호 등록
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 등록", description = "HD_코드-계좌번호 등록")
	int insertHdCodeDeposit01(kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO dHDCodeDeposit01IO);

	/**
	 * HD_코드-계좌번호 단건조회
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 단건조회", description = "HD_코드-계좌번호 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO selectHdCodeDeposit01(kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO dHDCodeDeposit01IO);

	/**
	 * HD_코드-계좌번호 전채건수조회
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 전채건수조회", description = "HD_코드-계좌번호 전채건수조회")
	java.lang.Integer selectCountHdCodeDeposit01(kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO dHDCodeDeposit01IO);

	/**
	 * HD_코드-계좌번호 목록조회
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 목록조회", description = "HD_코드-계좌번호 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO> selectListHdCodeDeposit01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드-계좌번호 수정
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 수정", description = "HD_코드-계좌번호 수정")
	int updateHdCodeDeposit01(kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO dHDCodeDeposit01IO);

	/**
	 * HD_코드-계좌번호 병합
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 병합", description = "HD_코드-계좌번호 병합")
	int mergeHdCodeDeposit01(kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO dHDCodeDeposit01IO);

	/**
	 * HD_코드-계좌번호 삭제
	 * @TestValues 	deptCode=; housetag=; depositNo=; receipttag=; bankCode=; bankName=; listorder=; outdepositno=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; virTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드-계좌번호 삭제", description = "HD_코드-계좌번호 삭제")
	int deleteHdCodeDeposit01(kait.hd.code.onl.dao.dto.DHDCodeDeposit01IO dHDCodeDeposit01IO);


}
