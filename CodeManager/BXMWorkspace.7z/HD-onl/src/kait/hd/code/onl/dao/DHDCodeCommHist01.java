/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeCommHist01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_CODE_COMM_HIST", description = "HD_CODE_COMM_HIST")
public interface DHDCodeCommHist01
{
	/**
	 * HD_CODE_COMM_HIST 등록
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 등록", description = "HD_CODE_COMM_HIST 등록")
	int insertHdCodeCommHist01(kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO dHDCodeCommHist01IO);

	/**
	 * HD_CODE_COMM_HIST 단건조회
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 단건조회", description = "HD_CODE_COMM_HIST 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO selectHdCodeCommHist01(kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO dHDCodeCommHist01IO);

	/**
	 * HD_CODE_COMM_HIST 전채건수조회
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 전채건수조회", description = "HD_CODE_COMM_HIST 전채건수조회")
	java.lang.Integer selectCountHdCodeCommHist01(kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO dHDCodeCommHist01IO);

	/**
	 * HD_CODE_COMM_HIST 목록조회
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 목록조회", description = "HD_CODE_COMM_HIST 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO> selectListHdCodeCommHist01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_CODE_COMM_HIST 수정
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 수정", description = "HD_CODE_COMM_HIST 수정")
	int updateHdCodeCommHist01(kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO dHDCodeCommHist01IO);

	/**
	 * HD_CODE_COMM_HIST 병합
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 병합", description = "HD_CODE_COMM_HIST 병합")
	int mergeHdCodeCommHist01(kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO dHDCodeCommHist01IO);

	/**
	 * HD_CODE_COMM_HIST 삭제
	 * @TestValues 	histDate=; gubun=; code=; nm=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_COMM_HIST 삭제", description = "HD_CODE_COMM_HIST 삭제")
	int deleteHdCodeCommHist01(kait.hd.code.onl.dao.dto.DHDCodeCommHist01IO dHDCodeCommHist01IO);


}
