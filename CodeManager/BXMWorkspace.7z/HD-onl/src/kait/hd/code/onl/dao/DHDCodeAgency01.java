/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeAgency01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드-대행사", description = "HD_코드-대행사")
public interface DHDCodeAgency01
{
	/**
	 * HD_코드-대행사 등록
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 등록", description = "HD_코드-대행사 등록")
	int insertHdCodeAgency01(kait.hd.code.onl.dao.dto.DHDCodeAgency01IO dHDCodeAgency01IO);

	/**
	 * HD_코드-대행사 단건조회
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 단건조회", description = "HD_코드-대행사 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeAgency01IO selectHdCodeAgency01(kait.hd.code.onl.dao.dto.DHDCodeAgency01IO dHDCodeAgency01IO);

	/**
	 * HD_코드-대행사 전채건수조회
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 전채건수조회", description = "HD_코드-대행사 전채건수조회")
	java.lang.Integer selectCountHdCodeAgency01(kait.hd.code.onl.dao.dto.DHDCodeAgency01IO dHDCodeAgency01IO);

	/**
	 * HD_코드-대행사 목록조회
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 목록조회", description = "HD_코드-대행사 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgency01IO> selectListHdCodeAgency01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeAgency01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드-대행사 수정
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 수정", description = "HD_코드-대행사 수정")
	int updateHdCodeAgency01(kait.hd.code.onl.dao.dto.DHDCodeAgency01IO dHDCodeAgency01IO);

	/**
	 * HD_코드-대행사 병합
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 병합", description = "HD_코드-대행사 병합")
	int mergeHdCodeAgency01(kait.hd.code.onl.dao.dto.DHDCodeAgency01IO dHDCodeAgency01IO);

	/**
	 * HD_코드-대행사 삭제
	 * @TestValues 	deptCode=; housetag=; agencyCode=; agencyName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-대행사 삭제", description = "HD_코드-대행사 삭제")
	int deleteHdCodeAgency01(kait.hd.code.onl.dao.dto.DHDCodeAgency01IO dHDCodeAgency01IO);


}
