/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeCustomer01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_고객_컨버젼용", description = "HD_코드_고객_컨버젼용")
public interface DHDCodeCustomer01
{
	/**
	 * HD_코드_고객_컨버젼용 등록
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 등록", description = "HD_코드_고객_컨버젼용 등록")
	int insertHdCodeCustomer01(kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO dHDCodeCustomer01IO);

	/**
	 * HD_코드_고객_컨버젼용 단건조회
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 단건조회", description = "HD_코드_고객_컨버젼용 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO selectHdCodeCustomer01(kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO dHDCodeCustomer01IO);

	/**
	 * HD_코드_고객_컨버젼용 전채건수조회
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 전채건수조회", description = "HD_코드_고객_컨버젼용 전채건수조회")
	java.lang.Integer selectCountHdCodeCustomer01(kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO dHDCodeCustomer01IO);

	/**
	 * HD_코드_고객_컨버젼용 목록조회
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 목록조회", description = "HD_코드_고객_컨버젼용 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO> selectListHdCodeCustomer01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_고객_컨버젼용 수정
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 수정", description = "HD_코드_고객_컨버젼용 수정")
	int updateHdCodeCustomer01(kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO dHDCodeCustomer01IO);

	/**
	 * HD_코드_고객_컨버젼용 병합
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 병합", description = "HD_코드_고객_컨버젼용 병합")
	int mergeHdCodeCustomer01(kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO dHDCodeCustomer01IO);

	/**
	 * HD_코드_고객_컨버젼용 삭제
	 * @TestValues 	custCode=; custName=; custcodeTag=; handphone=; tel=; compTel=; zip=; addr1=; addr2=; owner=; condition=; category=; email=; residentZip=; residentAddr1=; residentAddr2=; useyn=; compRecvYn=; deptCode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_컨버젼용 삭제", description = "HD_코드_고객_컨버젼용 삭제")
	int deleteHdCodeCustomer01(kait.hd.code.onl.dao.dto.DHDCodeCustomer01IO dHDCodeCustomer01IO);


}
