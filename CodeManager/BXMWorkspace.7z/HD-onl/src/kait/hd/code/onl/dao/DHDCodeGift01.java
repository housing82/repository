/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeGift01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_선물품목코드", description = "HD_코드_선물품목코드")
public interface DHDCodeGift01
{
	/**
	 * HD_코드_선물품목코드 등록
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 등록", description = "HD_코드_선물품목코드 등록")
	int insertHdCodeGift01(kait.hd.code.onl.dao.dto.DHDCodeGift01IO dHDCodeGift01IO);

	/**
	 * HD_코드_선물품목코드 단건조회
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 단건조회", description = "HD_코드_선물품목코드 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeGift01IO selectHdCodeGift01(kait.hd.code.onl.dao.dto.DHDCodeGift01IO dHDCodeGift01IO);

	/**
	 * HD_코드_선물품목코드 전채건수조회
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 전채건수조회", description = "HD_코드_선물품목코드 전채건수조회")
	java.lang.Integer selectCountHdCodeGift01(kait.hd.code.onl.dao.dto.DHDCodeGift01IO dHDCodeGift01IO);

	/**
	 * HD_코드_선물품목코드 목록조회
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 목록조회", description = "HD_코드_선물품목코드 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeGift01IO> selectListHdCodeGift01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeGift01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_선물품목코드 수정
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 수정", description = "HD_코드_선물품목코드 수정")
	int updateHdCodeGift01(kait.hd.code.onl.dao.dto.DHDCodeGift01IO dHDCodeGift01IO);

	/**
	 * HD_코드_선물품목코드 병합
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 병합", description = "HD_코드_선물품목코드 병합")
	int mergeHdCodeGift01(kait.hd.code.onl.dao.dto.DHDCodeGift01IO dHDCodeGift01IO);

	/**
	 * HD_코드_선물품목코드 삭제
	 * @TestValues 	deptCode=; housetag=; giftcode=; giftname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_선물품목코드 삭제", description = "HD_코드_선물품목코드 삭제")
	int deleteHdCodeGift01(kait.hd.code.onl.dao.dto.DHDCodeGift01IO dHDCodeGift01IO);


}
