package kait.hd.code.onl.bc;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bxm.common.annotaion.BxmCategory;
import bxm.container.annotation.BxmBean;
import bxm.dft.app.KaitApplicationException;
import bxm.dft.context.DefaultApplicationContext;

import kait.hd.acmast.onl.dao.DHDAcmastE01;
import kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO;
import kait.hd.code.onl.bc.dto.BHDeCodeTest01In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest01Out;
import kait.hd.code.onl.bc.dto.BHDeCodeTest02In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest02Out;
import kait.hd.code.onl.bc.dto.BHDeCodeTest03In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest03Out;
import kait.hd.code.onl.dao.DHDCodeAcnt01;
import kait.hd.code.onl.dao.DHDCodeAgency01;
import kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO;
import kait.hd.code.onl.dao.dto.DHDCodeAgency01IO;


/**
 * Generated Code Skeleton 2017-06-23 18:03:48
 * 
 * <b>History :</b>
 * <pre>
 * 
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           CodeSkeleton       			2017-06-23 18:03:48          신규작성
 * </pre>
 * 
 * @since 2017-06-23 18:03:48
 * @version 3.0.0
 * @author Developer
 * @see "BXM Bean"
 */
@BxmBean
@BxmCategory(type = "BC", logicalName = "분양계정관리", description = "분양계정관리")
public class BHDeCodeTest {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private DHDAcmastE01 dHDAcmastE01;
	private DHDCodeAcnt01 dHDCodeAcnt01;
	private DHDCodeAgency01 dHDCodeAgency01;

	
	@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")
	public BHDeCodeTest01Out searchField(BHDeCodeTest01In bHDeCodeTest01In) throws KaitApplicationException {
		logger.debug("[START-BC] searchField input:\n{}", bHDeCodeTest01In);

		if(bHDeCodeTest01In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDAcmastE01 = DefaultApplicationContext.getBean(dHDAcmastE01, DHDAcmastE01.class);
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);
		dHDCodeAgency01 = DefaultApplicationContext.getBean(dHDCodeAgency01, DHDCodeAgency01.class);

		/** ### Output Variable ### */
		BHDeCodeTest01Out out = null;

		/** ### Callee Input Setting ### */
		DHDAcmastE01IO inDHDAcmastE01IO = bHDeCodeTest01In.getInDHDAcmastE01IO();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeTest01In.getInDHDCodeAcnt01IO();
		DHDCodeAgency01IO inDHDCodeAgency01IO = bHDeCodeTest01In.getInDHDCodeAgency01IO();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO01 = bHDeCodeTest01In.getInDHDCodeAcnt01IO01();
		int inPageNum = 0;
		int inPageCount = 0;


		/** ### Execute Callee ### */
		int outInsertHdAcmastE01 = dHDAcmastE01.insertHdAcmastE01(inDHDAcmastE01IO);
		DHDCodeAcnt01IO outDHDCodeAcnt01IO = dHDCodeAcnt01.selectHdCodeAcnt01(inDHDCodeAcnt01IO);
		Integer outSelectCountHdCodeAgency01 = dHDCodeAgency01.selectCountHdCodeAgency01(inDHDCodeAgency01IO);
		List<DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List = dHDCodeAcnt01.selectListHdCodeAcnt01(inDHDCodeAcnt01IO01, inPageNum, inPageCount);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeTest01Out();
		out.setOutInsertHdAcmastE01(outInsertHdAcmastE01);
		out.setOutDHDCodeAcnt01IO(outDHDCodeAcnt01IO);
		out.setOutSelectCountHdCodeAgency01(outSelectCountHdCodeAgency01);
		out.setOutSelectListHdCodeAcnt01List(outSelectListHdCodeAcnt01List);


		logger.debug("[END-BC] searchField output:\n{}", out);
		return out;
	}


	@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")
	public BHDeCodeTest02Out searchFieldDetail(BHDeCodeTest02In bHDeCodeTest02In) throws KaitApplicationException {
		logger.debug("[START-BC] searchFieldDetail input:\n{}", bHDeCodeTest02In);

		if(bHDeCodeTest02In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDAcmastE01 = DefaultApplicationContext.getBean(dHDAcmastE01, DHDAcmastE01.class);
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);
		dHDCodeAgency01 = DefaultApplicationContext.getBean(dHDCodeAgency01, DHDCodeAgency01.class);

		/** ### Output Variable ### */
		BHDeCodeTest02Out out = null;

		/** ### Callee Input Setting ### */
		DHDAcmastE01IO inDHDAcmastE01IO = bHDeCodeTest02In.getInDHDAcmastE01IO();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeTest02In.getInDHDCodeAcnt01IO();
		DHDCodeAgency01IO inDHDCodeAgency01IO = bHDeCodeTest02In.getInDHDCodeAgency01IO();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO01 = bHDeCodeTest02In.getInDHDCodeAcnt01IO01();
		int inPageNum = 0;
		int inPageCount = 0;


		/** ### Execute Callee ### */
		int outInsertHdAcmastE01 = dHDAcmastE01.insertHdAcmastE01(inDHDAcmastE01IO);
		DHDCodeAcnt01IO outDHDCodeAcnt01IO = dHDCodeAcnt01.selectHdCodeAcnt01(inDHDCodeAcnt01IO);
		Integer outSelectCountHdCodeAgency01 = dHDCodeAgency01.selectCountHdCodeAgency01(inDHDCodeAgency01IO);
		List<DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List = dHDCodeAcnt01.selectListHdCodeAcnt01(inDHDCodeAcnt01IO01, inPageNum, inPageCount);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeTest02Out();
		out.setOutInsertHdAcmastE01(outInsertHdAcmastE01);
		out.setOutDHDCodeAcnt01IO(outDHDCodeAcnt01IO);
		out.setOutSelectCountHdCodeAgency01(outSelectCountHdCodeAgency01);
		out.setOutSelectListHdCodeAcnt01List(outSelectListHdCodeAcnt01List);


		logger.debug("[END-BC] searchFieldDetail output:\n{}", out);
		return out;
	}


	@BxmCategory(logicalName = "분양계정 조회", description = "분양계정 조회")
	public BHDeCodeTest03Out getCodeAccount(BHDeCodeTest03In bHDeCodeTest03In) throws KaitApplicationException {
		logger.debug("[START-BC] getCodeAccount input:\n{}", bHDeCodeTest03In);

		if(bHDeCodeTest03In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);

		/** ### Output Variable ### */
		BHDeCodeTest03Out out = null;

		/** ### Callee Input Setting ### */
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeTest03In.getInDHDCodeAcnt01IO();

		/** ### Execute Callee ### */
		int outInsertHdCodeAcnt01 = dHDCodeAcnt01.insertHdCodeAcnt01(inDHDCodeAcnt01IO);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeTest03Out();
		out.setOutInsertHdCodeAcnt01(outInsertHdCodeAcnt01);


		logger.debug("[END-BC] getCodeAccount output:\n{}", out);
		return out;
	}



}	
