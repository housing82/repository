/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeSihang01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_시행사", description = "HD_코드_시행사")
public interface DHDCodeSihang01
{
	/**
	 * HD_코드_시행사 등록
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 등록", description = "HD_코드_시행사 등록")
	int insertHdCodeSihang01(kait.hd.code.onl.dao.dto.DHDCodeSihang01IO dHDCodeSihang01IO);

	/**
	 * HD_코드_시행사 단건조회
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 단건조회", description = "HD_코드_시행사 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeSihang01IO selectHdCodeSihang01(kait.hd.code.onl.dao.dto.DHDCodeSihang01IO dHDCodeSihang01IO);

	/**
	 * HD_코드_시행사 전채건수조회
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 전채건수조회", description = "HD_코드_시행사 전채건수조회")
	java.lang.Integer selectCountHdCodeSihang01(kait.hd.code.onl.dao.dto.DHDCodeSihang01IO dHDCodeSihang01IO);

	/**
	 * HD_코드_시행사 목록조회
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 목록조회", description = "HD_코드_시행사 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeSihang01IO> selectListHdCodeSihang01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeSihang01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_시행사 수정
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 수정", description = "HD_코드_시행사 수정")
	int updateHdCodeSihang01(kait.hd.code.onl.dao.dto.DHDCodeSihang01IO dHDCodeSihang01IO);

	/**
	 * HD_코드_시행사 병합
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 병합", description = "HD_코드_시행사 병합")
	int mergeHdCodeSihang01(kait.hd.code.onl.dao.dto.DHDCodeSihang01IO dHDCodeSihang01IO);

	/**
	 * HD_코드_시행사 삭제
	 * @TestValues 	deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; 
	 */
	@BxmCategory(logicalName = "HD_코드_시행사 삭제", description = "HD_코드_시행사 삭제")
	int deleteHdCodeSihang01(kait.hd.code.onl.dao.dto.DHDCodeSihang01IO dHDCodeSihang01IO);


}
