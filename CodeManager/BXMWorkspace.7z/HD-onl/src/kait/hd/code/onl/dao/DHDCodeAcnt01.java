/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeAcnt01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_전표_계정", description = "HD_분양_전표_계정")
public interface DHDCodeAcnt01
{
	/**
	 * HD_분양_전표_계정 등록
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 등록", description = "HD_분양_전표_계정 등록")
	int insertHdCodeAcnt01(kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO dHDCodeAcnt01IO);

	/**
	 * HD_분양_전표_계정 단건조회
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 단건조회", description = "HD_분양_전표_계정 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO selectHdCodeAcnt01(kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO dHDCodeAcnt01IO);

	/**
	 * HD_분양_전표_계정 전채건수조회
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 전채건수조회", description = "HD_분양_전표_계정 전채건수조회")
	java.lang.Integer selectCountHdCodeAcnt01(kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO dHDCodeAcnt01IO);

	/**
	 * HD_분양_전표_계정 목록조회
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 목록조회", description = "HD_분양_전표_계정 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO> selectListHdCodeAcnt01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_전표_계정 수정
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 수정", description = "HD_분양_전표_계정 수정")
	int updateHdCodeAcnt01(kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO dHDCodeAcnt01IO);

	/**
	 * HD_분양_전표_계정 병합
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 병합", description = "HD_분양_전표_계정 병합")
	int mergeHdCodeAcnt01(kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO dHDCodeAcnt01IO);

	/**
	 * HD_분양_전표_계정 삭제
	 * @TestValues 	deptCode=; jcode=; jacntcode=; jacntname=; detailcode=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_전표_계정 삭제", description = "HD_분양_전표_계정 삭제")
	int deleteHdCodeAcnt01(kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO dHDCodeAcnt01IO);


}
