/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeHouseHist01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_분양구분_이력", description = "HD_코드_분양구분_이력")
public interface DHDCodeHouseHist01
{
	/**
	 * HD_코드_분양구분_이력 등록
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 등록", description = "HD_코드_분양구분_이력 등록")
	int insertHdCodeHouseHist01(kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO dHDCodeHouseHist01IO);

	/**
	 * HD_코드_분양구분_이력 단건조회
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 단건조회", description = "HD_코드_분양구분_이력 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO selectHdCodeHouseHist01(kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO dHDCodeHouseHist01IO);

	/**
	 * HD_코드_분양구분_이력 전채건수조회
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 전채건수조회", description = "HD_코드_분양구분_이력 전채건수조회")
	java.lang.Integer selectCountHdCodeHouseHist01(kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO dHDCodeHouseHist01IO);

	/**
	 * HD_코드_분양구분_이력 목록조회
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 목록조회", description = "HD_코드_분양구분_이력 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO> selectListHdCodeHouseHist01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_분양구분_이력 수정
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 수정", description = "HD_코드_분양구분_이력 수정")
	int updateHdCodeHouseHist01(kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO dHDCodeHouseHist01IO);

	/**
	 * HD_코드_분양구분_이력 병합
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 병합", description = "HD_코드_분양구분_이력 병합")
	int mergeHdCodeHouseHist01(kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO dHDCodeHouseHist01IO);

	/**
	 * HD_코드_분양구분_이력 삭제
	 * @TestValues 	histDate=; deptCode=; housetag=; housedate=; completiondate=; houseCnt=; moveinstartdate=; moveinenddate=; penaltyrate=; hicTag=; tirmRate=; sodukRate=; juminRate=; damdang=; damdangTel=; printCnt=; resellTag=; virdepositYn=; virbankCode=; deptAddrUseYn=; contPblName=; contDwName=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; contPblName2=; contDwName2=; contPblName3=; contDwName3=; slipgroup=; triTag=; applyCheckYn=; anne1aPbl=; anne1aDw=; anne1bPbl=; anne1bDw=; anne2aPbl=; anne2aDw=; anne2bPbl=; anne2bDw=; anne3Pbl=; anne3Dw=; anne4Pbl=; anne4Dw=; delayday=; delayrate=; agreeTag=; indeminityTag=; indeminityFrdt=; indeminityTodt=; sealtype=; jiroTag=; jiroSn=; hdDaymonthTag=; rtDaymonthTag=; rtFixrateTag=; predisTag=; proxyTag=; trustTag=; printYn=; rtFixrateDay=; rtFixrate=; virdeposit2Yn=; virbank2Code=; rtFixrate2=; rtExtrate=; rtGurtyn=; rtRentyn=; oncesalerate=; delayBlock=; 
	 */
	@BxmCategory(logicalName = "HD_코드_분양구분_이력 삭제", description = "HD_코드_분양구분_이력 삭제")
	int deleteHdCodeHouseHist01(kait.hd.code.onl.dao.dto.DHDCodeHouseHist01IO dHDCodeHouseHist01IO);


}
