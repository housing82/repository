/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeCustomerTxtup01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_고객_자료올리기", description = "HD_코드_고객_자료올리기")
public interface DHDCodeCustomerTxtup01
{
	/**
	 * HD_코드_고객_자료올리기 등록
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 등록", description = "HD_코드_고객_자료올리기 등록")
	int insertHdCodeCustomerTxtup01(kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO dHDCodeCustomerTxtup01IO);

	/**
	 * HD_코드_고객_자료올리기 단건조회
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 단건조회", description = "HD_코드_고객_자료올리기 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO selectHdCodeCustomerTxtup01(kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO dHDCodeCustomerTxtup01IO);

	/**
	 * HD_코드_고객_자료올리기 전채건수조회
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 전채건수조회", description = "HD_코드_고객_자료올리기 전채건수조회")
	java.lang.Integer selectCountHdCodeCustomerTxtup01(kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO dHDCodeCustomerTxtup01IO);

	/**
	 * HD_코드_고객_자료올리기 목록조회
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 목록조회", description = "HD_코드_고객_자료올리기 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO> selectListHdCodeCustomerTxtup01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_고객_자료올리기 수정
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 수정", description = "HD_코드_고객_자료올리기 수정")
	int updateHdCodeCustomerTxtup01(kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO dHDCodeCustomerTxtup01IO);

	/**
	 * HD_코드_고객_자료올리기 병합
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 병합", description = "HD_코드_고객_자료올리기 병합")
	int mergeHdCodeCustomerTxtup01(kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO dHDCodeCustomerTxtup01IO);

	/**
	 * HD_코드_고객_자료올리기 삭제
	 * @TestValues 	custCode=; custcodeTag=; custName=; deptCode=; handphone=; tel=; zip=; addr=; email=; processTag=; errMsg=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; addr2=; addrTag=; representName=; 
	 */
	@BxmCategory(logicalName = "HD_코드_고객_자료올리기 삭제", description = "HD_코드_고객_자료올리기 삭제")
	int deleteHdCodeCustomerTxtup01(kait.hd.code.onl.dao.dto.DHDCodeCustomerTxtup01IO dHDCodeCustomerTxtup01IO);


}
