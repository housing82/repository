/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeDeptmemo01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_현장메모", description = "HD_코드_현장메모")
public interface DHDCodeDeptmemo01
{
	/**
	 * HD_코드_현장메모 등록
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 등록", description = "HD_코드_현장메모 등록")
	int insertHdCodeDeptmemo01(kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO dHDCodeDeptmemo01IO);

	/**
	 * HD_코드_현장메모 단건조회
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 단건조회", description = "HD_코드_현장메모 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO selectHdCodeDeptmemo01(kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO dHDCodeDeptmemo01IO);

	/**
	 * HD_코드_현장메모 전채건수조회
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 전채건수조회", description = "HD_코드_현장메모 전채건수조회")
	java.lang.Integer selectCountHdCodeDeptmemo01(kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO dHDCodeDeptmemo01IO);

	/**
	 * HD_코드_현장메모 목록조회
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 목록조회", description = "HD_코드_현장메모 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO> selectListHdCodeDeptmemo01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_현장메모 수정
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 수정", description = "HD_코드_현장메모 수정")
	int updateHdCodeDeptmemo01(kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO dHDCodeDeptmemo01IO);

	/**
	 * HD_코드_현장메모 병합
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 병합", description = "HD_코드_현장메모 병합")
	int mergeHdCodeDeptmemo01(kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO dHDCodeDeptmemo01IO);

	/**
	 * HD_코드_현장메모 삭제
	 * @TestValues 	deptCode=; seq=; title=; nm=; officetel=; handphone=; email=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_현장메모 삭제", description = "HD_코드_현장메모 삭제")
	int deleteHdCodeDeptmemo01(kait.hd.code.onl.dao.dto.DHDCodeDeptmemo01IO dHDCodeDeptmemo01IO);


}
