/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeAgree01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드_약정차수", description = "HD_코드_약정차수")
public interface DHDCodeAgree01
{
	/**
	 * HD_코드_약정차수 등록
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 등록", description = "HD_코드_약정차수 등록")
	int insertHdCodeAgree01(kait.hd.code.onl.dao.dto.DHDCodeAgree01IO dHDCodeAgree01IO);

	/**
	 * HD_코드_약정차수 단건조회
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 단건조회", description = "HD_코드_약정차수 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeAgree01IO selectHdCodeAgree01(kait.hd.code.onl.dao.dto.DHDCodeAgree01IO dHDCodeAgree01IO);

	/**
	 * HD_코드_약정차수 전채건수조회
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 전채건수조회", description = "HD_코드_약정차수 전채건수조회")
	java.lang.Integer selectCountHdCodeAgree01(kait.hd.code.onl.dao.dto.DHDCodeAgree01IO dHDCodeAgree01IO);

	/**
	 * HD_코드_약정차수 목록조회
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 목록조회", description = "HD_코드_약정차수 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeAgree01IO> selectListHdCodeAgree01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeAgree01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드_약정차수 수정
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 수정", description = "HD_코드_약정차수 수정")
	int updateHdCodeAgree01(kait.hd.code.onl.dao.dto.DHDCodeAgree01IO dHDCodeAgree01IO);

	/**
	 * HD_코드_약정차수 병합
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 병합", description = "HD_코드_약정차수 병합")
	int mergeHdCodeAgree01(kait.hd.code.onl.dao.dto.DHDCodeAgree01IO dHDCodeAgree01IO);

	/**
	 * HD_코드_약정차수 삭제
	 * @TestValues 	deptCode=; housetag=; agreeseq=; agreenm=; agreedate=; midtype=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드_약정차수 삭제", description = "HD_코드_약정차수 삭제")
	int deleteHdCodeAgree01(kait.hd.code.onl.dao.dto.DHDCodeAgree01IO dHDCodeAgree01IO);


}
