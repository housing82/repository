package kait.hd.code.onl.sc;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bxm.common.annotaion.BxmCategory;
import bxm.container.annotation.BxmService;
import bxm.container.annotation.BxmServiceOperation;
import bxm.dft.app.KaitApplicationException;
import bxm.dft.context.DefaultApplicationContext;
import bxm.kait.util.CommonHdrUtils;

import kait.hd.code.onl.bc.BHDeCodeTest;
import kait.hd.code.onl.bc.BHDeCodeAccount;
import kait.hd.code.onl.sc.dto.SHDCODE00101Out;
import kait.hd.code.onl.sc.dto.SHDCODE00101In;
import kait.hd.code.onl.bc.dto.BHDeCodeTest01In;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub01;
import kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub02;
import kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub03;
import kait.hd.code.onl.dao.dto.DHDCodeAgency01IO;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub04;
import kait.hd.code.onl.bc.dto.BHDeCodeTest01Out;
import kait.hd.code.onl.bc.dto.BHDeCodeTest02In;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub05;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub06;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub07;
import kait.hd.code.onl.sc.dto.SHDCODE00101Sub08;
import kait.hd.code.onl.bc.dto.BHDeCodeTest02Out;
import kait.hd.code.onl.sc.dto.BHDeCodeTest01Out;
import kait.hd.code.onl.sc.dto.BHDeCodeTest02Out;
import kait.hd.code.onl.sc.dto.SHDCODE00102Out;
import kait.hd.code.onl.sc.dto.SHDCODE00102In;
import kait.hd.code.onl.bc.dto.BHDeCodeAccount01In;
import kait.hd.code.onl.sc.dto.SHDCODE00102Sub01;
import kait.hd.code.onl.bc.dto.BHDeCodeAccount01Out;
import kait.hd.code.onl.sc.dto.BHDeCodeAccount01Out;
import kait.hd.code.onl.sc.dto.SHDCODE00103Out;
import kait.hd.code.onl.sc.dto.SHDCODE00103In;


/**
 * Generated Code Skeleton 2017-06-23 18:42:48
 * 
 * <b>History :</b>
 * <pre>
 * 
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           CodeSkeleton       			2017-06-23 18:42:48          신규작성
 * </pre>
 * 
 * @since 2017-06-23 18:42:48
 * @version 3.0.0
 * @author Developer
 * @see "BXM Service"
 */
@BxmService("SHDCODE001")
@BxmCategory(type = "SC", logicalName = "분양계정관리", description = "분양계정관리")
public class SHDCODE001 {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	private BHDeCodeTest bHDeCodeTest;
	private BHDeCodeAccount bHDeCodeAccount;


	@BxmServiceOperation("SHDCODE00101")
	@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")
	public SHDCODE00101Out searchField(SHDCODE00101In sHDCODE00101In) throws KaitApplicationException {
		logger.debug("[START-SC] searchField input:\n{}", sHDCODE00101In);
		
		/** ### Validate Parameter ### */

		/** ### Bean Initialize ### */
		bHDeCodeTest = DefaultApplicationContext.getBean(bHDeCodeTest, BHDeCodeTest.class);

		/** ### Output Variable ### */
		SHDCODE00101Out out = null;
		
		/** ### Set Bean Input Value  ### */
		BHDeCodeTest01In inBHDeCodeTest01In = new BHDeCodeTest01In();
		SHDCODE00101Sub01 inSHDCODE00101Sub01 = sHDCODE00101In.getInSHDCODE00101Sub01();
		DHDAcmastE01IO inDHDAcmastE01IO = new DHDAcmastE01IO();

		if( inSHDCODE00101Sub01 != null ) {
			inDHDAcmastE01IO.setJcode(inSHDCODE00101Sub01.getJcode());
			inDHDAcmastE01IO.setJacntcode(inSHDCODE00101Sub01.getJacntcode());
			inDHDAcmastE01IO.setJacntname(inSHDCODE00101Sub01.getJacntname());
			inDHDAcmastE01IO.setInputDutyId(inSHDCODE00101Sub01.getInputDutyId());
			inDHDAcmastE01IO.setInputDate(inSHDCODE00101Sub01.getInputDate());
			inDHDAcmastE01IO.setChgDutyId(inSHDCODE00101Sub01.getChgDutyId());
			inDHDAcmastE01IO.setChgDate(inSHDCODE00101Sub01.getChgDate());
		}
		inBHDeCodeTest01In.setInDHDAcmastE01IO(inDHDAcmastE01IO);

		SHDCODE00101Sub02 inSHDCODE00101Sub02 = sHDCODE00101In.getInSHDCODE00101Sub02();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = new DHDCodeAcnt01IO();

		if( inSHDCODE00101Sub02 != null ) {
			inDHDCodeAcnt01IO.setDeptCode(inSHDCODE00101Sub02.getDeptCode());
			inDHDCodeAcnt01IO.setJcode(inSHDCODE00101Sub02.getJcode());
			inDHDCodeAcnt01IO.setJacntcode(inSHDCODE00101Sub02.getJacntcode());
			inDHDCodeAcnt01IO.setJacntname(inSHDCODE00101Sub02.getJacntname());
			inDHDCodeAcnt01IO.setDetailcode(inSHDCODE00101Sub02.getDetailcode());
			inDHDCodeAcnt01IO.setInputDutyId(inSHDCODE00101Sub02.getInputDutyId());
			inDHDCodeAcnt01IO.setInputDate(inSHDCODE00101Sub02.getInputDate());
			inDHDCodeAcnt01IO.setChgDutyId(inSHDCODE00101Sub02.getChgDutyId());
			inDHDCodeAcnt01IO.setChgDate(inSHDCODE00101Sub02.getChgDate());
		}
		inBHDeCodeTest01In.setInDHDCodeAcnt01IO(inDHDCodeAcnt01IO);

		SHDCODE00101Sub03 inSHDCODE00101Sub03 = sHDCODE00101In.getInSHDCODE00101Sub03();
		DHDCodeAgency01IO inDHDCodeAgency01IO = new DHDCodeAgency01IO();

		if( inSHDCODE00101Sub03 != null ) {
			inDHDCodeAgency01IO.setDeptCode(inSHDCODE00101Sub03.getDeptCode());
			inDHDCodeAgency01IO.setHousetag(inSHDCODE00101Sub03.getHousetag());
			inDHDCodeAgency01IO.setAgencyCode(inSHDCODE00101Sub03.getAgencyCode());
			inDHDCodeAgency01IO.setAgencyName(inSHDCODE00101Sub03.getAgencyName());
			inDHDCodeAgency01IO.setRemark(inSHDCODE00101Sub03.getRemark());
			inDHDCodeAgency01IO.setInputDutyId(inSHDCODE00101Sub03.getInputDutyId());
			inDHDCodeAgency01IO.setInputDate(inSHDCODE00101Sub03.getInputDate());
			inDHDCodeAgency01IO.setChgDutyId(inSHDCODE00101Sub03.getChgDutyId());
			inDHDCodeAgency01IO.setChgDate(inSHDCODE00101Sub03.getChgDate());
		}
		inBHDeCodeTest01In.setInDHDCodeAgency01IO(inDHDCodeAgency01IO);

		SHDCODE00101Sub04 inSHDCODE00101Sub04 = sHDCODE00101In.getInSHDCODE00101Sub04();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO01 = new DHDCodeAcnt01IO();

		if( inSHDCODE00101Sub04 != null ) {
			inDHDCodeAcnt01IO01.setDeptCode(inSHDCODE00101Sub04.getDeptCode());
			inDHDCodeAcnt01IO01.setJcode(inSHDCODE00101Sub04.getJcode());
			inDHDCodeAcnt01IO01.setJacntcode(inSHDCODE00101Sub04.getJacntcode());
			inDHDCodeAcnt01IO01.setJacntname(inSHDCODE00101Sub04.getJacntname());
			inDHDCodeAcnt01IO01.setDetailcode(inSHDCODE00101Sub04.getDetailcode());
			inDHDCodeAcnt01IO01.setInputDutyId(inSHDCODE00101Sub04.getInputDutyId());
			inDHDCodeAcnt01IO01.setInputDate(inSHDCODE00101Sub04.getInputDate());
			inDHDCodeAcnt01IO01.setChgDutyId(inSHDCODE00101Sub04.getChgDutyId());
			inDHDCodeAcnt01IO01.setChgDate(inSHDCODE00101Sub04.getChgDate());
		}
		inBHDeCodeTest01In.setInDHDCodeAcnt01IO01(inDHDCodeAcnt01IO01);


		BHDeCodeTest02In inBHDeCodeTest02In = new BHDeCodeTest02In();
		SHDCODE00101Sub05 inSHDCODE00101Sub05 = sHDCODE00101In.getInSHDCODE00101Sub05();
		DHDAcmastE01IO inDHDAcmastE01IO01 = new DHDAcmastE01IO();

		if( inSHDCODE00101Sub05 != null ) {
			inDHDAcmastE01IO01.setJcode(inSHDCODE00101Sub05.getJcode());
			inDHDAcmastE01IO01.setJacntcode(inSHDCODE00101Sub05.getJacntcode());
			inDHDAcmastE01IO01.setJacntname(inSHDCODE00101Sub05.getJacntname());
			inDHDAcmastE01IO01.setInputDutyId(inSHDCODE00101Sub05.getInputDutyId());
			inDHDAcmastE01IO01.setInputDate(inSHDCODE00101Sub05.getInputDate());
			inDHDAcmastE01IO01.setChgDutyId(inSHDCODE00101Sub05.getChgDutyId());
			inDHDAcmastE01IO01.setChgDate(inSHDCODE00101Sub05.getChgDate());
		}
		inBHDeCodeTest02In.setInDHDAcmastE01IO(inDHDAcmastE01IO01);

		SHDCODE00101Sub06 inSHDCODE00101Sub06 = sHDCODE00101In.getInSHDCODE00101Sub06();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO0101 = new DHDCodeAcnt01IO();

		if( inSHDCODE00101Sub06 != null ) {
			inDHDCodeAcnt01IO0101.setDeptCode(inSHDCODE00101Sub06.getDeptCode());
			inDHDCodeAcnt01IO0101.setJcode(inSHDCODE00101Sub06.getJcode());
			inDHDCodeAcnt01IO0101.setJacntcode(inSHDCODE00101Sub06.getJacntcode());
			inDHDCodeAcnt01IO0101.setJacntname(inSHDCODE00101Sub06.getJacntname());
			inDHDCodeAcnt01IO0101.setDetailcode(inSHDCODE00101Sub06.getDetailcode());
			inDHDCodeAcnt01IO0101.setInputDutyId(inSHDCODE00101Sub06.getInputDutyId());
			inDHDCodeAcnt01IO0101.setInputDate(inSHDCODE00101Sub06.getInputDate());
			inDHDCodeAcnt01IO0101.setChgDutyId(inSHDCODE00101Sub06.getChgDutyId());
			inDHDCodeAcnt01IO0101.setChgDate(inSHDCODE00101Sub06.getChgDate());
		}
		inBHDeCodeTest02In.setInDHDCodeAcnt01IO(inDHDCodeAcnt01IO0101);

		SHDCODE00101Sub07 inSHDCODE00101Sub07 = sHDCODE00101In.getInSHDCODE00101Sub07();
		DHDCodeAgency01IO inDHDCodeAgency01IO01 = new DHDCodeAgency01IO();

		if( inSHDCODE00101Sub07 != null ) {
			inDHDCodeAgency01IO01.setDeptCode(inSHDCODE00101Sub07.getDeptCode());
			inDHDCodeAgency01IO01.setHousetag(inSHDCODE00101Sub07.getHousetag());
			inDHDCodeAgency01IO01.setAgencyCode(inSHDCODE00101Sub07.getAgencyCode());
			inDHDCodeAgency01IO01.setAgencyName(inSHDCODE00101Sub07.getAgencyName());
			inDHDCodeAgency01IO01.setRemark(inSHDCODE00101Sub07.getRemark());
			inDHDCodeAgency01IO01.setInputDutyId(inSHDCODE00101Sub07.getInputDutyId());
			inDHDCodeAgency01IO01.setInputDate(inSHDCODE00101Sub07.getInputDate());
			inDHDCodeAgency01IO01.setChgDutyId(inSHDCODE00101Sub07.getChgDutyId());
			inDHDCodeAgency01IO01.setChgDate(inSHDCODE00101Sub07.getChgDate());
		}
		inBHDeCodeTest02In.setInDHDCodeAgency01IO(inDHDCodeAgency01IO01);

		SHDCODE00101Sub08 inSHDCODE00101Sub08 = sHDCODE00101In.getInSHDCODE00101Sub08();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO0102 = new DHDCodeAcnt01IO();

		if( inSHDCODE00101Sub08 != null ) {
			inDHDCodeAcnt01IO0102.setDeptCode(inSHDCODE00101Sub08.getDeptCode());
			inDHDCodeAcnt01IO0102.setJcode(inSHDCODE00101Sub08.getJcode());
			inDHDCodeAcnt01IO0102.setJacntcode(inSHDCODE00101Sub08.getJacntcode());
			inDHDCodeAcnt01IO0102.setJacntname(inSHDCODE00101Sub08.getJacntname());
			inDHDCodeAcnt01IO0102.setDetailcode(inSHDCODE00101Sub08.getDetailcode());
			inDHDCodeAcnt01IO0102.setInputDutyId(inSHDCODE00101Sub08.getInputDutyId());
			inDHDCodeAcnt01IO0102.setInputDate(inSHDCODE00101Sub08.getInputDate());
			inDHDCodeAcnt01IO0102.setChgDutyId(inSHDCODE00101Sub08.getChgDutyId());
			inDHDCodeAcnt01IO0102.setChgDate(inSHDCODE00101Sub08.getChgDate());
		}
		inBHDeCodeTest02In.setInDHDCodeAcnt01IO01(inDHDCodeAcnt01IO0102);



		/** ### Execute Bean ### */
		BHDeCodeTest01Out outBHDeCodeTest01Out = bHDeCodeTest.searchField(inBHDeCodeTest01In);
		BHDeCodeTest02Out outBHDeCodeTest02Out = bHDeCodeTest.searchFieldDetail(inBHDeCodeTest02In);

		/** ### Set Output Value  ### */
		out = new SHDCODE00101Out();
	// [OUT-FIELD] size: 2
/**
 [OUT-FIELD] outBHDeCodeTest01Out: {type=D:/Developer/BXMWorkspace/HD-onl/src/kait/hd/code/onl/bc/dto/BHDeCodeTest01Out.omm, calleeAnnotations=[@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")], kind=omm}
calleeOutputType : kait.hd.code.onl.bc.dto.BHDeCodeTest01Out
Type: Integer, Name: outInsertHdAcmastE01, Length: 9, Description: HD_ACMAST_E 등록 결과, ArrayReference: null, ArrayReferenceType: null
Type: kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO, Name: outDHDCodeAcnt01IO, Length: 0, Description: HD_분양_전표_계정 ( HD_CODE_ACNT ), ArrayReference: null, ArrayReferenceType: null
Type: Integer, Name: outSelectCountHdCodeAgency01, Length: 9, Description: HD_코드-대행사 전채건수조회 결과, ArrayReference: null, ArrayReferenceType: null
Type: Integer, Name: outSelectListHdCodeAcnt01Cnt, Length: 9, Description: HD_분양_전표_계정 목록조회 결과 건수, ArrayReference: null, ArrayReferenceType: null
Type: kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO, Name: outSelectListHdCodeAcnt01List, Length: 0, Description: HD_분양_전표_계정 목록조회 결과, ArrayReference: outSelectListHdCodeAcnt01Cnt, ArrayReferenceType: null

 [OUT-FIELD] outBHDeCodeTest02Out: {type=D:/Developer/BXMWorkspace/HD-onl/src/kait/hd/code/onl/bc/dto/BHDeCodeTest02Out.omm, calleeAnnotations=[@BxmCategory(logicalName = "현장 다건조회", description = "현장 다건조회")], kind=omm}
calleeOutputType : kait.hd.code.onl.bc.dto.BHDeCodeTest02Out
Type: Integer, Name: outInsertHdAcmastE01, Length: 9, Description: HD_ACMAST_E 등록 결과, ArrayReference: null, ArrayReferenceType: null
Type: kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO, Name: outDHDCodeAcnt01IO, Length: 0, Description: HD_분양_전표_계정 ( HD_CODE_ACNT ), ArrayReference: null, ArrayReferenceType: null
Type: Integer, Name: outSelectCountHdCodeAgency01, Length: 9, Description: HD_코드-대행사 전채건수조회 결과, ArrayReference: null, ArrayReferenceType: null
Type: Integer, Name: outSelectListHdCodeAcnt01Cnt, Length: 9, Description: HD_분양_전표_계정 목록조회 결과 건수, ArrayReference: null, ArrayReferenceType: null
Type: kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO, Name: outSelectListHdCodeAcnt01List, Length: 0, Description: HD_분양_전표_계정 목록조회 결과, ArrayReference: outSelectListHdCodeAcnt01Cnt, ArrayReferenceType: null


*/
		/** ### Set [search] OkResultMessage Code ### */
		CommonHdrUtils.setOkResultMessage("");
		
		logger.debug("[END-SC] searchField output:\n{}", out);
		return out;
	}


	@BxmServiceOperation("SHDCODE00102")
	@BxmCategory(logicalName = "분양계정 조회", description = "분양계정 조회")
	public SHDCODE00102Out getCodeAccount(SHDCODE00102In sHDCODE00102In) throws KaitApplicationException {
		logger.debug("[START-SC] getCodeAccount input:\n{}", sHDCODE00102In);
		
		/** ### Validate Parameter ### */

		/** ### Bean Initialize ### */
		bHDeCodeAccount = DefaultApplicationContext.getBean(bHDeCodeAccount, BHDeCodeAccount.class);

		/** ### Output Variable ### */
		SHDCODE00102Out out = null;
		
		/** ### Set Bean Input Value  ### */
		BHDeCodeAccount01In inBHDeCodeAccount01In = new BHDeCodeAccount01In();
		SHDCODE00102Sub01 inSHDCODE00102Sub01 = sHDCODE00102In.getInSHDCODE00102Sub01();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = new DHDCodeAcnt01IO();

		if( inSHDCODE00102Sub01 != null ) {
			inDHDCodeAcnt01IO.setDeptCode(inSHDCODE00102Sub01.getDeptCode());
			inDHDCodeAcnt01IO.setJcode(inSHDCODE00102Sub01.getJcode());
			inDHDCodeAcnt01IO.setJacntcode(inSHDCODE00102Sub01.getJacntcode());
			inDHDCodeAcnt01IO.setJacntname(inSHDCODE00102Sub01.getJacntname());
			inDHDCodeAcnt01IO.setDetailcode(inSHDCODE00102Sub01.getDetailcode());
			inDHDCodeAcnt01IO.setInputDutyId(inSHDCODE00102Sub01.getInputDutyId());
			inDHDCodeAcnt01IO.setInputDate(inSHDCODE00102Sub01.getInputDate());
			inDHDCodeAcnt01IO.setChgDutyId(inSHDCODE00102Sub01.getChgDutyId());
			inDHDCodeAcnt01IO.setChgDate(inSHDCODE00102Sub01.getChgDate());
		}
		inBHDeCodeAccount01In.setInDHDCodeAcnt01IO(inDHDCodeAcnt01IO);



		/** ### Execute Bean ### */
		BHDeCodeAccount01Out outBHDeCodeAccount01Out = bHDeCodeAccount.getCodeAccount(inBHDeCodeAccount01In);

		/** ### Set Output Value  ### */
		out = new SHDCODE00102Out();
	// [OUT-FIELD] size: 1
/**
 [OUT-FIELD] outBHDeCodeAccount01Out: {type=D:/Developer/BXMWorkspace/HD-onl/src/kait/hd/code/onl/bc/dto/BHDeCodeAccount01Out.omm, calleeAnnotations=[@BxmCategory(logicalName = "분양계정 조회", description = "분양계정 조회")], kind=omm}
calleeOutputType : kait.hd.code.onl.bc.dto.BHDeCodeAccount01Out
Type: Integer, Name: outInsertHdCodeAcnt01, Length: 9, Description: HD_분양_전표_계정 등록 결과, ArrayReference: null, ArrayReferenceType: null


*/
		/** ### Set [get] OkResultMessage Code ### */
		CommonHdrUtils.setOkResultMessage("");
		
		logger.debug("[END-SC] getCodeAccount output:\n{}", out);
		return out;
	}


	@BxmServiceOperation("SHDCODE00103")
	@BxmCategory(logicalName = "분양계정 저장", description = "분양계정 저장")
	public SHDCODE00103Out saveCodeAccount(SHDCODE00103In sHDCODE00103In) throws KaitApplicationException {
		logger.debug("[START-SC] saveCodeAccount input:\n{}", sHDCODE00103In);
		
		/** ### Validate Parameter ### */

		/** ### Bean Initialize ### */

		/** ### Output Variable ### */
		SHDCODE00103Out out = null;
		
		/** ### Set Bean Input Value  ### */

		/** ### Execute Bean ### */

		/** ### Set Output Value  ### */
		out = new SHDCODE00103Out();
	// [OUT-FIELD] size: 0
/**

*/
		/** ### Set [save] OkResultMessage Code ### */
		CommonHdrUtils.setOkResultMessage("");
		
		logger.debug("[END-SC] saveCodeAccount output:\n{}", out);
		return out;
	}



}	
