/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeSihangHist01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST", description = "HD_CODE_SIHANG_HIST")
public interface DHDCodeSihangHist01
{
	/**
	 * HD_CODE_SIHANG_HIST 등록
	 * @TestValues 	histDate=; deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST 등록", description = "HD_CODE_SIHANG_HIST 등록")
	int insertHdCodeSihangHist01(kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO dHDCodeSihangHist01IO);

	/**
	 * HD_CODE_SIHANG_HIST 단건조회
	 * @TestValues 	histDate=; deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST 단건조회", description = "HD_CODE_SIHANG_HIST 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO selectHdCodeSihangHist01(kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO dHDCodeSihangHist01IO);

	/**
	 * HD_CODE_SIHANG_HIST 전채건수조회
	 * @TestValues 	histDate=; deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST 전채건수조회", description = "HD_CODE_SIHANG_HIST 전채건수조회")
	java.lang.Integer selectCountHdCodeSihangHist01(kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO dHDCodeSihangHist01IO);

	/**
	 * HD_CODE_SIHANG_HIST 목록조회
	 * @TestValues 	histDate=; deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST 목록조회", description = "HD_CODE_SIHANG_HIST 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO> selectListHdCodeSihangHist01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_CODE_SIHANG_HIST 수정
	 * @TestValues 	histDate=; deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST 수정", description = "HD_CODE_SIHANG_HIST 수정")
	int updateHdCodeSihangHist01(kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO dHDCodeSihangHist01IO);

	/**
	 * HD_CODE_SIHANG_HIST 삭제
	 * @TestValues 	histDate=; deptCode=; seq=; sihangVendor=; sihangDepyo=; sihangUpte=; sihangUpjong=; sihangZip=; sihangAddr1=; sihangAddr2=; inputDutyId=; inputDate=; chgDutyId=; sihangName=; chgDate=; sihangZipOrg=; sihangAddr1Org=; sihangAddr2Org=; sihangAddrTag=; triTag=; 
	 */
	@BxmCategory(logicalName = "HD_CODE_SIHANG_HIST 삭제", description = "HD_CODE_SIHANG_HIST 삭제")
	int deleteHdCodeSihangHist01(kait.hd.code.onl.dao.dto.DHDCodeSihangHist01IO dHDCodeSihangHist01IO);


}
