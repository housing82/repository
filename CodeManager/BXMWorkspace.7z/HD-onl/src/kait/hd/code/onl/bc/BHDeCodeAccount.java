package kait.hd.code.onl.bc;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import bxm.common.annotaion.BxmCategory;
import bxm.container.annotation.BxmBean;
import bxm.dft.app.KaitApplicationException;
import bxm.dft.context.DefaultApplicationContext;

import kait.hd.code.onl.bc.dto.BHDeCodeAccount01In;
import kait.hd.code.onl.bc.dto.BHDeCodeAccount01Out;
import kait.hd.code.onl.bc.dto.BHDeCodeAccount02In;
import kait.hd.code.onl.bc.dto.BHDeCodeAccount02Out;
import kait.hd.code.onl.dao.DHDCodeAcnt01;
import kait.hd.code.onl.dao.DHDCodeAgency01;
import kait.hd.code.onl.dao.dto.DHDCodeAcnt01IO;
import kait.hd.code.onl.dao.dto.DHDCodeAgency01IO;


/**
 * Generated Code Skeleton 2017-06-23 18:03:49
 * 
 * <b>History :</b>
 * <pre>
 * 
 * 버전          성명                   일자              변경내용
 * -------       ----------------       -----------       -----------------
 * 0.1           CodeSkeleton       			2017-06-23 18:03:49          신규작성
 * </pre>
 * 
 * @since 2017-06-23 18:03:49
 * @version 3.0.0
 * @author Developer
 * @see "BXM Bean"
 */
@BxmBean
@BxmCategory(type = "BC", logicalName = "분양계정관리", description = "분양계정관리")
public class BHDeCodeAccount {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private DHDCodeAcnt01 dHDCodeAcnt01;
	private DHDCodeAgency01 dHDCodeAgency01;

	
	@BxmCategory(logicalName = "분양계정 조회", description = "분양계정 조회")
	public BHDeCodeAccount01Out getCodeAccount(BHDeCodeAccount01In bHDeCodeAccount01In) throws KaitApplicationException {
		logger.debug("[START-BC] getCodeAccount input:\n{}", bHDeCodeAccount01In);

		if(bHDeCodeAccount01In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);

		/** ### Output Variable ### */
		BHDeCodeAccount01Out out = null;

		/** ### Callee Input Setting ### */
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeAccount01In.getInDHDCodeAcnt01IO();

		/** ### Execute Callee ### */
		int outInsertHdCodeAcnt01 = dHDCodeAcnt01.insertHdCodeAcnt01(inDHDCodeAcnt01IO);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeAccount01Out();
		out.setOutInsertHdCodeAcnt01(outInsertHdCodeAcnt01);


		logger.debug("[END-BC] getCodeAccount output:\n{}", out);
		return out;
	}


	@BxmCategory(logicalName = "분양계정 저장", description = "분양계정 저장")
	public BHDeCodeAccount02Out saveCodeAccount(BHDeCodeAccount02In bHDeCodeAccount02In) throws KaitApplicationException {
		logger.debug("[START-BC] saveCodeAccount input:\n{}", bHDeCodeAccount02In);

		if(bHDeCodeAccount02In == null) {
			//메시지코드 결정후 일괄치환
			throw new KaitApplicationException("", new Object[]{"Input OMM Parameter is null"});
		}

		/** ### Callee Initialize ### */
		dHDCodeAgency01 = DefaultApplicationContext.getBean(dHDCodeAgency01, DHDCodeAgency01.class);
		dHDCodeAcnt01 = DefaultApplicationContext.getBean(dHDCodeAcnt01, DHDCodeAcnt01.class);

		/** ### Output Variable ### */
		BHDeCodeAccount02Out out = null;
		Integer delCnt = 0;
		Integer updCnt = 0;
		Integer insCnt = 0;

		/** ### Callee Input Setting ### */
		List<DHDCodeAgency01IO> inDeleteDHDCodeAgency01IOList = bHDeCodeAccount02In.getInDeleteDHDCodeAgency01IOList();
		List<DHDCodeAgency01IO> inUpdateDHDCodeAgency01IOList = bHDeCodeAccount02In.getInUpdateDHDCodeAgency01IOList();
		List<DHDCodeAcnt01IO> insertDHDCodeAcnt01IOList = bHDeCodeAccount02In.getInsertDHDCodeAcnt01IOList();
		DHDCodeAcnt01IO inDHDCodeAcnt01IO = bHDeCodeAccount02In.getInDHDCodeAcnt01IO();
		int inPageNum = 0;
		int inPageCount = 0;

		DHDCodeAgency01IO inDHDCodeAgency01IO = bHDeCodeAccount02In.getInDHDCodeAgency01IO();

		/** ### Execute Save Callee ### */
		// delete
		if(inDeleteDHDCodeAgency01IOList != null) {
			for(DHDCodeAgency01IO item : inDeleteDHDCodeAgency01IOList) {
				/** ### Execute Delete ### */
				delCnt = delCnt + dHDCodeAgency01.deleteHdCodeAgency01(item);
			}
		}
		logger.debug("- saveCodeAccount delete count: {}", delCnt);

		// update
		if(inUpdateDHDCodeAgency01IOList != null) {
			for(DHDCodeAgency01IO item : inUpdateDHDCodeAgency01IOList) {
				/** ### Execute Update ### */
				updCnt = updCnt + dHDCodeAgency01.updateHdCodeAgency01(item);
			}
		}
		logger.debug("- saveCodeAccount update count: {}", updCnt);

		// insert
		if(insertDHDCodeAcnt01IOList != null) {
			for(DHDCodeAcnt01IO item : insertDHDCodeAcnt01IOList) {
				/** ### Execute Insert ### */
				insCnt = insCnt + dHDCodeAcnt01.insertHdCodeAcnt01(item);
			}
		}
		logger.debug("- saveCodeAccount insert count: {}", insCnt);

		/** ### Execute Callee ### */
		List<DHDCodeAcnt01IO> outSelectListHdCodeAcnt01List = dHDCodeAcnt01.selectListHdCodeAcnt01(inDHDCodeAcnt01IO, inPageNum, inPageCount);
		int outInsertHdCodeAgency01 = dHDCodeAgency01.insertHdCodeAgency01(inDHDCodeAgency01IO);

		/** ### Caller Output Setting ### */
		out = new BHDeCodeAccount02Out();
		out.setDelCnt(delCnt);
		out.setUpdCnt(updCnt);
		out.setInsCnt(insCnt);
		out.setOutSelectListHdCodeAcnt01List(outSelectListHdCodeAcnt01List);
		out.setOutInsertHdCodeAgency01(outInsertHdCodeAgency01);

		
		logger.debug("[END-BC] saveCodeAccount trxCount: {}, output:\n{}", (delCnt + updCnt + insCnt), out);
		return out;		
	}



}	
