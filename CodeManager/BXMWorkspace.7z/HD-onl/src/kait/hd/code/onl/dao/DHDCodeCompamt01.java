/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/code/onl/daoDHDCodeCompamt01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_코드-국민주택기금", description = "HD_코드-국민주택기금")
public interface DHDCodeCompamt01
{
	/**
	 * HD_코드-국민주택기금 등록
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 등록", description = "HD_코드-국민주택기금 등록")
	int insertHdCodeCompamt01(kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO dHDCodeCompamt01IO);

	/**
	 * HD_코드-국민주택기금 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 단건조회", description = "HD_코드-국민주택기금 단건조회")
	kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO selectHdCodeCompamt01(kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO dHDCodeCompamt01IO);

	/**
	 * HD_코드-국민주택기금 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 전채건수조회", description = "HD_코드-국민주택기금 전채건수조회")
	java.lang.Integer selectCountHdCodeCompamt01(kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO dHDCodeCompamt01IO);

	/**
	 * HD_코드-국민주택기금 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 목록조회", description = "HD_코드-국민주택기금 목록조회")
	java.util.List<kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO> selectListHdCodeCompamt01(
			@Param("in") kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_코드-국민주택기금 수정
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 수정", description = "HD_코드-국민주택기금 수정")
	int updateHdCodeCompamt01(kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO dHDCodeCompamt01IO);

	/**
	 * HD_코드-국민주택기금 병합
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 병합", description = "HD_코드-국민주택기금 병합")
	int mergeHdCodeCompamt01(kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO dHDCodeCompamt01IO);

	/**
	 * HD_코드-국민주택기금 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; compDate=; compAmt=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_코드-국민주택기금 삭제", description = "HD_코드-국민주택기금 삭제")
	int deleteHdCodeCompamt01(kait.hd.code.onl.dao.dto.DHDCodeCompamt01IO dHDCodeCompamt01IO);


}
