/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.tax.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/tax/onl/daoDHDTaxCalculateReal01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_세금계산서_실입금", description = "HD_분양_세금계산서_실입금")
public interface DHDTaxCalculateReal01
{
	/**
	 * HD_분양_세금계산서_실입금 등록
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 등록", description = "HD_분양_세금계산서_실입금 등록")
	int insertHdTaxCalculateReal01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO dHDTaxCalculateReal01IO);

	/**
	 * HD_분양_세금계산서_실입금 단건조회
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 단건조회", description = "HD_분양_세금계산서_실입금 단건조회")
	kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO selectHdTaxCalculateReal01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO dHDTaxCalculateReal01IO);

	/**
	 * HD_분양_세금계산서_실입금 전채건수조회
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 전채건수조회", description = "HD_분양_세금계산서_실입금 전채건수조회")
	java.lang.Integer selectCountHdTaxCalculateReal01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO dHDTaxCalculateReal01IO);

	/**
	 * HD_분양_세금계산서_실입금 목록조회
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 목록조회", description = "HD_분양_세금계산서_실입금 목록조회")
	java.util.List<kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO> selectListHdTaxCalculateReal01(
			@Param("in") kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_세금계산서_실입금 수정
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 수정", description = "HD_분양_세금계산서_실입금 수정")
	int updateHdTaxCalculateReal01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO dHDTaxCalculateReal01IO);

	/**
	 * HD_분양_세금계산서_실입금 병합
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 병합", description = "HD_분양_세금계산서_실입금 병합")
	int mergeHdTaxCalculateReal01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO dHDTaxCalculateReal01IO);

	/**
	 * HD_분양_세금계산서_실입금 삭제
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_실입금 삭제", description = "HD_분양_세금계산서_실입금 삭제")
	int deleteHdTaxCalculateReal01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateReal01IO dHDTaxCalculateReal01IO);


}
