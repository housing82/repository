/**
 * Generated Code Skeleton 2017-06-13 18:26:41 
 */
package kait.hd.tax.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/tax/onl/daoDHDTaxCalcHistory01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력", description = "HD_분양_세금계산서_작업이력")
public interface DHDTaxCalcHistory01
{
	/**
	 * HD_분양_세금계산서_작업이력 등록
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 등록", description = "HD_분양_세금계산서_작업이력 등록")
	int insertHdTaxCalcHistory01(kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO dHDTaxCalcHistory01IO);

	/**
	 * HD_분양_세금계산서_작업이력 단건조회
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 단건조회", description = "HD_분양_세금계산서_작업이력 단건조회")
	kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO selectHdTaxCalcHistory01(kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO dHDTaxCalcHistory01IO);

	/**
	 * HD_분양_세금계산서_작업이력 전채건수조회
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 전채건수조회", description = "HD_분양_세금계산서_작업이력 전채건수조회")
	java.lang.Integer selectCountHdTaxCalcHistory01(kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO dHDTaxCalcHistory01IO);

	/**
	 * HD_분양_세금계산서_작업이력 목록조회
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 목록조회", description = "HD_분양_세금계산서_작업이력 목록조회")
	java.util.List<kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO> selectListHdTaxCalcHistory01(
			@Param("in") kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_세금계산서_작업이력 수정
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 수정", description = "HD_분양_세금계산서_작업이력 수정")
	int updateHdTaxCalcHistory01(kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO dHDTaxCalcHistory01IO);

	/**
	 * HD_분양_세금계산서_작업이력 병합
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 병합", description = "HD_분양_세금계산서_작업이력 병합")
	int mergeHdTaxCalcHistory01(kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO dHDTaxCalcHistory01IO);

	/**
	 * HD_분양_세금계산서_작업이력 삭제
	 * @TestValues 	deptCode=; housetag=; workDate=; termFr=; termTo=; targetCnt=; workCnt=; endYn=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_작업이력 삭제", description = "HD_분양_세금계산서_작업이력 삭제")
	int deleteHdTaxCalcHistory01(kait.hd.tax.onl.dao.dto.DHDTaxCalcHistory01IO dHDTaxCalcHistory01IO);


}
