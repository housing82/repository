/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.tax.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/tax/onl/daoDHDTaxCalculateAgree01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액", description = "HD_분양_세금계산서_약정금액")
public interface DHDTaxCalculateAgree01
{
	/**
	 * HD_분양_세금계산서_약정금액 등록
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 등록", description = "HD_분양_세금계산서_약정금액 등록")
	int insertHdTaxCalculateAgree01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO dHDTaxCalculateAgree01IO);

	/**
	 * HD_분양_세금계산서_약정금액 단건조회
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 단건조회", description = "HD_분양_세금계산서_약정금액 단건조회")
	kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO selectHdTaxCalculateAgree01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO dHDTaxCalculateAgree01IO);

	/**
	 * HD_분양_세금계산서_약정금액 전채건수조회
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 전채건수조회", description = "HD_분양_세금계산서_약정금액 전채건수조회")
	java.lang.Integer selectCountHdTaxCalculateAgree01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO dHDTaxCalculateAgree01IO);

	/**
	 * HD_분양_세금계산서_약정금액 목록조회
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 목록조회", description = "HD_분양_세금계산서_약정금액 목록조회")
	java.util.List<kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO> selectListHdTaxCalculateAgree01(
			@Param("in") kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_세금계산서_약정금액 수정
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 수정", description = "HD_분양_세금계산서_약정금액 수정")
	int updateHdTaxCalculateAgree01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO dHDTaxCalculateAgree01IO);

	/**
	 * HD_분양_세금계산서_약정금액 병합
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 병합", description = "HD_분양_세금계산서_약정금액 병합")
	int mergeHdTaxCalculateAgree01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO dHDTaxCalculateAgree01IO);

	/**
	 * HD_분양_세금계산서_약정금액 삭제
	 * @TestValues 	deptCode=; housetag=; counts=; times=; calculatetag=; transactioncode=; demandtag=; receiptdate=; buildno=; houseno=; changetag=; kun=; ho=; square=; sangho=; represantation=; addr=; addr2=; uptae=; upjong=; blank=; supplyamt=; landamt=; buildamt=; vatamt=; specialname=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_세금계산서_약정금액 삭제", description = "HD_분양_세금계산서_약정금액 삭제")
	int deleteHdTaxCalculateAgree01(kait.hd.tax.onl.dao.dto.DHDTaxCalculateAgree01IO dHDTaxCalculateAgree01IO);


}
