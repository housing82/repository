/**
 * Generated Code Skeleton 2017-06-13 18:26:41 
 */
package kait.hd.temp.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/temp/onl/daoDHDTempVirtureDeposit01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT", description = "HD_TEMP_VIRTURE_DEPOSIT")
public interface DHDTempVirtureDeposit01
{
	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 등록
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 등록", description = "HD_TEMP_VIRTURE_DEPOSIT 등록")
	int insertHdTempVirtureDeposit01(kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO dHDTempVirtureDeposit01IO);

	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 단건조회
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 단건조회", description = "HD_TEMP_VIRTURE_DEPOSIT 단건조회")
	kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO selectHdTempVirtureDeposit01(kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO dHDTempVirtureDeposit01IO);

	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 전채건수조회
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 전채건수조회", description = "HD_TEMP_VIRTURE_DEPOSIT 전채건수조회")
	java.lang.Integer selectCountHdTempVirtureDeposit01(kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO dHDTempVirtureDeposit01IO);

	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 목록조회
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 목록조회", description = "HD_TEMP_VIRTURE_DEPOSIT 목록조회")
	java.util.List<kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO> selectListHdTempVirtureDeposit01(
			@Param("in") kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 수정
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 수정", description = "HD_TEMP_VIRTURE_DEPOSIT 수정")
	int updateHdTempVirtureDeposit01(kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO dHDTempVirtureDeposit01IO);

	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 병합
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 병합", description = "HD_TEMP_VIRTURE_DEPOSIT 병합")
	int mergeHdTempVirtureDeposit01(kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO dHDTempVirtureDeposit01IO);

	/**
	 * HD_TEMP_VIRTURE_DEPOSIT 삭제
	 * @TestValues 	virDepositno=; makeSeq=; 
	 */
	@BxmCategory(logicalName = "HD_TEMP_VIRTURE_DEPOSIT 삭제", description = "HD_TEMP_VIRTURE_DEPOSIT 삭제")
	int deleteHdTempVirtureDeposit01(kait.hd.temp.onl.dao.dto.DHDTempVirtureDeposit01IO dHDTempVirtureDeposit01IO);


}
