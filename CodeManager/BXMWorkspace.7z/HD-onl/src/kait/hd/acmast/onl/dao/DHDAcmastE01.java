/**
 * Generated Code Skeleton 2017-06-13 18:26:36 
 */
package kait.hd.acmast.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/acmast/onl/daoDHDAcmastE01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_ACMAST_E", description = "HD_ACMAST_E")
public interface DHDAcmastE01
{
	/**
	 * HD_ACMAST_E 등록
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 등록", description = "HD_ACMAST_E 등록")
	int insertHdAcmastE01(kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO dHDAcmastE01IO);

	/**
	 * HD_ACMAST_E 단건조회
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 단건조회", description = "HD_ACMAST_E 단건조회")
	kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO selectHdAcmastE01(kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO dHDAcmastE01IO);

	/**
	 * HD_ACMAST_E 전채건수조회
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 전채건수조회", description = "HD_ACMAST_E 전채건수조회")
	java.lang.Integer selectCountHdAcmastE01(kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO dHDAcmastE01IO);

	/**
	 * HD_ACMAST_E 목록조회
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 목록조회", description = "HD_ACMAST_E 목록조회")
	java.util.List<kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO> selectListHdAcmastE01(
			@Param("in") kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_ACMAST_E 수정
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 수정", description = "HD_ACMAST_E 수정")
	int updateHdAcmastE01(kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO dHDAcmastE01IO);

	/**
	 * HD_ACMAST_E 병합
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 병합", description = "HD_ACMAST_E 병합")
	int mergeHdAcmastE01(kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO dHDAcmastE01IO);

	/**
	 * HD_ACMAST_E 삭제
	 * @TestValues 	jcode=; jacntcode=; jacntname=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_ACMAST_E 삭제", description = "HD_ACMAST_E 삭제")
	int deleteHdAcmastE01(kait.hd.acmast.onl.dao.dto.DHDAcmastE01IO dHDAcmastE01IO);


}
