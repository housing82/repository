/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.sale.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/sale/onl/daoDHDSaleEtc01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별 제한사항", description = "HD_계약_세대별 제한사항")
public interface DHDSaleEtc01
{
	/**
	 * HD_계약_세대별 제한사항 등록
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 등록", description = "HD_계약_세대별 제한사항 등록")
	int insertHdSaleEtc01(kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO dHDSaleEtc01IO);

	/**
	 * HD_계약_세대별 제한사항 단건조회
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 단건조회", description = "HD_계약_세대별 제한사항 단건조회")
	kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO selectHdSaleEtc01(kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO dHDSaleEtc01IO);

	/**
	 * HD_계약_세대별 제한사항 전채건수조회
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 전채건수조회", description = "HD_계약_세대별 제한사항 전채건수조회")
	java.lang.Integer selectCountHdSaleEtc01(kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO dHDSaleEtc01IO);

	/**
	 * HD_계약_세대별 제한사항 목록조회
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 목록조회", description = "HD_계약_세대별 제한사항 목록조회")
	java.util.List<kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO> selectListHdSaleEtc01(
			@Param("in") kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별 제한사항 수정
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 수정", description = "HD_계약_세대별 제한사항 수정")
	int updateHdSaleEtc01(kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO dHDSaleEtc01IO);

	/**
	 * HD_계약_세대별 제한사항 병합
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 병합", description = "HD_계약_세대별 제한사항 병합")
	int mergeHdSaleEtc01(kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO dHDSaleEtc01IO);

	/**
	 * HD_계약_세대별 제한사항 삭제
	 * @TestValues 	custCode=; seq=; etcSeq=; uniqueDiv=; effectNo=; deliveryDate=; creditor=; bondAmt=; cancelYn=; cancelDate=; cancelDesc=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별 제한사항 삭제", description = "HD_계약_세대별 제한사항 삭제")
	int deleteHdSaleEtc01(kait.hd.sale.onl.dao.dto.DHDSaleEtc01IO dHDSaleEtc01IO);


}
