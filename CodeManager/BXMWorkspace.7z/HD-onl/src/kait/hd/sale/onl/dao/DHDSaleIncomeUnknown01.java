/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.sale.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/sale/onl/daoDHDSaleIncomeUnknown01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_불명자료", description = "HD_분양_불명자료")
public interface DHDSaleIncomeUnknown01
{
	/**
	 * HD_분양_불명자료 등록
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 등록", description = "HD_분양_불명자료 등록")
	int insertHdSaleIncomeUnknown01(kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO dHDSaleIncomeUnknown01IO);

	/**
	 * HD_분양_불명자료 단건조회
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 단건조회", description = "HD_분양_불명자료 단건조회")
	kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO selectHdSaleIncomeUnknown01(kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO dHDSaleIncomeUnknown01IO);

	/**
	 * HD_분양_불명자료 전채건수조회
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 전채건수조회", description = "HD_분양_불명자료 전채건수조회")
	java.lang.Integer selectCountHdSaleIncomeUnknown01(kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO dHDSaleIncomeUnknown01IO);

	/**
	 * HD_분양_불명자료 목록조회
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 목록조회", description = "HD_분양_불명자료 목록조회")
	java.util.List<kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO> selectListHdSaleIncomeUnknown01(
			@Param("in") kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_불명자료 수정
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 수정", description = "HD_분양_불명자료 수정")
	int updateHdSaleIncomeUnknown01(kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO dHDSaleIncomeUnknown01IO);

	/**
	 * HD_분양_불명자료 병합
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 병합", description = "HD_분양_불명자료 병합")
	int mergeHdSaleIncomeUnknown01(kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO dHDSaleIncomeUnknown01IO);

	/**
	 * HD_분양_불명자료 삭제
	 * @TestValues 	deptCode=; housetag=; receiptDate=; seq=; receiptCode=; depositNo=; rAmt=; confirmAmt=; ptag=; memo=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_불명자료 삭제", description = "HD_분양_불명자료 삭제")
	int deleteHdSaleIncomeUnknown01(kait.hd.sale.onl.dao.dto.DHDSaleIncomeUnknown01IO dHDSaleIncomeUnknown01IO);


}
