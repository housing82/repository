/**
 * Generated Code Skeleton 2017-06-13 18:26:41 
 */
package kait.hd.virture.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/virture/onl/daoDHDVirtureAccount01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_가상계좌", description = "HD_분양_가상계좌")
public interface DHDVirtureAccount01
{
	/**
	 * HD_분양_가상계좌 등록
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 등록", description = "HD_분양_가상계좌 등록")
	int insertHdVirtureAccount01(kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO dHDVirtureAccount01IO);

	/**
	 * HD_분양_가상계좌 단건조회
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 단건조회", description = "HD_분양_가상계좌 단건조회")
	kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO selectHdVirtureAccount01(kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO dHDVirtureAccount01IO);

	/**
	 * HD_분양_가상계좌 전채건수조회
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 전채건수조회", description = "HD_분양_가상계좌 전채건수조회")
	java.lang.Integer selectCountHdVirtureAccount01(kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO dHDVirtureAccount01IO);

	/**
	 * HD_분양_가상계좌 목록조회
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 목록조회", description = "HD_분양_가상계좌 목록조회")
	java.util.List<kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO> selectListHdVirtureAccount01(
			@Param("in") kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_가상계좌 수정
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 수정", description = "HD_분양_가상계좌 수정")
	int updateHdVirtureAccount01(kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO dHDVirtureAccount01IO);

	/**
	 * HD_분양_가상계좌 병합
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 병합", description = "HD_분양_가상계좌 병합")
	int mergeHdVirtureAccount01(kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO dHDVirtureAccount01IO);

	/**
	 * HD_분양_가상계좌 삭제
	 * @TestValues 	troccorgCd=; trIl=; cporgCd=; deptrSeq=; hndorgCd=; trSi=; txSeq=; txCd=; trCd=; fnGb=; vaNo=; depbnkCd=; depAmt=; ytstjmAmt=; depbnkNm=; custNm=; deptSt=; depcntGb=; 
	 */
	@BxmCategory(logicalName = "HD_분양_가상계좌 삭제", description = "HD_분양_가상계좌 삭제")
	int deleteHdVirtureAccount01(kait.hd.virture.onl.dao.dto.DHDVirtureAccount01IO dHDVirtureAccount01IO);


}
