/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSquaredetailCnt01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수", description = "HD_기본_평형별약정_변경차수")
public interface DHDReferSquaredetailCnt01
{
	/**
	 * HD_기본_평형별약정_변경차수 등록
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 등록", description = "HD_기본_평형별약정_변경차수 등록")
	int insertHdReferSquaredetailCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO dHDReferSquaredetailCnt01IO);

	/**
	 * HD_기본_평형별약정_변경차수 단건조회
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 단건조회", description = "HD_기본_평형별약정_변경차수 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO selectHdReferSquaredetailCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO dHDReferSquaredetailCnt01IO);

	/**
	 * HD_기본_평형별약정_변경차수 전채건수조회
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 전채건수조회", description = "HD_기본_평형별약정_변경차수 전채건수조회")
	java.lang.Integer selectCountHdReferSquaredetailCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO dHDReferSquaredetailCnt01IO);

	/**
	 * HD_기본_평형별약정_변경차수 목록조회
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 목록조회", description = "HD_기본_평형별약정_변경차수 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO> selectListHdReferSquaredetailCnt01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_평형별약정_변경차수 수정
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 수정", description = "HD_기본_평형별약정_변경차수 수정")
	int updateHdReferSquaredetailCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO dHDReferSquaredetailCnt01IO);

	/**
	 * HD_기본_평형별약정_변경차수 병합
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 병합", description = "HD_기본_평형별약정_변경차수 병합")
	int mergeHdReferSquaredetailCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO dHDReferSquaredetailCnt01IO);

	/**
	 * HD_기본_평형별약정_변경차수 삭제
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; counts=; agreedate=; landamt=; buildamt=; vatamt=; bamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_변경차수 삭제", description = "HD_기본_평형별약정_변경차수 삭제")
	int deleteHdReferSquaredetailCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailCnt01IO dHDReferSquaredetailCnt01IO);


}
