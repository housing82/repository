/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSelldetailHist01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별약정_이력", description = "HD_기본_세대별약정_이력")
public interface DHDReferSelldetailHist01
{
	/**
	 * HD_기본_세대별약정_이력 등록
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 등록", description = "HD_기본_세대별약정_이력 등록")
	int insertHdReferSelldetailHist01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO dHDReferSelldetailHist01IO);

	/**
	 * HD_기본_세대별약정_이력 단건조회
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 단건조회", description = "HD_기본_세대별약정_이력 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO selectHdReferSelldetailHist01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO dHDReferSelldetailHist01IO);

	/**
	 * HD_기본_세대별약정_이력 전채건수조회
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 전채건수조회", description = "HD_기본_세대별약정_이력 전채건수조회")
	java.lang.Integer selectCountHdReferSelldetailHist01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO dHDReferSelldetailHist01IO);

	/**
	 * HD_기본_세대별약정_이력 목록조회
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 목록조회", description = "HD_기본_세대별약정_이력 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO> selectListHdReferSelldetailHist01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별약정_이력 수정
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 수정", description = "HD_기본_세대별약정_이력 수정")
	int updateHdReferSelldetailHist01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO dHDReferSelldetailHist01IO);

	/**
	 * HD_기본_세대별약정_이력 병합
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 병합", description = "HD_기본_세대별약정_이력 병합")
	int mergeHdReferSelldetailHist01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO dHDReferSelldetailHist01IO);

	/**
	 * HD_기본_세대별약정_이력 삭제
	 * @TestValues 	histDate=; deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; triTag=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정_이력 삭제", description = "HD_기본_세대별약정_이력 삭제")
	int deleteHdReferSelldetailHist01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailHist01IO dHDReferSelldetailHist01IO);


}
