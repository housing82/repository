/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferIncomebill01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_납부안내입력자료", description = "HD_기본_납부안내입력자료")
public interface DHDReferIncomebill01
{
	/**
	 * HD_기본_납부안내입력자료 등록
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 등록", description = "HD_기본_납부안내입력자료 등록")
	int insertHdReferIncomebill01(kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO dHDReferIncomebill01IO);

	/**
	 * HD_기본_납부안내입력자료 단건조회
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 단건조회", description = "HD_기본_납부안내입력자료 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO selectHdReferIncomebill01(kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO dHDReferIncomebill01IO);

	/**
	 * HD_기본_납부안내입력자료 전채건수조회
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 전채건수조회", description = "HD_기본_납부안내입력자료 전채건수조회")
	java.lang.Integer selectCountHdReferIncomebill01(kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO dHDReferIncomebill01IO);

	/**
	 * HD_기본_납부안내입력자료 목록조회
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 목록조회", description = "HD_기본_납부안내입력자료 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO> selectListHdReferIncomebill01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_납부안내입력자료 수정
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 수정", description = "HD_기본_납부안내입력자료 수정")
	int updateHdReferIncomebill01(kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO dHDReferIncomebill01IO);

	/**
	 * HD_기본_납부안내입력자료 병합
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 병합", description = "HD_기본_납부안내입력자료 병합")
	int mergeHdReferIncomebill01(kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO dHDReferIncomebill01IO);

	/**
	 * HD_기본_납부안내입력자료 삭제
	 * @TestValues 	deptCode=; housetag=; billTag=; depositNo=; depositor=; payWay=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내입력자료 삭제", description = "HD_기본_납부안내입력자료 삭제")
	int deleteHdReferIncomebill01(kait.hd.refer.onl.dao.dto.DHDReferIncomebill01IO dHDReferIncomebill01IO);


}
