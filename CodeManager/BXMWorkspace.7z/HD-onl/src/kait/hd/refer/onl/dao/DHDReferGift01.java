/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferGift01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_세대별서비스지급", description = "HD_계약_세대별서비스지급")
public interface DHDReferGift01
{
	/**
	 * HD_계약_세대별서비스지급 등록
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 등록", description = "HD_계약_세대별서비스지급 등록")
	int insertHdReferGift01(kait.hd.refer.onl.dao.dto.DHDReferGift01IO dHDReferGift01IO);

	/**
	 * HD_계약_세대별서비스지급 단건조회
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 단건조회", description = "HD_계약_세대별서비스지급 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferGift01IO selectHdReferGift01(kait.hd.refer.onl.dao.dto.DHDReferGift01IO dHDReferGift01IO);

	/**
	 * HD_계약_세대별서비스지급 전채건수조회
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 전채건수조회", description = "HD_계약_세대별서비스지급 전채건수조회")
	java.lang.Integer selectCountHdReferGift01(kait.hd.refer.onl.dao.dto.DHDReferGift01IO dHDReferGift01IO);

	/**
	 * HD_계약_세대별서비스지급 목록조회
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 목록조회", description = "HD_계약_세대별서비스지급 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferGift01IO> selectListHdReferGift01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferGift01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_세대별서비스지급 수정
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 수정", description = "HD_계약_세대별서비스지급 수정")
	int updateHdReferGift01(kait.hd.refer.onl.dao.dto.DHDReferGift01IO dHDReferGift01IO);

	/**
	 * HD_계약_세대별서비스지급 병합
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 병합", description = "HD_계약_세대별서비스지급 병합")
	int mergeHdReferGift01(kait.hd.refer.onl.dao.dto.DHDReferGift01IO dHDReferGift01IO);

	/**
	 * HD_계약_세대별서비스지급 삭제
	 * @TestValues 	deptCode=; housetag=; custCode=; seq=; giftcode=; giftgivedate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_세대별서비스지급 삭제", description = "HD_계약_세대별서비스지급 삭제")
	int deleteHdReferGift01(kait.hd.refer.onl.dao.dto.DHDReferGift01IO dHDReferGift01IO);


}
