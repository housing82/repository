/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSquareCnt01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수", description = "HD_기본_평형별기본_변경차수")
public interface DHDReferSquareCnt01
{
	/**
	 * HD_기본_평형별기본_변경차수 등록
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 등록", description = "HD_기본_평형별기본_변경차수 등록")
	int insertHdReferSquareCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO dHDReferSquareCnt01IO);

	/**
	 * HD_기본_평형별기본_변경차수 단건조회
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 단건조회", description = "HD_기본_평형별기본_변경차수 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO selectHdReferSquareCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO dHDReferSquareCnt01IO);

	/**
	 * HD_기본_평형별기본_변경차수 전채건수조회
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 전채건수조회", description = "HD_기본_평형별기본_변경차수 전채건수조회")
	java.lang.Integer selectCountHdReferSquareCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO dHDReferSquareCnt01IO);

	/**
	 * HD_기본_평형별기본_변경차수 목록조회
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 목록조회", description = "HD_기본_평형별기본_변경차수 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO> selectListHdReferSquareCnt01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_평형별기본_변경차수 수정
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 수정", description = "HD_기본_평형별기본_변경차수 수정")
	int updateHdReferSquareCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO dHDReferSquareCnt01IO);

	/**
	 * HD_기본_평형별기본_변경차수 병합
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 병합", description = "HD_기본_평형별기본_변경차수 병합")
	int mergeHdReferSquareCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO dHDReferSquareCnt01IO);

	/**
	 * HD_기본_평형별기본_변경차수 삭제
	 * @TestValues 	deptCode=; housetag=; cnt=; seq=; cntDate=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본_변경차수 삭제", description = "HD_기본_평형별기본_변경차수 삭제")
	int deleteHdReferSquareCnt01(kait.hd.refer.onl.dao.dto.DHDReferSquareCnt01IO dHDReferSquareCnt01IO);


}
