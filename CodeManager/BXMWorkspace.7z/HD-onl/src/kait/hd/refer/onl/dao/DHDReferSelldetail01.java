/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSelldetail01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별약정", description = "HD_기본_세대별약정")
public interface DHDReferSelldetail01
{
	/**
	 * HD_기본_세대별약정 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 등록", description = "HD_기본_세대별약정 등록")
	int insertHdReferSelldetail01(kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO dHDReferSelldetail01IO);

	/**
	 * HD_기본_세대별약정 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 단건조회", description = "HD_기본_세대별약정 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO selectHdReferSelldetail01(kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO dHDReferSelldetail01IO);

	/**
	 * HD_기본_세대별약정 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 전채건수조회", description = "HD_기본_세대별약정 전채건수조회")
	java.lang.Integer selectCountHdReferSelldetail01(kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO dHDReferSelldetail01IO);

	/**
	 * HD_기본_세대별약정 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 목록조회", description = "HD_기본_세대별약정 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO> selectListHdReferSelldetail01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별약정 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 수정", description = "HD_기본_세대별약정 수정")
	int updateHdReferSelldetail01(kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO dHDReferSelldetail01IO);

	/**
	 * HD_기본_세대별약정 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 병합", description = "HD_기본_세대별약정 병합")
	int mergeHdReferSelldetail01(kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO dHDReferSelldetail01IO);

	/**
	 * HD_기본_세대별약정 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정 삭제", description = "HD_기본_세대별약정 삭제")
	int deleteHdReferSelldetail01(kait.hd.refer.onl.dao.dto.DHDReferSelldetail01IO dHDReferSelldetail01IO);


}
