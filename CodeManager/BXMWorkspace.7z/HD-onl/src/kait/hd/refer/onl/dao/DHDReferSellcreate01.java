/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSellcreate01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_공급세대생성", description = "HD_기본_공급세대생성")
public interface DHDReferSellcreate01
{
	/**
	 * HD_기본_공급세대생성 등록
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 등록", description = "HD_기본_공급세대생성 등록")
	int insertHdReferSellcreate01(kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO dHDReferSellcreate01IO);

	/**
	 * HD_기본_공급세대생성 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 단건조회", description = "HD_기본_공급세대생성 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO selectHdReferSellcreate01(kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO dHDReferSellcreate01IO);

	/**
	 * HD_기본_공급세대생성 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 전채건수조회", description = "HD_기본_공급세대생성 전채건수조회")
	java.lang.Integer selectCountHdReferSellcreate01(kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO dHDReferSellcreate01IO);

	/**
	 * HD_기본_공급세대생성 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 목록조회", description = "HD_기본_공급세대생성 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO> selectListHdReferSellcreate01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_공급세대생성 수정
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 수정", description = "HD_기본_공급세대생성 수정")
	int updateHdReferSellcreate01(kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO dHDReferSellcreate01IO);

	/**
	 * HD_기본_공급세대생성 병합
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 병합", description = "HD_기본_공급세대생성 병합")
	int mergeHdReferSellcreate01(kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO dHDReferSellcreate01IO);

	/**
	 * HD_기본_공급세대생성 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; options=; startBuildno=; startHouseno=; endHouseno=; sedesu=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_공급세대생성 삭제", description = "HD_기본_공급세대생성 삭제")
	int deleteHdReferSellcreate01(kait.hd.refer.onl.dao.dto.DHDReferSellcreate01IO dHDReferSellcreate01IO);


}
