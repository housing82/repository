/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSelldetailChange01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_세대별약정확정", description = "HD_기본_세대별약정확정")
public interface DHDReferSelldetailChange01
{
	/**
	 * HD_기본_세대별약정확정 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 등록", description = "HD_기본_세대별약정확정 등록")
	int insertHdReferSelldetailChange01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO dHDReferSelldetailChange01IO);

	/**
	 * HD_기본_세대별약정확정 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 단건조회", description = "HD_기본_세대별약정확정 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO selectHdReferSelldetailChange01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO dHDReferSelldetailChange01IO);

	/**
	 * HD_기본_세대별약정확정 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 전채건수조회", description = "HD_기본_세대별약정확정 전채건수조회")
	java.lang.Integer selectCountHdReferSelldetailChange01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO dHDReferSelldetailChange01IO);

	/**
	 * HD_기본_세대별약정확정 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 목록조회", description = "HD_기본_세대별약정확정 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO> selectListHdReferSelldetailChange01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_세대별약정확정 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 수정", description = "HD_기본_세대별약정확정 수정")
	int updateHdReferSelldetailChange01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO dHDReferSelldetailChange01IO);

	/**
	 * HD_기본_세대별약정확정 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 병합", description = "HD_기본_세대별약정확정 병합")
	int mergeHdReferSelldetailChange01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO dHDReferSelldetailChange01IO);

	/**
	 * HD_기본_세대별약정확정 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; counts=; agreedate=; agreeamt=; landamt=; buildamt=; vatamt=; dcYn=; acYn=; distributeRate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_세대별약정확정 삭제", description = "HD_기본_세대별약정확정 삭제")
	int deleteHdReferSelldetailChange01(kait.hd.refer.onl.dao.dto.DHDReferSelldetailChange01IO dHDReferSelldetailChange01IO);


}
