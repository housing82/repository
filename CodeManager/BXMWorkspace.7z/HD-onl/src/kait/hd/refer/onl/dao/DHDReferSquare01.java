/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSquare01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_평형별기본", description = "HD_기본_평형별기본")
public interface DHDReferSquare01
{
	/**
	 * HD_기본_평형별기본 등록
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 등록", description = "HD_기본_평형별기본 등록")
	int insertHdReferSquare01(kait.hd.refer.onl.dao.dto.DHDReferSquare01IO dHDReferSquare01IO);

	/**
	 * HD_기본_평형별기본 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 단건조회", description = "HD_기본_평형별기본 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSquare01IO selectHdReferSquare01(kait.hd.refer.onl.dao.dto.DHDReferSquare01IO dHDReferSquare01IO);

	/**
	 * HD_기본_평형별기본 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 전채건수조회", description = "HD_기본_평형별기본 전채건수조회")
	java.lang.Integer selectCountHdReferSquare01(kait.hd.refer.onl.dao.dto.DHDReferSquare01IO dHDReferSquare01IO);

	/**
	 * HD_기본_평형별기본 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 목록조회", description = "HD_기본_평형별기본 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSquare01IO> selectListHdReferSquare01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSquare01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_평형별기본 수정
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 수정", description = "HD_기본_평형별기본 수정")
	int updateHdReferSquare01(kait.hd.refer.onl.dao.dto.DHDReferSquare01IO dHDReferSquare01IO);

	/**
	 * HD_기본_평형별기본 병합
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 병합", description = "HD_기본_평형별기본 병합")
	int mergeHdReferSquare01(kait.hd.refer.onl.dao.dto.DHDReferSquare01IO dHDReferSquare01IO);

	/**
	 * HD_기본_평형별기본 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; vattag=; exclusivearea=; commonarea=; etccommonarea=; parkingarea=; servicearea=; sitearea=; landamt=; buildamt=; vatamt=; totBamt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; prtsquare=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별기본 삭제", description = "HD_기본_평형별기본 삭제")
	int deleteHdReferSquare01(kait.hd.refer.onl.dao.dto.DHDReferSquare01IO dHDReferSquare01IO);


}
