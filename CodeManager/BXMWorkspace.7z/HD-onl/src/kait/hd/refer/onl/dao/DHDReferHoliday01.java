/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferHoliday01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_현장별휴일적용", description = "HD_기본_현장별휴일적용")
public interface DHDReferHoliday01
{
	/**
	 * HD_기본_현장별휴일적용 등록
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 등록", description = "HD_기본_현장별휴일적용 등록")
	int insertHdReferHoliday01(kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO dHDReferHoliday01IO);

	/**
	 * HD_기본_현장별휴일적용 단건조회
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 단건조회", description = "HD_기본_현장별휴일적용 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO selectHdReferHoliday01(kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO dHDReferHoliday01IO);

	/**
	 * HD_기본_현장별휴일적용 전채건수조회
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 전채건수조회", description = "HD_기본_현장별휴일적용 전채건수조회")
	java.lang.Integer selectCountHdReferHoliday01(kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO dHDReferHoliday01IO);

	/**
	 * HD_기본_현장별휴일적용 목록조회
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 목록조회", description = "HD_기본_현장별휴일적용 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO> selectListHdReferHoliday01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_현장별휴일적용 수정
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 수정", description = "HD_기본_현장별휴일적용 수정")
	int updateHdReferHoliday01(kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO dHDReferHoliday01IO);

	/**
	 * HD_기본_현장별휴일적용 병합
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 병합", description = "HD_기본_현장별휴일적용 병합")
	int mergeHdReferHoliday01(kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO dHDReferHoliday01IO);

	/**
	 * HD_기본_현장별휴일적용 삭제
	 * @TestValues 	deptCode=; housetag=; rateTag=; adTag=; holiday=; gongDays=; ptag=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별휴일적용 삭제", description = "HD_기본_현장별휴일적용 삭제")
	int deleteHdReferHoliday01(kait.hd.refer.onl.dao.dto.DHDReferHoliday01IO dHDReferHoliday01IO);


}
