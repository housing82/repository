/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferIncomedate01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_금융수납처리일자", description = "HD_분양_금융수납처리일자")
public interface DHDReferIncomedate01
{
	/**
	 * HD_분양_금융수납처리일자 등록
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 등록", description = "HD_분양_금융수납처리일자 등록")
	int insertHdReferIncomedate01(kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO dHDReferIncomedate01IO);

	/**
	 * HD_분양_금융수납처리일자 단건조회
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 단건조회", description = "HD_분양_금융수납처리일자 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO selectHdReferIncomedate01(kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO dHDReferIncomedate01IO);

	/**
	 * HD_분양_금융수납처리일자 전채건수조회
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 전채건수조회", description = "HD_분양_금융수납처리일자 전채건수조회")
	java.lang.Integer selectCountHdReferIncomedate01(kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO dHDReferIncomedate01IO);

	/**
	 * HD_분양_금융수납처리일자 목록조회
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 목록조회", description = "HD_분양_금융수납처리일자 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO> selectListHdReferIncomedate01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_금융수납처리일자 수정
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 수정", description = "HD_분양_금융수납처리일자 수정")
	int updateHdReferIncomedate01(kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO dHDReferIncomedate01IO);

	/**
	 * HD_분양_금융수납처리일자 병합
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 병합", description = "HD_분양_금융수납처리일자 병합")
	int mergeHdReferIncomedate01(kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO dHDReferIncomedate01IO);

	/**
	 * HD_분양_금융수납처리일자 삭제
	 * @TestValues 	deptCode=; housetag=; depositNo=; startdate=; q8050tag=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_분양_금융수납처리일자 삭제", description = "HD_분양_금융수납처리일자 삭제")
	int deleteHdReferIncomedate01(kait.hd.refer.onl.dao.dto.DHDReferIncomedate01IO dHDReferIncomedate01IO);


}
