/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferIncomeremark01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_납부안내비고사항", description = "HD_기본_납부안내비고사항")
public interface DHDReferIncomeremark01
{
	/**
	 * HD_기본_납부안내비고사항 등록
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 등록", description = "HD_기본_납부안내비고사항 등록")
	int insertHdReferIncomeremark01(kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO dHDReferIncomeremark01IO);

	/**
	 * HD_기본_납부안내비고사항 단건조회
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 단건조회", description = "HD_기본_납부안내비고사항 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO selectHdReferIncomeremark01(kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO dHDReferIncomeremark01IO);

	/**
	 * HD_기본_납부안내비고사항 전채건수조회
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 전채건수조회", description = "HD_기본_납부안내비고사항 전채건수조회")
	java.lang.Integer selectCountHdReferIncomeremark01(kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO dHDReferIncomeremark01IO);

	/**
	 * HD_기본_납부안내비고사항 목록조회
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 목록조회", description = "HD_기본_납부안내비고사항 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO> selectListHdReferIncomeremark01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_납부안내비고사항 수정
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 수정", description = "HD_기본_납부안내비고사항 수정")
	int updateHdReferIncomeremark01(kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO dHDReferIncomeremark01IO);

	/**
	 * HD_기본_납부안내비고사항 병합
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 병합", description = "HD_기본_납부안내비고사항 병합")
	int mergeHdReferIncomeremark01(kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO dHDReferIncomeremark01IO);

	/**
	 * HD_기본_납부안내비고사항 삭제
	 * @TestValues 	deptCode=; housetag=; billTag=; seq=; remark=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_납부안내비고사항 삭제", description = "HD_기본_납부안내비고사항 삭제")
	int deleteHdReferIncomeremark01(kait.hd.refer.onl.dao.dto.DHDReferIncomeremark01IO dHDReferIncomeremark01IO);


}
