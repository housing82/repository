/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferMovein01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_입주배정", description = "HD_기본_입주배정")
public interface DHDReferMovein01
{
	/**
	 * HD_기본_입주배정 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 등록", description = "HD_기본_입주배정 등록")
	int insertHdReferMovein01(kait.hd.refer.onl.dao.dto.DHDReferMovein01IO dHDReferMovein01IO);

	/**
	 * HD_기본_입주배정 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 단건조회", description = "HD_기본_입주배정 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferMovein01IO selectHdReferMovein01(kait.hd.refer.onl.dao.dto.DHDReferMovein01IO dHDReferMovein01IO);

	/**
	 * HD_기본_입주배정 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 전채건수조회", description = "HD_기본_입주배정 전채건수조회")
	java.lang.Integer selectCountHdReferMovein01(kait.hd.refer.onl.dao.dto.DHDReferMovein01IO dHDReferMovein01IO);

	/**
	 * HD_기본_입주배정 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 목록조회", description = "HD_기본_입주배정 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferMovein01IO> selectListHdReferMovein01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferMovein01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_입주배정 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 수정", description = "HD_기본_입주배정 수정")
	int updateHdReferMovein01(kait.hd.refer.onl.dao.dto.DHDReferMovein01IO dHDReferMovein01IO);

	/**
	 * HD_기본_입주배정 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 병합", description = "HD_기본_입주배정 병합")
	int mergeHdReferMovein01(kait.hd.refer.onl.dao.dto.DHDReferMovein01IO dHDReferMovein01IO);

	/**
	 * HD_기본_입주배정 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; moveinTag=; moveinDate=; publishDate=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_입주배정 삭제", description = "HD_기본_입주배정 삭제")
	int deleteHdReferMovein01(kait.hd.refer.onl.dao.dto.DHDReferMovein01IO dHDReferMovein01IO);


}
