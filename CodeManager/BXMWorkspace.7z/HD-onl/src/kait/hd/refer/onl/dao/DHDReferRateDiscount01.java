/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferRateDiscount01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_현장별할인이율", description = "HD_기본_현장별할인이율")
public interface DHDReferRateDiscount01
{
	/**
	 * HD_기본_현장별할인이율 등록
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 등록", description = "HD_기본_현장별할인이율 등록")
	int insertHdReferRateDiscount01(kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO dHDReferRateDiscount01IO);

	/**
	 * HD_기본_현장별할인이율 단건조회
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 단건조회", description = "HD_기본_현장별할인이율 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO selectHdReferRateDiscount01(kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO dHDReferRateDiscount01IO);

	/**
	 * HD_기본_현장별할인이율 전채건수조회
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 전채건수조회", description = "HD_기본_현장별할인이율 전채건수조회")
	java.lang.Integer selectCountHdReferRateDiscount01(kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO dHDReferRateDiscount01IO);

	/**
	 * HD_기본_현장별할인이율 목록조회
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 목록조회", description = "HD_기본_현장별할인이율 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO> selectListHdReferRateDiscount01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_현장별할인이율 수정
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 수정", description = "HD_기본_현장별할인이율 수정")
	int updateHdReferRateDiscount01(kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO dHDReferRateDiscount01IO);

	/**
	 * HD_기본_현장별할인이율 병합
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 병합", description = "HD_기본_현장별할인이율 병합")
	int mergeHdReferRateDiscount01(kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO dHDReferRateDiscount01IO);

	/**
	 * HD_기본_현장별할인이율 삭제
	 * @TestValues 	deptCode=; housetag=; rateTag=; startdate=; enddate=; discntrate=; discntcut=; discntunit=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_기본_현장별할인이율 삭제", description = "HD_기본_현장별할인이율 삭제")
	int deleteHdReferRateDiscount01(kait.hd.refer.onl.dao.dto.DHDReferRateDiscount01IO dHDReferRateDiscount01IO);


}
