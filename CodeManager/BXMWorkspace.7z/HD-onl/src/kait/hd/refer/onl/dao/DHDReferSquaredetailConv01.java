/**
 * Generated Code Skeleton 2017-06-13 18:26:39 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferSquaredetailConv01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_기본_평형별약정_업로드", description = "HD_기본_평형별약정_업로드")
public interface DHDReferSquaredetailConv01
{
	/**
	 * HD_기본_평형별약정_업로드 등록
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 등록", description = "HD_기본_평형별약정_업로드 등록")
	int insertHdReferSquaredetailConv01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO dHDReferSquaredetailConv01IO);

	/**
	 * HD_기본_평형별약정_업로드 단건조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 단건조회", description = "HD_기본_평형별약정_업로드 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO selectHdReferSquaredetailConv01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO dHDReferSquaredetailConv01IO);

	/**
	 * HD_기본_평형별약정_업로드 전채건수조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 전채건수조회", description = "HD_기본_평형별약정_업로드 전채건수조회")
	java.lang.Integer selectCountHdReferSquaredetailConv01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO dHDReferSquaredetailConv01IO);

	/**
	 * HD_기본_평형별약정_업로드 목록조회
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 목록조회", description = "HD_기본_평형별약정_업로드 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO> selectListHdReferSquaredetailConv01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_기본_평형별약정_업로드 수정
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 수정", description = "HD_기본_평형별약정_업로드 수정")
	int updateHdReferSquaredetailConv01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO dHDReferSquaredetailConv01IO);

	/**
	 * HD_기본_평형별약정_업로드 병합
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 병합", description = "HD_기본_평형별약정_업로드 병합")
	int mergeHdReferSquaredetailConv01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO dHDReferSquaredetailConv01IO);

	/**
	 * HD_기본_평형별약정_업로드 삭제
	 * @TestValues 	deptCode=; housetag=; seq=; square=; type=; classJrw=; optioncode=; counts=; agreedate=; bamt=; landamt=; buildamt=; vatamt=; manageamt=; 
	 */
	@BxmCategory(logicalName = "HD_기본_평형별약정_업로드 삭제", description = "HD_기본_평형별약정_업로드 삭제")
	int deleteHdReferSquaredetailConv01(kait.hd.refer.onl.dao.dto.DHDReferSquaredetailConv01IO dHDReferSquaredetailConv01IO);


}
