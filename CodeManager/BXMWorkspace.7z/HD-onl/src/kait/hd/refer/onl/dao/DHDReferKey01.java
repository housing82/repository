/**
 * Generated Code Skeleton 2017-06-13 18:26:38 
 */
package kait.hd.refer.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/refer/onl/daoDHDReferKey01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_계약_열쇠인수", description = "HD_계약_열쇠인수")
public interface DHDReferKey01
{
	/**
	 * HD_계약_열쇠인수 등록
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 등록", description = "HD_계약_열쇠인수 등록")
	int insertHdReferKey01(kait.hd.refer.onl.dao.dto.DHDReferKey01IO dHDReferKey01IO);

	/**
	 * HD_계약_열쇠인수 단건조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 단건조회", description = "HD_계약_열쇠인수 단건조회")
	kait.hd.refer.onl.dao.dto.DHDReferKey01IO selectHdReferKey01(kait.hd.refer.onl.dao.dto.DHDReferKey01IO dHDReferKey01IO);

	/**
	 * HD_계약_열쇠인수 전채건수조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 전채건수조회", description = "HD_계약_열쇠인수 전채건수조회")
	java.lang.Integer selectCountHdReferKey01(kait.hd.refer.onl.dao.dto.DHDReferKey01IO dHDReferKey01IO);

	/**
	 * HD_계약_열쇠인수 목록조회
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 목록조회", description = "HD_계약_열쇠인수 목록조회")
	java.util.List<kait.hd.refer.onl.dao.dto.DHDReferKey01IO> selectListHdReferKey01(
			@Param("in") kait.hd.refer.onl.dao.dto.DHDReferKey01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_계약_열쇠인수 수정
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 수정", description = "HD_계약_열쇠인수 수정")
	int updateHdReferKey01(kait.hd.refer.onl.dao.dto.DHDReferKey01IO dHDReferKey01IO);

	/**
	 * HD_계약_열쇠인수 병합
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 병합", description = "HD_계약_열쇠인수 병합")
	int mergeHdReferKey01(kait.hd.refer.onl.dao.dto.DHDReferKey01IO dHDReferKey01IO);

	/**
	 * HD_계약_열쇠인수 삭제
	 * @TestValues 	deptCode=; housetag=; buildno=; houseno=; rentYn=; keyDate=; keyCnt=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; 
	 */
	@BxmCategory(logicalName = "HD_계약_열쇠인수 삭제", description = "HD_계약_열쇠인수 삭제")
	int deleteHdReferKey01(kait.hd.refer.onl.dao.dto.DHDReferKey01IO dHDReferKey01IO);


}
