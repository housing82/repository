/**
 * Generated Code Skeleton 2017-06-13 18:26:40 
 */
package kait.hd.slip.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/hd/slip/onl/daoDHDSlipParent01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "HD_분양_회계전표_목차", description = "HD_분양_회계전표_목차")
public interface DHDSlipParent01
{
	/**
	 * HD_분양_회계전표_목차 등록
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 등록", description = "HD_분양_회계전표_목차 등록")
	int insertHdSlipParent01(kait.hd.slip.onl.dao.dto.DHDSlipParent01IO dHDSlipParent01IO);

	/**
	 * HD_분양_회계전표_목차 단건조회
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 단건조회", description = "HD_분양_회계전표_목차 단건조회")
	kait.hd.slip.onl.dao.dto.DHDSlipParent01IO selectHdSlipParent01(kait.hd.slip.onl.dao.dto.DHDSlipParent01IO dHDSlipParent01IO);

	/**
	 * HD_분양_회계전표_목차 전채건수조회
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 전채건수조회", description = "HD_분양_회계전표_목차 전채건수조회")
	java.lang.Integer selectCountHdSlipParent01(kait.hd.slip.onl.dao.dto.DHDSlipParent01IO dHDSlipParent01IO);

	/**
	 * HD_분양_회계전표_목차 목록조회
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 목록조회", description = "HD_분양_회계전표_목차 목록조회")
	java.util.List<kait.hd.slip.onl.dao.dto.DHDSlipParent01IO> selectListHdSlipParent01(
			@Param("in") kait.hd.slip.onl.dao.dto.DHDSlipParent01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * HD_분양_회계전표_목차 수정
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 수정", description = "HD_분양_회계전표_목차 수정")
	int updateHdSlipParent01(kait.hd.slip.onl.dao.dto.DHDSlipParent01IO dHDSlipParent01IO);

	/**
	 * HD_분양_회계전표_목차 병합
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 병합", description = "HD_분양_회계전표_목차 병합")
	int mergeHdSlipParent01(kait.hd.slip.onl.dao.dto.DHDSlipParent01IO dHDSlipParent01IO);

	/**
	 * HD_분양_회계전표_목차 삭제
	 * @TestValues 	slipdate=; slipseq=; cashtag=; makedate=; makecomp=; makedept=; makeseq=; empno=; editemp=; editdate=; company=; edtcompany=; cashsumtag=; printSeq=; cancelTag=; 
	 */
	@BxmCategory(logicalName = "HD_분양_회계전표_목차 삭제", description = "HD_분양_회계전표_목차 삭제")
	int deleteHdSlipParent01(kait.hd.slip.onl.dao.dto.DHDSlipParent01IO dHDSlipParent01IO);


}
