/**
 * Generated Code Skeleton 2017-06-13 18:26:41 
 */
package kait.sm.code.onl.dao;

import bxm.container.annotation.BxmDataAccess;
import bxm.common.annotaion.BxmCategory;
import org.apache.ibatis.annotations.Param;

@SuppressWarnings({ "all" })
@BxmDataAccess(mapper = "kait/sm/code/onl/daoDSMCodeCust01.dbio", datasource = "MainDS")
@BxmCategory(logicalName = "SM_CODE_CUST", description = "SM_CODE_CUST")
public interface DSMCodeCust01
{
	/**
	 * SM_CODE_CUST 등록
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 등록", description = "SM_CODE_CUST 등록")
	int insertSmCodeCust01(kait.sm.code.onl.dao.dto.DSMCodeCust01IO dSMCodeCust01IO);

	/**
	 * SM_CODE_CUST 단건조회
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 단건조회", description = "SM_CODE_CUST 단건조회")
	kait.sm.code.onl.dao.dto.DSMCodeCust01IO selectSmCodeCust01(kait.sm.code.onl.dao.dto.DSMCodeCust01IO dSMCodeCust01IO);

	/**
	 * SM_CODE_CUST 전채건수조회
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 전채건수조회", description = "SM_CODE_CUST 전채건수조회")
	java.lang.Integer selectCountSmCodeCust01(kait.sm.code.onl.dao.dto.DSMCodeCust01IO dSMCodeCust01IO);

	/**
	 * SM_CODE_CUST 목록조회
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 목록조회", description = "SM_CODE_CUST 목록조회")
	java.util.List<kait.sm.code.onl.dao.dto.DSMCodeCust01IO> selectListSmCodeCust01(
			@Param("in") kait.sm.code.onl.dao.dto.DSMCodeCust01IO in, @Param("pageNum") int pageNum,
			@Param("pageCount") int pageCount);

	/**
	 * SM_CODE_CUST 수정
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 수정", description = "SM_CODE_CUST 수정")
	int updateSmCodeCust01(kait.sm.code.onl.dao.dto.DSMCodeCust01IO dSMCodeCust01IO);

	/**
	 * SM_CODE_CUST 병합
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 병합", description = "SM_CODE_CUST 병합")
	int mergeSmCodeCust01(kait.sm.code.onl.dao.dto.DSMCodeCust01IO dSMCodeCust01IO);

	/**
	 * SM_CODE_CUST 삭제
	 * @TestValues 	custCode=; approveYn=; useYn=; custDiv=; bankDiv=; custName=; custAbbr=; custEng=; custLegalNo=; representName=; representRrn=; bizStatus=; bizType=; phone=; cellno=; fax=; zipCode=; addr1=; addr2=; compPhone=; infoYn=; sendZipCode=; sendAddr1=; sendAddr2=; sendReceiptname=; sendEmail=; bankCode=; depositNo=; depositOwner=; agentName=; agentRrn=; agentPhone=; agentCellno=; agentFax=; agentZipCode=; agentAddr1=; agentAddr2=; agentEmail=; foreignTag=; foreignNation=; companyCode=; projCode=; incomeDiv=; custGroupCode=; amYn=; tmYn=; hdYn=; mmYn=; hdPassword=; inputDutyId=; inputDate=; chgDutyId=; chgDate=; fileName=; custDiv2=; zipCodeOrg=; addr1Org=; addr2Org=; addrTag=; agentZipCodeOrg=; agentAddr1Org=; agentAddr2Org=; agentAddrTag=; sendZipCodeOrg=; sendAddr1Org=; sendAddr2Org=; sendAddrTag=; custCode2=; specialCustYn=; 
	 */
	@BxmCategory(logicalName = "SM_CODE_CUST 삭제", description = "SM_CODE_CUST 삭제")
	int deleteSmCodeCust01(kait.sm.code.onl.dao.dto.DSMCodeCust01IO dSMCodeCust01IO);


}
